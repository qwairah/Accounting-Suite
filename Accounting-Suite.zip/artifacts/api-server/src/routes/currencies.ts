import { Router } from "express";
import { db } from "@workspace/db";
import { currenciesTable } from "@workspace/db";
import { eq } from "drizzle-orm";

const router = Router();

const toCurrency = (c: typeof currenciesTable.$inferSelect) => ({
  ...c,
  exchangeRate: parseFloat(c.exchangeRate ?? "1"),
  accountLimit: c.accountLimit ? parseFloat(c.accountLimit) : null,
});

router.get("/", async (req, res): Promise<void> => {
  const currencies = await db.select().from(currenciesTable);
  res.json(currencies.map(toCurrency));
});

router.post("/", async (req, res): Promise<void> => {
  const body = req.body;
  const [currency] = await db.insert(currenciesTable).values({
    code: body.code,
    nameAr: body.nameAr,
    symbol: body.symbol,
    exchangeRate: String(body.exchangeRate ?? 1),
    isBase: body.isBase ?? false,
    accountLimit: body.accountLimit != null ? String(body.accountLimit) : null,
  }).returning();
  res.status(201).json(toCurrency(currency));
});

router.put("/:id", async (req, res): Promise<void> => {
  const id = parseInt(String(req.params.id));
  if (isNaN(id)) { res.status(400).json({ error: "Invalid id" }); return; }
  const body = req.body;
  const [currency] = await db.update(currenciesTable).set({
    code: body.code,
    nameAr: body.nameAr,
    symbol: body.symbol,
    exchangeRate: body.exchangeRate != null ? String(body.exchangeRate) : undefined,
    accountLimit: body.accountLimit != null ? String(body.accountLimit) : undefined,
  }).where(eq(currenciesTable.id, id)).returning();
  if (!currency) { res.status(404).json({ error: "Not found" }); return; }
  res.json(toCurrency(currency));
});

router.delete("/:id", async (req, res): Promise<void> => {
  const id = parseInt(String(req.params.id));
  if (isNaN(id)) { res.status(400).json({ error: "Invalid id" }); return; }
  const [existing] = await db.select().from(currenciesTable).where(eq(currenciesTable.id, id));
  if (!existing) { res.status(404).json({ error: "Not found" }); return; }
  if (existing.isBase) {
    res.status(400).json({ error: "لا يمكن حذف العملة الأساسية" }); return;
  }
  await db.delete(currenciesTable).where(eq(currenciesTable.id, id));
  res.json({ ok: true });
});

export default router;
