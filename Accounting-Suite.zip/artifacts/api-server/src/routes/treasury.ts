import { Router } from "express";
import { db } from "@workspace/db";
import { treasuriesTable, treasuryTransactionsTable } from "@workspace/db";
import { eq, desc, sql } from "drizzle-orm";

const router = Router();

const toTx = (t: typeof treasuryTransactionsTable.$inferSelect) => ({
  ...t,
  voucherNumber: t.transactionNumber,
  amount: parseFloat(t.amount ?? "0"),
});

router.get("/", async (req, res): Promise<void> => {
  const { type } = req.query;
  const txs = await db.select().from(treasuryTransactionsTable).orderBy(desc(treasuryTransactionsTable.createdAt));
  const filtered = type ? txs.filter(t => t.type === type) : txs;
  res.json(filtered.map(toTx));
});

router.post("/", async (req, res): Promise<void> => {
  const body = req.body;
  const amount = parseFloat(body.amount);
  
  const [treasury] = await db.select().from(treasuriesTable).where(eq(treasuriesTable.id, body.treasuryId));
  if (treasury) {
    const currentBalance = parseFloat(treasury.balance ?? "0");
    const newBalance = body.type === "receipt" ? currentBalance + amount : currentBalance - amount;
    await db.update(treasuriesTable).set({ balance: String(newBalance) }).where(eq(treasuriesTable.id, treasury.id));
  }
  
  const [{ cnt }] = await db.select({ cnt: sql<number>`count(*)` }).from(treasuryTransactionsTable);
  const voucherNum = String(Number(cnt) + 1);
  const [tx] = await db.insert(treasuryTransactionsTable).values({
    transactionNumber: voucherNum,
    type: body.type,
    date: body.date,
    accountId: body.accountId ?? null,
    accountNameAr: body.accountNameAr ?? null,
    amount: String(amount),
    currencyId: body.currencyId ?? null,
    description: body.description ?? null,
    treasuryId: body.treasuryId,
  }).returning();
  
  res.status(201).json(toTx(tx));
});

router.get("/summary", async (req, res): Promise<void> => {
  const treasuries = await db.select().from(treasuriesTable);
  const txs = await db.select().from(treasuryTransactionsTable);
  
  const totalReceipts = txs.filter(t => t.type === "receipt").reduce((sum, t) => sum + parseFloat(t.amount ?? "0"), 0);
  const totalPayments = txs.filter(t => t.type === "payment").reduce((sum, t) => sum + parseFloat(t.amount ?? "0"), 0);
  const totalBalance = treasuries.reduce((sum, t) => sum + parseFloat(t.balance ?? "0"), 0);
  const totalReceive = txs.filter(t => t.type === "receive").reduce((sum, t) => sum + parseFloat(t.amount ?? "0"), 0);
  const totalPay = txs.filter(t => t.type === "pay").reduce((sum, t) => sum + parseFloat(t.amount ?? "0"), 0);
  
  res.json({
    totalBalance,
    totalReceipts: totalReceipts + totalReceive,
    totalPayments: totalPayments + totalPay,
    totalReceive: totalReceipts + totalReceive,
    totalPay: totalPayments + totalPay,
    treasuries: treasuries.map(t => ({
      id: t.id,
      nameAr: t.nameAr,
      balance: parseFloat(t.balance ?? "0"),
    })),
  });
});

router.get("/:id", async (req, res): Promise<void> => {
  const id = parseInt(String(req.params.id));
  if (isNaN(id)) { res.status(400).json({ error: "Invalid id" }); return; }
  const [tx] = await db.select().from(treasuryTransactionsTable).where(eq(treasuryTransactionsTable.id, id));
  if (!tx) { res.status(404).json({ error: "Not found" }); return; }
  res.json(toTx(tx));
});

router.put("/:id", async (req, res): Promise<void> => {
  const id = parseInt(String(req.params.id));
  if (isNaN(id)) { res.status(400).json({ error: "Invalid id" }); return; }
  const body = req.body;
  const updates: any = {};
  if (body.type !== undefined) updates.type = body.type;
  if (body.date !== undefined) updates.date = body.date;
  if (body.amount !== undefined) updates.amount = String(parseFloat(body.amount));
  if (body.accountId !== undefined) updates.accountId = body.accountId;
  if (body.accountNameAr !== undefined) updates.accountNameAr = body.accountNameAr;
  if (body.description !== undefined) updates.description = body.description;
  if (body.currencyId !== undefined) updates.currencyId = body.currencyId;
  const [tx] = await db.update(treasuryTransactionsTable).set(updates).where(eq(treasuryTransactionsTable.id, id)).returning();
  if (!tx) { res.status(404).json({ error: "Not found" }); return; }
  res.json(toTx(tx));
});

router.delete("/:id", async (req, res): Promise<void> => {
  const id = parseInt(String(req.params.id));
  if (isNaN(id)) { res.status(400).json({ error: "Invalid id" }); return; }
  await db.delete(treasuryTransactionsTable).where(eq(treasuryTransactionsTable.id, id));
  res.json({ success: true });
});

export default router;
