import { Router } from "express";
import { db } from "@workspace/db";
import { purchaseInvoicesTable, itemsTable, suppliersTable } from "@workspace/db";
import { eq, desc, sql } from "drizzle-orm";

const router = Router();

const toPurchase = (p: typeof purchaseInvoicesTable.$inferSelect) => ({
  ...p,
  subtotal: parseFloat(p.subtotal ?? "0"),
  discount: parseFloat(p.discount ?? "0"),
  taxAmount: parseFloat(p.taxAmount ?? "0"),
  total: parseFloat(p.total ?? "0"),
  paidAmount: parseFloat(p.paidAmount ?? "0"),
  items: Array.isArray(p.items) ? p.items : [],
});

router.get("/", async (req, res): Promise<void> => {
  const purchases = await db.select().from(purchaseInvoicesTable).orderBy(desc(purchaseInvoicesTable.createdAt));
  res.json(purchases.map(toPurchase));
});

router.post("/", async (req, res): Promise<void> => {
  const body = req.body;
  
  let subtotal = 0;
  let taxTotal = 0;
  const processedItems = [];
  
  for (const lineItem of (body.items || [])) {
    const [item] = await db.select().from(itemsTable).where(eq(itemsTable.id, lineItem.itemId));
    const qty = parseFloat(lineItem.quantity);
    const price = parseFloat(lineItem.unitPrice);
    const disc = parseFloat(lineItem.discount ?? "0");
    const taxRate = parseFloat(lineItem.taxRate ?? item?.taxRate ?? "0");
    const lineTotal = qty * price - disc;
    const lineTax = lineTotal * (taxRate / 100);
    subtotal += lineTotal;
    taxTotal += lineTax;
    processedItems.push({
      itemId: lineItem.itemId,
      itemCode: item?.code ?? "",
      itemNameAr: item?.nameAr ?? "",
      quantity: qty,
      unit: item?.unit ?? "قطعة",
      unitPrice: price,
      discount: disc,
      taxRate,
      total: lineTotal + lineTax,
    });
    
    if (item) {
      const newQty = parseFloat(item.stockQuantity ?? "0") + qty;
      await db.update(itemsTable).set({ stockQuantity: String(newQty), costPrice: String(price) }).where(eq(itemsTable.id, item.id));
    }
  }
  
  const globalDiscount = parseFloat(body.discount ?? "0");
  const total = subtotal - globalDiscount + taxTotal;
  
  let supplierName = body.supplierName;
  if (body.supplierId && !supplierName) {
    const [supplier] = await db.select().from(suppliersTable).where(eq(suppliersTable.id, body.supplierId));
    supplierName = supplier?.nameAr;
  }
  
  const [{ cnt }] = await db.select({ cnt: sql<number>`count(*)` }).from(purchaseInvoicesTable);
  const invoiceNumber = String(Number(cnt) + 1);
  
  const [purchase] = await db.insert(purchaseInvoicesTable).values({
    invoiceNumber,
    supplierId: body.supplierId ?? null,
    supplierName: supplierName ?? null,
    date: body.date,
    status: "posted",
    items: processedItems as any,
    subtotal: String(subtotal),
    discount: String(globalDiscount),
    taxAmount: String(taxTotal),
    total: String(total),
    paidAmount: String(body.paidAmount ?? 0),
    notes: body.notes ?? null,
  }).returning();
  
  res.status(201).json(toPurchase(purchase));
});

router.get("/:id", async (req, res): Promise<void> => {
  const id = parseInt(String(req.params.id));
  if (isNaN(id)) { res.status(400).json({ error: "Invalid id" }); return; }
  const [purchase] = await db.select().from(purchaseInvoicesTable).where(eq(purchaseInvoicesTable.id, id));
  if (!purchase) { res.status(404).json({ error: "Not found" }); return; }
  res.json(toPurchase(purchase));
});

router.put("/:id", async (req, res): Promise<void> => {
  const id = parseInt(String(req.params.id));
  if (isNaN(id)) { res.status(400).json({ error: "Invalid id" }); return; }
  const body = req.body;
  const [purchase] = await db.update(purchaseInvoicesTable).set({
    status: body.status,
    paidAmount: body.paidAmount != null ? String(body.paidAmount) : undefined,
    notes: body.notes,
  }).where(eq(purchaseInvoicesTable.id, id)).returning();
  if (!purchase) { res.status(404).json({ error: "Not found" }); return; }
  res.json(toPurchase(purchase));
});

router.delete("/:id", async (req, res): Promise<void> => {
  const id = parseInt(String(req.params.id));
  if (isNaN(id)) { res.status(400).json({ error: "Invalid id" }); return; }
  await db.delete(purchaseInvoicesTable).where(eq(purchaseInvoicesTable.id, id));
  res.json({ success: true });
});

export default router;
