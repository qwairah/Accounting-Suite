import { Router } from "express";
import { db } from "@workspace/db";
import { suppliersTable } from "@workspace/db";
import { eq } from "drizzle-orm";

const router = Router();

router.get("/", async (req, res): Promise<void> => {
  const suppliers = await db.select().from(suppliersTable).orderBy(suppliersTable.code);
  res.json(suppliers.map(s => ({
    ...s,
    balance: parseFloat(s.openingBalance ?? "0"),
    openingBalance: undefined,
  })));
});

router.post("/", async (req, res): Promise<void> => {
  const body = req.body;
  const [supplier] = await db.insert(suppliersTable).values({
    code: body.code || `SUP-${Date.now()}`,
    nameAr: body.nameAr,
    phone: body.phone,
    address: body.address,
    openingBalance: String(body.openingBalance ?? 0),
  }).returning();
  res.status(201).json({ ...supplier, balance: parseFloat(supplier.openingBalance ?? "0") });
});

router.get("/:id", async (req, res): Promise<void> => {
  const id = parseInt(String(req.params.id));
  if (isNaN(id)) { res.status(400).json({ error: "Invalid id" }); return; }
  const [supplier] = await db.select().from(suppliersTable).where(eq(suppliersTable.id, id));
  if (!supplier) { res.status(404).json({ error: "Not found" }); return; }
  res.json({ ...supplier, balance: parseFloat(supplier.openingBalance ?? "0") });
});

router.put("/:id", async (req, res): Promise<void> => {
  const id = parseInt(String(req.params.id));
  if (isNaN(id)) { res.status(400).json({ error: "Invalid id" }); return; }
  const body = req.body;
  const [supplier] = await db.update(suppliersTable).set({
    code: body.code,
    nameAr: body.nameAr,
    phone: body.phone,
    address: body.address,
    openingBalance: body.openingBalance != null ? String(body.openingBalance) : undefined,
  }).where(eq(suppliersTable.id, id)).returning();
  if (!supplier) { res.status(404).json({ error: "Not found" }); return; }
  res.json({ ...supplier, balance: parseFloat(supplier.openingBalance ?? "0") });
});

router.delete("/:id", async (req, res): Promise<void> => {
  const id = parseInt(String(req.params.id));
  if (isNaN(id)) { res.status(400).json({ error: "Invalid id" }); return; }
  await db.delete(suppliersTable).where(eq(suppliersTable.id, id));
  res.json({ success: true });
});

export default router;
