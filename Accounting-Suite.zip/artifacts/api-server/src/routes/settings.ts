import { Router } from "express";
import { db } from "@workspace/db";
import { settingsTable } from "@workspace/db";
import { eq } from "drizzle-orm";

const router = Router();

const toSettings = (s: typeof settingsTable.$inferSelect) => ({
  ...s,
  taxRate: parseFloat(s.taxRate ?? "15"),
});

router.get("/", async (req, res): Promise<void> => {
  let [settings] = await db.select().from(settingsTable);
  if (!settings) {
    [settings] = await db.insert(settingsTable).values({
      companyName: "قويرة سوفت",
      companyNameEn: "Qawera Soft",
      address: "",
      phone: "",
      taxNumber: "",
      printCopies: 1,
      showLogo: true,
      taxRate: "15",
      baseCurrency: "SAR",
    }).returning();
  }
  res.json(toSettings(settings));
});

router.put("/", async (req, res): Promise<void> => {
  const body = req.body;
  let [existing] = await db.select().from(settingsTable);
  
  if (!existing) {
    [existing] = await db.insert(settingsTable).values({
      companyName: body.companyName ?? "قويرة سوفت",
      companyNameEn: body.companyNameEn ?? "Qawera Soft",
      address: body.address ?? "",
      phone: body.phone ?? "",
      taxNumber: body.taxNumber ?? "",
      printCopies: body.printCopies ?? 1,
      showLogo: body.showLogo ?? true,
      taxRate: String(body.taxRate ?? 15),
      baseCurrency: body.baseCurrency ?? "SAR",
      renewalDate: body.renewalDate ?? null,
    }).returning();
    res.json(toSettings(existing));
    return;
  }
  
  const [settings] = await db.update(settingsTable).set({
    companyName: body.companyName,
    companyNameEn: body.companyNameEn,
    address: body.address,
    phone: body.phone,
    taxNumber: body.taxNumber,
    printCopies: body.printCopies,
    showLogo: body.showLogo,
    taxRate: body.taxRate != null ? String(body.taxRate) : undefined,
    baseCurrency: body.baseCurrency,
    renewalDate: body.renewalDate,
  }).where(eq(settingsTable.id, existing.id)).returning();
  
  res.json(toSettings(settings));
});

export default router;
