import { Router, type IRouter } from "express";
import healthRouter from "./health";
import accountsRouter from "./accounts";
import customersRouter from "./customers";
import suppliersRouter from "./suppliers";
import itemsRouter from "./items";
import currenciesRouter from "./currencies";
import salesRouter from "./sales";
import purchasesRouter from "./purchases";
import journalRouter from "./journal";
import treasuryRouter from "./treasury";
import inventoryRouter from "./inventory";
import reportsRouter from "./reports";
import settingsRouter from "./settings";
import exchangeRouter from "./exchange";
import backupRouter from "./backup";

const router: IRouter = Router();

router.use(healthRouter);
router.use("/accounts", accountsRouter);
router.use("/customers", customersRouter);
router.use("/suppliers", suppliersRouter);
router.use("/items", itemsRouter);
router.use("/currencies", currenciesRouter);
router.use("/sales", salesRouter);
router.use("/purchases", purchasesRouter);
router.use("/journal", journalRouter);
router.use("/treasury", treasuryRouter);
router.use("/inventory", inventoryRouter);
router.use("/reports", reportsRouter);
router.use("/settings", settingsRouter);
router.use("/exchange", exchangeRouter);
router.use("/backup", backupRouter);

export default router;
