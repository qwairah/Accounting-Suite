import { Router } from "express";
import { db } from "@workspace/db";
import { warehousesTable, inventoryOperationsTable, itemsTable } from "@workspace/db";
import { eq, desc } from "drizzle-orm";

const router = Router();

const toOp = (o: typeof inventoryOperationsTable.$inferSelect) => ({
  ...o,
  items: Array.isArray(o.items) ? o.items : [],
});

// ── المخازن ──────────────────────────────────────────
router.get("/warehouses", async (req, res): Promise<void> => {
  const warehouses = await db.select().from(warehousesTable).orderBy(warehousesTable.id);
  res.json(warehouses);
});

router.post("/warehouses", async (req, res): Promise<void> => {
  const body = req.body;
  if (!body.nameAr?.trim()) { res.status(400).json({ message: "اسم المخزن مطلوب" }); return; }
  const code = body.code?.trim() || `WH-${Date.now()}`;
  const existing = await db.select().from(warehousesTable).where(eq(warehousesTable.code, code));
  if (existing.length > 0) { res.status(409).json({ message: "كود المخزن مستخدم مسبقاً" }); return; }
  const [warehouse] = await db.insert(warehousesTable).values({
    code,
    nameAr: body.nameAr.trim(),
    address: body.address?.trim() ?? null,
    isMain: body.isMain ?? false,
  }).returning();
  res.status(201).json(warehouse);
});

router.delete("/warehouses/:id", async (req, res): Promise<void> => {
  await db.delete(warehousesTable).where(eq(warehousesTable.id, parseInt(req.params.id)));
  res.json({ message: "تم الحذف" });
});

// ── العمليات المخزنية ─────────────────────────────────
router.get("/operations", async (req, res): Promise<void> => {
  const ops = await db.select().from(inventoryOperationsTable).orderBy(desc(inventoryOperationsTable.createdAt));
  res.json(ops.map(toOp));
});

router.delete("/operations/:id", async (req, res): Promise<void> => {
  const [op] = await db.select().from(inventoryOperationsTable).where(eq(inventoryOperationsTable.id, parseInt(req.params.id)));
  if (!op) { res.status(404).json({ message: "العملية غير موجودة" }); return; }
  const opItems = Array.isArray(op.items) ? op.items as any[] : [];
  for (const opItem of opItems) {
    const [item] = await db.select().from(itemsTable).where(eq(itemsTable.id, opItem.itemId));
    if (item) {
      const qty = parseFloat(item.stockQuantity ?? "0");
      let newQty = qty;
      if (op.type === "in" || op.type === "transfer") newQty = qty - parseFloat(opItem.quantity);
      else if (op.type === "out") newQty = qty + parseFloat(opItem.quantity);
      else if (op.type === "adjust") {
        const adjType = op.adjustType;
        if (adjType === "opening" || adjType === "increase") newQty = qty - parseFloat(opItem.quantity);
        else if (adjType === "deficit" || adjType === "damaged") newQty = qty + parseFloat(opItem.quantity);
      }
      await db.update(itemsTable).set({ stockQuantity: String(Math.max(0, newQty)) }).where(eq(itemsTable.id, item.id));
    }
  }
  await db.delete(inventoryOperationsTable).where(eq(inventoryOperationsTable.id, parseInt(req.params.id)));
  res.json({ message: "تم الحذف مع عكس أثر العملية على المخزون" });
});

router.post("/operations", async (req, res): Promise<void> => {
  const body = req.body;
  const opItems: any[] = body.items || [];

  if (!["in", "out", "transfer", "adjust", "count"].includes(body.type)) {
    res.status(400).json({ message: "نوع العملية غير صحيح" });
    return;
  }
  if (body.type !== "count" && opItems.length === 0) {
    res.status(400).json({ message: "أضف صنفاً على الأقل" });
    return;
  }
  if (body.type === "transfer" && !body.toWarehouseId) {
    res.status(400).json({ message: "حدد مخزن الوجهة للتحويل" });
    return;
  }
  if (body.type === "adjust" && !body.adjustType) {
    res.status(400).json({ message: "حدد نوع التسوية" });
    return;
  }

  for (const opItem of opItems) {
    if (!opItem.itemId || opItem.itemId <= 0) continue;
    const [item] = await db.select().from(itemsTable).where(eq(itemsTable.id, parseInt(opItem.itemId)));
    if (!item) continue;
    const currentQty = parseFloat(item.stockQuantity ?? "0");
    let newQty = currentQty;

    if (body.type === "in") {
      newQty = currentQty + parseFloat(opItem.quantity);
    } else if (body.type === "out") {
      newQty = currentQty - parseFloat(opItem.quantity);
    } else if (body.type === "transfer") {
      newQty = currentQty - parseFloat(opItem.quantity);
    } else if (body.type === "adjust") {
      const adjType = body.adjustType;
      if (adjType === "opening") {
        newQty = parseFloat(opItem.quantity);
      } else if (adjType === "increase") {
        newQty = currentQty + parseFloat(opItem.quantity);
      } else if (adjType === "deficit") {
        newQty = currentQty - parseFloat(opItem.quantity);
      } else if (adjType === "damaged") {
        newQty = currentQty - parseFloat(opItem.quantity);
      }
    } else if (body.type === "count") {
      newQty = parseFloat(opItem.quantity);
    }

    await db.update(itemsTable)
      .set({ stockQuantity: String(Math.max(0, newQty)), ...(body.type === "in" && opItem.unitCost > 0 ? { costPrice: String(opItem.unitCost) } : {}) })
      .where(eq(itemsTable.id, item.id));
  }

  const [op] = await db.insert(inventoryOperationsTable).values({
    operationNumber: `INV-${Date.now()}`,
    type: body.type,
    adjustType: body.adjustType ?? null,
    date: body.date,
    warehouseId: parseInt(body.warehouseId) || 1,
    toWarehouseId: body.toWarehouseId ? parseInt(body.toWarehouseId) : null,
    items: opItems as any,
    notes: body.notes ?? null,
  }).returning();

  res.status(201).json(toOp(op));
});

// ملخص المخزون
router.get("/stock-summary", async (req, res): Promise<void> => {
  const items = await db.select().from(itemsTable);
  const summary = items.map(i => ({
    itemId: i.id,
    itemName: i.nameAr,
    quantity: parseFloat(i.stockQuantity ?? "0"),
    unit: i.unit ?? "وحدة",
    costPrice: parseFloat(i.costPrice ?? "0"),
    totalValue: parseFloat(i.stockQuantity ?? "0") * parseFloat(i.costPrice ?? "0"),
  })).filter(s => s.quantity > 0);
  res.json(summary);
});

export default router;
