import { Router } from "express";
import { db } from "@workspace/db";
import { salesInvoicesTable, itemsTable, customersTable } from "@workspace/db";
import { eq, desc, gte, lte, and, sql } from "drizzle-orm";

const router = Router();

const toSale = (s: typeof salesInvoicesTable.$inferSelect) => ({
  ...s,
  subtotal: parseFloat(s.subtotal ?? "0"),
  discount: parseFloat(s.discount ?? "0"),
  taxAmount: parseFloat(s.taxAmount ?? "0"),
  total: parseFloat(s.total ?? "0"),
  paidAmount: parseFloat(s.paidAmount ?? "0"),
  items: Array.isArray(s.items) ? s.items : [],
});

router.get("/stats", async (req, res): Promise<void> => {
  const sales = await db.select().from(salesInvoicesTable);
  const totalSales = sales.reduce((sum, s) => sum + parseFloat(s.total ?? "0"), 0);
  const totalReceived = sales.reduce((sum, s) => sum + parseFloat(s.paidAmount ?? "0"), 0);
  const paidCount = sales.filter(s => s.status === "paid").length;
  const monthlySales: { month: string; amount: number }[] = [];
  res.json({
    totalSales,
    totalInvoices: sales.length,
    paidInvoices: paidCount,
    unpaidInvoices: sales.length - paidCount,
    totalReceived,
    totalOutstanding: totalSales - totalReceived,
    monthlySales,
  });
});

router.get("/", async (req, res): Promise<void> => {
  const sales = await db.select().from(salesInvoicesTable).orderBy(desc(salesInvoicesTable.createdAt));
  res.json(sales.map(toSale));
});

router.post("/", async (req, res): Promise<void> => {
  const body = req.body;
  
  let subtotal = 0;
  let taxTotal = 0;
  const processedItems = [];
  
  for (const lineItem of (body.items || [])) {
    const [item] = await db.select().from(itemsTable).where(eq(itemsTable.id, lineItem.itemId));
    const qty = parseFloat(lineItem.quantity);
    const price = parseFloat(lineItem.unitPrice);
    const disc = parseFloat(lineItem.discount ?? "0");
    const taxRate = parseFloat(lineItem.taxRate ?? item?.taxRate ?? "0");
    const lineTotal = qty * price - disc;
    const lineTax = lineTotal * (taxRate / 100);
    subtotal += lineTotal;
    taxTotal += lineTax;
    processedItems.push({
      itemId: lineItem.itemId,
      itemCode: item?.code ?? "",
      itemNameAr: item?.nameAr ?? "",
      quantity: qty,
      unit: item?.unit ?? "قطعة",
      unitPrice: price,
      discount: disc,
      taxRate,
      total: lineTotal + lineTax,
    });
    
    if (item) {
      const newQty = parseFloat(item.stockQuantity ?? "0") - qty;
      await db.update(itemsTable).set({ stockQuantity: String(newQty) }).where(eq(itemsTable.id, item.id));
    }
  }
  
  const globalDiscount = parseFloat(body.discount ?? "0");
  const total = subtotal - globalDiscount + taxTotal;
  
  let customerName = body.customerName;
  if (body.customerId && !customerName) {
    const [customer] = await db.select().from(customersTable).where(eq(customersTable.id, body.customerId));
    customerName = customer?.nameAr;
  }
  
  const [{ cnt }] = await db.select({ cnt: sql<number>`count(*)` }).from(salesInvoicesTable);
  const invoiceNumber = String(Number(cnt) + 1);
  
  const [sale] = await db.insert(salesInvoicesTable).values({
    invoiceNumber,
    customerId: body.customerId ?? null,
    customerName: customerName ?? null,
    date: body.date,
    dueDate: body.dueDate ?? null,
    status: "posted",
    items: processedItems as any,
    subtotal: String(subtotal),
    discount: String(globalDiscount),
    taxAmount: String(taxTotal),
    total: String(total),
    paidAmount: String(body.paidAmount ?? 0),
    notes: body.notes ?? null,
    currencyId: body.currencyId ?? null,
  }).returning();
  
  res.status(201).json(toSale(sale));
});

router.get("/:id", async (req, res): Promise<void> => {
  const id = parseInt(String(req.params.id));
  if (isNaN(id)) { res.status(400).json({ error: "Invalid id" }); return; }
  const [sale] = await db.select().from(salesInvoicesTable).where(eq(salesInvoicesTable.id, id));
  if (!sale) { res.status(404).json({ error: "Not found" }); return; }
  res.json(toSale(sale));
});

router.put("/:id", async (req, res): Promise<void> => {
  const id = parseInt(String(req.params.id));
  if (isNaN(id)) { res.status(400).json({ error: "Invalid id" }); return; }
  const body = req.body;
  const [sale] = await db.update(salesInvoicesTable).set({
    status: body.status,
    paidAmount: body.paidAmount != null ? String(body.paidAmount) : undefined,
    notes: body.notes,
  }).where(eq(salesInvoicesTable.id, id)).returning();
  if (!sale) { res.status(404).json({ error: "Not found" }); return; }
  res.json(toSale(sale));
});

router.delete("/:id", async (req, res): Promise<void> => {
  const id = parseInt(String(req.params.id));
  if (isNaN(id)) { res.status(400).json({ error: "Invalid id" }); return; }
  await db.delete(salesInvoicesTable).where(eq(salesInvoicesTable.id, id));
  res.json({ success: true });
});

export default router;
