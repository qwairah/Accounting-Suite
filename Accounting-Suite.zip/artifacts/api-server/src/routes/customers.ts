import { Router } from "express";
import { db } from "@workspace/db";
import { customersTable } from "@workspace/db";
import { eq } from "drizzle-orm";

const router = Router();

router.get("/", async (req, res): Promise<void> => {
  const customers = await db.select().from(customersTable).orderBy(customersTable.code);
  res.json(customers.map(c => ({
    ...c,
    balance: parseFloat(c.openingBalance ?? "0"),
    creditLimit: parseFloat(c.creditLimit ?? "0"),
    openingBalance: undefined,
  })));
});

router.post("/", async (req, res): Promise<void> => {
  const body = req.body;
  const [customer] = await db.insert(customersTable).values({
    code: body.code || `CUS-${Date.now()}`,
    nameAr: body.nameAr,
    phone: body.phone,
    address: body.address,
    relatives: body.relatives,
    whatsappNotify: body.whatsappNotify ?? false,
    smsNotify: body.smsNotify ?? false,
    creditLimit: String(body.creditLimit ?? 0),
    openingBalance: String(body.openingBalance ?? 0),
  }).returning();
  res.status(201).json({ ...customer, balance: parseFloat(customer.openingBalance ?? "0"), creditLimit: parseFloat(customer.creditLimit ?? "0") });
});

router.get("/:id", async (req, res): Promise<void> => {
  const id = parseInt(String(req.params.id));
  if (isNaN(id)) { res.status(400).json({ error: "Invalid id" }); return; }
  const [customer] = await db.select().from(customersTable).where(eq(customersTable.id, id));
  if (!customer) { res.status(404).json({ error: "Not found" }); return; }
  res.json({ ...customer, balance: parseFloat(customer.openingBalance ?? "0"), creditLimit: parseFloat(customer.creditLimit ?? "0") });
});

router.put("/:id", async (req, res): Promise<void> => {
  const id = parseInt(String(req.params.id));
  if (isNaN(id)) { res.status(400).json({ error: "Invalid id" }); return; }
  const body = req.body;
  const [customer] = await db.update(customersTable).set({
    code: body.code,
    nameAr: body.nameAr,
    phone: body.phone,
    address: body.address,
    relatives: body.relatives,
    whatsappNotify: body.whatsappNotify,
    smsNotify: body.smsNotify,
    creditLimit: body.creditLimit != null ? String(body.creditLimit) : undefined,
    openingBalance: body.openingBalance != null ? String(body.openingBalance) : undefined,
  }).where(eq(customersTable.id, id)).returning();
  if (!customer) { res.status(404).json({ error: "Not found" }); return; }
  res.json({ ...customer, balance: parseFloat(customer.openingBalance ?? "0"), creditLimit: parseFloat(customer.creditLimit ?? "0") });
});

router.delete("/:id", async (req, res): Promise<void> => {
  const id = parseInt(String(req.params.id));
  if (isNaN(id)) { res.status(400).json({ error: "Invalid id" }); return; }
  await db.delete(customersTable).where(eq(customersTable.id, id));
  res.json({ success: true });
});

export default router;
