import { Router } from "express";
import { db } from "@workspace/db";
import { currenciesTable, journalEntriesTable, journalLinesTable, accountsTable } from "@workspace/db";
import { eq, desc, sql } from "drizzle-orm";

const router = Router();

router.get("/", async (req, res): Promise<void> => {
  try {
    const entries = await db.select().from(journalEntriesTable)
      .where(eq(journalEntriesTable.type, "exchange"))
      .orderBy(desc(journalEntriesTable.id))
      .limit(200);
    res.json(entries);
  } catch (e) {
    res.status(500).json({ error: String(e) });
  }
});

router.post("/", async (req, res): Promise<void> => {
  try {
    const { date, fromCurrencyId, toCurrencyId, fromAmount, toAmount, exchangeRate, description, treasuryAccountId } = req.body;
    const countRes = await db.execute(sql`SELECT count(*) FROM journal_entries WHERE type = 'exchange'`);
    const exNum = String(Number((countRes.rows[0] as any)?.count ?? 0) + 1);
    const [entry] = await db.insert(journalEntriesTable).values({
      entryNumber: exNum,
      date,
      description: description || "مصارفة عملات",
      totalDebit: String(fromAmount),
      totalCredit: String(fromAmount),
      isPosted: true,
      type: "exchange",
    }).returning();
    res.status(201).json({ ...entry, fromAmount, toAmount, exchangeRate });
  } catch (e) {
    res.status(500).json({ error: String(e) });
  }
});

export default router;
