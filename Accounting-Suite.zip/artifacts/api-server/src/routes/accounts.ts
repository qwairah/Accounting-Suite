import { Router } from "express";
import { db } from "@workspace/db";
import { accountsTable } from "@workspace/db";
import { eq, inArray, sql } from "drizzle-orm";

const router = Router();

// ====== دليل الحسابات الموحد (النظام المحاسبي العربي) ======
const MAIN_ACCOUNTS = [
  // ─── 1. الأصول ─────────────────────────────────────────
  { code: "1",     nameAr: "الأصول",               nameEn: "Assets",                  type: "assets",      subType: null,                 subSubType: null,            isMain: true },
  { code: "1.1",   nameAr: "أصول ثابتة",           nameEn: "Fixed Assets",            type: "assets",      subType: "fixed_assets",       subSubType: null,            isMain: true },
  { code: "1.2",   nameAr: "أصول متداولة",         nameEn: "Current Assets",          type: "assets",      subType: "current_assets",     subSubType: null,            isMain: true },
  { code: "1.2.1", nameAr: "الصناديق",             nameEn: "Cash Funds",              type: "assets",      subType: "current_assets",     subSubType: "cash",          isMain: true },
  { code: "1.2.2", nameAr: "البنوك",               nameEn: "Bank Accounts",           type: "assets",      subType: "current_assets",     subSubType: "bank",          isMain: true },
  { code: "1.2.3", nameAr: "العملاء",              nameEn: "Customers",               type: "assets",      subType: "current_assets",     subSubType: "customer",      isMain: true },
  { code: "1.2.4", nameAr: "المخزون",              nameEn: "Inventory",               type: "assets",      subType: "current_assets",     subSubType: "inventory",     isMain: true },
  // ─── 2. الخصوم ─────────────────────────────────────────
  { code: "2",     nameAr: "الخصوم",               nameEn: "Liabilities",             type: "liabilities", subType: null,                 subSubType: null,            isMain: true },
  { code: "2.1",   nameAr: "التزامات ثابتة",       nameEn: "Fixed Liabilities",       type: "liabilities", subType: "fixed_liabilities",  subSubType: null,            isMain: true },
  { code: "2.2",   nameAr: "التزامات متداولة",     nameEn: "Current Liabilities",     type: "liabilities", subType: "current_liabilities", subSubType: null,           isMain: true },
  { code: "2.2.1", nameAr: "الموردون",             nameEn: "Suppliers",               type: "liabilities", subType: "current_liabilities", subSubType: "supplier",     isMain: true },
  { code: "2.2.2", nameAr: "الدائنون",             nameEn: "Creditors",               type: "liabilities", subType: "current_liabilities", subSubType: "creditor",     isMain: true },
  { code: "2.2.3", nameAr: "التزامات أخرى",       nameEn: "Other Liabilities",       type: "liabilities", subType: "current_liabilities", subSubType: "other",        isMain: true },
  { code: "2.3",   nameAr: "حقوق الملكية",        nameEn: "Equity",                  type: "liabilities", subType: "equity",             subSubType: null,            isMain: true },
  { code: "2.3.1", nameAr: "رأس المال",            nameEn: "Capital",                 type: "liabilities", subType: "equity",             subSubType: "capital",       isMain: true },
  { code: "2.3.2", nameAr: "المساهمين",            nameEn: "Shareholders",            type: "liabilities", subType: "equity",             subSubType: "shareholders",  isMain: true },
  { code: "2.3.3", nameAr: "المسحوبات",            nameEn: "Drawings",                type: "liabilities", subType: "equity",             subSubType: "drawings",      isMain: true },
  { code: "2.3.4", nameAr: "الأرباح والخسائر",    nameEn: "Profit & Loss",           type: "liabilities", subType: "equity",             subSubType: "profit_loss",   isMain: true },
  // ─── 3. المصروفات ──────────────────────────────────────
  { code: "3",     nameAr: "المصروفات",                 nameEn: "Expenses",               type: "expenses",    subType: null,              subSubType: null,              isMain: true },
  { code: "3.1",   nameAr: "تكاليف النشاط",             nameEn: "Activity Costs",         type: "expenses",    subType: "activity_costs",  subSubType: null,              isMain: true },
  { code: "3.1.1", nameAr: "المشتريات",                 nameEn: "Purchases",              type: "expenses",    subType: "activity_costs",  subSubType: "purchases",       isMain: true },
  { code: "3.1.2", nameAr: "مردودات المبيعات",          nameEn: "Sales Returns",          type: "expenses",    subType: "activity_costs",  subSubType: "sales_returns",   isMain: true },
  { code: "3.1.3", nameAr: "تكلفة المبيعات",           nameEn: "Cost of Sales",          type: "expenses",    subType: "activity_costs",  subSubType: "cost_of_sales",   isMain: true },
  { code: "3.1.4", nameAr: "الخصم المسموح به",         nameEn: "Discount Allowed",       type: "expenses",    subType: "activity_costs",  subSubType: "discount_allowed",isMain: true },
  { code: "3.1.5", nameAr: "تسوية المخزون",            nameEn: "Inventory Adjustment",   type: "expenses",    subType: "activity_costs",  subSubType: "inv_settle",      isMain: true },
  { code: "3.1.6", nameAr: "الأصناف التالفة",          nameEn: "Damaged Items",          type: "expenses",    subType: "activity_costs",  subSubType: "damaged",         isMain: true },
  { code: "3.2",   nameAr: "مصاريف إدارية وتشغيلية",  nameEn: "Admin & Operating Exp",  type: "expenses",    subType: "admin_expenses",  subSubType: null,              isMain: true },
  // ─── 4. الإيرادات ──────────────────────────────────────
  { code: "4",     nameAr: "الإيرادات",            nameEn: "Revenue",                 type: "revenue",     subType: null,               subSubType: null,             isMain: true },
  { code: "4.1",   nameAr: "إيرادات النشاط",      nameEn: "Activity Revenue",        type: "revenue",     subType: "activity_revenue", subSubType: null,             isMain: true },
  { code: "4.1.1", nameAr: "المبيعات",             nameEn: "Sales",                   type: "revenue",     subType: "activity_revenue", subSubType: "sales",          isMain: true },
  { code: "4.1.2", nameAr: "مردودات المشتريات",   nameEn: "Purchase Returns",        type: "revenue",     subType: "activity_revenue", subSubType: "purch_returns",  isMain: true },
  { code: "4.1.3", nameAr: "الخصم المكتسب",                  nameEn: "Discount Earned",         type: "revenue",     subType: "activity_revenue", subSubType: "disc_earned",    isMain: true },
  { code: "4.1.4", nameAr: "فوارق بيع وشراء العملات",        nameEn: "Currency Exchange Diff",  type: "revenue",     subType: "activity_revenue", subSubType: "currency_diff",  isMain: true },
  { code: "4.2",   nameAr: "إيرادات أخرى",                   nameEn: "Other Revenue",           type: "revenue",     subType: "other_revenue",    subSubType: null,             isMain: true },
];

// ====== الحسابات الفرعية الافتراضية (تظهر في القائمة، isMain: false) ======
const PREDEFINED_SUB_ACCOUNTS = [
  // ─── 1.2.4 المخزون ──────────────────────────────────
  { code: "1.2.4.1", nameAr: "بضاعة أول المدة",                type: "assets",      subType: "current_assets",   subSubType: "inventory",         isMain: false },
  { code: "1.2.4.2", nameAr: "المخزن الرئيسي",                 type: "assets",      subType: "current_assets",   subSubType: "inventory",         isMain: false },
  // ─── 2.3.1 رأس المال ────────────────────────────────
  { code: "2.3.1.1", nameAr: "رأس المال",                       type: "liabilities", subType: "equity",           subSubType: "capital",           isMain: false },
  // ─── 2.3.4 الأرباح والخسائر ─────────────────────────
  { code: "2.3.4.1", nameAr: "ح/الأرباح والخسائر",             type: "liabilities", subType: "equity",           subSubType: "profit_loss",       isMain: false },
  // ─── 3.1.1 المشتريات ────────────────────────────────
  { code: "3.1.1.1", nameAr: "مشتريات نقدي",                   type: "expenses",    subType: "activity_costs",   subSubType: "purchases",         isMain: false },
  { code: "3.1.1.2", nameAr: "مشتريات آجل",                    type: "expenses",    subType: "activity_costs",   subSubType: "purchases",         isMain: false },
  // ─── 3.1.2 مردودات المبيعات ─────────────────────────
  { code: "3.1.2.1", nameAr: "مردودات مبيعات نقدي",            type: "expenses",    subType: "activity_costs",   subSubType: "sales_returns",     isMain: false },
  { code: "3.1.2.2", nameAr: "مردودات مبيعات آجل",             type: "expenses",    subType: "activity_costs",   subSubType: "sales_returns",     isMain: false },
  // ─── 3.1.3 تكلفة المبيعات ───────────────────────────
  { code: "3.1.3.1", nameAr: "تكلفة المبيعات",                 type: "expenses",    subType: "activity_costs",   subSubType: "cost_of_sales",     isMain: false },
  // ─── 3.1.4 الخصم المسموح به ─────────────────────────
  { code: "3.1.4.1", nameAr: "الخصم المسموح به",               type: "expenses",    subType: "activity_costs",   subSubType: "discount_allowed",  isMain: false },
  // ─── 3.1.5 تسوية المخزون ────────────────────────────
  { code: "3.1.5.1", nameAr: "عجز وزيادة المخزون",            type: "expenses",    subType: "activity_costs",   subSubType: "inv_settle",        isMain: false },
  { code: "3.1.5.2", nameAr: "تسوية المخزون - صرف وتوريد",   type: "expenses",    subType: "activity_costs",   subSubType: "inv_settle",        isMain: false },
  // ─── 3.1.6 الأصناف التالفة ──────────────────────────
  { code: "3.1.6.1", nameAr: "الأصناف التالفة",                type: "expenses",    subType: "activity_costs",   subSubType: "damaged",           isMain: false },
  // ─── 4.1.1 المبيعات ─────────────────────────────────
  { code: "4.1.1.1", nameAr: "مبيعات نقدي",                    type: "revenue",     subType: "activity_revenue", subSubType: "sales",             isMain: false },
  { code: "4.1.1.2", nameAr: "مبيعات آجل",                     type: "revenue",     subType: "activity_revenue", subSubType: "sales",             isMain: false },
  // ─── 4.1.2 مردودات المشتريات ────────────────────────
  { code: "4.1.2.1", nameAr: "مردودات مشتريات نقدي",           type: "revenue",     subType: "activity_revenue", subSubType: "purch_returns",     isMain: false },
  { code: "4.1.2.2", nameAr: "مردودات مشتريات آجل",            type: "revenue",     subType: "activity_revenue", subSubType: "purch_returns",     isMain: false },
  // ─── 4.1.3 الخصم المكتسب ────────────────────────────
  { code: "4.1.3.1", nameAr: "الخصم المكتسب",                  type: "revenue",     subType: "activity_revenue", subSubType: "disc_earned",       isMain: false },
  // ─── 4.1.4 فوارق بيع وشراء العملات ─────────────────
  { code: "4.1.4.1", nameAr: "فوارق بيع وشراء العملات",        type: "revenue",     subType: "activity_revenue", subSubType: "currency_diff",     isMain: false },
];

const mapAccount = (a: any) => ({
  ...a,
  openingBalance: parseFloat(a.openingBalance ?? "0"),
  ceiling: parseFloat(a.ceiling ?? "0"),
});

router.get("/", async (req, res): Promise<void> => {
  const accounts = await db.select().from(accountsTable).orderBy(accountsTable.code);
  res.json(accounts.map(mapAccount));
});

router.get("/balances", async (req, res): Promise<void> => {
  const accounts = await db.select().from(accountsTable).orderBy(accountsTable.code);
  res.json(accounts.map(a => ({
    id: a.id, code: a.code, nameAr: a.nameAr, type: a.type,
    balance: parseFloat(a.openingBalance ?? "0"),
    debit: parseFloat(a.openingBalance ?? "0") > 0 ? parseFloat(a.openingBalance ?? "0") : 0,
    credit: parseFloat(a.openingBalance ?? "0") < 0 ? Math.abs(parseFloat(a.openingBalance ?? "0")) : 0,
  })));
});

// ====== تهيئة الحسابات الرئيسية (يُضيف فقط المفقودة) ======
router.post("/init-main", async (req, res): Promise<void> => {
  const existing = await db.select({ code: accountsTable.code }).from(accountsTable);
  const existingCodes = new Set(existing.map(e => e.code));

  const allToInsert = [
    ...MAIN_ACCOUNTS.filter(a => !existingCodes.has(a.code)),
    ...PREDEFINED_SUB_ACCOUNTS.filter(a => !existingCodes.has(a.code)),
  ];
  if (allToInsert.length === 0) {
    res.json({ message: "الحسابات الرئيسية والافتراضية موجودة مسبقاً", created: 0 });
    return;
  }
  const created = await db.insert(accountsTable).values(
    allToInsert.map(a => ({
      code: a.code, nameAr: a.nameAr, nameEn: (a as any).nameEn ?? null,
      type: a.type, subType: a.subType ?? null, subSubType: a.subSubType ?? null,
      isMain: a.isMain, openingBalance: "0", ceiling: "0", enableCeiling: false,
    }))
  ).onConflictDoNothing().returning();
  res.json({ message: `تم إنشاء ${created.length} حساباً (رئيسية وافتراضية)`, created: created.length });
});

// ====== إعادة تهيئة الحسابات الرئيسية (يحذف القديمة ويُعيد البناء) ======
router.post("/reset-main", async (req, res): Promise<void> => {
  const mainAccounts = await db.select({ id: accountsTable.id }).from(accountsTable).where(eq(accountsTable.isMain, true));
  if (mainAccounts.length > 0) {
    const ids = mainAccounts.map(a => a.id);
    await db.delete(accountsTable).where(inArray(accountsTable.id, ids));
  }
  // ترحيل البيانات القديمة — النوع الرئيسي
  await db.execute(sql`UPDATE accounts SET type = 'liabilities' WHERE type IN ('liabilities_equity','equity')`);
  // ترحيل subType القديمة
  await db.execute(sql`UPDATE accounts SET sub_type = 'fixed_assets'      WHERE sub_type = 'fixed'        AND type = 'assets'`);
  await db.execute(sql`UPDATE accounts SET sub_type = 'current_assets'    WHERE sub_type IN ('current','receivable') AND type = 'assets'`);
  await db.execute(sql`UPDATE accounts SET sub_type = 'activity_costs'    WHERE sub_type IN ('activity','cost')   AND type = 'expenses'`);
  await db.execute(sql`UPDATE accounts SET sub_type = 'admin_expenses'    WHERE sub_type = 'operational'  AND type = 'expenses'`);
  await db.execute(sql`UPDATE accounts SET sub_type = 'activity_revenue'  WHERE sub_type IN ('activity_rev','sales_rev') AND type = 'revenue'`);
  await db.execute(sql`UPDATE accounts SET sub_type = 'other_revenue'     WHERE sub_type = 'other_rev'    AND type = 'revenue'`);
  await db.execute(sql`UPDATE accounts SET sub_type = 'fixed_liabilities' WHERE sub_type = 'fixed_liab'   AND type = 'liabilities'`);
  await db.execute(sql`UPDATE accounts SET sub_type = 'current_liabilities' WHERE sub_type IN ('payable','creditor_sub') AND type = 'liabilities'`);
  // ترحيل subSubType القديمة
  await db.execute(sql`UPDATE accounts SET sub_sub_type = 'profit_loss'    WHERE sub_sub_type IN ('profit','pl')`);
  await db.execute(sql`UPDATE accounts SET sub_sub_type = 'cost_of_sales'  WHERE sub_sub_type = 'cost_sales'`);
  await db.execute(sql`UPDATE accounts SET sub_sub_type = 'sales_returns'  WHERE sub_sub_type IN ('sale_returns', 'production')`);
  await db.execute(sql`UPDATE accounts SET sub_sub_type = 'purch_returns'  WHERE sub_sub_type IN ('purch_returns','purchase_returns')`);
  await db.execute(sql`UPDATE accounts SET sub_sub_type = 'disc_earned'    WHERE sub_sub_type = 'discount_earned'`);
  await db.execute(sql`UPDATE accounts SET sub_sub_type = 'supplier'       WHERE sub_sub_type = 'suppliers'`);
  // تعيين subSubType للحسابات القديمة التي لا تملكه
  await db.execute(sql`UPDATE accounts SET sub_sub_type = 'customer' WHERE sub_type = 'current_assets' AND (sub_sub_type IS NULL OR sub_sub_type = '') AND type = 'assets' AND is_main = false`);
  await db.execute(sql`UPDATE accounts SET sub_sub_type = 'supplier' WHERE sub_type = 'current_liabilities' AND (sub_sub_type IS NULL OR sub_sub_type = '') AND type = 'liabilities' AND is_main = false`);

  // حذف الحسابات الرئيسية القديمة بالأكواد التقليدية
  const oldMainCodes = ["1000","1100","1200","1210","1220","1230","1240","2000","2100","2110","2120","2200","2210","3000","3100","3200","4000","4100","4110","4200","4210"];
  await db.delete(accountsTable).where(inArray(accountsTable.code, oldMainCodes));
  const mainRows = MAIN_ACCOUNTS.map(a => ({
    code: a.code, nameAr: a.nameAr, nameEn: a.nameEn ?? null,
    type: a.type, subType: a.subType ?? null, subSubType: a.subSubType ?? null,
    isMain: true, openingBalance: "0", ceiling: "0", enableCeiling: false,
  }));
  const createdMain = await db.insert(accountsTable).values(mainRows).onConflictDoNothing().returning();

  // إنشاء الحسابات الفرعية الافتراضية (إذا لم تكن موجودة)
  const subRows = PREDEFINED_SUB_ACCOUNTS.map(a => ({
    code: a.code, nameAr: a.nameAr, nameEn: null,
    type: a.type, subType: a.subType ?? null, subSubType: a.subSubType ?? null,
    isMain: false, openingBalance: "0", ceiling: "0", enableCeiling: false,
  }));
  const createdSub = await db.insert(accountsTable).values(subRows).onConflictDoNothing().returning();

  const total = createdMain.length + createdSub.length;
  res.json({ message: `✅ تم إعادة بناء ${createdMain.length} حساباً رئيسياً و${createdSub.length} حساباً افتراضياً`, created: total });
});

router.post("/", async (req, res): Promise<void> => {
  const body = req.body;
  // ── توليد رقم الحساب التسعة أرقام تلقائياً ──
  let accountCode = body.code;
  if (!accountCode || accountCode.trim() === "") {
    const typePrefix: Record<string, string> = {
      assets: "1", liabilities: "2", expenses: "3", revenue: "4",
    };
    const prefix = typePrefix[body.type] || "9";
    const countRes = await db.execute(
      sql`SELECT count(*) FROM accounts WHERE type = ${body.type} AND is_main = false`
    );
    const seq = Number((countRes.rows[0] as any)?.count ?? 0) + 1;
    accountCode = `${prefix}${String(seq).padStart(8, "0")}`;
  }
  const [account] = await db.insert(accountsTable).values({
    code: accountCode,
    nameAr: body.nameAr,
    nameEn: body.nameEn ?? null,
    type: body.type,
    subType: body.subType ?? null,
    subSubType: body.subSubType ?? null,
    parentId: body.parentId ?? null,
    isMain: body.isMain ?? false,
    phone: body.phone ?? null,
    address: body.address ?? null,
    relatives: body.relatives ?? null,
    whatsappNotify: body.whatsappNotify ?? body.enableWhatsapp ?? false,
    telegramNotify: body.telegramNotify ?? body.enableTelegram ?? false,
    smsNotify: body.smsNotify ?? body.enableSms ?? false,
    openingBalance: String(body.openingBalance ?? 0),
    enableCeiling: body.enableCeiling ?? false,
    ceiling: String(body.ceiling ?? 0),
  }).returning();
  res.status(201).json(mapAccount(account));
});

router.get("/:id", async (req, res): Promise<void> => {
  const id = parseInt(String(req.params.id));
  if (isNaN(id)) { res.status(400).json({ error: "Invalid id" }); return; }
  const [account] = await db.select().from(accountsTable).where(eq(accountsTable.id, id));
  if (!account) { res.status(404).json({ error: "Not found" }); return; }
  res.json(mapAccount(account));
});

router.put("/:id", async (req, res): Promise<void> => {
  const id = parseInt(String(req.params.id));
  if (isNaN(id)) { res.status(400).json({ error: "Invalid id" }); return; }
  const body = req.body;
  const [updated] = await db.update(accountsTable).set({
    nameAr: body.nameAr,
    nameEn: body.nameEn ?? null,
    type: body.type,
    subType: body.subType ?? null,
    subSubType: body.subSubType ?? null,
    phone: body.phone ?? null,
    address: body.address ?? null,
    relatives: body.relatives ?? null,
    whatsappNotify: body.whatsappNotify ?? body.enableWhatsapp ?? false,
    telegramNotify: body.telegramNotify ?? body.enableTelegram ?? false,
    smsNotify: body.smsNotify ?? body.enableSms ?? false,
    openingBalance: String(body.openingBalance ?? 0),
    enableCeiling: body.enableCeiling ?? false,
    ceiling: String(body.ceiling ?? 0),
  }).where(eq(accountsTable.id, id)).returning();
  if (!updated) { res.status(404).json({ error: "Not found" }); return; }
  res.json(mapAccount(updated));
});

router.delete("/:id", async (req, res): Promise<void> => {
  const id = parseInt(String(req.params.id));
  if (isNaN(id)) { res.status(400).json({ error: "Invalid id" }); return; }
  await db.delete(accountsTable).where(eq(accountsTable.id, id));
  res.json({ success: true });
});

export default router;
