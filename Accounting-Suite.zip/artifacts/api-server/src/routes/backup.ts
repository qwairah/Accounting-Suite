import { Router } from "express";
import { db } from "@workspace/db";
import {
  accountsTable, customersTable, suppliersTable, itemsTable,
  currenciesTable, salesInvoicesTable, purchaseInvoicesTable, journalEntriesTable,
} from "@workspace/db";
import { eq, sql } from "drizzle-orm";

const router = Router();

// POST /api/backup/bulk-post — يُرحّل جميع العمليات غير المرحّلة (draft → posted)
router.post("/bulk-post", async (req, res): Promise<void> => {
  try {
    // عدّ المسودات أولاً
    const srSales = await db.execute(sql`SELECT count(*) FROM sales_invoices WHERE status='draft'`);
    const srPurch = await db.execute(sql`SELECT count(*) FROM purchase_invoices WHERE status='draft'`);
    const srJourn = await db.execute(sql`SELECT count(*) FROM journal_entries WHERE status='draft'`);

    const salesCount = Number((srSales.rows[0] as any)?.count ?? 0);
    const purchCount = Number((srPurch.rows[0] as any)?.count ?? 0);
    const journCount = Number((srJourn.rows[0] as any)?.count ?? 0);

    // تحديث الحالة
    if (salesCount  > 0) await db.update(salesInvoicesTable ).set({ status: "posted" }).where(eq(salesInvoicesTable.status,  "draft"));
    if (purchCount  > 0) await db.update(purchaseInvoicesTable).set({ status: "posted" }).where(eq(purchaseInvoicesTable.status, "draft"));
    if (journCount  > 0) await db.update(journalEntriesTable ).set({ status: "posted" }).where(eq(journalEntriesTable.status,  "draft"));

    const total = salesCount + purchCount + journCount;
    res.json({ ok: true, total, results: { sales: salesCount, purchases: purchCount, journal: journCount } });
  } catch (err: any) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

const uid = () => `${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;

// POST /api/backup/restore — يستعيد النسخة الاحتياطية كاملةً إلى قاعدة البيانات
router.post("/restore", async (req, res): Promise<void> => {
  const body = req.body || {};
  const results: Record<string, number> = {};
  const errors: string[] = [];

  // ── 1. حسابات ─────────────────────────────────────────────────────────────
  const accs: any[] = Array.isArray(body.accounts) ? body.accounts : [];
  if (accs.length > 0) {
    let ok = 0;
    for (const a of accs) {
      if (!a.nameAr) continue;
      try {
        await db.insert(accountsTable).values({
          code: a.code || a.accountNumber || `ACC-${uid()}`,
          nameAr: a.nameAr,
          nameEn: a.nameEn || null,
          type: a.type || "other",
          subType: a.subType || null,
          subSubType: a.subSubType || null,
          openingBalance: String(a.openingBalance ?? 0),
          isMain: a.isMain ?? false,
          phone: a.phone || null,
          address: a.address || null,
        }).onConflictDoNothing();
        ok++;
      } catch (e: any) { errors.push(`account:${a.nameAr}: ${e.message}`); }
    }
    results.accounts = ok;
  }

  // ── 2. عملاء ───────────────────────────────────────────────────────────────
  const custs: any[] = Array.isArray(body.customers) ? body.customers : [];
  if (custs.length > 0) {
    let ok = 0;
    for (const c of custs) {
      if (!c.nameAr) continue;
      try {
        await db.insert(customersTable).values({
          code: c.code || `CUS-${uid()}`,
          nameAr: c.nameAr,
          phone: c.phone || null,
          address: c.address || null,
          openingBalance: String(c.openingBalance ?? c.balance ?? 0),
          creditLimit: String(c.creditLimit ?? 0),
          whatsappNotify: c.whatsappNotify ?? false,
          smsNotify: c.smsNotify ?? false,
        }).onConflictDoNothing();
        ok++;
      } catch (e: any) { errors.push(`customer:${c.nameAr}: ${e.message}`); }
    }
    results.customers = ok;
  }

  // ── 3. موردون ──────────────────────────────────────────────────────────────
  const supps: any[] = Array.isArray(body.suppliers) ? body.suppliers : [];
  if (supps.length > 0) {
    let ok = 0;
    for (const s of supps) {
      if (!s.nameAr) continue;
      try {
        await db.insert(suppliersTable).values({
          code: s.code || `SUP-${uid()}`,
          nameAr: s.nameAr,
          phone: s.phone || null,
          address: s.address || null,
          openingBalance: String(s.openingBalance ?? s.balance ?? 0),
          creditLimit: String(s.creditLimit ?? 0),
          whatsappNotify: s.whatsappNotify ?? false,
          smsNotify: s.smsNotify ?? false,
        }).onConflictDoNothing();
        ok++;
      } catch (e: any) { errors.push(`supplier:${s.nameAr}: ${e.message}`); }
    }
    results.suppliers = ok;
  }

  // ── 4. أصناف ───────────────────────────────────────────────────────────────
  const itms: any[] = Array.isArray(body.items) ? body.items : [];
  if (itms.length > 0) {
    let ok = 0;
    for (const it of itms) {
      if (!it.nameAr) continue;
      try {
        await db.insert(itemsTable).values({
          code: it.code || `ITM-${uid()}`,
          nameAr: it.nameAr,
          nameEn: it.nameEn || null,
          unit: it.unit || "حبة",
          salePrice: String(it.salePrice ?? it.price ?? 0),
          costPrice: String(it.costPrice ?? it.cost ?? 0),
          stockQuantity: String(it.stockQuantity ?? it.stock ?? 0),
          minStock: String(it.minStock ?? it.minStockAlert ?? 0),
          description: it.description || null,
          categoryId: null,
          warehouseId: null,
        }).onConflictDoNothing();
        ok++;
      } catch (e: any) { errors.push(`item:${it.nameAr}: ${e.message}`); }
    }
    results.items = ok;
  }

  // ── 5. عملات ───────────────────────────────────────────────────────────────
  const currs: any[] = Array.isArray(body.currencies) ? body.currencies : [];
  if (currs.length > 0) {
    let ok = 0;
    for (const cur of currs) {
      if ((!cur.nameAr && !cur.code) || cur.isBase) continue; // نتجاهل العملة الأساس
      try {
        await db.insert(currenciesTable).values({
          code: cur.code || "XXX",
          nameAr: cur.nameAr || cur.code,
          symbol: cur.symbol || cur.code,
          exchangeRate: String(cur.rate ?? cur.exchangeRate ?? 1),
          isBase: false,
        }).onConflictDoNothing();
        ok++;
      } catch (e: any) { errors.push(`currency:${cur.nameAr}: ${e.message}`); }
    }
    results.currencies = ok;
  }

  // ── 6. مبيعات ──────────────────────────────────────────────────────────────
  const sls: any[] = Array.isArray(body.sales) ? body.sales : [];
  if (sls.length > 0) {
    let ok = 0;
    for (const s of sls) {
      try {
        await db.insert(salesInvoicesTable).values({
          invoiceNumber: s.invoiceNumber || `INV-${uid()}`,
          customerId: s.customerId || null,
          customerName: s.customerName || null,
          date: s.date || new Date().toISOString().split("T")[0],
          dueDate: s.dueDate || null,
          status: s.status || "posted",
          items: Array.isArray(s.items) ? (s.items as any) : [],
          subtotal: String(s.subtotal ?? s.total ?? 0),
          discount: String(s.discount ?? 0),
          taxAmount: String(s.taxAmount ?? s.tax ?? 0),
          total: String(s.total ?? 0),
          paidAmount: String(s.paidAmount ?? s.paid ?? s.total ?? 0),
          notes: s.notes || null,
          currencyId: s.currencyId || null,
        }).onConflictDoNothing();
        ok++;
      } catch (e: any) { errors.push(`sale: ${e.message}`); }
    }
    results.sales = ok;
  }

  // ── 7. مشتريات ─────────────────────────────────────────────────────────────
  const prcs: any[] = Array.isArray(body.purchases) ? body.purchases : [];
  if (prcs.length > 0) {
    let ok = 0;
    for (const p of prcs) {
      try {
        await db.insert(purchaseInvoicesTable).values({
          invoiceNumber: p.invoiceNumber || `PRC-${uid()}`,
          supplierId: p.supplierId || null,
          supplierName: p.supplierName || null,
          date: p.date || new Date().toISOString().split("T")[0],
          dueDate: p.dueDate || null,
          status: p.status || "posted",
          items: Array.isArray(p.items) ? (p.items as any) : [],
          subtotal: String(p.subtotal ?? p.total ?? 0),
          discount: String(p.discount ?? 0),
          taxAmount: String(p.taxAmount ?? p.tax ?? 0),
          total: String(p.total ?? 0),
          paidAmount: String(p.paidAmount ?? p.paid ?? p.total ?? 0),
          notes: p.notes || null,
          currencyId: p.currencyId || null,
        }).onConflictDoNothing();
        ok++;
      } catch (e: any) { errors.push(`purchase: ${e.message}`); }
    }
    results.purchases = ok;
  }

  // ── 8. قيود يومية ──────────────────────────────────────────────────────────
  const jrns: any[] = Array.isArray(body.journal) ? body.journal : [];
  if (jrns.length > 0) {
    let ok = 0;
    // احسب آخر رقم قيد موجود
    const countRes = await db.execute(sql`SELECT count(*) FROM journal_entries`);
    let lastNum = Number((countRes.rows[0] as any)?.count ?? 0);
    for (const j of jrns) {
      try {
        const lines = Array.isArray(j.lines) ? j.lines : [];
        const totalDebit = lines.length > 0
          ? lines.reduce((s: number, l: any) => s + parseFloat(l.debit ?? "0"), 0)
          : parseFloat(String(j.totalDebit ?? j.debit ?? 0));
        const totalCredit = lines.length > 0
          ? lines.reduce((s: number, l: any) => s + parseFloat(l.credit ?? "0"), 0)
          : parseFloat(String(j.totalCredit ?? j.credit ?? 0));
        lastNum++;
        await db.insert(journalEntriesTable).values({
          entryNumber: j.entryNumber || String(lastNum),
          date: j.date || new Date().toISOString().split("T")[0],
          description: j.description || j.notes || j.details || "",
          lines: lines as any,
          totalDebit: String(totalDebit),
          totalCredit: String(totalCredit),
          status: j.status || "posted",
        }).onConflictDoNothing();
        ok++;
      } catch (e: any) { errors.push(`journal: ${e.message}`); }
    }
    results.journal = ok;
  }

  const total = Object.values(results).reduce((s, n) => s + n, 0);
  res.json({ ok: true, total, results, errors: errors.slice(0, 20) });
});

export default router;
