import { Router } from "express";
import { db } from "@workspace/db";
import {
  accountsTable,
  customersTable,
  suppliersTable,
  itemsTable,
  salesInvoicesTable,
  purchaseInvoicesTable,
  treasuriesTable,
  treasuryTransactionsTable,
} from "@workspace/db";
import { desc } from "drizzle-orm";

const router = Router();

router.get("/trial-balance", async (req, res): Promise<void> => {
  const accounts = await db.select().from(accountsTable).orderBy(accountsTable.code);
  const result = accounts.map(a => {
    const bal = parseFloat(a.openingBalance ?? "0");
    return {
      accountId: a.id,
      accountCode: a.code,
      accountNameAr: a.nameAr,
      accountType: a.type,
      openingDebit: bal > 0 ? bal : 0,
      openingCredit: bal < 0 ? Math.abs(bal) : 0,
      periodDebit: 0,
      periodCredit: 0,
      closingDebit: bal > 0 ? bal : 0,
      closingCredit: bal < 0 ? Math.abs(bal) : 0,
    };
  });
  res.json(result);
});

router.get("/income-statement", async (req, res): Promise<void> => {
  const sales = await db.select().from(salesInvoicesTable);
  const purchases = await db.select().from(purchaseInvoicesTable);
  
  const revenue = sales.reduce((sum, s) => sum + parseFloat(s.total ?? "0"), 0);
  const costOfSales = purchases.reduce((sum, p) => sum + parseFloat(p.total ?? "0"), 0);
  const grossProfit = revenue - costOfSales;
  
  res.json({
    revenue,
    costOfSales,
    grossProfit,
    operatingExpenses: 0,
    netProfit: grossProfit,
    breakdown: [
      { category: "ايرادات المبيعات", amount: revenue },
      { category: "تكلفة المشتريات", amount: -costOfSales },
      { category: "مجمل الربح", amount: grossProfit },
    ],
  });
});

router.get("/balance-sheet", async (req, res): Promise<void> => {
  const accounts = await db.select().from(accountsTable);
  const sales = await db.select().from(salesInvoicesTable);
  const purchases = await db.select().from(purchaseInvoicesTable);
  const treasuries = await db.select().from(treasuriesTable);
  
  const totalSales = sales.reduce((sum, s) => sum + parseFloat(s.total ?? "0"), 0);
  const totalPurchases = purchases.reduce((sum, p) => sum + parseFloat(p.total ?? "0"), 0);
  const cashBalance = treasuries.reduce((sum, t) => sum + parseFloat(t.balance ?? "0"), 0);
  
  const assets = cashBalance + totalSales;
  const liabilities = totalPurchases;
  const equity = assets - liabilities;
  
  res.json({
    assets,
    liabilities,
    equity,
    currentAssets: assets,
    fixedAssets: 0,
    currentLiabilities: liabilities,
    longTermLiabilities: 0,
    breakdown: [
      { category: "النقدية والصناديق", amount: cashBalance, type: "assets" },
      { category: "المدينون", amount: totalSales - sales.reduce((s, inv) => s + parseFloat(inv.paidAmount ?? "0"), 0), type: "assets" },
      { category: "الدائنون", amount: totalPurchases - purchases.reduce((s, inv) => s + parseFloat(inv.paidAmount ?? "0"), 0), type: "liabilities" },
      { category: "حقوق الملكية", amount: equity, type: "equity" },
    ],
  });
});

router.get("/dashboard", async (req, res): Promise<void> => {
  const today = new Date().toISOString().split("T")[0];
  
  const [customers, suppliers, sales, purchases, treasuries] = await Promise.all([
    db.select().from(customersTable),
    db.select().from(suppliersTable),
    db.select().from(salesInvoicesTable).orderBy(desc(salesInvoicesTable.createdAt)),
    db.select().from(purchaseInvoicesTable),
    db.select().from(treasuriesTable),
  ]);
  
  const items = await db.select().from(itemsTable);
  
  const todaySales = sales.filter(s => s.date === today).reduce((sum, s) => sum + parseFloat(s.total ?? "0"), 0);
  const todayPurchases = purchases.filter(p => p.date === today).reduce((sum, p) => sum + parseFloat(p.total ?? "0"), 0);
  const cashBalance = treasuries.reduce((sum, t) => sum + parseFloat(t.balance ?? "0"), 0);
  const totalSales = sales.reduce((sum, s) => sum + parseFloat(s.total ?? "0"), 0);
  const totalReceived = sales.reduce((sum, s) => sum + parseFloat(s.paidAmount ?? "0"), 0);
  const totalPurchases = purchases.reduce((sum, p) => sum + parseFloat(p.total ?? "0"), 0);
  const totalPaid = purchases.reduce((sum, p) => sum + parseFloat(p.paidAmount ?? "0"), 0);
  
  const recentSales = sales.slice(0, 5).map(s => ({
    ...s,
    subtotal: parseFloat(s.subtotal ?? "0"),
    discount: parseFloat(s.discount ?? "0"),
    taxAmount: parseFloat(s.taxAmount ?? "0"),
    total: parseFloat(s.total ?? "0"),
    paidAmount: parseFloat(s.paidAmount ?? "0"),
    items: Array.isArray(s.items) ? s.items : [],
  }));
  
  const lowStockItems = items
    .filter(i => parseFloat(i.stockQuantity ?? "0") < parseFloat(i.minStock ?? "0"))
    .map(i => ({
      itemId: i.id,
      itemCode: i.code,
      itemNameAr: i.nameAr,
      stockQuantity: parseFloat(i.stockQuantity ?? "0"),
      costPrice: parseFloat(i.costPrice ?? "0"),
      totalValue: parseFloat(i.stockQuantity ?? "0") * parseFloat(i.costPrice ?? "0"),
      minStock: parseFloat(i.minStock ?? "0"),
      isBelowMin: true,
    }));
  
  res.json({
    todaySales,
    todayPurchases,
    totalCustomers: customers.length,
    totalSuppliers: suppliers.length,
    cashBalance,
    totalReceivables: totalSales - totalReceived,
    totalPayables: totalPurchases - totalPaid,
    netProfit: totalSales - totalPurchases,
    recentSales,
    lowStockItems,
  });
});

router.get("/item-movements", async (req, res): Promise<void> => {
  res.json([]);
});

export default router;
