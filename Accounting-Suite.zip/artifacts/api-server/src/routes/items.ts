import { Router } from "express";
import { db } from "@workspace/db";
import { itemsTable } from "@workspace/db";
import { eq } from "drizzle-orm";

const router = Router();

const toItem = (i: typeof itemsTable.$inferSelect) => ({
  ...i,
  costPrice: parseFloat(i.costPrice ?? "0"),
  salePrice: parseFloat(i.salePrice ?? "0"),
  stockQuantity: parseFloat(i.stockQuantity ?? "0"),
  minStock: parseFloat(i.minStock ?? "0"),
  taxRate: parseFloat(i.taxRate ?? "0"),
});

router.get("/", async (req, res): Promise<void> => {
  const items = await db.select().from(itemsTable).orderBy(itemsTable.code);
  res.json(items.map(toItem));
});

router.get("/stock-summary", async (req, res): Promise<void> => {
  const items = await db.select().from(itemsTable).orderBy(itemsTable.code);
  const result = items.map(i => ({
    itemId: i.id,
    itemCode: i.code,
    itemNameAr: i.nameAr,
    stockQuantity: parseFloat(i.stockQuantity ?? "0"),
    costPrice: parseFloat(i.costPrice ?? "0"),
    totalValue: parseFloat(i.stockQuantity ?? "0") * parseFloat(i.costPrice ?? "0"),
    minStock: parseFloat(i.minStock ?? "0"),
    isBelowMin: parseFloat(i.stockQuantity ?? "0") < parseFloat(i.minStock ?? "0"),
  }));
  res.json(result);
});

router.post("/", async (req, res): Promise<void> => {
  const body = req.body;
  const [item] = await db.insert(itemsTable).values({
    code: body.code || `ITM-${Date.now()}`,
    nameAr: body.nameAr,
    nameEn: body.nameEn,
    category: body.category,
    unit: body.unit || "قطعة",
    costPrice: String(body.costPrice ?? 0),
    salePrice: String(body.salePrice ?? 0),
    stockQuantity: String(body.openingStock ?? 0),
    minStock: String(body.minStock ?? 0),
    barcode: body.barcode,
    taxRate: String(body.taxRate ?? 0),
  }).returning();
  res.status(201).json(toItem(item));
});

router.get("/:id", async (req, res): Promise<void> => {
  const id = parseInt(String(req.params.id));
  if (isNaN(id)) { res.status(400).json({ error: "Invalid id" }); return; }
  const [item] = await db.select().from(itemsTable).where(eq(itemsTable.id, id));
  if (!item) { res.status(404).json({ error: "Not found" }); return; }
  res.json(toItem(item));
});

router.put("/:id", async (req, res): Promise<void> => {
  const id = parseInt(String(req.params.id));
  if (isNaN(id)) { res.status(400).json({ error: "Invalid id" }); return; }
  const body = req.body;
  const [item] = await db.update(itemsTable).set({
    code: body.code,
    nameAr: body.nameAr,
    nameEn: body.nameEn,
    category: body.category,
    unit: body.unit,
    costPrice: body.costPrice != null ? String(body.costPrice) : undefined,
    salePrice: body.salePrice != null ? String(body.salePrice) : undefined,
    minStock: body.minStock != null ? String(body.minStock) : undefined,
    barcode: body.barcode,
    taxRate: body.taxRate != null ? String(body.taxRate) : undefined,
  }).where(eq(itemsTable.id, id)).returning();
  if (!item) { res.status(404).json({ error: "Not found" }); return; }
  res.json(toItem(item));
});

router.delete("/:id", async (req, res): Promise<void> => {
  const id = parseInt(String(req.params.id));
  if (isNaN(id)) { res.status(400).json({ error: "Invalid id" }); return; }
  await db.delete(itemsTable).where(eq(itemsTable.id, id));
  res.json({ success: true });
});

export default router;
