import { Router } from "express";
import { db } from "@workspace/db";
import { journalEntriesTable } from "@workspace/db";
import { eq, desc, sql } from "drizzle-orm";

const router = Router();

const toEntry = (e: typeof journalEntriesTable.$inferSelect) => ({
  ...e,
  totalDebit: parseFloat(e.totalDebit ?? "0"),
  totalCredit: parseFloat(e.totalCredit ?? "0"),
  lines: Array.isArray(e.lines) ? e.lines : [],
});

router.get("/", async (req, res): Promise<void> => {
  const entries = await db.select().from(journalEntriesTable).orderBy(desc(journalEntriesTable.createdAt));
  res.json(entries.map(toEntry));
});

router.post("/", async (req, res): Promise<void> => {
  const body = req.body;
  const lines = body.lines || [];
  const totalDebit = lines.reduce((sum: number, l: any) => sum + parseFloat(l.debit ?? "0"), 0);
  const totalCredit = lines.reduce((sum: number, l: any) => sum + parseFloat(l.credit ?? "0"), 0);
  
  const countRes = await db.execute(sql`SELECT count(*) FROM journal_entries WHERE entry_number NOT LIKE 'EX-%' AND (type IS NULL OR type != 'exchange')`);
  const entryNum = String(Number((countRes.rows[0] as any)?.count ?? 0) + 1);
  const [entry] = await db.insert(journalEntriesTable).values({
    entryNumber: entryNum,
    date: body.date,
    description: body.description,
    lines: lines as any,
    totalDebit: String(totalDebit),
    totalCredit: String(totalCredit),
    status: "posted",
  }).returning();
  
  res.status(201).json(toEntry(entry));
});

router.get("/:id", async (req, res): Promise<void> => {
  const id = parseInt(String(req.params.id));
  if (isNaN(id)) { res.status(400).json({ error: "Invalid id" }); return; }
  const [entry] = await db.select().from(journalEntriesTable).where(eq(journalEntriesTable.id, id));
  if (!entry) { res.status(404).json({ error: "Not found" }); return; }
  res.json(toEntry(entry));
});

router.put("/:id", async (req, res): Promise<void> => {
  const id = parseInt(String(req.params.id));
  if (isNaN(id)) { res.status(400).json({ error: "Invalid id" }); return; }
  const body = req.body;
  const lines = body.lines || [];
  const totalDebit = lines.length > 0 ? lines.reduce((sum: number, l: any) => sum + parseFloat(l.debit ?? "0"), 0) : undefined;
  const totalCredit = lines.length > 0 ? lines.reduce((sum: number, l: any) => sum + parseFloat(l.credit ?? "0"), 0) : undefined;
  const updates: any = {};
  if (body.date !== undefined) updates.date = body.date;
  if (body.description !== undefined) updates.description = body.description;
  if (body.notes !== undefined) updates.notes = body.notes;
  if (lines.length > 0) { updates.lines = lines; updates.totalDebit = String(totalDebit); updates.totalCredit = String(totalCredit); }
  const [entry] = await db.update(journalEntriesTable).set(updates).where(eq(journalEntriesTable.id, id)).returning();
  if (!entry) { res.status(404).json({ error: "Not found" }); return; }
  res.json(toEntry(entry));
});

router.delete("/:id", async (req, res): Promise<void> => {
  const id = parseInt(String(req.params.id));
  if (isNaN(id)) { res.status(400).json({ error: "Invalid id" }); return; }
  await db.delete(journalEntriesTable).where(eq(journalEntriesTable.id, id));
  res.json({ success: true });
});

export default router;
