import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { SettingsProvider } from "@/contexts/SettingsContext";
import NotFound from "@/pages/not-found";
import Dashboard from "@/pages/index";
import SalesPage from "@/pages/sales";
import PurchasesPage from "@/pages/purchases";
import AccountsPage from "@/pages/accounts";
import CustomersPage from "@/pages/customers";
import SuppliersPage from "@/pages/suppliers";
import ItemsPage from "@/pages/items";
import TreasuryPage from "@/pages/treasury";
import CurrenciesPage from "@/pages/currencies";
import JournalPage from "@/pages/journal";
import InventoryPage from "@/pages/inventory";
import ReportsPage from "@/pages/reports";
import SettingsPage from "@/pages/settings";
import ExchangePage from "@/pages/exchange";
import JournalAccountsPage from "@/pages/journal-accounts";
import BackupPage from "@/pages/backup";
import QuotePage from "@/pages/quote";
import PurchaseOrderPage from "@/pages/purchase-order";
import UsersPage from "@/pages/users";
import AppLayout from "@/components/layout/app-layout";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: { refetchOnWindowFocus: false, retry: false },
  },
});

function Router() {
  return (
    <AppLayout>
      <Switch>
        <Route path="/" component={Dashboard} />
        <Route path="/sales" component={SalesPage} />
        <Route path="/purchases" component={PurchasesPage} />
        <Route path="/accounts" component={AccountsPage} />
        <Route path="/customers" component={CustomersPage} />
        <Route path="/suppliers" component={SuppliersPage} />
        <Route path="/items" component={ItemsPage} />
        <Route path="/items/quote" component={QuotePage} />
        <Route path="/items/purchase-order" component={PurchaseOrderPage} />
        <Route path="/treasury" component={TreasuryPage} />
        <Route path="/currencies" component={CurrenciesPage} />
        <Route path="/journal" component={JournalPage} />
        <Route path="/inventory" component={InventoryPage} />
        <Route path="/reports" component={ReportsPage} />
        <Route path="/reports/other" component={ReportsPage} />
        <Route path="/settings" component={SettingsPage} />
        <Route path="/settings/users" component={UsersPage} />
        <Route path="/exchange" component={ExchangePage} />
        <Route path="/journal-accounts" component={JournalAccountsPage} />
        <Route path="/backup" component={BackupPage} />
        <Route component={NotFound} />
      </Switch>
    </AppLayout>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <SettingsProvider>
        <TooltipProvider>
          <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
            <div dir="rtl" className="font-sans text-right">
              <Router />
            </div>
          </WouterRouter>
          <Toaster />
        </TooltipProvider>
      </SettingsProvider>
    </QueryClientProvider>
  );
}

export default App;
