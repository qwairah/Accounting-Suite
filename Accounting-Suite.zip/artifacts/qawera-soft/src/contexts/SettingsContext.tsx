import React, { createContext, useContext, useState, useEffect, ReactNode } from "react";

export type AppSettings = {
  // Company
  companyName: string; companyNameEn: string;
  companyAddress: string; companyAddressEn: string;
  phone: string; phone2: string; email: string;
  taxNumber: string; logoUrl: string; signatureUrl: string;
  // Security
  enablePassword: boolean; password: string; operationsLimit: number;
  activationNumbers: string;
  // Print
  printHeader: boolean; printSignature: boolean; numberToWords: boolean;
  showBalance: boolean; hideDocColumn: boolean; printAscending: boolean;
  debitLabel: string; creditLabel: string; invoiceNotes: string;
  voucherNotes: string; entryNotes: string; statementNotes: string;
  printByCurrency: boolean; showDate: boolean; printLines: number;
  invoiceFontSizeScreen: number; invoiceFontSizePrint: number;
  voucherFontSizeScreen: number; voucherFontSizePrint: number;
  printFontColor: string;
  // Notifications
  enableWhatsapp: boolean; enableSms: boolean; enableTelegram: boolean;
  sendOnSave: boolean; attachInvoiceImage: boolean;
  msgPrefix: string; msgSuffix: string; msgDebit: string; msgCredit: string;
  invoiceImageType: string; useBusinessWhatsapp: boolean;
  // Other
  defaultFund: string; editVoucherDate: boolean; autoAddItemPrice: boolean;
  updatePricesOnInvoice: boolean; viewPreviousYears: boolean;
  showTime: boolean; autoAddQty1: boolean; accountCeiling: boolean;
  // Display
  appFontSize: number; appFontColor: string;
  // Backup
  backupDaily: boolean; backupTime: string; backupFolder: string;
  googleDriveFolder: string; backupEmail: string; addImages: boolean;
  // Renewal
  renewalDate: string;
  // Edit Permissions
  allowEditInvoices: boolean;
  allowEditVouchers: boolean;
  allowEditJournals: boolean;
  allowEditExchange: boolean;
  allowEditAccountNames: boolean;
  // Delete Permissions
  allowDeleteInvoices: boolean;
  allowDeleteVouchers: boolean;
  allowDeleteJournals: boolean;
  allowDeleteExchange: boolean;
  // Extra Security
  hideAmounts: boolean;
  requirePassForReports: boolean;
  requirePassForSettings: boolean;
};

const defaultSettings: AppSettings = {
  companyName: "قـويـره سوفت", companyNameEn: "Qwairah Soft",
  companyAddress: "", companyAddressEn: "", phone: "", phone2: "",
  email: "", taxNumber: "", logoUrl: "/logo.png", signatureUrl: "",
  enablePassword: true, password: "735162242", operationsLimit: 100,
  activationNumbers: "+967771096572, +967715107412, +967735162242",
  printHeader: true, printSignature: true, numberToWords: true,
  showBalance: true, hideDocColumn: false, printAscending: false,
  debitLabel: "مدين", creditLabel: "دائن",
  invoiceNotes: "", voucherNotes: "", entryNotes: "", statementNotes: "",
  printByCurrency: false, showDate: true, printLines: 3,
  invoiceFontSizeScreen: 14, invoiceFontSizePrint: 14,
  voucherFontSizeScreen: 14, voucherFontSizePrint: 14,
  printFontColor: "#000000",
  enableWhatsapp: true, enableSms: false, enableTelegram: false,
  sendOnSave: true, attachInvoiceImage: true,
  msgPrefix: "عزيزي العميل،", msgSuffix: "شكراً لتعاملكم معنا",
  msgDebit: "عليك", msgCredit: "لك",
  invoiceImageType: "pdf", useBusinessWhatsapp: false,
  defaultFund: "الصندوق الرئيسي", editVoucherDate: true,
  autoAddItemPrice: true, updatePricesOnInvoice: false,
  viewPreviousYears: false, showTime: false, autoAddQty1: true,
  accountCeiling: false,
  appFontSize: 14, appFontColor: "#ffffff",
  backupDaily: false, backupTime: "23:00",
  backupFolder: "/storage/QWAIRAH_Backups",
  googleDriveFolder: "قـويـره سوفت - نسخ احتياطية",
  backupEmail: "", addImages: false,
  renewalDate: "",
  allowEditInvoices: true,
  allowEditVouchers: true,
  allowEditJournals: true,
  allowEditExchange: true,
  allowEditAccountNames: true,
  allowDeleteInvoices: true,
  allowDeleteVouchers: true,
  allowDeleteJournals: true,
  allowDeleteExchange: true,
  hideAmounts: false,
  requirePassForReports: false,
  requirePassForSettings: false,
};

type SettingsCtx = {
  settings: AppSettings;
  updateSettings: (partial: Partial<AppSettings>) => void;
};

const SettingsContext = createContext<SettingsCtx>({
  settings: defaultSettings,
  updateSettings: () => {},
});

const STORAGE_KEY = "qawera_settings_v2";

export function SettingsProvider({ children }: { children: ReactNode }) {
  const [settings, setSettings] = useState<AppSettings>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) return { ...defaultSettings, ...JSON.parse(stored) };
    } catch {}
    return defaultSettings;
  });

  const updateSettings = (partial: Partial<AppSettings>) => {
    setSettings(prev => {
      const next = { ...prev, ...partial };
      try { localStorage.setItem(STORAGE_KEY, JSON.stringify(next)); } catch {}
      return next;
    });
  };

  // Apply font size and color to root
  useEffect(() => {
    document.documentElement.style.fontSize = `${settings.appFontSize}px`;
  }, [settings.appFontSize]);

  useEffect(() => {
    if (settings.appFontColor) {
      document.documentElement.style.setProperty("--app-font-color", settings.appFontColor);
    }
  }, [settings.appFontColor]);

  return (
    <SettingsContext.Provider value={{ settings, updateSettings }}>
      {children}
    </SettingsContext.Provider>
  );
}

export const useSettings = () => useContext(SettingsContext);
export { defaultSettings };
