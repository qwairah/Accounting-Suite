// Shared print/PDF utility for all documents in قـويـره سوفت

// Arabic number to words
const ones = ["","واحد","اثنان","ثلاثة","أربعة","خمسة","ستة","سبعة","ثمانية","تسعة","عشرة","أحد عشر","اثنا عشر","ثلاثة عشر","أربعة عشر","خمسة عشر","ستة عشر","سبعة عشر","ثمانية عشر","تسعة عشر"];
const tens = ["","","عشرون","ثلاثون","أربعون","خمسون","ستون","سبعون","ثمانون","تسعون"];
const hundreds = ["","مائة","مئتان","ثلاثمائة","أربعمائة","خمسمائة","ستمائة","سبعمائة","ثمانمائة","تسعمائة"];
const thousands = ["","ألف","ألفان","ثلاثة آلاف","أربعة آلاف","خمسة آلاف","ستة آلاف","سبعة آلاف","ثمانية آلاف","تسعة آلاف","عشرة آلاف"];

function numToWordsAr(n: number): string {
  if (n === 0) return "صفر";
  if (n < 0) return "سالب " + numToWordsAr(-n);
  n = Math.round(n);
  const parts: string[] = [];
  if (n >= 1000) {
    const th = Math.floor(n / 1000);
    if (th < 10) parts.push(thousands[th]);
    else parts.push(numToWordsAr(th) + " ألف");
    n %= 1000;
  }
  if (n >= 100) { parts.push(hundreds[Math.floor(n / 100)]); n %= 100; }
  if (n >= 20) {
    const t = Math.floor(n / 10);
    const o = n % 10;
    parts.push(o > 0 ? ones[o] + " و" + tens[t] : tens[t]);
    n = 0;
  }
  if (n > 0) parts.push(ones[n]);
  return parts.filter(Boolean).join(" و");
}

export function amountInWords(amount: number, currencyAr: string = "ريال يمني"): string {
  const intPart = Math.floor(amount);
  const fracPart = Math.round((amount - intPart) * 100);
  let result = numToWordsAr(intPart) + " " + currencyAr;
  if (fracPart > 0) result += " و" + numToWordsAr(fracPart) + " فلس";
  return result + " فقط لا غير";
}

interface CompanyInfo {
  companyName?: string;
  companyNameEn?: string;
  companyAddress?: string;
  companyAddressEn?: string;
  phone?: string;
  phone2?: string;
  email?: string;
  taxNumber?: string;
  logoUrl?: string;
  signatureUrl?: string;
  printHeader?: boolean;
  printSignature?: boolean;
  invoiceNotes?: string;
  voucherNotes?: string;
  entryNotes?: string;
  statementNotes?: string;
  printFontColor?: string;
  invoiceFontSizePrint?: number;
  numberToWords?: boolean;
  currencyNameAr?: string;
}

const companyHeader = (info: CompanyInfo, docTitle: string) => `
  <div class="doc-header">
    <div class="header-ar">
      <div class="company-name-ar">${info.companyName || "قـويـره سوفت"}</div>
      ${info.companyAddress ? `<div class="company-info">${info.companyAddress}</div>` : ""}
      ${info.phone ? `<div class="company-info">📞 ${info.phone}</div>` : ""}
      ${info.phone2 ? `<div class="company-info">📞 ${info.phone2}</div>` : ""}
      ${info.taxNumber ? `<div class="company-info">الرقم الضريبي: ${info.taxNumber}</div>` : ""}
    </div>
    <div class="header-logo">
      ${info.logoUrl ? `<img src="${info.logoUrl}" alt="Logo" class="logo-img" onerror="this.style.display='none'" />` : `<div class="logo-placeholder">Q</div>`}
      <div class="doc-title">${docTitle}</div>
    </div>
    <div class="header-en">
      <div class="company-name-en">${info.companyNameEn || "Qwairah Soft"}</div>
      ${info.companyAddressEn ? `<div class="company-info">${info.companyAddressEn}</div>` : ""}
      ${info.email ? `<div class="company-info">${info.email}</div>` : ""}
    </div>
  </div>
`;

const docCSS = (fontSize: number = 14, fontColor: string = "#000") => `
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body { font-family: 'Segoe UI', Arial, sans-serif; direction: rtl; font-size: ${fontSize}px; color: ${fontColor}; background: #fff; padding: 20px; }
  .doc-header { display: flex; align-items: flex-start; justify-content: space-between; border-bottom: 3px solid #064E3B; padding-bottom: 15px; margin-bottom: 15px; }
  .header-ar { flex: 1; text-align: right; }
  .header-en { flex: 1; text-align: left; direction: ltr; }
  .header-logo { text-align: center; padding: 0 15px; }
  .company-name-ar { font-size: 1.4em; font-weight: bold; color: #064E3B; margin-bottom: 3px; }
  .company-name-en { font-size: 1.1em; font-weight: bold; color: #064E3B; margin-bottom: 3px; }
  .company-info { font-size: 0.85em; color: #444; margin-top: 2px; }
  .logo-img { width: 80px; height: 80px; object-fit: contain; border-radius: 8px; border: 2px solid #064E3B; }
  .logo-placeholder { width: 80px; height: 80px; background: #064E3B; color: #F59E0B; font-size: 2em; font-weight: bold; display: flex; align-items: center; justify-content: center; border-radius: 8px; margin: 0 auto; }
  .doc-title { font-size: 1.1em; font-weight: bold; color: #B45309; margin-top: 5px; text-align: center; }
  .doc-meta { display: flex; flex-wrap: wrap; gap: 10px; background: #f0fdf4; border: 1px solid #bbf7d0; border-radius: 8px; padding: 10px; margin-bottom: 15px; font-size: 0.9em; }
  .doc-meta span { font-weight: bold; color: #064E3B; }
  .doc-meta .label { color: #666; font-weight: normal; }
  table { width: 100%; border-collapse: collapse; margin: 15px 0; }
  thead tr { background: #064E3B; color: white; }
  th { padding: 10px; text-align: right; font-weight: bold; font-size: 0.9em; }
  td { padding: 9px; text-align: right; border-bottom: 1px solid #e5e7eb; }
  tr:nth-child(even) td { background: #f9fafb; }
  .amount { font-weight: bold; color: #064E3B; }
  .total-row td { background: #f0fdf4 !important; font-weight: bold; border-top: 2px solid #064E3B; color: #064E3B; }
  .footer-notes { border-top: 1px solid #e5e7eb; margin-top: 15px; padding-top: 10px; font-size: 0.85em; color: #666; }
  .signature-section { display: flex; justify-content: space-between; margin-top: 25px; padding-top: 15px; border-top: 1px dashed #ccc; }
  .sig-box { text-align: center; min-width: 150px; }
  .sig-label { font-size: 0.85em; color: #666; margin-bottom: 30px; }
  .sig-line { border-bottom: 1px solid #333; width: 150px; margin: 0 auto; }
  .sig-img { max-height: 60px; margin-bottom: 5px; }
  .balance-row { background: #fef3c7 !important; font-weight: bold; color: #92400e; }
  @media print { body { padding: 10px; } }
`;

export const buildDocumentHTML = (
  title: string,
  metaFields: { label: string; value: string }[],
  tableHeaders: string[],
  tableRows: string[][],
  totals: { label: string; value: string }[],
  info: CompanyInfo = {},
  extraFooter?: string
): string => {
  const fontSize = info.invoiceFontSizePrint || 14;
  const fontColor = info.printFontColor || "#000";
  const metaHtml = metaFields.map(f => `<div><span class="label">${f.label}: </span><span>${f.value}</span></div>`).join("");
  const headersHtml = tableHeaders.map(h => `<th>${h}</th>`).join("");
  const rowsHtml = tableRows.map(row => `<tr>${row.map(cell => `<td>${cell}</td>`).join("")}</tr>`).join("");
  const totalsHtml = totals.map(t => `<tr class="total-row"><td colspan="${tableHeaders.length - 1}" style="text-align:right"><b>${t.label}</b></td><td class="amount">${t.value}</td></tr>`).join("");
  const sigHtml = info.printSignature ? `
    <div class="signature-section">
      <div class="sig-box"><div class="sig-label">المحاسب</div><div class="sig-line"></div></div>
      <div class="sig-box">
        ${info.signatureUrl ? `<img class="sig-img" src="${info.signatureUrl}" alt="sig" />` : ""}
        <div class="sig-label">المدير / المفوض بالتوقيع</div>
        <div class="sig-line"></div>
      </div>
      <div class="sig-box"><div class="sig-label">المستلم</div><div class="sig-line"></div></div>
    </div>
  ` : "";
  let amountWordsHtml = "";
  if (info.numberToWords && totals.length > 0) {
    const firstTotal = totals[0].value;
    const numMatch = firstTotal.match(/([\d,]+\.?\d*)/);
    if (numMatch) {
      const amt = parseFloat(numMatch[1].replace(/,/g, ""));
      if (!isNaN(amt)) {
        amountWordsHtml = `<div style="background:#f0fdf4;border:1px solid #bbf7d0;border-radius:6px;padding:10px;margin:10px 0;font-size:0.9em;color:#064E3B;font-weight:bold;direction:rtl;text-align:right">💬 فقط: ${amountInWords(amt, info.currencyNameAr || "ريال يمني")}</div>`;
      }
    }
  }
  return `<!DOCTYPE html><html dir="rtl"><head><meta charset="utf-8"><title>${title}</title>
    <style>${docCSS(fontSize, fontColor)}</style></head><body>
    ${info.printHeader !== false ? companyHeader(info, title) : `<h2 style="color:#064E3B;text-align:center;border-bottom:2px solid #F59E0B;padding-bottom:8px">${title}</h2>`}
    <div class="doc-meta">${metaHtml}</div>
    <table><thead><tr>${headersHtml}</tr></thead>
    <tbody>${rowsHtml}${totalsHtml}</tbody></table>
    ${amountWordsHtml}
    ${extraFooter ? `<div class="footer-notes">${extraFooter}</div>` : ""}
    ${sigHtml}
    </body></html>`;
};

export const printDocument = (
  title: string,
  metaFields: { label: string; value: string }[],
  tableHeaders: string[],
  tableRows: string[][],
  totals: { label: string; value: string }[],
  info: CompanyInfo = {},
  extraFooter?: string
) => {
  const w = window.open("", "_blank");
  if (!w) return;

  const fontSize = info.invoiceFontSizePrint || 14;
  const fontColor = info.printFontColor || "#000";

  const metaHtml = metaFields.map(f => `<div><span class="label">${f.label}: </span><span>${f.value}</span></div>`).join("");
  const headersHtml = tableHeaders.map(h => `<th>${h}</th>`).join("");
  const rowsHtml = tableRows.map(row => `<tr>${row.map(cell => `<td>${cell}</td>`).join("")}</tr>`).join("");
  const totalsHtml = totals.map(t => `<tr class="total-row"><td colspan="${tableHeaders.length - 1}" style="text-align:right"><b>${t.label}</b></td><td class="amount">${t.value}</td></tr>`).join("");
  const sigHtml = info.printSignature ? `
    <div class="signature-section">
      <div class="sig-box"><div class="sig-label">المحاسب</div><div class="sig-line"></div></div>
      <div class="sig-box">
        ${info.signatureUrl ? `<img class="sig-img" src="${info.signatureUrl}" alt="sig" />` : ""}
        <div class="sig-label">المدير / المفوض بالتوقيع</div>
        <div class="sig-line"></div>
      </div>
      <div class="sig-box"><div class="sig-label">المستلم</div><div class="sig-line"></div></div>
    </div>
  ` : "";

  // Amount in words (extract first numeric total when numberToWords is on)
  let amountWordsHtml = "";
  if (info.numberToWords && totals.length > 0) {
    const firstTotal = totals[0].value;
    const numMatch = firstTotal.match(/([\d,]+\.?\d*)/);
    if (numMatch) {
      const amt = parseFloat(numMatch[1].replace(/,/g, ""));
      if (!isNaN(amt)) {
        amountWordsHtml = `<div style="background:#f0fdf4;border:1px solid #bbf7d0;border-radius:6px;padding:10px;margin:10px 0;font-size:0.9em;color:#064E3B;font-weight:bold;direction:rtl;text-align:right">💬 فقط: ${amountInWords(amt, info.currencyNameAr || "ريال يمني")}</div>`;
      }
    }
  }

  w.document.write(`<!DOCTYPE html><html dir="rtl"><head><meta charset="utf-8"><title>${title}</title>
    <style>${docCSS(fontSize, fontColor)}</style></head><body>
    ${info.printHeader !== false ? companyHeader(info, title) : `<h2 style="color:#064E3B;text-align:center;border-bottom:2px solid #F59E0B;padding-bottom:8px">${title}</h2>`}
    <div class="doc-meta">${metaHtml}</div>
    <table><thead><tr>${headersHtml}</tr></thead>
    <tbody>${rowsHtml}${totalsHtml}</tbody></table>
    ${amountWordsHtml}
    ${extraFooter ? `<div class="footer-notes">${extraFooter}</div>` : ""}
    ${sigHtml}
    </body></html>`);
  w.document.close();
  w.focus();
  setTimeout(() => { w.print(); }, 500);
};

export const printStatement = (
  accountName: string,
  transactions: { date: string; description: string; debit: number; credit: number; balance: number; currency: string }[],
  info: CompanyInfo = {}
) => {
  const w = window.open("", "_blank");
  if (!w) return;
  const fontSize = info.invoiceFontSizePrint || 14;
  const rowsHtml = transactions.map((t, i) => `
    <tr>
      <td>${i + 1}</td>
      <td>${t.date}</td>
      <td>${t.description}</td>
      <td class="amount">${t.debit > 0 ? t.debit.toFixed(2) : "-"}</td>
      <td class="amount">${t.credit > 0 ? t.credit.toFixed(2) : "-"}</td>
      <td class="amount ${t.balance < 0 ? 'style="color:red"' : ''}">${Math.abs(t.balance).toFixed(2)} ${t.balance < 0 ? "مدين" : "دائن"}</td>
      <td>${t.currency}</td>
    </tr>
  `).join("");

  w.document.write(`<!DOCTYPE html><html dir="rtl"><head><meta charset="utf-8"><title>كشف حساب - ${accountName}</title>
    <style>${docCSS(fontSize, info.printFontColor)}</style></head><body>
    ${info.printHeader !== false ? companyHeader(info, `كشف حساب: ${accountName}`) : ""}
    <table>
      <thead><tr><th>#</th><th>التاريخ</th><th>البيان</th><th>مدين</th><th>دائن</th><th>الرصيد</th><th>العملة</th></tr></thead>
      <tbody>${rowsHtml}</tbody>
    </table>
    ${info.statementNotes ? `<div class="footer-notes">${info.statementNotes}</div>` : ""}
    </body></html>`);
  w.document.close();
  setTimeout(() => w.print(), 500);
};

export const sendWhatsApp = (
  phone: string,
  message: string,
) => {
  const cleaned = phone.replace(/\D/g, "");
  const encoded = encodeURIComponent(message);
  window.open(`https://wa.me/${cleaned}?text=${encoded}`, "_blank");
};

export const sendTelegram = (phone: string, message: string) => {
  const encoded = encodeURIComponent(message);
  window.open(`https://t.me/share/url?text=${encoded}`, "_blank");
};

export const buildInvoiceMessage = (
  type: string,
  number: string | number,
  clientName: string,
  amount: number,
  currency: string,
  balance: number,
  notes: string,
  prefix: string,
  suffix: string
) => {
  return `${prefix}
*${type} رقم: ${number}*
👤 العميل: ${clientName}
💰 المبلغ: ${amount.toFixed(2)} ${currency}
📊 الرصيد الحالي: ${Math.abs(balance).toFixed(2)} ${currency} ${balance < 0 ? "مدين" : "دائن"}
${notes ? `📝 ملاحظة: ${notes}` : ""}
${suffix}`;
};
