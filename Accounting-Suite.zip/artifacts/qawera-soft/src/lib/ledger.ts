export type LedgerDocType = "sale" | "purchase" | "receipt" | "payment" | "journal" | "exchange";

export type LedgerEntry = {
  id: string;
  date: string;
  docType: LedgerDocType;
  docNumber: string;
  docId: string | number;
  accountId: number;
  debit: number;
  credit: number;
  description: string;
  currencySymbol?: string;
  ref?: string;
};

const KEY = "qawera_ledger_v1";

export function getLedger(): LedgerEntry[] {
  try { return JSON.parse(localStorage.getItem(KEY) || "[]"); } catch { return []; }
}

export function saveLedger(entries: LedgerEntry[]) {
  localStorage.setItem(KEY, JSON.stringify(entries));
}

export function postToLedger(newEntries: LedgerEntry[]) {
  const current = getLedger();
  saveLedger([...current, ...newEntries]);
}

export function removeFromLedger(docId: string | number, docType: LedgerDocType) {
  const current = getLedger();
  saveLedger(current.filter(e => !(String(e.docId) === String(docId) && e.docType === docType)));
}

export function getLedgerForAccount(accountId: number, fromDate?: string, toDate?: string): LedgerEntry[] {
  return getLedger().filter(e => {
    if (e.accountId !== accountId) return false;
    if (fromDate && e.date < fromDate) return false;
    if (toDate && e.date > toDate) return false;
    return true;
  }).sort((a, b) => a.date.localeCompare(b.date) || a.id.localeCompare(b.id));
}

export function getAccountBalance(accountId: number, openingBalance: number): number {
  const entries = getLedgerForAccount(accountId);
  const totalDebit = entries.reduce((s, e) => s + (e.debit || 0), 0);
  const totalCredit = entries.reduce((s, e) => s + (e.credit || 0), 0);
  return openingBalance + totalDebit - totalCredit;
}

export function makeId(): string {
  return `${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
}

export const docTypeLabel: Record<LedgerDocType, string> = {
  sale: "مبيعات",
  purchase: "مشتريات",
  receipt: "سند قبض",
  payment: "سند صرف",
  journal: "قيد يومي",
  exchange: "مصارفة",
};
