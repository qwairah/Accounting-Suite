import { useEffect, useRef } from "react";
import { X, Printer, Download, Share2 } from "lucide-react";

interface InvoicePrintOverlayProps {
  html: string;
  title?: string;
  onClose: () => void;
  onShare?: () => void;
}

export function InvoicePrintOverlay({ html, title = "فاتورة", onClose, onShare }: InvoicePrintOverlayProps) {
  const iframeRef = useRef<HTMLIFrameElement>(null);

  useEffect(() => {
    document.body.style.overflow = "hidden";
    return () => { document.body.style.overflow = ""; };
  }, []);

  useEffect(() => {
    if (iframeRef.current) {
      const doc = iframeRef.current.contentDocument;
      if (doc) {
        doc.open();
        doc.write(html);
        doc.close();
      }
    }
  }, [html]);

  const handlePrint = () => {
    iframeRef.current?.contentWindow?.print();
  };

  const handleDownload = () => {
    const blob = new Blob([html], { type: "text/html;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${title}.html`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div
      className="fixed inset-0 z-[9999] flex flex-col"
      style={{ background: "rgba(2,44,34,0.98)", backdropFilter: "blur(4px)" }}
    >
      {/* Toolbar */}
      <div
        className="flex items-center gap-2 px-4 py-3 border-b border-emerald-700/50 shrink-0"
        style={{ background: "rgba(6,78,59,0.95)" }}
        dir="rtl"
      >
        <button
          onClick={onClose}
          className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-white transition-colors"
          title="إغلاق"
        >
          <X className="w-5 h-5" />
        </button>

        <h2 className="text-amber-400 font-bold text-base flex-1 text-right">{title}</h2>

        {onShare && (
          <button
            onClick={onShare}
            className="flex items-center gap-2 px-4 py-2 rounded-xl bg-blue-700 hover:bg-blue-600 text-white font-bold text-sm transition-colors"
          >
            <Share2 className="w-4 h-4" />
            مشاركة
          </button>
        )}
        <button
          onClick={handleDownload}
          className="flex items-center gap-2 px-4 py-2 rounded-xl bg-emerald-700 hover:bg-emerald-600 text-white font-bold text-sm transition-colors"
        >
          <Download className="w-4 h-4" />
          حفظ
        </button>
        <button
          onClick={handlePrint}
          className="flex items-center gap-2 px-4 py-2 rounded-xl bg-amber-600 hover:bg-amber-500 text-white font-bold text-sm transition-colors"
        >
          <Printer className="w-4 h-4" />
          طباعة
        </button>
      </div>

      {/* Invoice content */}
      <div className="flex-1 overflow-hidden bg-gray-100">
        <iframe
          ref={iframeRef}
          className="w-full h-full border-0"
          title={title}
          style={{ background: "#fff" }}
        />
      </div>
    </div>
  );
}
