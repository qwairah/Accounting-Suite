import React from "react";
import { Link, useLocation } from "wouter";
import {
  LayoutDashboard, ShoppingCart, ShoppingBag, Wallet, Users, Building2,
  PackageSearch, Settings, BookOpen, LineChart, Coins, Boxes,
  ArrowLeftRight, PenLine, FileText, DatabaseBackup, Menu, Tag, BarChart2, UserCog,
  ClipboardList, ArrowRight, AlertTriangle
} from "lucide-react";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { useSettings } from "@/contexts/SettingsContext";

const menuItems = [
  { icon: LayoutDashboard, label: "الرئيسية", path: "/" },
  { icon: ShoppingCart, label: "المبيعات", path: "/sales" },
  { icon: ShoppingBag, label: "المشتريات", path: "/purchases" },
  { icon: Wallet, label: "صرف / قبض", path: "/treasury" },
  { icon: PenLine, label: "قيد يومي", path: "/journal" },
  { icon: ArrowLeftRight, label: "مصارفة العملات", path: "/exchange" },
  { icon: BookOpen, label: "الحسابات", path: "/accounts" },
  { icon: Users, label: "العملاء", path: "/customers" },
  { icon: Building2, label: "الموردين", path: "/suppliers" },
  { icon: PackageSearch, label: "الأصناف", path: "/items" },
  { icon: Tag, label: "عرض سعر", path: "/items/quote" },
  { icon: ClipboardList, label: "طلب شراء", path: "/items/purchase-order" },
  { icon: Boxes, label: "عمليات مخزنية", path: "/inventory" },
  { icon: FileText, label: "قيود وحسابات", path: "/journal-accounts" },
  { icon: Coins, label: "العملات", path: "/currencies" },
  { icon: LineChart, label: "التقارير", path: "/reports" },
  { icon: BarChart2, label: "تقارير أخرى", path: "/reports/other" },
  { icon: DatabaseBackup, label: "النسخ الاحتياطية", path: "/backup" },
  { icon: UserCog, label: "المستخدمون", path: "/settings/users" },
  { icon: Settings, label: "الإعدادات", path: "/settings" },
];

const pageTitles: Record<string, string> = {
  "/sales": "المبيعات",
  "/purchases": "المشتريات",
  "/treasury": "صرف / قبض",
  "/journal": "القيد اليومي",
  "/exchange": "مصارفة العملات",
  "/accounts": "الحسابات",
  "/customers": "العملاء",
  "/suppliers": "الموردين",
  "/items": "الأصناف",
  "/items/quote": "عرض سعر",
  "/items/purchase-order": "طلب شراء",
  "/inventory": "العمليات المخزنية",
  "/journal-accounts": "قيود وحسابات",
  "/currencies": "العملات",
  "/reports": "التقارير",
  "/reports/other": "تقارير أخرى",
  "/backup": "النسخ الاحتياطية",
  "/settings": "الإعدادات",
  "/settings/users": "المستخدمون",
};

export default function AppLayout({ children }: { children: React.ReactNode }) {
  const [location, navigate] = useLocation();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = React.useState(false);
  const { settings } = useSettings();

  const isRenewalExpired = React.useMemo(() => {
    if (!settings.renewalDate) return false;
    return new Date(settings.renewalDate) < new Date(new Date().toDateString());
  }, [settings.renewalDate]);

  const daysUntilRenewal = React.useMemo(() => {
    if (!settings.renewalDate) return null;
    const diff = Math.ceil((new Date(settings.renewalDate).getTime() - Date.now()) / 86400000);
    return diff;
  }, [settings.renewalDate]);

  const isHome = location === "/";
  const pageTitle = Object.entries(pageTitles).find(([p]) => location === p || location.startsWith(p + "/"))?.[1] ?? "";

  const isActive = (path: string) =>
    path === "/" ? location === "/" : location === path || location.startsWith(path + "/");

  const SidebarContent = () => (
    <div className="flex flex-col h-full" style={{ background: "linear-gradient(180deg, #022c22 0%, #064E3B 50%, #065F46 100%)" }}>
      {/* Logo */}
      <div className="p-4 border-b border-emerald-700/50">
        <div className="flex items-center gap-2">
          <img src="/logo.png" alt="Qwairah" className="w-10 h-10 rounded-xl object-cover border border-amber-500/40" onError={e => { e.currentTarget.style.display = "none"; }} />
          <div>
            <h1 className="text-lg font-black leading-tight" style={{
              background: "linear-gradient(135deg, #F59E0B, #FCD34D, #F59E0B)",
              WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent",
            }}>{settings.companyName || "قـويـره سوفت"}</h1>
            <p className="text-emerald-400 text-xs">نظام المحاسبة المتكامل</p>
          </div>
        </div>
      </div>

      {/* Menu Items */}
      <div className="flex-1 overflow-y-auto py-2 px-2 space-y-0.5">
        {menuItems.map((item) => {
          const Icon = item.icon;
          const active = isActive(item.path);
          return (
            <Link key={item.path} href={item.path} onClick={() => setIsMobileMenuOpen(false)}>
              <div className={`flex items-center gap-2.5 px-3 py-2 rounded-lg transition-all duration-200 group cursor-pointer ${active ? "bg-amber-500 text-white shadow-lg" : "text-emerald-100 hover:bg-emerald-700/60 hover:text-white"}`}>
                <Icon className={`w-4 h-4 flex-shrink-0 ${active ? "text-white" : "text-amber-400 group-hover:text-amber-300"}`} />
                <span className="font-semibold text-xs">{item.label}</span>
              </div>
            </Link>
          );
        })}
      </div>

      {/* Footer */}
      <div className="p-3 border-t border-emerald-700/50">
        <div className="text-center text-emerald-600 text-xs">QWAIRAH SOFT v2.0</div>
      </div>
    </div>
  );

  return (
    <div className="flex h-screen overflow-hidden" style={{ background: "linear-gradient(135deg, #011a13 0%, #064E3B 50%, #065F46 100%)" }}>
      {/* Desktop Sidebar */}
      <aside className="hidden md:flex w-52 flex-col shrink-0 z-20 border-l border-emerald-700/30">
        <SidebarContent />
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Mobile Header */}
        <header className="md:hidden flex items-center justify-between p-3 border-b border-emerald-700/50 sticky top-0 z-10" style={{ background: "#022c22" }}>
          <Sheet open={isMobileMenuOpen} onOpenChange={setIsMobileMenuOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="text-amber-400 hover:bg-emerald-700">
                <Menu className="w-6 h-6" />
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="p-0 w-52 border-0" dir="rtl">
              <SidebarContent />
            </SheetContent>
          </Sheet>
          <h1 className="text-xl font-black" style={{
            background: "linear-gradient(135deg, #F59E0B, #FCD34D)",
            WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent",
          }}>قـويـره سوفت</h1>
          <div className="w-10"></div>
        </header>

        {/* Back Arrow Bar — يظهر في جميع الصفحات عدا الرئيسية */}
        {!isHome && (
          <div
            dir="rtl"
            className="flex items-center gap-3 px-4 py-2 border-b border-emerald-700/40 sticky top-0 z-10"
            style={{ background: "rgba(2,44,34,0.95)", backdropFilter: "blur(8px)" }}
          >
            <button
              onClick={() => navigate("/")}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-amber-400 hover:text-amber-300 hover:bg-amber-500/10 transition-all font-bold text-sm border border-amber-500/20 hover:border-amber-400/40"
            >
              <ArrowRight className="w-4 h-4" />
              رجوع
            </button>
            {pageTitle && (
              <span className="text-emerald-200 font-bold text-sm opacity-80">{pageTitle}</span>
            )}
          </div>
        )}

        {/* Renewal Warning Banner */}
        {settings.renewalDate && daysUntilRenewal !== null && daysUntilRenewal <= 7 && (
          <div dir="rtl" className={`flex items-center gap-2 px-4 py-2 text-sm font-bold border-b ${isRenewalExpired ? "bg-red-900/80 border-red-700 text-red-200" : "bg-amber-900/70 border-amber-700 text-amber-200"}`}>
            <AlertTriangle className="w-4 h-4 flex-shrink-0" />
            {isRenewalExpired
              ? `⛔ انتهت صلاحية البرنامج منذ ${Math.abs(daysUntilRenewal)} يوم — يرجى التواصل للتجديد`
              : `⚠️ سيتوقف البرنامج بعد ${daysUntilRenewal} ${daysUntilRenewal === 1 ? "يوم" : "أيام"} — يرجى التجديد قبل ${settings.renewalDate}`
            }
          </div>
        )}

        {/* Scrollable Content */}
        <div className="flex-1 overflow-auto p-3 md:p-5">
          <div className="max-w-7xl mx-auto">
            {children}
          </div>
        </div>
      </main>
    </div>
  );
}
