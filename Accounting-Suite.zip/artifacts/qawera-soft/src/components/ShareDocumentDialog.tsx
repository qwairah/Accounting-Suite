import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { MessageCircle, Send, Copy, FileText, ImageIcon, CheckCircle, Phone, X, Camera } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface ShareDocumentDialogProps {
  open: boolean;
  onClose: () => void;
  docTitle: string;
  message: string;
  phone?: string;
  onPrintPDF: () => void;
  htmlContent?: string;
}

export function ShareDocumentDialog({ open, onClose, docTitle, message, phone, onPrintPDF, htmlContent }: ShareDocumentDialogProps) {
  const { toast } = useToast();
  const [copied, setCopied] = useState(false);

  const cleanPhone = (phone || "").replace(/\D/g, "");

  const shareViaWhatsApp = () => {
    const url = cleanPhone
      ? `https://wa.me/${cleanPhone}?text=${encodeURIComponent(message)}`
      : `https://wa.me/?text=${encodeURIComponent(message)}`;
    window.open(url, "_blank");
  };

  const shareViaTelegram = () => {
    window.open(`https://t.me/share/url?text=${encodeURIComponent(message)}`, "_blank");
  };

  const shareViaSMS = () => {
    const url = cleanPhone
      ? `sms:+${cleanPhone}?body=${encodeURIComponent(message)}`
      : `sms:?body=${encodeURIComponent(message)}`;
    window.location.href = url;
  };

  const copyToClipboard = async () => {
    try {
      await navigator.clipboard.writeText(message);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
      toast({ title: "✅ تم نسخ النص" });
    } catch {
      const el = document.createElement("textarea");
      el.value = message;
      document.body.appendChild(el);
      el.select();
      document.execCommand("copy");
      document.body.removeChild(el);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
      toast({ title: "✅ تم نسخ النص" });
    }
  };

  const buildImageHTML = () => {
    if (htmlContent) {
      return htmlContent.replace("</body>", `
<script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"><\/script>
<div style="position:fixed;bottom:16px;left:50%;transform:translateX(-50%);display:flex;gap:8px;z-index:9999">
  <button onclick="dl('png')" style="background:#064E3B;color:white;border:none;padding:10px 20px;border-radius:8px;font-size:14px;cursor:pointer;font-weight:bold">⬇️ تحميل PNG</button>
  <button onclick="dl('jpeg')" style="background:#7c3aed;color:white;border:none;padding:10px 20px;border-radius:8px;font-size:14px;cursor:pointer;font-weight:bold">⬇️ تحميل JPEG</button>
  <button onclick="window.print()" style="background:#b45309;color:white;border:none;padding:10px 20px;border-radius:8px;font-size:14px;cursor:pointer;font-weight:bold">🖨️ طباعة</button>
</div>
<script>
function dl(fmt){
  document.querySelector('[style*="position:fixed"]').style.display='none';
  html2canvas(document.body,{scale:2,useCORS:true,backgroundColor:'#ffffff'}).then(function(canvas){
    document.querySelector('[style*="position:fixed"]').style.display='flex';
    var link=document.createElement('a');
    link.download='${docTitle.replace(/[^a-z0-9أ-ي ]/gi, "_")}.'+fmt;
    link.href=canvas.toDataURL('image/'+fmt,0.95);
    link.click();
  });
}
<\/script>
</body>`);
    }
    const safeContent = message.replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/\*/g, "").replace(/\n/g, "<br/>");
    return `<!DOCTYPE html><html dir="rtl">
<head><meta charset="utf-8"><title>${docTitle}</title>
<script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"><\/script>
<style>
body{font-family:'Segoe UI',Arial,sans-serif;direction:rtl;background:#f0fdf4;padding:20px;max-width:640px;margin:0 auto;}
#capture{background:white;border-radius:16px;overflow:hidden;box-shadow:0 4px 20px rgba(0,0,0,0.15);}
.hdr{background:#064E3B;padding:20px;text-align:center;}
.hdr h2{color:#F59E0B;font-size:1.6em;margin:0 0 4px;}
.hdr p{color:#a7f3d0;font-size:0.95em;margin:0;}
.body{padding:24px;line-height:1.9;font-size:15px;color:#1a1a1a;white-space:pre-wrap;}
.footer{background:#f0fdf4;padding:12px;text-align:center;font-size:0.85em;color:#065f46;border-top:2px dashed #a7f3d0;}
.btns{display:flex;gap:10px;margin-top:16px;flex-wrap:wrap;}
.btn{padding:10px 18px;border-radius:8px;font-size:14px;font-weight:bold;cursor:pointer;border:none;flex:1;min-width:120px;}
@media print{.btns{display:none;}}
</style></head>
<body>
<div id="capture">
  <div class="hdr"><h2>قـويـره سوفت</h2><p>${docTitle}</p></div>
  <div class="body">${safeContent}</div>
  <div class="footer">QWAIRAH SOFT — نظام المحاسبة المتكامل</div>
</div>
<div class="btns">
  <button class="btn" style="background:#064E3B;color:white" onclick="dl('png')">⬇️ PNG صورة</button>
  <button class="btn" style="background:#7c3aed;color:white" onclick="dl('jpeg')">⬇️ JPEG صورة</button>
  <button class="btn" style="background:#b45309;color:white" onclick="window.print()">🖨️ طباعة / PDF</button>
</div>
<script>
function dl(fmt){
  var el=document.getElementById('capture');
  html2canvas(el,{scale:2,useCORS:true,backgroundColor:'#ffffff'}).then(function(canvas){
    var link=document.createElement('a');
    link.download='${docTitle.replace(/[^a-z0-9أ-ي ]/gi, "_")}.'+fmt;
    link.href=canvas.toDataURL('image/'+fmt,0.95);
    link.click();
  });
}
<\/script>
</body></html>`;
  };

  const downloadAsImage = () => {
    const w = window.open("", "_blank");
    if (!w) return;
    w.document.write(buildImageHTML());
    w.document.close();
  };

  const shareImageViaWhatsApp = () => {
    const w = window.open("", "_blank");
    if (!w) {
      toast({ title: "⚠️ فعّل النوافذ المنبثقة في متصفحك", variant: "destructive" });
      return;
    }
    w.document.write(buildImageHTML());
    w.document.close();
    setTimeout(() => {
      const url = cleanPhone
        ? `https://wa.me/${cleanPhone}?text=${encodeURIComponent("📋 " + docTitle + "\n\nالسلام عليكم،\nمرفق صورة الوثيقة. يرجى الاطلاع عليها.\n\n" + message.split("\n").slice(0, 5).join("\n"))}`
        : `https://wa.me/?text=${encodeURIComponent("📋 " + docTitle + "\n" + message.split("\n").slice(0, 5).join("\n"))}`;
      window.open(url, "_blank");
    }, 1200);
    toast({ title: "📷 يتم فتح صورة الوثيقة + واتساب", description: "حمّل الصورة ثم أرفقها في محادثة واتساب" });
    onClose();
  };

  return (
    <Dialog open={open} onOpenChange={v => !v && onClose()}>
      <DialogContent className="max-w-md text-white border-emerald-700 overflow-hidden p-0" dir="rtl" style={{ background: "linear-gradient(135deg, #022c22, #064E3B)" }}>
        <DialogHeader className="p-4 pb-0">
          <div className="flex items-center justify-between">
            <DialogTitle className="text-amber-400 text-lg">📤 مشاركة — {docTitle}</DialogTitle>
            <button onClick={onClose} className="text-emerald-400 hover:text-white transition-colors">
              <X className="w-5 h-5" />
            </button>
          </div>
        </DialogHeader>

        <div className="p-4 space-y-4">
          <div className="bg-emerald-900/50 rounded-xl p-3 max-h-44 overflow-y-auto border border-emerald-700/50">
            <p className="text-emerald-100 text-sm whitespace-pre-line leading-relaxed">{message.replace(/\*/g, "")}</p>
          </div>

          {phone && (
            <div className="flex items-center gap-2 text-emerald-400 text-xs bg-emerald-900/30 rounded-lg px-3 py-2">
              <Phone className="w-3.5 h-3.5" />
              <span>سيتم الإرسال إلى: <span className="text-amber-300 font-bold">{phone}</span></span>
            </div>
          )}

          <div>
            <p className="text-emerald-300 text-xs font-bold mb-2">📱 إرسال نصي عبر:</p>
            <div className="grid grid-cols-2 gap-2">
              <Button onClick={shareViaWhatsApp} className="bg-green-700 hover:bg-green-600 h-12 gap-2 font-bold text-sm">
                <MessageCircle className="w-5 h-5" /> واتساب نص
              </Button>
              <Button onClick={shareImageViaWhatsApp} className="bg-green-900 hover:bg-green-800 border border-green-600 h-12 gap-2 font-bold text-sm">
                <Camera className="w-4 h-4" /> واتساب + صورة
              </Button>
              <Button onClick={shareViaTelegram} className="bg-blue-700 hover:bg-blue-600 h-12 gap-2 font-bold text-sm">
                <Send className="w-5 h-5" /> تيليجرام
              </Button>
              <Button onClick={shareViaSMS} variant="outline" className="border-purple-600 text-purple-300 hover:bg-purple-900/30 h-12 gap-2 font-bold text-sm">
                <Phone className="w-5 h-5" /> رسالة SMS
              </Button>
            </div>
          </div>

          <div>
            <p className="text-emerald-300 text-xs font-bold mb-2">📄 تصدير ملف:</p>
            <div className="grid grid-cols-3 gap-2">
              <Button onClick={() => { onPrintPDF(); onClose(); }} variant="outline" className="border-red-600 text-red-300 hover:bg-red-900/30 h-12 gap-2 font-bold text-sm">
                <FileText className="w-5 h-5" /> PDF
              </Button>
              <Button onClick={() => { downloadAsImage(); onClose(); }} variant="outline" className="border-cyan-600 text-cyan-300 hover:bg-cyan-900/30 h-12 gap-2 font-bold text-sm">
                <ImageIcon className="w-5 h-5" /> صورة
              </Button>
              <Button onClick={copyToClipboard} variant="outline" className={`h-12 gap-2 font-bold text-sm transition-all ${copied ? "border-green-600 text-green-300 bg-green-900/20" : "border-amber-600 text-amber-300 hover:bg-amber-900/30"}`}>
                {copied ? <CheckCircle className="w-5 h-5" /> : <Copy className="w-5 h-5" />}
                {copied ? "نُسخ!" : "نسخ"}
              </Button>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
