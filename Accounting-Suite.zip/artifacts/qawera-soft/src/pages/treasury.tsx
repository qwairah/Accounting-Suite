import { useState, useMemo } from "react";
import { useListTreasuryTransactions, useCreateTreasuryTransaction, useGetTreasurySummary, useListAccounts, useListCurrencies, useCreateAccount } from "@workspace/api-client-react";
import { useQueryClient, useMutation } from "@tanstack/react-query";
import { getListTreasuryTransactionsQueryKey, getGetTreasurySummaryQueryKey, getListAccountsQueryKey } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, Camera, Search, Trash2, Share2, MessageCircle, ArrowDownCircle, ArrowUpCircle, UserPlus, Printer, MoreVertical, ArrowRight, FileText, ImageIcon, Send, X, Edit2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { ShareDocumentDialog } from "@/components/ShareDocumentDialog";
import { printDocument } from "@/lib/printUtils";
import { useSettings } from "@/contexts/SettingsContext";
import { postToLedger, removeFromLedger, makeId } from "@/lib/ledger";

type VoucherType = "receive" | "pay";

const typeConfig = {
  receive: { label: "سند قبض", color: "text-green-400", bg: "bg-green-900/20 border-green-600/40", icon: ArrowDownCircle },
  pay: { label: "سند صرف", color: "text-red-400", bg: "bg-red-900/20 border-red-600/40", icon: ArrowUpCircle },
};

const defaultForm = {
  type: "receive" as VoucherType,
  accountId: "",
  fundBank: "",
  fundCurrencyId: "",
  accCurrencyId: "",
  currencyId: "",
  exchangeRate: 1,
  fxRate: 1,
  amount: 0,
  description: "",
  notes: "",
  date: new Date().toISOString().split("T")[0],
};

export default function TreasuryPage() {
  const qc = useQueryClient();
  const { settings } = useSettings();
  const { data: transactions = [], isLoading } = useListTreasuryTransactions();
  const { data: summary } = useGetTreasurySummary();
  const { data: allAccounts = [] } = useListAccounts();
  const { data: currencies = [] } = useListCurrencies();
  const createTx = useCreateTreasuryTransaction();
  const createAccount = useCreateAccount();
  const { toast } = useToast();

  const [open, setOpen] = useState(false);
  const [addAccOpen, setAddAccOpen] = useState(false);
  const [shareOpen, setShareOpen] = useState(false);
  const [sharePhone, setSharePhone] = useState("");
  const [shareMsg, setShareMsg] = useState("");
  const [search, setSearch] = useState("");
  const [filterType, setFilterType] = useState<string>("all");
  const [form, setForm] = useState({ ...defaultForm });
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [newAcc, setNewAcc] = useState({ nameAr: "", type: "assets", subSubType: "cash", phone: "", address: "" });
  const [pageSize, setPageSize] = useState(25);
  const [editTx, setEditTx] = useState<any>(null);
  const [editDescription, setEditDescription] = useState("");
  const [editNotes, setEditNotes] = useState("");
  const [editAmount, setEditAmount] = useState(0);
  const [editDate, setEditDate] = useState("");
  const [showCalc, setShowCalc] = useState(false);
  const [calcExpr, setCalcExpr] = useState("");
  const [customVoucherNum, setCustomVoucherNum] = useState<string>("");
  const [accountSearch, setAccountSearch] = useState("");
  const [accDropOpen, setAccDropOpen] = useState(false);

  const set = (k: string, v: any) => setForm(f => ({ ...f, [k]: v }));

  const applyCalc = () => {
    try {
      // eslint-disable-next-line no-new-func
      const v = Function('"use strict"; return (' + calcExpr.replace(/×/g, "*").replace(/÷/g, "/") + ")")();
      if (!isNaN(Number(v))) { set("amount", Number(v)); setCalcExpr(""); setShowCalc(false); }
    } catch { /**/ }
  };
  const setNa = (k: string, v: any) => setNewAcc(a => ({ ...a, [k]: v }));

  const fundAccounts = useMemo(() => (allAccounts as any[]).filter(a => !a.isMain && (a.subSubType === "cash" || a.subSubType === "bank")), [allAccounts]);
  const customerAccounts = useMemo(() => (allAccounts as any[]).filter(a => !a.isMain), [allAccounts]);

  const selectedCurrency = (currencies as any[]).find((c: any) => String(c.id) === form.currencyId);
  const isYER = !form.currencyId || selectedCurrency?.code === "YER";
  const baseRate = selectedCurrency?.exchangeRate || 1;
  const effectiveRate = form.exchangeRate || baseRate;
  const amountSar = form.amount * effectiveRate;
  const currencySymbol = selectedCurrency?.symbol || "ر.ي";

  // Fund currency (عملة الصندوق/البنك)
  const fundCurrency = (currencies as any[]).find((c: any) => String(c.id) === form.fundCurrencyId);
  const fundCurrencySymbol = fundCurrency?.symbol || "ر.ي";
  const fundCurrencyName = fundCurrency?.nameAr || "ريال يمني";

  // Account currency (عملة الحساب)
  const accCurrency = (currencies as any[]).find((c: any) => String(c.id) === form.accCurrencyId);
  const accCurrencySymbol = accCurrency?.symbol || "ر.ي";
  const accCurrencyName = accCurrency?.nameAr || "ريال يمني";

  // مصارفة: هل العملتان مختلفتان؟
  const hasFxDiff = !!(form.fundCurrencyId && form.accCurrencyId && form.fundCurrencyId !== form.accCurrencyId);
  const fxRate = hasFxDiff ? (form.fxRate || 1) : 1;
  // المبلغ بعملة الحساب (بعد تطبيق سعر الصرف)
  const accAmount = form.amount * fxRate;
  // المبلغ بعملة الصندوق (المدخل الأصلي)
  const fundAmount = form.amount;

  const deleteTxMutation = useMutation({
    mutationFn: async (id: number) => {
      const res = await fetch(`/api/treasury/${id}`, { method: "DELETE" });
      return res.json();
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: getListTreasuryTransactionsQueryKey() });
      qc.invalidateQueries({ queryKey: getGetTreasurySummaryQueryKey() });
      toast({ title: "✅ تم حذف السند" });
    }
  });

  const updateTxMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: any }) => {
      const res = await fetch(`/api/treasury/${id}`, { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify(data) });
      return res.json();
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: getListTreasuryTransactionsQueryKey() });
      toast({ title: "✅ تم تعديل السند" });
      setEditTx(null);
    }
  });

  const filtered = useMemo(() => {
    let list = transactions as any[];
    if (filterType !== "all") list = list.filter(t => t.type === filterType);
    if (search) list = list.filter(t => t.accountName?.includes(search) || t.description?.includes(search) || t.voucherNumber?.includes(search));
    return list;
  }, [transactions, filterType, search]);

  const displayedTx = pageSize === -1 ? filtered : filtered.slice(0, pageSize);

  const openEditTx = (tx: any) => {
    setEditTx(tx);
    setEditDescription(tx.description || "");
    setEditNotes(tx.notes || "");
    setEditAmount(Number(tx.amount) || 0);
    setEditDate(tx.date || new Date().toISOString().split("T")[0]);
  };

  const handleSubmit = async () => {
    if (!form.amount || form.amount <= 0) { toast({ title: "خطأ", description: "أدخل المبلغ", variant: "destructive" }); return; }
    if (!form.accountId) { toast({ title: "خطأ", description: "حدد الحساب", variant: "destructive" }); return; }

    if (form.type === "pay") {
      const fundAcc = form.fundBank ? fundAccounts.find((a: any) => a.nameAr === form.fundBank) : null;
      if (fundAcc) {
        const fundBalance = Number((fundAcc as any).openingBalance ?? 0);
        if (fundBalance <= 0) {
          toast({ title: "⛔ لا يوجد رصيد", description: `الصندوق/البنك "${form.fundBank}" لا يحتوي على رصيد`, variant: "destructive" }); return;
        }
        if (form.amount > fundBalance) {
          toast({ title: "⛔ الرصيد غير كافٍ", description: `الرصيد المتوفر: ${fundBalance.toFixed(2)}، المطلوب: ${form.amount.toFixed(2)}`, variant: "destructive" }); return;
        }
      } else if (!form.fundBank) {
        toast({ title: "⛔ حدد الصندوق أو البنك", description: "يجب تحديد الصندوق أو البنك قبل سند الصرف", variant: "destructive" }); return;
      }
    }

    const acc = customerAccounts.find(a => String(a.id) === form.accountId);
    const fundAcc = form.fundBank ? fundAccounts.find((a: any) => a.nameAr === form.fundBank) : null;
    const snapForm = { ...form };
    const snapAcc = acc;
    const snapFundAcc = fundAcc;
    const snapFundSym = fundCurrencySymbol;
    const snapAccSym = accCurrencySymbol;
    const snapHasFxDiff = hasFxDiff;
    const snapFxRate = fxRate;
    const snapFundAmount = fundAmount;          // مبلغ الصندوق (بعملة الصندوق)
    const snapAccAmount = accAmount;            // مبلغ الحساب (بعد الصرف)
    const saved = await createTx.mutateAsync({ data: {
      type: form.type, date: form.date, accountId: parseInt(form.accountId),
      accountName: acc?.nameAr, fundBank: form.fundBank,
      fundCurrencyId: form.fundCurrencyId ? parseInt(form.fundCurrencyId) : undefined,
      accCurrencyId: form.accCurrencyId ? parseInt(form.accCurrencyId) : undefined,
      currencyId: form.fundCurrencyId ? parseInt(form.fundCurrencyId) : (form.currencyId ? parseInt(form.currencyId) : undefined),
      currencyCode: fundCurrency?.code || selectedCurrency?.code || "ر.ي",
      exchangeRate: snapHasFxDiff ? snapFxRate : effectiveRate,
      amount: form.amount,
      amountSar: snapHasFxDiff ? snapAccAmount : amountSar,
      description: form.description, notes: form.notes,
    }});

    const docId = String((saved as any)?.id || Date.now());
    const docNum = (saved as any)?.voucherNumber || docId;
    const ledgerEntries: any[] = [];
    const desc = snapForm.description || (snapForm.type === "receive" ? "سند قبض" : "سند صرف");
    const fxNote = snapHasFxDiff ? ` (صرف: ${snapFxRate} ${snapFundSym}→${snapAccSym})` : "";

    if (snapForm.type === "receive") {
      // قبض: مدين الصندوق/البنك بالمبلغ الأصلي، دائن الحساب بالمبلغ بعد الصرف
      if (snapFundAcc) ledgerEntries.push({
        id: makeId(), date: snapForm.date, docType: "receipt" as const, docNumber: docNum, docId,
        accountId: (snapFundAcc as any).id,
        debit: snapFundAmount, credit: 0,
        description: `${desc} — ${snapAcc?.nameAr || ""}${fxNote}`,
        currencySymbol: snapFundSym,
        ref: snapAcc?.nameAr,
      });
      if (snapAcc) ledgerEntries.push({
        id: makeId(), date: snapForm.date, docType: "receipt" as const, docNumber: docNum, docId,
        accountId: (snapAcc as any).id,
        debit: 0, credit: snapAccAmount,
        description: `${desc} — دائن${fxNote}`,
        currencySymbol: snapAccSym,
        ref: snapFundAcc ? (snapFundAcc as any).nameAr : "",
      });
    } else {
      // صرف: مدين الحساب بالمبلغ بعد الصرف، دائن الصندوق/البنك بالمبلغ الأصلي
      if (snapAcc) ledgerEntries.push({
        id: makeId(), date: snapForm.date, docType: "payment" as const, docNumber: docNum, docId,
        accountId: (snapAcc as any).id,
        debit: snapAccAmount, credit: 0,
        description: `${desc} — مدين${fxNote}`,
        currencySymbol: snapAccSym,
        ref: snapFundAcc ? (snapFundAcc as any).nameAr : "",
      });
      if (snapFundAcc) ledgerEntries.push({
        id: makeId(), date: snapForm.date, docType: "payment" as const, docNumber: docNum, docId,
        accountId: (snapFundAcc as any).id,
        debit: 0, credit: snapFundAmount,
        description: `${desc} — ${snapAcc?.nameAr || ""}${fxNote}`,
        currencySymbol: snapFundSym,
        ref: snapAcc?.nameAr,
      });
    }
    postToLedger(ledgerEntries);
    const autoShareMsg = settings.sendOnSave ? buildVoucherMsg() : "";
    const autoSharePhone = settings.sendOnSave ? ((snapAcc as any)?.phone || "") : "";

    qc.invalidateQueries({ queryKey: getListTreasuryTransactionsQueryKey() });
    qc.invalidateQueries({ queryKey: getGetTreasurySummaryQueryKey() });

    setOpen(false);
    setForm({ ...defaultForm }); setImagePreview(null);
    toast({ title: `✅ تم حفظ سند ${form.type === "receive" ? "القبض" : "الصرف"}` });
    if (settings.sendOnSave) { setSharePhone(autoSharePhone); setShareMsg(autoShareMsg); setShareOpen(true); }
  };

  const handleAddAccount = async () => {
    if (!newAcc.nameAr) { toast({ title: "خطأ", description: "اسم الحساب مطلوب", variant: "destructive" }); return; }
    const res = await createAccount.mutateAsync({ data: { nameAr: newAcc.nameAr, type: newAcc.type, subSubType: newAcc.subSubType, phone: newAcc.phone, address: newAcc.address } });
    qc.invalidateQueries({ queryKey: getListAccountsQueryKey() });
    setAddAccOpen(false);
    // إذا كان الحساب الجديد صندوقاً أو بنكاً → اختَره في قائمة الصناديق
    if (newAcc.subSubType === "cash" || newAcc.subSubType === "bank") {
      set("fundBank", newAcc.nameAr);
    } else {
      set("accountId", String((res as any).id));
      setAccountSearch(newAcc.nameAr);
    }
    setNewAcc({ nameAr: "", type: "assets", subSubType: "cash", phone: "", address: "" });
    toast({ title: "✅ تم إنشاء الحساب" });
  };

  const SEP = "─────────────────────";

  const buildVoucherMsg = (tx?: any) => {
    const isReceive = tx ? tx.type === "receive" : form.type === "receive";
    const typeLabel = isReceive ? "سند قبض" : "سند صرف";
    const emoji = isReceive ? "📥" : "📤";
    const sym = tx ? (tx.currencyCode || "ر.ي") : currencySymbol;
    const amt = tx ? Number(tx.amount) : form.amount;
    const vNum = tx?.voucherNumber || "جديد";
    const accName = tx ? tx.accountName : customerAccounts.find(a => String(a.id) === form.accountId)?.nameAr || "";
    const desc = tx ? tx.description : form.description;
    const txDate = tx ? tx.date : form.date;
    const notes = tx ? tx.notes : form.notes;
    const fmt = (n: number) => n.toLocaleString("ar-YE", { minimumFractionDigits: 0, maximumFractionDigits: 2 });
    return [
      `${emoji} *${typeLabel} — قـويـره سوفت*`,
      `رقم السند: *${vNum}*`,
      `التاريخ: ${txDate}`,
      `الحساب: ${accName}`,
      SEP,
      `💰 *المبلغ: ${fmt(amt)} ${sym}*`,
      desc ? `البيان: ${desc}` : "",
      notes ? `📝 ملاحظة: ${notes}` : "",
      SEP,
      "قـويـره سوفت — نظام المحاسبة المتكامل"
    ].filter(Boolean).join("\n");
  };

  const handlePrintVoucher = (tx?: any) => {
    const isReceive = tx ? tx.type === "receive" : form.type === "receive";
    const typeLabel = isReceive ? "سند قبض" : "سند صرف";
    const sym = tx ? (tx.currencyCode || "ر.ي") : currencySymbol;
    const amt = tx ? Number(tx.amount) : form.amount;
    const accName = tx ? tx.accountName : customerAccounts.find(a => String(a.id) === form.accountId)?.nameAr || "";
    const desc = tx ? tx.description : form.description;
    const notes = tx ? tx.notes : form.notes;
    printDocument(
      typeLabel,
      [
        { label: "رقم السند", value: tx?.voucherNumber || "—" },
        { label: "التاريخ", value: tx?.date || form.date },
        { label: "الحساب", value: accName },
        { label: "الصندوق / البنك", value: tx?.fundBank || form.fundBank || "—" },
        { label: "العملة", value: sym },
        { label: "البيان", value: desc || "—" },
      ],
      ["البند", "القيمة"],
      [
        ["المبلغ", `${amt.toFixed(2)} ${sym}`],
        ...(amountSar !== amt ? [["يعادل بالريال", `${amountSar.toFixed(2)} ر.ي`]] : []),
      ],
      [{ label: "💰 إجمالي المبلغ", value: `${amt.toFixed(2)} ${sym}` }],
      { ...settings, numberToWords: settings.numberToWords, currencyNameAr: selectedCurrency?.nameAr || "ريال يمني" },
      notes ? `ملاحظات: ${notes}` : ""
    );
  };

  const openShareForTx = (tx: any) => {
    const acc = customerAccounts.find(a => a.id === tx.accountId);
    setSharePhone((acc as any)?.phone || "");
    setShareMsg(buildVoucherMsg(tx));
    setShareOpen(true);
  };

  const openShareFromForm = () => {
    const acc = customerAccounts.find(a => String(a.id) === form.accountId);
    setSharePhone((acc as any)?.phone || "");
    setShareMsg(buildVoucherMsg());
    setShareOpen(true);
  };

  return (
    <div className="space-y-5 animate-in fade-in duration-300">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-amber-400">صرف / قبض</h1>
          <p className="text-emerald-200 mt-1">سندات القبض والصرف</p>
        </div>
        <Button onClick={() => { setForm({ ...defaultForm, fundBank: settings.defaultFund || "", notes: settings.voucherNotes || "" }); setOpen(true); }} className="bg-amber-500 hover:bg-amber-400 text-white gap-2 h-11 px-5">
          <Plus className="w-4 h-4" /> سند جديد
        </Button>
      </div>

      {summary && (
        <div className="grid grid-cols-3 gap-3">
          {[
            { label: "إجمالي القبض", value: (summary as any).totalReceive || 0, color: "text-green-400", bg: "border-green-600/40 bg-green-900/20" },
            { label: "إجمالي الصرف", value: (summary as any).totalPay || 0, color: "text-red-400", bg: "border-red-600/40 bg-red-900/20" },
            { label: "صافي الرصيد", value: ((summary as any).totalReceive || 0) - ((summary as any).totalPay || 0), color: "text-amber-400", bg: "border-amber-600/40 bg-amber-900/20" },
          ].map((s, i) => (
            <div key={i} className={`rounded-xl p-4 border ${s.bg}`}>
              <p className="text-emerald-300 text-xs">{s.label}</p>
              <p className={`text-xl font-bold ${s.color}`}>{Number(s.value).toFixed(2)} ر.ي</p>
            </div>
          ))}
        </div>
      )}

      <div className="flex gap-2 items-center">
        <div className="relative flex-1">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-emerald-400" />
          <Input value={search} onChange={e => setSearch(e.target.value)} placeholder="بحث في السندات..." className="bg-emerald-900/50 border-emerald-700 text-white pr-10 placeholder:text-emerald-500" />
        </div>
        <div className="flex rounded-xl overflow-hidden border border-emerald-700">
          {[["all", "الكل"], ["receive", "قبض"], ["pay", "صرف"]].map(([v, l]) => (
            <button key={v} onClick={() => setFilterType(v)}
              className={`px-4 py-2 text-sm font-bold transition-colors ${filterType === v ? "bg-amber-500 text-white" : "text-emerald-300 hover:bg-white/10"}`}>{l}</button>
          ))}
        </div>
        <Select value={String(pageSize)} onValueChange={v => setPageSize(Number(v))}>
          <SelectTrigger className="bg-emerald-900 border-emerald-700 text-white h-10 w-28 text-sm"><SelectValue /></SelectTrigger>
          <SelectContent className="bg-emerald-900 border-emerald-700">
            {[10, 25, 50, 100, -1].map(n => <SelectItem key={n} value={String(n)} className="text-white text-sm">{n === -1 ? "الكل" : `${n}`}</SelectItem>)}
          </SelectContent>
        </Select>
      </div>

      <div className="bg-white/5 rounded-xl border border-white/10 overflow-x-auto">
        <table className="w-full text-sm min-w-max">
          <thead className="bg-emerald-800/50">
            <tr>
              <th className="p-2.5 text-center text-amber-300 w-12">#</th>
              <th className="p-2.5 text-right text-amber-300">النوع</th>
              <th className="p-2.5 text-right text-amber-300">الحساب</th>
              <th className="p-2.5 text-right text-amber-300">التاريخ</th>
              <th className="p-2.5 text-right text-amber-300">المبلغ</th>
              <th className="p-2.5 text-right text-amber-300">العملة</th>
              <th className="p-2.5 text-right text-amber-300">البيان</th>
              <th className="p-2.5 text-center text-amber-300">إجراءات</th>
            </tr>
          </thead>
          <tbody>
            {isLoading ? <tr><td colSpan={8} className="p-6 text-center text-emerald-200">جاري التحميل...</td></tr>
            : displayedTx.length === 0 ? <tr><td colSpan={8} className="p-8 text-center text-emerald-300">لا توجد سندات</td></tr>
            : displayedTx.map((tx: any) => {
              const cfg = typeConfig[tx.type as VoucherType] || typeConfig.receive;
              return (
                <tr key={tx.id} className="border-t border-white/5 hover:bg-emerald-800/30 transition-colors">
                  <td className="p-2.5">
                    <span className="text-amber-400 font-black">{tx.voucherNumber || tx.transactionNumber}</span>
                  </td>
                  <td className="p-2.5">
                    <span className={`px-2 py-0.5 rounded-full text-xs font-bold ${cfg.bg}`}>
                      {tx.type === "receive" ? "▼ قبض" : "▲ صرف"}
                    </span>
                  </td>
                  <td className="p-2.5 text-white font-semibold text-sm whitespace-nowrap">{tx.accountName || "—"}</td>
                  <td className="p-2.5 text-emerald-300 text-sm whitespace-nowrap">{tx.date}</td>
                  <td className="p-2.5 whitespace-nowrap"><span className={`font-black text-sm ${tx.type === "receive" ? "text-green-400" : "text-red-400"}`}>{Number(tx.amount).toFixed(2)}</span></td>
                  <td className="p-2.5 text-emerald-300 text-xs whitespace-nowrap">{tx.currencyCode || "ر.ي"}{tx.exchangeRate && tx.exchangeRate !== 1 ? ` (×${Number(tx.exchangeRate).toFixed(2)})` : ""}</td>
                  <td className="p-2.5 text-emerald-200 text-xs max-w-[150px] truncate">{tx.description || "—"}</td>
                  <td className="p-2.5">
                    <div className="flex gap-1 justify-center">
                      <Button size="sm" variant="ghost" className="text-amber-400 h-7 w-7 p-0" title="تعديل" onClick={() => openEditTx(tx)}><Edit2 className="w-3.5 h-3.5" /></Button>
                      <Button size="sm" variant="ghost" className="text-blue-400 h-7 w-7 p-0" onClick={() => handlePrintVoucher(tx)}><Printer className="w-3.5 h-3.5" /></Button>
                      <Button size="sm" variant="ghost" className="text-green-400 h-7 w-7 p-0" onClick={() => openShareForTx(tx)}><Share2 className="w-3.5 h-3.5" /></Button>
                      {settings.allowDeleteInvoices && <Button size="sm" variant="ghost" className="text-red-400 h-7 w-7 p-0" title="حذف" onClick={() => deleteTxMutation.mutate(tx.id)}><Trash2 className="w-3.5 h-3.5" /></Button>}
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {pageSize !== -1 && filtered.length > pageSize && (
        <div className="text-center text-emerald-400 text-sm">
          يُعرض {pageSize} من {filtered.length} — <button className="text-amber-400 underline" onClick={() => setPageSize(-1)}>عرض الكل</button>
        </div>
      )}

      <ShareDocumentDialog
        open={shareOpen}
        onClose={() => setShareOpen(false)}
        docTitle={form.type === "receive" ? "سند قبض" : "سند صرف"}
        message={shareMsg}
        phone={sharePhone}
        onPrintPDF={() => handlePrintVoucher()}
      />

      {/* Edit Voucher Dialog */}
      <Dialog open={!!editTx} onOpenChange={v => !v && setEditTx(null)}>
        <DialogContent className="max-w-sm text-white border-amber-700" dir="rtl" style={{background: "linear-gradient(135deg, #022c22, #064E3B)"}}>
          <DialogHeader><DialogTitle className="text-amber-400">✏️ تعديل السند</DialogTitle></DialogHeader>
          <div className="space-y-4 py-2">
            <div className="bg-emerald-800/40 rounded-xl p-3 border border-emerald-700 text-sm space-y-1">
              <p className="text-emerald-300">رقم السند: <span className="text-white font-mono">{editTx?.voucherNumber}</span></p>
              <p className="text-emerald-300">النوع: <span className={editTx?.type === "receive" ? "text-green-400" : "text-red-400"}>{editTx?.type === "receive" ? "▼ سند قبض" : "▲ سند صرف"}</span></p>
              <p className="text-emerald-300">الحساب: <span className="text-white">{editTx?.accountName || "—"}</span></p>
              <p className="text-emerald-300">العملة: <span className="text-amber-300 font-bold">{editTx?.currencyCode || "ر.ي"}</span></p>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label className="text-emerald-300 text-sm">التاريخ</Label>
                <Input type="date" value={editDate} onChange={e => setEditDate(e.target.value)} className="bg-emerald-900 border-emerald-700 text-white mt-1 h-10 text-sm" />
              </div>
              <div>
                <Label className="text-emerald-300 text-sm">المبلغ</Label>
                <Input type="number" step="0.01" min="0" value={editAmount || ""} onChange={e => setEditAmount(parseFloat(e.target.value)||0)} className="bg-emerald-900 border-amber-600 text-amber-300 mt-1 h-10 text-sm font-bold text-center border" />
              </div>
            </div>
            <div>
              <Label className="text-emerald-300 text-sm">البيان</Label>
              <Input value={editDescription} onChange={e => setEditDescription(e.target.value)} className="bg-emerald-900 border-emerald-700 text-white mt-1 h-10 text-sm" placeholder="وصف السند..." />
            </div>
            <div>
              <Label className="text-emerald-300 text-sm">ملاحظات</Label>
              <Input value={editNotes} onChange={e => setEditNotes(e.target.value)} className="bg-emerald-900 border-emerald-700 text-white mt-1 h-10 text-sm" placeholder="أضف ملاحظة..." />
            </div>
            <div className="flex gap-2">
              <Button onClick={() => updateTxMutation.mutate({ id: editTx.id, data: { description: editDescription, notes: editNotes, amount: editAmount, date: editDate } })} disabled={updateTxMutation.isPending} className="flex-1 bg-amber-500 hover:bg-amber-400 text-white">{updateTxMutation.isPending ? "..." : "حفظ التعديل"}</Button>
              <Button variant="ghost" onClick={() => setEditTx(null)} className="text-emerald-300 border border-emerald-700">إلغاء</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Voucher Dialog */}
      <Dialog open={open} onOpenChange={v => { if (!v) { setForm({ ...defaultForm }); setImagePreview(null); setAccountSearch(""); setAccDropOpen(false); } setOpen(v); }}>
        <DialogContent className="max-w-md p-0 text-white border-emerald-700 overflow-hidden" dir="rtl" style={{background: "linear-gradient(135deg, #022c22, #064E3B)"}}>
          <div className="sticky top-0 z-20 flex items-center gap-1.5 px-3 py-2.5 border-b border-emerald-700" style={{background: "rgba(6,78,59,0.95)"}}>
            <Button size="sm" variant="ghost" onClick={() => { setOpen(false); setForm({ ...defaultForm }); setImagePreview(null); }} className="text-emerald-200 hover:text-white h-8 w-8 p-0">
              <ArrowRight className="w-4 h-4" />
            </Button>
            <span className="flex-1 text-center font-bold text-sm" style={{color: form.type === "receive" ? "#34d399" : "#f87171"}}>
              {form.type === "receive" ? "▼ سند قبض" : "▲ سند صرف"}
            </span>
            <Button size="sm" onClick={handleSubmit} disabled={createTx.isPending} className={`h-8 px-3 text-xs font-bold gap-1 text-white ${form.type === "receive" ? "bg-green-700 hover:bg-green-600" : "bg-red-700 hover:bg-red-600"}`}>
              {createTx.isPending ? "..." : "حفظ"}
            </Button>
            <Button size="sm" variant="ghost" onClick={() => handlePrintVoucher()} className="text-red-400 hover:text-red-300 h-8 w-8 p-0">
              <FileText className="w-4 h-4" />
            </Button>
            <Button size="sm" variant="ghost" onClick={openShareFromForm} className="text-blue-400 hover:text-blue-300 h-8 w-8 p-0">
              <ImageIcon className="w-4 h-4" />
            </Button>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button size="sm" variant="ghost" className="text-emerald-300 hover:text-white h-8 w-8 p-0">
                  <MoreVertical className="w-4 h-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent className="bg-emerald-900 border-emerald-700 text-white" align="end">
                <DropdownMenuItem className="text-white gap-2 cursor-pointer" onClick={openShareFromForm}><Share2 className="w-4 h-4 text-blue-400" /> مشاركة</DropdownMenuItem>
                <DropdownMenuItem className="text-white gap-2 cursor-pointer" onClick={() => { const acc = customerAccounts.find(a => String(a.id) === form.accountId); const m = buildVoucherMsg(); window.location.href = `sms:${((acc as any)?.phone || "").replace(/\D/g, "")}?body=${encodeURIComponent(m)}`; }}><Send className="w-4 h-4 text-purple-400" /> SMS</DropdownMenuItem>
                <DropdownMenuItem className="text-green-400 gap-2 cursor-pointer" onClick={() => { const acc = customerAccounts.find(a => String(a.id) === form.accountId); const m = encodeURIComponent(buildVoucherMsg()); const ph = ((acc as any)?.phone || "").replace(/\D/g, ""); window.open(ph ? `https://wa.me/${ph}?text=${m}` : `https://wa.me/?text=${m}`, "_blank"); }}><MessageCircle className="w-4 h-4" /> واتساب</DropdownMenuItem>
                <DropdownMenuItem className="text-blue-400 gap-2 cursor-pointer" onClick={() => { window.open(`https://t.me/share/url?text=${encodeURIComponent(buildVoucherMsg())}`, "_blank"); }}><Send className="w-4 h-4" /> تيليجرام</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>

          <div className="overflow-y-auto max-h-[82vh] p-4 space-y-4">

            {/* رقم السند + التاريخ */}
            <div className="flex items-center gap-3 bg-emerald-900/50 rounded-xl px-3 py-2.5 border border-emerald-700/40">
              <span className="text-emerald-400 text-xs shrink-0">رقم السند</span>
              <Input
                value={customVoucherNum}
                onChange={e => setCustomVoucherNum(e.target.value)}
                placeholder="تلقائي"
                className="bg-amber-500/20 border-amber-500/40 text-amber-300 font-black text-center h-8 w-24 text-sm"
              />
              <div className="w-px h-6 bg-white/10" />
              <span className="text-emerald-400 text-xs shrink-0">التاريخ</span>
              <Input type="date" value={form.date} onChange={e => set("date", e.target.value)}
                disabled={!settings.editVoucherDate}
                className="bg-transparent border-none text-white text-sm p-0 h-auto focus-visible:ring-0 flex-1" />
            </div>

            {/* Type Toggle */}
            <div className="flex rounded-xl overflow-hidden border border-emerald-700">
              <button onClick={() => set("type", "receive")} className={`flex-1 py-3.5 font-bold transition-all flex items-center justify-center gap-2 text-base ${form.type === "receive" ? "bg-green-700 text-white" : "text-emerald-300 hover:bg-white/10"}`}>
                <ArrowDownCircle className="w-5 h-5" /> قبض
              </button>
              <button onClick={() => set("type", "pay")} className={`flex-1 py-3.5 font-bold transition-all flex items-center justify-center gap-2 text-base ${form.type === "pay" ? "bg-red-700 text-white" : "text-emerald-300 hover:bg-white/10"}`}>
                <ArrowUpCircle className="w-5 h-5" /> صرف
              </button>
            </div>

            {/* الصندوق / البنك + عملته */}
            <div>
              <div className="flex justify-between items-center mb-1">
                <Label className="text-emerald-300 text-sm">الصندوق / البنك</Label>
                <button
                  onClick={() => { setNewAcc(n => ({ ...n, subSubType: "cash" })); setAddAccOpen(true); }}
                  className="text-amber-400 text-xs flex items-center gap-1 hover:text-amber-300">
                  <Plus className="w-3 h-3" /> صندوق/بنك جديد
                </button>
              </div>
              <div className="flex gap-2 flex-wrap">
                <Select value={form.fundBank} onValueChange={v => set("fundBank", v)}>
                  <SelectTrigger className="bg-emerald-900 border-emerald-700 text-white h-11 text-sm flex-1 min-w-0">
                    <SelectValue placeholder="اختر الصندوق أو البنك" />
                  </SelectTrigger>
                  <SelectContent className="bg-emerald-900 border-emerald-700">
                    {fundAccounts.length === 0 ? (
                      <div className="px-3 py-3 text-center">
                        <p className="text-white/50 text-xs mb-2">لا توجد صناديق أو بنوك</p>
                        <button
                          onClick={() => { setNewAcc(n => ({ ...n, subSubType: "cash" })); setAddAccOpen(true); }}
                          className="text-amber-400 text-xs font-bold flex items-center gap-1 mx-auto hover:text-amber-300">
                          <Plus className="w-3 h-3" /> أنشئ صندوقاً جديداً
                        </button>
                      </div>
                    ) : (
                      fundAccounts.map((a: any) => (
                        <SelectItem key={a.id} value={a.nameAr} className="text-white text-sm">
                          {a.subSubType === "bank" ? "🏦 " : "💵 "}{a.nameAr}
                        </SelectItem>
                      ))
                    )}
                  </SelectContent>
                </Select>
                {/* عملة الصندوق */}
                <Select value={form.fundCurrencyId} onValueChange={v => set("fundCurrencyId", v)}>
                  <SelectTrigger className="bg-emerald-950 border-amber-600/60 text-amber-300 h-11 text-xs w-24 shrink-0">
                    <SelectValue placeholder="العملة" />
                  </SelectTrigger>
                  <SelectContent className="bg-emerald-900 border-emerald-700">
                    {(currencies as any[]).map((c: any) => (
                      <SelectItem key={c.id} value={String(c.id)} className="text-white text-sm">{c.symbol} — {c.nameAr || c.code}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {/* سعر الصرف بجانب عملة الصندوق — إذا كانت غير رسمية */}
                {hasFxDiff && fundCurrency && !(fundCurrency as any).isBase && (fundCurrency as any).code !== "YER" && (
                  <div className="flex items-center gap-1 bg-amber-950/60 border border-amber-600/60 rounded-lg px-2.5 h-11 shrink-0">
                    <span className="text-emerald-400 text-xs font-bold">×</span>
                    <Input
                      type="number"
                      step="0.0001"
                      min="0.0001"
                      value={form.fxRate || ""}
                      onChange={e => set("fxRate", parseFloat(e.target.value) || 1)}
                      className="w-20 bg-transparent border-none text-amber-200 h-9 text-sm text-center p-0 focus-visible:ring-0 font-bold"
                      placeholder="السعر"
                    />
                    <span className="text-white/50 text-xs">{accCurrencySymbol || "ر.ي"}</span>
                  </div>
                )}
              </div>
            </div>

            {/* Account — Autocomplete Search */}
            <div>
              <div className="flex justify-between items-center mb-1">
                <Label className="text-emerald-300 text-sm">الحساب *</Label>
                <button onClick={() => setAddAccOpen(true)} className="text-amber-400 text-xs flex items-center gap-1 hover:text-amber-300">
                  <UserPlus className="w-3 h-3" /> حساب جديد
                </button>
              </div>
              <div className="relative">
                <Input
                  value={accountSearch}
                  onChange={e => {
                    setAccountSearch(e.target.value);
                    set("accountId", "");
                    setAccDropOpen(true);
                  }}
                  onFocus={() => setAccDropOpen(true)}
                  onBlur={() => setTimeout(() => setAccDropOpen(false), 200)}
                  placeholder="ابحث باسم الحساب..."
                  className={`bg-emerald-900 border-emerald-700 text-white h-11 text-sm pr-9 ${form.accountId ? "border-amber-500" : ""}`}
                />
                <Search className="absolute right-3 top-3.5 w-4 h-4 text-emerald-400 pointer-events-none" />
                {form.accountId && (
                  <button onClick={() => { set("accountId", ""); setAccountSearch(""); }}
                    className="absolute left-2 top-3 text-white/40 hover:text-white">
                    <X className="w-4 h-4" />
                  </button>
                )}
                {accDropOpen && accountSearch && (
                  <div className="absolute z-50 w-full top-full mt-1 bg-emerald-900 border border-emerald-600 rounded-xl shadow-2xl max-h-52 overflow-y-auto">
                    {customerAccounts
                      .filter((a: any) => a.nameAr?.includes(accountSearch) || (a.accountNumber && String(a.accountNumber).includes(accountSearch)))
                      .slice(0, 12)
                      .map((a: any) => (
                        <button key={a.id} onClick={() => {
                          set("accountId", String(a.id));
                          setAccountSearch(a.nameAr);
                          setAccDropOpen(false);
                        }}
                          className={`w-full text-right px-3 py-2.5 flex items-center gap-2 hover:bg-emerald-700 transition-colors text-sm border-b border-emerald-800/60 last:border-0 ${String(a.id) === form.accountId ? "bg-emerald-700" : ""}`}>
                          <span className="text-white font-medium flex-1">{a.nameAr}</span>
                          {a.accountNumber && <span className="text-emerald-400 text-xs font-mono">{a.accountNumber}</span>}
                          {a.openingBalance !== 0 && <span className="text-amber-400 text-xs">{Number(a.openingBalance || 0).toFixed(0)}</span>}
                        </button>
                      ))}
                    {customerAccounts.filter((a: any) => a.nameAr?.includes(accountSearch)).length === 0 && (
                      <div className="px-3 py-3 text-center">
                        <p className="text-white/50 text-xs mb-2">لا يوجد حساب بهذا الاسم</p>
                        <button onClick={() => { setAddAccOpen(true); setNewAcc(n => ({...n, nameAr: accountSearch})); setAccDropOpen(false); }}
                          className="text-amber-400 text-xs hover:text-amber-300 font-bold flex items-center gap-1 mx-auto">
                          <UserPlus className="w-3 h-3" /> إضافة "{accountSearch}" كحساب جديد
                        </button>
                      </div>
                    )}
                  </div>
                )}
              </div>
              {form.accountId && (
                <p className="text-emerald-400 text-xs mt-1 flex items-center gap-1">
                  ✓ <span className="text-amber-300 font-bold">{accountSearch}</span> — محدد
                </p>
              )}
            </div>

            {/* عملة الحساب */}
            <div>
              <Label className="text-emerald-300 text-sm mb-1 block">عملة الحساب</Label>
              <div className="flex gap-2 flex-wrap">
                <Select value={form.accCurrencyId} onValueChange={v => set("accCurrencyId", v)}>
                  <SelectTrigger className="bg-emerald-950 border-amber-600/60 text-amber-300 h-11 text-sm flex-1">
                    <SelectValue placeholder="اختر عملة الحساب..." />
                  </SelectTrigger>
                  <SelectContent className="bg-emerald-900 border-emerald-700">
                    {(currencies as any[]).map((c: any) => (
                      <SelectItem key={c.id} value={String(c.id)} className="text-white text-sm">{c.symbol} — {c.nameAr || c.code}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {/* سعر الصرف بجانب عملة الحساب — إذا كانت غير رسمية */}
                {hasFxDiff && accCurrency && !(accCurrency as any).isBase && (accCurrency as any).code !== "YER" && (
                  <div className="flex items-center gap-1 bg-amber-950/60 border border-amber-600/60 rounded-lg px-2.5 h-11 shrink-0">
                    <span className="text-emerald-400 text-xs font-bold">×</span>
                    <Input
                      type="number"
                      step="0.0001"
                      min="0.0001"
                      value={form.fxRate || ""}
                      onChange={e => set("fxRate", parseFloat(e.target.value) || 1)}
                      className="w-20 bg-transparent border-none text-amber-200 h-9 text-sm text-center p-0 focus-visible:ring-0 font-bold"
                      placeholder="السعر"
                    />
                    <span className="text-white/50 text-xs">{fundCurrencySymbol || "ر.ي"}</span>
                  </div>
                )}
              </div>
            </div>

            {/* Amount - Large + Calculator */}
            <div>
              <div className="flex items-center justify-between mb-1">
                <Label className="text-emerald-300 text-sm">المبلغ *</Label>
                <button onClick={() => setShowCalc(v => !v)}
                  className={`text-xs flex items-center gap-1 px-2.5 py-1 rounded-xl border transition-colors ${showCalc ? "bg-amber-500 border-amber-400 text-white" : "bg-white/5 border-white/10 text-emerald-300 hover:border-amber-500/50"}`}>
                  🧮 آلة حاسبة
                </button>
              </div>
              <Input
                type="number"
                min="0"
                value={form.amount || ""}
                onChange={e => set("amount", parseFloat(e.target.value) || 0)}
                className={`bg-emerald-900 border-2 text-white text-2xl font-black h-16 text-center tracking-wider ${form.type === "receive" ? "border-green-600 focus:border-green-400" : "border-red-600 focus:border-red-400"}`}
                placeholder="0.00"
              />
              {showCalc && (
                <div className="mt-2 p-2 bg-emerald-950 rounded-xl border border-emerald-700 space-y-1.5">
                  <Input value={calcExpr} onChange={e => setCalcExpr(e.target.value)} placeholder="0 + 0..."
                    className="bg-emerald-900 border-emerald-600 text-white h-8 text-sm text-left font-mono" dir="ltr" />
                  <div className="grid grid-cols-4 gap-1">
                    {["7","8","9","÷","4","5","6","×","1","2","3","-","0",".","C","+"].map(k => (
                      <button key={k} onClick={() => k === "C" ? setCalcExpr("") : setCalcExpr(p => p + k)}
                        className="bg-emerald-800 hover:bg-emerald-700 text-white rounded-lg h-8 text-sm font-bold transition-colors">
                        {k}
                      </button>
                    ))}
                  </div>
                  <button onClick={applyCalc} className="w-full bg-amber-500 hover:bg-amber-400 text-white rounded-lg h-8 text-sm font-bold">
                    = تطبيق
                  </button>
                </div>
              )}

              {/* نتيجة المصارفة — سطر مدمج */}
              {hasFxDiff && form.amount > 0 && (
                <div className="mt-2 flex items-center gap-2 px-3 py-2 rounded-lg bg-emerald-950/60 border border-emerald-700/40 text-xs flex-wrap">
                  <span className="text-amber-300 font-bold">{fundAmount.toFixed(2)} {fundCurrencySymbol}</span>
                  <span className="text-emerald-400">×</span>
                  <span className="text-white font-bold">{fxRate}</span>
                  <span className="text-emerald-400">=</span>
                  <span className="text-green-300 font-black text-sm">{accAmount.toFixed(2)} {accCurrencySymbol}</span>
                  <span className="text-white/40 mr-auto">💱 {fundCurrencyName} → {accCurrencyName}</span>
                </div>
              )}

              {/* ملخص القيد المحاسبي */}
              {form.amount > 0 && (form.fundBank || form.accountId) && (
                <div className="mt-3 rounded-xl border border-emerald-700/50 bg-emerald-950/60 p-3 space-y-1.5 text-xs">
                  <p className="text-emerald-400 font-bold text-center mb-2">القيد المحاسبي</p>
                  {hasFxDiff && (
                    <div className="flex justify-center items-center gap-1 mb-1 text-amber-400/70">
                      <span>سعر الصرف:</span>
                      <span className="font-bold text-amber-300">{fxRate}</span>
                      <span>{fundCurrencySymbol}/{accCurrencySymbol}</span>
                    </div>
                  )}
                  {form.type === "receive" ? (
                    <>
                      {form.fundBank && (
                        <div className="flex justify-between items-center py-1 border-b border-emerald-800/40">
                          <span className="text-green-400">↑ مدين — {form.fundBank}</span>
                          <span className="text-green-300 font-bold">{fundAmount.toFixed(2)} {fundCurrencySymbol}</span>
                        </div>
                      )}
                      {form.accountId && (
                        <div className="flex justify-between items-center py-1">
                          <span className="text-red-400">↓ دائن — {accountSearch}</span>
                          <span className="text-red-300 font-bold">{accAmount.toFixed(2)} {accCurrencySymbol}</span>
                        </div>
                      )}
                    </>
                  ) : (
                    <>
                      {form.accountId && (
                        <div className="flex justify-between items-center py-1 border-b border-emerald-800/40">
                          <span className="text-green-400">↑ مدين — {accountSearch}</span>
                          <span className="text-green-300 font-bold">{accAmount.toFixed(2)} {accCurrencySymbol}</span>
                        </div>
                      )}
                      {form.fundBank && (
                        <div className="flex justify-between items-center py-1">
                          <span className="text-red-400">↓ دائن — {form.fundBank}</span>
                          <span className="text-red-300 font-bold">{fundAmount.toFixed(2)} {fundCurrencySymbol}</span>
                        </div>
                      )}
                    </>
                  )}
                </div>
              )}
            </div>

            {/* Statement + Camera */}
            <div className="flex gap-2 items-end">
              <div className="flex-1">
                <Label className="text-emerald-300 text-sm">البيان</Label>
                <Input value={form.description} onChange={e => set("description", e.target.value)} className="bg-emerald-900 border-emerald-700 text-white mt-1 h-11 text-sm" placeholder="وصف المبلغ..." />
              </div>
              <label className="cursor-pointer">
                <div className={`h-11 w-12 rounded-lg border-2 border-dashed flex items-center justify-center transition-colors ${imagePreview ? "border-emerald-500 bg-emerald-800" : "border-emerald-700 hover:border-amber-400"}`}>
                  {imagePreview ? <img src={imagePreview} alt="" className="h-10 w-11 object-cover rounded" /> : <Camera className="w-5 h-5 text-emerald-400" />}
                </div>
                <input type="file" accept="image/*" capture="environment" className="hidden" onChange={e => { const f = e.target.files?.[0]; if (f) setImagePreview(URL.createObjectURL(f)); }} />
              </label>
            </div>

            {/* Notes */}
            <div>
              <Label className="text-emerald-300 text-sm">ملاحظات</Label>
              <Input value={form.notes} onChange={e => set("notes", e.target.value)} className="bg-emerald-900 border-emerald-700 text-white mt-1 h-11 text-sm" />
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Add Account Dialog */}
      <Dialog open={addAccOpen} onOpenChange={setAddAccOpen}>
        <DialogContent className="max-w-sm text-white border-emerald-700" dir="rtl" style={{background: "linear-gradient(135deg, #022c22, #064E3B)"}}>
          <DialogHeader>
            <DialogTitle className="text-amber-400">
              {newAcc.subSubType === "cash" ? "💵 إنشاء صندوق جديد" : newAcc.subSubType === "bank" ? "🏦 إنشاء حساب بنكي جديد" : "إنشاء حساب جديد"}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <div>
              <Label className="text-emerald-200">نوع الحساب</Label>
              <Select value={newAcc.subSubType} onValueChange={v => {
                setNa("subSubType", v);
                if (v === "cash" || v === "bank") setNa("type", "assets");
              }}>
                <SelectTrigger className="bg-emerald-900 border-emerald-700 text-white mt-1 h-11"><SelectValue /></SelectTrigger>
                <SelectContent className="bg-emerald-900 border-emerald-700">
                  <SelectItem value="cash" className="text-white">💵 صندوق نقدي</SelectItem>
                  <SelectItem value="bank" className="text-white">🏦 حساب بنكي</SelectItem>
                  <SelectItem value="customer" className="text-white">عميل</SelectItem>
                  <SelectItem value="supplier" className="text-white">مورد</SelectItem>
                  <SelectItem value="other" className="text-white">أخرى</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-emerald-200">
                {newAcc.subSubType === "cash" ? "اسم الصندوق *" : newAcc.subSubType === "bank" ? "اسم البنك / الحساب *" : "اسم الحساب *"}
              </Label>
              <Input value={newAcc.nameAr} onChange={e => setNa("nameAr", e.target.value)} className="bg-emerald-900 border-emerald-700 text-white mt-1 h-11" placeholder={newAcc.subSubType === "cash" ? "مثال: صندوق الريال" : newAcc.subSubType === "bank" ? "مثال: البنك الأهلي" : ""} />
            </div>
            <div><Label className="text-emerald-200">رقم الجوال</Label><Input value={newAcc.phone} onChange={e => setNa("phone", e.target.value)} className="bg-emerald-900 border-emerald-700 text-white mt-1 h-11" /></div>
            <div><Label className="text-emerald-200">العنوان</Label><Input value={newAcc.address} onChange={e => setNa("address", e.target.value)} className="bg-emerald-900 border-emerald-700 text-white mt-1 h-11" /></div>
            <div className="flex gap-2">
              <Button onClick={handleAddAccount} className="bg-amber-500 hover:bg-amber-400 text-white flex-1 h-11">✅ حفظ</Button>
              <Button variant="outline" onClick={() => setAddAccOpen(false)} className="border-emerald-600 text-emerald-200 h-11">إلغاء</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
