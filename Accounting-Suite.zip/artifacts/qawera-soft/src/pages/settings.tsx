import React, { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Save, Building2, Printer, Shield, Tag, Package, Ruler, HardDrive, Bell, Settings2, Calendar, Plus, Trash2, Upload, PenLine, Eraser, Type, Palette, Users, Eye, EyeOff, Key, Maximize2, X, PencilLine } from "lucide-react";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { useSettings } from "@/contexts/SettingsContext";
import type { AppSettings } from "@/contexts/SettingsContext";

type Tab = "company" | "editing" | "print" | "security" | "categories" | "groups" | "units" | "backup" | "notifications" | "other" | "renewal" | "users";

const tabs: { id: Tab; label: string; icon: any; color: string }[] = [
  { id: "company", label: "البيانات الشخصية", icon: Building2, color: "text-emerald-400" },
  { id: "editing", label: "خيارات التعديل", icon: PencilLine, color: "text-amber-400" },
  { id: "print", label: "خيارات الطباعة", icon: Printer, color: "text-blue-400" },
  { id: "security", label: "خيارات الأمان", icon: Shield, color: "text-red-400" },
  { id: "users", label: "إدارة المستخدمين", icon: Users, color: "text-violet-400" },
  { id: "categories", label: "التصنيفات", icon: Tag, color: "text-purple-400" },
  { id: "groups", label: "مجموعة الصنف", icon: Package, color: "text-orange-400" },
  { id: "units", label: "وحدات القياس", icon: Ruler, color: "text-teal-400" },
  { id: "backup", label: "حفظ البيانات", icon: HardDrive, color: "text-yellow-400" },
  { id: "notifications", label: "الإشعارات", icon: Bell, color: "text-pink-400" },
  { id: "other", label: "خيارات أخرى", icon: Settings2, color: "text-indigo-400" },
  { id: "renewal", label: "تاريخ التجديد", icon: Calendar, color: "text-amber-400" },
];

export default function SettingsPage() {
  const { settings, updateSettings } = useSettings();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState<Tab>("company");
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [lastPos, setLastPos] = useState({ x: 0, y: 0 });
  const sigIsDrawingRef = useRef(false);
  const sigLastPosRef = useRef({ x: 0, y: 0 });
  const [penColor, setPenColor] = useState("#000000");
  const [penWidth, setPenWidth] = useState(3);
  const [logoPreview, setLogoPreview] = useState<string>(settings.logoUrl || "/logo.png");

  const [units, setUnits] = useState<string[]>(["قطعة", "لتر", "كيلو", "كيس", "كرتون", "علبة", "صندوق"]);
  const [categories, setCategories] = useState<string[]>(["عام", "مواد غذائية", "مستلزمات"]);
  const [groups, setGroups] = useState<string[]>(["عام", "مجموعة A", "مجموعة B"]);
  const [newUnit, setNewUnit] = useState("");
  const [newCat, setNewCat] = useState("");
  const [newGroup, setNewGroup] = useState("");

  const [local, setLocal] = useState<AppSettings>({ ...settings });
  const set = (k: keyof AppSettings, v: any) => setLocal(f => ({ ...f, [k]: v }));
  const [sigOpen, setSigOpen] = useState(false);
  const sigCanvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => { setLocal({ ...settings }); }, [settings]);

  // ===== Users state =====
  type UserRecord = { id: number; name: string; username: string; password: string; role: string; active: boolean; showPass: boolean };
  const [users, setUsers] = useState<UserRecord[]>([
    { id: 1, name: "المدير العام", username: "admin", password: "735162242", role: "مدير", active: true, showPass: false },
    { id: 2, name: "محاسب", username: "acc1", password: "123456", role: "محاسب", active: true, showPass: false },
  ]);
  const [showAddUser, setShowAddUser] = useState(false);
  const [newUser, setNewUser] = useState({ name: "", username: "", password: "", role: "محاسب" });
  const userRoles = ["مدير", "محاسب", "مبيعات", "مشتريات", "مخزن", "قراءة فقط"];

  const handleSave = () => {
    updateSettings({ ...local });
    toast({ title: "✅ تم حفظ الإعدادات بنجاح", description: "جميع التغييرات سارية المفعول الآن" });
  };

  // Canvas signature
  const getPos = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>, rect: DOMRect) => {
    if ("touches" in e) {
      return { x: e.touches[0].clientX - rect.left, y: e.touches[0].clientY - rect.top };
    }
    return { x: (e as React.MouseEvent).clientX - rect.left, y: (e as React.MouseEvent).clientY - rect.top };
  };

  const startDraw = (e: React.MouseEvent<HTMLCanvasElement>) => {
    setIsDrawing(true);
    const rect = canvasRef.current!.getBoundingClientRect();
    setLastPos(getPos(e, rect));
  };
  const draw = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!isDrawing || !canvasRef.current) return;
    const ctx = canvasRef.current.getContext("2d")!;
    const rect = canvasRef.current.getBoundingClientRect();
    const pos = getPos(e, rect);
    ctx.beginPath(); ctx.moveTo(lastPos.x, lastPos.y); ctx.lineTo(pos.x, pos.y);
    ctx.strokeStyle = "#000000"; ctx.lineWidth = 3; ctx.lineCap = "round"; ctx.lineJoin = "round"; ctx.stroke();
    setLastPos(pos);
  };
  const stopDraw = () => {
    setIsDrawing(false);
    if (canvasRef.current) set("signatureUrl", canvasRef.current.toDataURL());
  };
  const clearSig = () => {
    if (canvasRef.current) {
      const ctx = canvasRef.current.getContext("2d")!;
      ctx.fillStyle = "#fff"; ctx.fillRect(0, 0, canvasRef.current.width, canvasRef.current.height);
    }
    if (sigCanvasRef.current) {
      const ctx = sigCanvasRef.current.getContext("2d")!;
      ctx.fillStyle = "#fff"; ctx.fillRect(0, 0, sigCanvasRef.current.width, sigCanvasRef.current.height);
    }
    set("signatureUrl", "");
  };

  // Full-screen canvas handlers — using refs to avoid stale closure
  const getSigPos = (canvas: HTMLCanvasElement, clientX: number, clientY: number) => {
    const rect = canvas.getBoundingClientRect();
    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;
    return { x: (clientX - rect.left) * scaleX, y: (clientY - rect.top) * scaleY };
  };

  const sigStartDraw = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    e.preventDefault();
    const canvas = sigCanvasRef.current; if (!canvas) return;
    sigIsDrawingRef.current = true;
    const cx = "touches" in e ? e.touches[0].clientX : (e as React.MouseEvent).clientX;
    const cy = "touches" in e ? e.touches[0].clientY : (e as React.MouseEvent).clientY;
    sigLastPosRef.current = getSigPos(canvas, cx, cy);
  };

  const sigDraw = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    e.preventDefault();
    if (!sigIsDrawingRef.current || !sigCanvasRef.current) return;
    const canvas = sigCanvasRef.current;
    const ctx = canvas.getContext("2d")!;
    const cx = "touches" in e ? e.touches[0].clientX : (e as React.MouseEvent).clientX;
    const cy = "touches" in e ? e.touches[0].clientY : (e as React.MouseEvent).clientY;
    const pos = getSigPos(canvas, cx, cy);
    ctx.beginPath();
    ctx.moveTo(sigLastPosRef.current.x, sigLastPosRef.current.y);
    ctx.lineTo(pos.x, pos.y);
    ctx.strokeStyle = penColor;
    ctx.lineWidth = penWidth;
    ctx.lineCap = "round";
    ctx.lineJoin = "round";
    ctx.stroke();
    sigLastPosRef.current = pos;
  };

  const sigStopDraw = (e?: React.MouseEvent | React.TouchEvent) => {
    e?.preventDefault();
    sigIsDrawingRef.current = false;
    if (sigCanvasRef.current) set("signatureUrl", sigCanvasRef.current.toDataURL());
  };

  const saveSig = () => {
    if (sigCanvasRef.current) set("signatureUrl", sigCanvasRef.current.toDataURL());
    setSigOpen(false);
  };
  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) { const url = URL.createObjectURL(file); setLogoPreview(url); set("logoUrl", url); }
  };

  const sectionTitle = (title: string) => (
    <div className="flex items-center gap-2 mb-4 pb-2 border-b border-white/10">
      <div className="w-1 h-5 bg-amber-400 rounded-full" />
      <h3 className="text-amber-400 font-bold text-sm">{title}</h3>
    </div>
  );

  const switchRow = (label: string, key: keyof AppSettings, desc?: string) => (
    <div className="flex items-center justify-between py-2.5 border-b border-white/5">
      <div>
        <p className="text-white text-sm font-semibold">{label}</p>
        {desc && <p className="text-white/40 text-xs">{desc}</p>}
      </div>
      <Switch checked={!!local[key]} onCheckedChange={v => set(key, v)} />
    </div>
  );

  const renderCompany = () => (
    <div className="space-y-4">
      {sectionTitle("بيانات المنشأة")}
      <div className="grid grid-cols-2 gap-3">
        <div><Label className="text-emerald-200 text-xs">اسم المنشأة (عربي)</Label><Input value={local.companyName} onChange={e => set("companyName", e.target.value)} className="bg-emerald-900/50 border-emerald-700 text-white mt-1" /></div>
        <div><Label className="text-emerald-200 text-xs">اسم المنشأة (إنجليزي)</Label><Input value={local.companyNameEn} onChange={e => set("companyNameEn", e.target.value)} className="bg-emerald-900/50 border-emerald-700 text-white mt-1" dir="ltr" /></div>
        <div><Label className="text-emerald-200 text-xs">العنوان (عربي)</Label><Input value={local.companyAddress} onChange={e => set("companyAddress", e.target.value)} className="bg-emerald-900/50 border-emerald-700 text-white mt-1" /></div>
        <div><Label className="text-emerald-200 text-xs">العنوان (إنجليزي)</Label><Input value={local.companyAddressEn} onChange={e => set("companyAddressEn", e.target.value)} className="bg-emerald-900/50 border-emerald-700 text-white mt-1" dir="ltr" /></div>
        <div><Label className="text-emerald-200 text-xs">رقم الجوال</Label><Input value={local.phone} onChange={e => set("phone", e.target.value)} className="bg-emerald-900/50 border-emerald-700 text-white mt-1" dir="ltr" /></div>
        <div><Label className="text-emerald-200 text-xs">رقم جوال ثاني</Label><Input value={local.phone2} onChange={e => set("phone2", e.target.value)} className="bg-emerald-900/50 border-emerald-700 text-white mt-1" dir="ltr" /></div>
        <div><Label className="text-emerald-200 text-xs">البريد الإلكتروني</Label><Input value={local.email} onChange={e => set("email", e.target.value)} className="bg-emerald-900/50 border-emerald-700 text-white mt-1" dir="ltr" /></div>
        <div><Label className="text-emerald-200 text-xs">الموقع الإلكتروني</Label><Input value={(local as any).website} onChange={e => set("website" as any, e.target.value)} className="bg-emerald-900/50 border-emerald-700 text-white mt-1" dir="ltr" placeholder="www.example.com" /></div>
        <div><Label className="text-emerald-200 text-xs">المدينة</Label><Input value={(local as any).city} onChange={e => set("city" as any, e.target.value)} className="bg-emerald-900/50 border-emerald-700 text-white mt-1" placeholder="صنعاء" /></div>
        <div><Label className="text-emerald-200 text-xs">الدولة</Label><Input value={(local as any).country} onChange={e => set("country" as any, e.target.value)} className="bg-emerald-900/50 border-emerald-700 text-white mt-1" placeholder="اليمن" /></div>
        <div><Label className="text-emerald-200 text-xs">إنستقرام</Label><Input value={(local as any).instagram} onChange={e => set("instagram" as any, e.target.value)} className="bg-emerald-900/50 border-emerald-700 text-white mt-1" dir="ltr" placeholder="@username" /></div>
        <div><Label className="text-emerald-200 text-xs">فيسبوك / تيليجرام</Label><Input value={(local as any).socialLink} onChange={e => set("socialLink" as any, e.target.value)} className="bg-emerald-900/50 border-emerald-700 text-white mt-1" dir="ltr" placeholder="رابط الصفحة" /></div>
        <div><Label className="text-emerald-200 text-xs">نشاط المنشأة</Label><Input value={(local as any).businessType} onChange={e => set("businessType" as any, e.target.value)} className="bg-emerald-900/50 border-emerald-700 text-white mt-1" placeholder="تجارة عامة" /></div>
        <div><Label className="text-emerald-200 text-xs">السجل التجاري</Label><Input value={(local as any).commercialReg} onChange={e => set("commercialReg" as any, e.target.value)} className="bg-emerald-900/50 border-emerald-700 text-white mt-1" /></div>
      </div>
      {sectionTitle("الشعار")}
      <div className="flex gap-4">
        <div className="space-y-2">
          <div className="rounded-xl border-2 border-dashed border-emerald-600/50 p-3 text-center">
            <img src={logoPreview || "/logo.png"} className="w-20 h-20 object-cover mx-auto rounded-xl border border-emerald-600/30 mb-2" alt="logo" onError={e => (e.currentTarget.src = "/logo.png")} />
            <label className="cursor-pointer">
              <Button type="button" size="sm" className="bg-emerald-700 hover:bg-emerald-600 text-white gap-1 h-7 text-xs w-full" asChild>
                <span><Upload className="w-3 h-3" />رفع الشعار</span>
              </Button>
              <input type="file" accept="image/*" className="hidden" onChange={handleLogoUpload} />
            </label>
          </div>
        </div>
        <div className="flex-1 space-y-2">
          {sectionTitle("التوقيع الإلكتروني (باليد)")}
          <div className="space-y-2">
            {/* Signature Preview Thumbnail */}
            <div className="rounded-xl border border-amber-500/40 bg-white overflow-hidden" style={{minHeight: 80}}>
              {local.signatureUrl ? (
                <img src={local.signatureUrl} alt="توقيعك" className="w-full object-contain" style={{maxHeight: 80}} />
              ) : (
                <div className="flex items-center justify-center h-20 text-black/20 text-lg font-bold select-none">التوقيع</div>
              )}
            </div>
            <div className="flex gap-2 items-center">
              <Button type="button" size="sm" onClick={() => setSigOpen(true)} className="bg-amber-600 hover:bg-amber-500 text-white gap-1.5 h-9 px-4 font-bold flex-1">
                <Maximize2 className="w-4 h-4" /> فتح لوحة التوقيع
              </Button>
              {local.signatureUrl && (
                <Button type="button" size="sm" onClick={clearSig} className="bg-red-800 hover:bg-red-700 text-white gap-1 h-9 px-3">
                  <Eraser className="w-4 h-4" />
                </Button>
              )}
            </div>
            {local.signatureUrl && <p className="text-green-400 text-xs font-semibold text-center">✅ تم حفظ التوقيع</p>}
          </div>
        </div>
      </div>
    </div>
  );

  const renderPrint = () => (
    <div className="space-y-3">
      {sectionTitle("إعدادات الطباعة الأساسية")}
      {switchRow("إظهار بيانات الشركة في أعلى المطبوعات", "printHeader")}
      {switchRow("إظهار التاريخ", "showDate")}
      {switchRow("طباعة التوقيع في الفواتير والسندات", "printSignature")}
      {switchRow("تفقيط الأرقام بالكلمات", "numberToWords")}
      {switchRow("إظهار رصيد الحساب أسفل السند", "showBalance")}
      {switchRow("إخفاء عمود المستند في الكشف", "hideDocColumn")}
      {switchRow("طباعة الحساب بجميع العملات", "printByCurrency")}
      {switchRow("طباعة تصاعدياً (الأقدم أولاً)", "printAscending")}
      {switchRow("طباعة كل فاتورة في صفحة منفصلة", "printPerPage" as any)}
      {switchRow("إظهار الوقت في المطبوعات", "showTime")}
      {sectionTitle("حجم الخط ولونه في المطبوعات")}
      <div className="grid grid-cols-3 gap-3">
        <div><Label className="text-emerald-200 text-xs">حجم خط الفاتورة (طباعة)</Label><Input type="number" min="8" max="20" value={local.invoiceFontSizePrint} onChange={e => set("invoiceFontSizePrint", parseInt(e.target.value))} className="bg-emerald-900/50 border-emerald-700 text-white mt-1" /></div>
        <div><Label className="text-emerald-200 text-xs">حجم خط السند (طباعة)</Label><Input type="number" min="8" max="20" value={local.voucherFontSizePrint} onChange={e => set("voucherFontSizePrint", parseInt(e.target.value))} className="bg-emerald-900/50 border-emerald-700 text-white mt-1" /></div>
        <div>
          <Label className="text-emerald-200 text-xs">لون الخط في الطباعة</Label>
          <div className="flex gap-2 mt-1 items-center">
            <input type="color" value={local.printFontColor} onChange={e => set("printFontColor", e.target.value)} className="w-10 h-9 rounded border border-emerald-700 cursor-pointer" />
            <Input value={local.printFontColor} onChange={e => set("printFontColor", e.target.value)} className="bg-emerald-900/50 border-emerald-700 text-white text-xs" dir="ltr" />
          </div>
        </div>
      </div>
      {sectionTitle("مسميات المدين والدائن")}
      <div className="grid grid-cols-2 gap-3">
        <div><Label className="text-emerald-200 text-xs">مسمى "مدين"</Label><Input value={local.debitLabel} onChange={e => set("debitLabel", e.target.value)} className="bg-emerald-900/50 border-emerald-700 text-white mt-1" /></div>
        <div><Label className="text-emerald-200 text-xs">مسمى "دائن"</Label><Input value={local.creditLabel} onChange={e => set("creditLabel", e.target.value)} className="bg-emerald-900/50 border-emerald-700 text-white mt-1" /></div>
      </div>
      {sectionTitle("ملاحظات الطباعة (تظهر للعميل بعد الطباعة)")}
      <div className="grid grid-cols-2 gap-3">
        <div><Label className="text-emerald-200 text-xs">ملاحظة أسفل الفاتورة</Label><Textarea value={local.invoiceNotes} onChange={e => set("invoiceNotes", e.target.value)} className="bg-emerald-900/50 border-emerald-700 text-white mt-1 resize-none text-sm" rows={2} /></div>
        <div><Label className="text-emerald-200 text-xs">ملاحظة أسفل السندات</Label><Textarea value={local.voucherNotes} onChange={e => set("voucherNotes", e.target.value)} className="bg-emerald-900/50 border-emerald-700 text-white mt-1 resize-none text-sm" rows={2} /></div>
        <div><Label className="text-emerald-200 text-xs">ملاحظة أسفل القيود</Label><Textarea value={local.entryNotes} onChange={e => set("entryNotes", e.target.value)} className="bg-emerald-900/50 border-emerald-700 text-white mt-1 resize-none text-sm" rows={2} /></div>
        <div><Label className="text-emerald-200 text-xs">ملاحظة أسفل كشف الحساب</Label><Textarea value={local.statementNotes} onChange={e => set("statementNotes", e.target.value)} className="bg-emerald-900/50 border-emerald-700 text-white mt-1 resize-none text-sm" rows={2} /></div>
      </div>
    </div>
  );

  const renderSecurity = () => (
    <div className="space-y-4">
      {sectionTitle("كلمة المرور")}
      {switchRow("تفعيل كلمة المرور", "enablePassword")}
      {local.enablePassword && (
        <div><Label className="text-emerald-200 text-xs">كلمة المرور</Label>
          <Input type="password" value={local.password} onChange={e => set("password", e.target.value)} className="bg-emerald-900/50 border-emerald-700 text-white mt-1" dir="ltr" />
          <p className="text-white/40 text-xs mt-1">كلمة المرور الافتراضية: 735162242</p>
        </div>
      )}
      {sectionTitle("خيارات الأمان العامة")}
      {switchRow("إخفاء الأرقام والمبالغ عن المستخدمين العاديين", "hideAmounts", "يُخفى الإجمالي والأرباح عن غير المشرف")}
      {switchRow("منع طباعة التقارير بدون كلمة مرور", "requirePassForReports")}
      {switchRow("تأمين الإعدادات بكلمة مرور مزدوجة", "requirePassForSettings")}
    </div>
  );

  const renderEditing = () => (
    <div className="space-y-4">
      {sectionTitle("🔒 صلاحيات التعديل بعد الحفظ")}
      <div className="rounded-xl border border-amber-500/20 p-4 space-y-1" style={{background: "rgba(146,64,14,0.1)"}}>
        <p className="text-amber-300 text-xs mb-3">تحكم في صلاحية تعديل العمليات بعد الحفظ — يؤثر على جميع المستخدمين</p>
        {switchRow("السماح بتعديل الفواتير (مبيعات / مشتريات)", "allowEditInvoices", "يمكن تعديل الفاتورة بعد إنشائها")}
        {switchRow("السماح بتعديل السندات (قبض / صرف)", "allowEditVouchers", "يمكن تعديل السند بعد الحفظ")}
        {switchRow("السماح بتعديل القيود اليومية", "allowEditJournals", "يمكن تعديل القيد بعد الترحيل")}
        {switchRow("السماح بتعديل مصارفة العملات", "allowEditExchange", "يمكن تعديل عملية الصرافة")}
        {switchRow("السماح بتعديل أسماء الحسابات", "allowEditAccountNames", "يمكن تغيير اسم أي حساب")}
      </div>
      {sectionTitle("🗑️ صلاحيات الحذف")}
      <div className="rounded-xl border border-red-500/20 p-4 space-y-1" style={{background: "rgba(127,29,29,0.1)"}}>
        <p className="text-red-300 text-xs mb-3">⚠️ تحكم في صلاحية حذف العمليات — الحذف لا يمكن التراجع عنه</p>
        {switchRow("السماح بحذف الفواتير (مبيعات / مشتريات)", "allowDeleteInvoices", "يمكن حذف الفاتورة نهائياً من السجل")}
        {switchRow("السماح بحذف السندات (قبض / صرف)", "allowDeleteVouchers", "يمكن حذف السند نهائياً")}
        {switchRow("السماح بحذف القيود اليومية", "allowDeleteJournals", "يمكن حذف القيد المحاسبي")}
        {switchRow("السماح بحذف مصارفة العملات", "allowDeleteExchange", "يمكن حذف عملية الصرافة")}
      </div>
    </div>
  );

  const listManager = (title: string, items: string[], setItems: React.Dispatch<React.SetStateAction<string[]>>, newVal: string, setNewVal: React.Dispatch<React.SetStateAction<string>>) => (
    <div className="space-y-3">
      {sectionTitle(title)}
      <div className="flex gap-2">
        <Input value={newVal} onChange={e => setNewVal(e.target.value)} placeholder="أضف عنصراً جديداً..." className="bg-emerald-900/50 border-emerald-700 text-white"
          onKeyDown={e => { if (e.key === "Enter" && newVal.trim() && !items.includes(newVal.trim())) { setItems(ls => [...ls, newVal.trim()]); setNewVal(""); }}} />
        <Button type="button" onClick={() => { if (newVal.trim() && !items.includes(newVal.trim())) { setItems(ls => [...ls, newVal.trim()]); setNewVal(""); }}} className="bg-amber-500 hover:bg-amber-400 text-white shrink-0"><Plus className="w-4 h-4" /></Button>
      </div>
      <div className="space-y-1">
        {items.map((item, i) => (
          <div key={i} className="flex items-center justify-between p-2.5 rounded-xl bg-emerald-900/40 border border-emerald-700/30">
            <span className="text-white text-sm font-semibold">{item}</span>
            <Button type="button" size="sm" variant="ghost" onClick={() => setItems(ls => ls.filter((_, idx) => idx !== i))} className="text-red-400 h-7 w-7 p-0"><Trash2 className="w-3 h-3" /></Button>
          </div>
        ))}
      </div>
    </div>
  );

  const renderBackup = () => (
    <div className="space-y-3">
      {sectionTitle("خيارات الحفظ التلقائي")}
      {switchRow("حفظ النسخة الاحتياطية يومياً", "backupDaily")}
      {switchRow("تضمين الصور المرفقة في النسخة", "addImages")}
      <div className="grid grid-cols-2 gap-3">
        <div><Label className="text-emerald-200 text-xs">وقت الحفظ التلقائي</Label><Input type="time" value={local.backupTime} onChange={e => set("backupTime", e.target.value)} className="bg-emerald-900/50 border-emerald-700 text-white mt-1" /></div>
        <div><Label className="text-emerald-200 text-xs">مجلد الحفظ في الهاتف</Label><Input value={local.backupFolder} onChange={e => set("backupFolder", e.target.value)} className="bg-emerald-900/50 border-emerald-700 text-white mt-1" dir="ltr" /></div>
        <div><Label className="text-emerald-200 text-xs">حساب الجيميل للنسخ في الدرايف</Label><Input value={local.backupEmail} onChange={e => set("backupEmail", e.target.value)} className="bg-emerald-900/50 border-emerald-700 text-white mt-1" dir="ltr" placeholder="example@gmail.com" /></div>
        <div><Label className="text-emerald-200 text-xs">اسم المجلد في جوجل درايف</Label><Input value={local.googleDriveFolder} onChange={e => set("googleDriveFolder", e.target.value)} className="bg-emerald-900/50 border-emerald-700 text-white mt-1" /></div>
      </div>
    </div>
  );

  const renderNotifications = () => (
    <div className="space-y-3">
      {sectionTitle("قنوات الإشعارات")}
      {switchRow("إشعار واتساب", "enableWhatsapp", "إرسال إشعار عبر واتساب عند كل عملية")}
      {switchRow("رسالة نصية SMS", "enableSms")}
      {switchRow("إشعار تيليجرام", "enableTelegram")}
      {switchRow("واتساب للأعمال (Business)", "useBusinessWhatsapp")}
      {switchRow("إرسال تلقائياً عند الحفظ", "sendOnSave")}
      {switchRow("إرفاق صورة PDF مع الإشعار", "attachInvoiceImage")}
      {sectionTitle("نص الرسائل")}
      <div className="grid grid-cols-2 gap-3">
        <div><Label className="text-emerald-200 text-xs">مقدمة الرسالة</Label><Textarea value={local.msgPrefix} onChange={e => set("msgPrefix", e.target.value)} className="bg-emerald-900/50 border-emerald-700 text-white mt-1 resize-none text-sm" rows={2} /></div>
        <div><Label className="text-emerald-200 text-xs">نهاية الرسالة</Label><Textarea value={local.msgSuffix} onChange={e => set("msgSuffix", e.target.value)} className="bg-emerald-900/50 border-emerald-700 text-white mt-1 resize-none text-sm" rows={2} /></div>
        <div><Label className="text-emerald-200 text-xs">كلمة "عليك" (المدين)</Label><Input value={local.msgDebit} onChange={e => set("msgDebit", e.target.value)} className="bg-emerald-900/50 border-emerald-700 text-white mt-1" /></div>
        <div><Label className="text-emerald-200 text-xs">كلمة "لك" (الدائن)</Label><Input value={local.msgCredit} onChange={e => set("msgCredit", e.target.value)} className="bg-emerald-900/50 border-emerald-700 text-white mt-1" /></div>
        <div>
          <Label className="text-emerald-200 text-xs">تنسيق صورة الفاتورة</Label>
          <Select value={local.invoiceImageType} onValueChange={v => set("invoiceImageType", v)}>
            <SelectTrigger className="bg-emerald-900/50 border-emerald-700 text-white mt-1"><SelectValue /></SelectTrigger>
            <SelectContent className="bg-emerald-900 border-emerald-700">
              <SelectItem value="pdf" className="text-white">PDF</SelectItem>
              <SelectItem value="jpg" className="text-white">JPEG</SelectItem>
              <SelectItem value="png" className="text-white">PNG</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>
    </div>
  );

  const renderOther = () => (
    <div className="space-y-3">
      {sectionTitle("الإعدادات المالية")}
      <div className="grid grid-cols-2 gap-3">
        <div><Label className="text-emerald-200 text-xs">بداية السنة المالية</Label>
          <Select value={(local as any).fiscalYearStart || "01-01"} onValueChange={v => set("fiscalYearStart" as any, v)}>
            <SelectTrigger className="bg-emerald-900/50 border-emerald-700 text-white mt-1"><SelectValue /></SelectTrigger>
            <SelectContent className="bg-emerald-900 border-emerald-700">
              {[["01-01","1 يناير"],["04-01","1 أبريل"],["07-01","1 يوليو"],["10-01","1 أكتوبر"]].map(([v,l]) =>
                <SelectItem key={v} value={v} className="text-white">{l}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
        <div><Label className="text-emerald-200 text-xs">طريقة ترقيم الفواتير</Label>
          <Select value={(local as any).invoiceNumbering || "auto"} onValueChange={v => set("invoiceNumbering" as any, v)}>
            <SelectTrigger className="bg-emerald-900/50 border-emerald-700 text-white mt-1"><SelectValue /></SelectTrigger>
            <SelectContent className="bg-emerald-900 border-emerald-700">
              <SelectItem value="auto" className="text-white">تلقائي (1، 2، 3...)</SelectItem>
              <SelectItem value="year" className="text-white">يشمل السنة (2025-001)</SelectItem>
              <SelectItem value="prefix" className="text-white">بادئة ثابتة (INV-001)</SelectItem>
              <SelectItem value="manual" className="text-white">يدوي</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div><Label className="text-emerald-200 text-xs">بادئة رقم الفاتورة</Label>
          <Input value={(local as any).invoicePrefix || "INV"} onChange={e => set("invoicePrefix" as any, e.target.value)} className="bg-emerald-900/50 border-emerald-700 text-white mt-1" dir="ltr" placeholder="INV" />
        </div>
        <div><Label className="text-emerald-200 text-xs">أول رقم للفاتورة</Label>
          <Input type="number" value={(local as any).invoiceStartNumber || 1} onChange={e => set("invoiceStartNumber" as any, parseInt(e.target.value))} className="bg-emerald-900/50 border-emerald-700 text-white mt-1" />
        </div>
        <div><Label className="text-emerald-200 text-xs">معدل الضريبة % (اختياري)</Label>
          <Input type="number" min="0" max="100" value={(local as any).taxRate ?? 0} onChange={e => set("taxRate" as any, parseFloat(e.target.value))} className="bg-emerald-900/50 border-emerald-700 text-white mt-1" placeholder="0 = بدون ضريبة" />
        </div>
        <div><Label className="text-emerald-200 text-xs">العملة الافتراضية</Label>
          <Input value={(local as any).defaultCurrency || "ريال يمني"} onChange={e => set("defaultCurrency" as any, e.target.value)} className="bg-emerald-900/50 border-emerald-700 text-white mt-1" placeholder="ريال يمني" />
        </div>
        <div><Label className="text-emerald-200 text-xs">الصندوق/البنك الافتراضي</Label><Input value={local.defaultFund} onChange={e => set("defaultFund", e.target.value)} className="bg-emerald-900/50 border-emerald-700 text-white mt-1" /></div>
        <div><Label className="text-emerald-200 text-xs">المستودع الافتراضي</Label>
          <Input value={(local as any).defaultWarehouse || "الرئيسي"} onChange={e => set("defaultWarehouse" as any, e.target.value)} className="bg-emerald-900/50 border-emerald-700 text-white mt-1" placeholder="الرئيسي" />
        </div>
      </div>
      {sectionTitle("خيارات النظام")}
      {switchRow("تعديل تاريخ العملية في القيود", "editVoucherDate")}
      {switchRow("استعراض سنوات سابقة", "viewPreviousYears")}
      {switchRow("إضافة سعر الصنف تلقائياً في الفاتورة", "autoAddItemPrice")}
      {switchRow("إضافة الكمية (1) تلقائياً في الفاتورة", "autoAddQty1")}
      {switchRow("تحديث أسعار البيع من الفاتورة", "updatePricesOnInvoice")}
      {switchRow("إظهار الوقت في الحسابات والسندات", "showTime")}
      {switchRow("تفعيل سقف الحساب", "accountCeiling")}
      {sectionTitle("حجم الخط ولون الخط في التطبيق")}
      <div className="grid grid-cols-2 gap-3">
        <div>
          <Label className="text-emerald-200 text-xs flex items-center gap-1"><Type className="w-3 h-3" />حجم خط التطبيق</Label>
          <div className="flex items-center gap-2 mt-1">
            <input type="range" min="12" max="20" value={local.appFontSize} onChange={e => set("appFontSize", parseInt(e.target.value))} className="flex-1 accent-amber-500" />
            <span className="text-amber-400 font-bold w-8">{local.appFontSize}</span>
          </div>
        </div>
        <div>
          <Label className="text-emerald-200 text-xs flex items-center gap-1"><Palette className="w-3 h-3" />لون خط التطبيق</Label>
          <div className="flex gap-2 mt-1 items-center">
            <input type="color" value={local.appFontColor || "#ffffff"} onChange={e => set("appFontColor", e.target.value)} className="w-10 h-9 rounded border border-emerald-700 cursor-pointer" />
            <Input value={local.appFontColor} onChange={e => set("appFontColor", e.target.value)} className="bg-emerald-900/50 border-emerald-700 text-white text-xs" dir="ltr" />
          </div>
        </div>
      </div>
    </div>
  );

  const renderRenewal = () => (
    <div className="space-y-4">
      {sectionTitle("معلومات الاشتراك")}
      <div className="rounded-xl p-5 border border-amber-500/30 text-center" style={{background: "rgba(146,64,14,0.2)"}}>
        <img src={logoPreview || "/logo.png"} alt="logo" className="w-16 h-16 mx-auto rounded-xl mb-3 border border-amber-500/30 object-cover" onError={e => (e.currentTarget.src = "/logo.png")} />
        <h3 className="text-amber-400 text-xl font-black">قـويـره سوفت</h3>
        <p className="text-emerald-300 text-sm">نظام المحاسبة المالي الشامل</p>
        <p className="text-white/50 text-xs mt-2">الاشتراك السنوي: 50 ريال سعودي</p>
        <div className="mt-3 pt-3 border-t border-white/10 space-y-1">
          {local.activationNumbers.split(",").map((num, i) => (
            <p key={i} className="text-white/70 text-xs">📞 {num.trim()}</p>
          ))}
        </div>
      </div>
      <div><Label className="text-emerald-200 text-xs">تاريخ تشغيل النظام</Label><Input type="date" value={new Date().toISOString().split("T")[0]} disabled className="bg-emerald-900/50 border-emerald-700 text-white/60 mt-1" /></div>
      <div><Label className="text-emerald-200 text-xs">تاريخ انتهاء الاشتراك</Label><Input type="date" value={local.renewalDate} onChange={e => set("renewalDate", e.target.value)} className="bg-emerald-900/50 border-emerald-700 text-white mt-1" /></div>
      {sectionTitle("حد العمليات والتفعيل")}
      <div><Label className="text-emerald-200 text-xs">حد العمليات المجانية</Label>
        <Input type="number" value={local.operationsLimit} onChange={e => set("operationsLimit", parseInt(e.target.value))} className="bg-emerald-900/50 border-emerald-700 text-white mt-1" />
        <p className="text-white/40 text-xs mt-1">بعد {local.operationsLimit} عملية يتوقف النظام حتى التفعيل (الاشتراك: 50 ريال سعودي سنوياً)</p>
      </div>
      <div className="rounded-xl p-4 border border-emerald-700/30 bg-emerald-900/20">
        <p className="text-emerald-300 text-sm font-semibold mb-2">مؤشر العمليات</p>
        <div className="flex items-center gap-3">
          <div className="flex-1 h-3 rounded-full bg-emerald-900 border border-emerald-700/30">
            <div className="h-full rounded-full transition-all" style={{width: "70%", background: "linear-gradient(90deg, #10b981, #F59E0B)"}} />
          </div>
          <span className="text-amber-400 font-bold text-sm">70 / {local.operationsLimit}</span>
        </div>
        <p className="text-white/40 text-xs mt-1">للتفعيل تواصل مع الدعم الفني</p>
      </div>
      <div><Label className="text-emerald-200 text-xs">أرقام التفعيل والدعم</Label>
        <Textarea value={local.activationNumbers} onChange={e => set("activationNumbers", e.target.value)} className="bg-emerald-900/50 border-emerald-700 text-white mt-1 resize-none text-sm" rows={3} dir="ltr" />
        <p className="text-white/40 text-xs mt-1">أدخل الأرقام مفصولة بفاصلة</p>
      </div>
    </div>
  );

  const renderUsers = () => (
    <div className="space-y-4">
      {sectionTitle("إدارة المستخدمين والصلاحيات")}
      <Button type="button" onClick={() => setShowAddUser(s => !s)}
        className="bg-violet-600 hover:bg-violet-500 text-white gap-2 h-9">
        <Plus className="w-4 h-4" />{showAddUser ? "إلغاء" : "إضافة مستخدم جديد"}
      </Button>
      {showAddUser && (
        <div className="rounded-xl border border-violet-500/30 p-4 space-y-3" style={{ background: "rgba(109,40,217,0.1)" }}>
          <p className="text-violet-300 font-bold text-sm">بيانات المستخدم الجديد</p>
          <div className="grid grid-cols-2 gap-3">
            <div><Label className="text-emerald-200 text-xs">الاسم الكامل</Label>
              <Input value={newUser.name} onChange={e => setNewUser(u => ({ ...u, name: e.target.value }))} className="bg-emerald-900/50 border-emerald-700 text-white mt-1" placeholder="اسم المستخدم" /></div>
            <div><Label className="text-emerald-200 text-xs">اسم المستخدم (للدخول)</Label>
              <Input value={newUser.username} onChange={e => setNewUser(u => ({ ...u, username: e.target.value }))} className="bg-emerald-900/50 border-emerald-700 text-white mt-1" dir="ltr" placeholder="username" /></div>
            <div><Label className="text-emerald-200 text-xs">كلمة المرور</Label>
              <Input type="password" value={newUser.password} onChange={e => setNewUser(u => ({ ...u, password: e.target.value }))} className="bg-emerald-900/50 border-emerald-700 text-white mt-1" dir="ltr" /></div>
            <div><Label className="text-emerald-200 text-xs">الدور / الصلاحية</Label>
              <Select value={newUser.role} onValueChange={v => setNewUser(u => ({ ...u, role: v }))}>
                <SelectTrigger className="bg-emerald-900/50 border-emerald-700 text-white mt-1"><SelectValue /></SelectTrigger>
                <SelectContent className="bg-emerald-900 border-emerald-700">
                  {userRoles.map(r => <SelectItem key={r} value={r} className="text-white">{r}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
          </div>
          <Button type="button" onClick={() => {
            if (!newUser.name || !newUser.username || !newUser.password) return;
            setUsers(us => [...us, { ...newUser, id: Date.now(), active: true, showPass: false }]);
            setNewUser({ name: "", username: "", password: "", role: "محاسب" });
            setShowAddUser(false);
            toast({ title: "✅ تم إضافة المستخدم" });
          }} className="bg-amber-500 hover:bg-amber-400 text-white gap-2">
            <Plus className="w-4 h-4" />حفظ المستخدم
          </Button>
        </div>
      )}
      <div className="space-y-2">
        {users.map(u => (
          <div key={u.id} className={`rounded-xl border p-3 flex items-center gap-3 transition-all ${u.active ? "border-emerald-700/40 bg-emerald-900/20" : "border-red-800/30 bg-red-900/10 opacity-60"}`}>
            <div className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${u.active ? "bg-violet-600/30 border border-violet-500/40" : "bg-red-900/30 border border-red-700/40"}`}>
              <Users className={`w-5 h-5 ${u.active ? "text-violet-300" : "text-red-400"}`} />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-white font-bold text-sm">{u.name}</p>
              <div className="flex gap-3 mt-0.5 flex-wrap">
                <span className="text-emerald-300 text-xs flex items-center gap-1"><Key className="w-3 h-3" />{u.username}</span>
                <span className="text-amber-400 text-xs">{u.role}</span>
                <span className="flex items-center gap-1 text-xs text-white/50">
                  {u.showPass ? u.password : "••••••••"}
                  <button type="button" onClick={() => setUsers(us => us.map(x => x.id === u.id ? { ...x, showPass: !x.showPass } : x))} className="text-white/30 hover:text-white/70">
                    {u.showPass ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
                  </button>
                </span>
              </div>
            </div>
            <div className="flex gap-2 items-center shrink-0">
              <Switch checked={u.active} onCheckedChange={v => setUsers(us => us.map(x => x.id === u.id ? { ...x, active: v } : x))} />
              {u.id !== 1 && (
                <Button type="button" size="sm" variant="ghost" onClick={() => setUsers(us => us.filter(x => x.id !== u.id))} className="text-red-400 hover:text-red-300 h-8 w-8 p-0">
                  <Trash2 className="w-4 h-4" />
                </Button>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  const renderTab = () => {
    switch (activeTab) {
      case "company": return renderCompany();
      case "editing": return renderEditing();
      case "print": return renderPrint();
      case "security": return renderSecurity();
      case "users": return renderUsers();
      case "categories": return listManager("التصنيفات", categories, setCategories, newCat, setNewCat);
      case "groups": return listManager("مجموعات الأصناف", groups, setGroups, newGroup, setNewGroup);
      case "units": return listManager("وحدات القياس", units, setUnits, newUnit, setNewUnit);
      case "backup": return renderBackup();
      case "notifications": return renderNotifications();
      case "other": return renderOther();
      case "renewal": return renderRenewal();
    }
  };

  return (
    <div className="space-y-4 animate-in fade-in duration-300" dir="rtl">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-amber-400">الإعدادات</h1>
          <p className="text-emerald-200 mt-1">ضبط وتخصيص النظام — كل تغيير يُطبَّق فوراً</p>
        </div>
        <Button onClick={handleSave} className="bg-amber-500 hover:bg-amber-400 text-white gap-2 h-11 px-5 font-bold shadow-lg">
          <Save className="w-4 h-4" />حفظ الإعدادات
        </Button>
      </div>

      <div className="grid grid-cols-12 gap-4">
        {/* Sidebar */}
        <div className="col-span-3">
          <div className="space-y-1 sticky top-4">
            {tabs.map(t => (
              <button key={t.id} onClick={() => setActiveTab(t.id)}
                className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-sm font-semibold transition-all text-right ${activeTab === t.id ? "bg-amber-500 text-white shadow-lg" : "text-emerald-300 hover:bg-white/10 border border-transparent hover:border-white/10"}`}>
                <t.icon className={`w-4 h-4 ${activeTab === t.id ? "text-white" : t.color} shrink-0`} />
                <span className="leading-tight">{t.label}</span>
              </button>
            ))}
          </div>
        </div>
        {/* Content */}
        <div className="col-span-9">
          <div className="rounded-2xl border border-white/10 p-5 min-h-96" style={{background: "rgba(6,78,59,0.2)"}}>
            {renderTab()}
          </div>
        </div>
      </div>

      {/* ── Full-Screen Signature Dialog ── */}
      <Dialog open={sigOpen} onOpenChange={v => !v && setSigOpen(false)}>
        <DialogContent className="max-w-4xl w-full p-0 border-amber-500 overflow-hidden" dir="rtl" style={{background: "#fff", maxHeight: "95vh"}}>
          {/* Header */}
          <div className="flex items-center justify-between px-4 py-3 border-b border-amber-400/40" style={{background: "linear-gradient(135deg, #064E3B, #065F46)"}}>
            <div className="flex items-center gap-2">
              <span className="text-2xl">✍️</span>
              <div>
                <p className="text-amber-400 font-bold text-sm">لوحة التوقيع الإلكتروني</p>
                <p className="text-emerald-300 text-xs">ارسم توقيعك بالإصبع أو القلم أو الماوس</p>
              </div>
            </div>
            <div className="flex gap-2 items-center">
              <Button size="sm" variant="ghost" onClick={() => setSigOpen(false)} className="text-white/50 hover:text-white h-8 w-8 p-0">
                <X className="w-4 h-4" />
              </Button>
            </div>
          </div>
          {/* Toolbar */}
          <div className="flex items-center gap-3 px-4 py-2 border-b border-gray-200" style={{background: "#f8f8f8"}}>
            <span className="text-gray-500 text-xs font-bold">القلم:</span>
            {["#000000","#1e40af","#065F46","#991b1b"].map(c => (
              <button key={c} onClick={() => setPenColor(c)}
                className="w-7 h-7 rounded-full border-4 transition-transform hover:scale-110"
                style={{background: c, borderColor: penColor === c ? "#F59E0B" : "#ddd"}} />
            ))}
            <div className="w-px h-5 bg-gray-300 mx-1" />
            <span className="text-gray-500 text-xs font-bold">السُمك:</span>
            {[2, 3, 5, 8].map(w => (
              <button key={w} onClick={() => setPenWidth(w)}
                className={`w-8 h-8 rounded-lg border-2 flex items-center justify-center transition-colors ${penWidth === w ? "border-amber-500 bg-amber-50" : "border-gray-200 hover:border-gray-400"}`}>
                <div className="rounded-full bg-gray-700" style={{width: w * 2, height: w * 2}} />
              </button>
            ))}
            <div className="flex-1" />
            <Button size="sm" onClick={() => {
              const canvas = sigCanvasRef.current; if (!canvas) return;
              const ctx = canvas.getContext("2d")!;
              ctx.fillStyle = "#fff"; ctx.fillRect(0, 0, canvas.width, canvas.height);
              set("signatureUrl", "");
            }} className="bg-red-600 hover:bg-red-500 text-white gap-1.5 h-8 px-3 text-xs">
              <Eraser className="w-3.5 h-3.5" /> مسح الكل
            </Button>
            <Button size="sm" onClick={saveSig} className="bg-amber-500 hover:bg-amber-400 text-white gap-1.5 h-8 px-4 font-bold text-xs">
              <Save className="w-3.5 h-3.5" /> حفظ التوقيع
            </Button>
          </div>
          {/* Canvas Area */}
          <div className="relative" style={{background: "#fff"}}>
            <canvas
              ref={sigCanvasRef}
              width={1200}
              height={420}
              className="w-full block"
              style={{touchAction: "none", cursor: "crosshair", display: "block", maxHeight: "calc(95vh - 130px)", userSelect: "none"}}
              onMouseDown={sigStartDraw}
              onMouseMove={sigDraw}
              onMouseUp={sigStopDraw}
              onMouseLeave={sigStopDraw}
              onTouchStart={sigStartDraw}
              onTouchMove={sigDraw}
              onTouchEnd={sigStopDraw}
            />
            {/* Guide lines */}
            <div className="absolute bottom-10 left-8 right-8 border-b-2 border-dashed border-gray-200 pointer-events-none" />
            <div className="absolute bottom-8 right-4 text-gray-300 text-xs pointer-events-none select-none">— وقّع فوق هذا السطر</div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
