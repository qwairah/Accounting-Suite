import { useState } from "react";
import { useLocation } from "wouter";
import {
  ShoppingCart, ShoppingBag, RefreshCw, Wallet, BookOpen, BarChart3,
  Package, Tag, DollarSign, Bell,
  Settings, Database, Download, Youtube, Send, X,
  Receipt, FileBarChart, Archive, BookMarked,
  Share2, HelpCircle
} from "lucide-react";

const helpGuide = [
  { icon: "🛒", title: "المبيعات", color: "#22C55E", steps: ["اضغط على زر «فاتورة جديدة» واختر العميل من القائمة", "أضف الأصناف والكميات والأسعار — يُعدَّل الإجمالي تلقائياً", "يمنع النظام البيع تلقائياً إذا كانت الكمية أكثر من المتوفر في المخزون", "اختر نوع الدفع: نقدي أو آجل. ثم اضغط «حفظ»"] },
  { icon: "🏪", title: "المشتريات", color: "#3B82F6", steps: ["اضغط «فاتورة شراء جديدة» وحدد المورد", "أضف الأصناف وكمياتها وأسعار الشراء", "يُحدَّث المخزون تلقائياً عند حفظ الفاتورة", "يمكن الطباعة مباشرة بعد الحفظ"] },
  { icon: "💰", title: "صرف / قبض", color: "#EAB308", steps: ["«قبض» لتسجيل أموال واردة، «صرف» لتسجيل أموال صادرة", "حدد الصندوق أو البنك الذي سيُصرف منه أو يُودَع فيه", "يمنع النظام الصرف تلقائياً إذا لم يكن الرصيد كافياً", "أدخل المبلغ والملاحظات ثم احفظ السند"] },
  { icon: "📋", title: "القيد اليومي", color: "#06B6D4", steps: ["القيد المحاسبي اليدوي: مدين ودائن يجب أن يتساووا", "أضف سطرين على الأقل لكل قيد", "لا يُسمح بتكرار نفس الحساب في سطور القيد الواحد", "اكتب الوصف والتاريخ ثم اضغط «حفظ القيد»"] },
  { icon: "💱", title: "مصارفة العملات", color: "#F97316", steps: ["لعمليات تبديل العملات (شراء/بيع الدولار، اليورو...)", "حدد العملة وسعر الصرف الفعلي", "يُنشئ النظام قيداً مزدوجاً تلقائياً"] },
  { icon: "📊", title: "الحسابات", color: "#A855F7", steps: ["دليل الحسابات بـ 4 مستويات: أصول، التزامات، إيرادات، مصروفات", "اضغط «تهيئة الحسابات الرئيسية» لإنشاء شجرة الحسابات الموحدة", "كل حساب له رقم فريد يُعيَّن تلقائياً", "يمكن ضبط «سقف الحساب» للتحكم في الحد الأقصى للرصيد"] },
  { icon: "📦", title: "المخزن", color: "#10B981", steps: ["سجّل حركات المخزون: توريد، صرف، تحويل، تسوية، جرد", "راقب الكميات المتوفرة لكل صنف", "المبيعات تُقلّص الكمية، والمشتريات تزيدها تلقائياً"] },
  { icon: "🏷️", title: "الأصناف والمنتجات", color: "#F59E0B", steps: ["أضف أصنافك: الاسم، الوحدة، سعر الشراء، سعر البيع", "حدد الكمية الافتتاحية للمخزون", "يمكن إنشاء عروض أسعار وطلبات شراء"] },
  { icon: "💵", title: "العملات", color: "#06B6D4", steps: ["أضف العملات التي تتعامل بها (دولار، يورو، ريال...)", "حدد سعر الصرف مقابل الريال اليمني", "يمكن تعديل سعر الصرف عند إنشاء أي سند أو قيد"] },
  { icon: "📈", title: "التقارير المالية", color: "#EC4899", steps: ["ميزان المراجعة — الأرباح والخسائر — المركز المالي", "كشف حساب أي عميل أو مورد أو حساب", "تقارير المبيعات والمشتريات والمخزون"] },
  { icon: "💾", title: "النسخ الاحتياطي", color: "#8B5CF6", steps: ["اضغط «نسخ احتياطي» لحفظ كامل قاعدة البيانات كملف .db", "احفظ الملف في مكان آمن (USB، سحابة...)", "لاسترجاع البيانات: اضغط «استرجاع» وأرفق ملف .db", "يُنصح بالنسخ الاحتياطي يومياً"] },
  { icon: "⚙️", title: "الإعدادات", color: "#C4B5FD", steps: ["بيانات الشركة: الاسم، العنوان، الشعار، رقم الهاتف", "تخصيص الفواتير والطباعة", "تغيير كلمة المرور وإدارة المستخدمين والصلاحيات"] },
];

export default function HomePage() {
  const [, navigate] = useLocation();
  const [showBell, setShowBell] = useState(false);
  const [showHelp, setShowHelp] = useState(false);
  const [activeHelpIdx, setActiveHelpIdx] = useState<number | null>(null);
  const [ops] = useState(1);
  const [notifications, setNotifications] = useState([
    { id: 1, text: "مرحباً بك في قويرة سوفت للمحاسبة", time: "الآن", read: false },
    { id: 2, text: "تذكير: تجديد الاشتراك السنوي", time: "اليوم", read: false },
    { id: 3, text: "تم النسخ الاحتياطي بنجاح", time: "أمس", read: true },
  ]);

  const OPS_LIMIT = 100;
  const unreadCount = notifications.filter(n => !n.read).length;

  const mainModules = [
    {
      label: "المبيعات",
      icon: ShoppingCart,
      route: "/sales",
      color: "#22C55E",
      glow: "0 0 20px #22C55E, 0 0 40px #22C55E44",
      bg: "rgba(34,197,94,0.12)",
      border: "rgba(34,197,94,0.4)",
    },
    {
      label: "المشتريات",
      icon: ShoppingBag,
      route: "/purchases",
      color: "#3B82F6",
      glow: "0 0 20px #3B82F6, 0 0 40px #3B82F644",
      bg: "rgba(59,130,246,0.12)",
      border: "rgba(59,130,246,0.4)",
    },
    {
      label: "مصارفة العملات",
      icon: RefreshCw,
      route: "/exchange",
      color: "#F97316",
      glow: "0 0 20px #F97316, 0 0 40px #F9731644",
      bg: "rgba(249,115,22,0.12)",
      border: "rgba(249,115,22,0.4)",
    },
    {
      label: "صرف / قبض",
      icon: Wallet,
      route: "/treasury",
      color: "#EAB308",
      glow: "0 0 20px #EAB308, 0 0 40px #EAB30844",
      bg: "rgba(234,179,8,0.12)",
      border: "rgba(234,179,8,0.4)",
    },
    {
      label: "قيد يومي",
      icon: BookOpen,
      route: "/journal",
      color: "#06B6D4",
      glow: "0 0 20px #06B6D4, 0 0 40px #06B6D444",
      bg: "rgba(6,182,212,0.12)",
      border: "rgba(6,182,212,0.4)",
    },
    {
      label: "الحسابات",
      icon: BarChart3,
      route: "/accounts",
      color: "#A855F7",
      glow: "0 0 20px #A855F7, 0 0 40px #A855F744",
      bg: "rgba(168,85,247,0.12)",
      border: "rgba(168,85,247,0.4)",
    },
  ];

  const smallModules = [
    { label: "مخزن", icon: Package, route: "/inventory", color: "#10B981" },
    { label: "قيود", icon: BookMarked, route: "/journal-accounts", color: "#8B5CF6" },
    { label: "أصناف", icon: Tag, route: "/items", color: "#F59E0B" },
    { label: "عملات", icon: DollarSign, route: "/currencies", color: "#06B6D4" },
    { label: "تقارير", icon: FileBarChart, route: "/reports", color: "#EC4899" },
  ];

  const actionButtons = [
    { label: "نسخ احتياطي", icon: Database, route: "/backup", color: "#10B981", bg: "rgba(16,185,129,0.15)" },
    { label: "استرجاع", icon: Download, route: "/backup", color: "#3B82F6", bg: "rgba(59,130,246,0.15)" },
  ];

  const docButtons = [
    { label: "عرض سعر", icon: Receipt, route: "/quote", color: "#22C55E" },
    { label: "طلب شراء", icon: Archive, route: "/purchase-order", color: "#3B82F6" },
  ];

  return (
    <div
      dir="rtl"
      style={{
        minHeight: "100vh",
        background: "linear-gradient(160deg, #022c22 0%, #064E3B 40%, #047857 80%, #065f46 100%)",
        fontFamily: "'Tajawal', sans-serif",
        display: "flex",
        flexDirection: "column",
        paddingBottom: 24,
      }}
    >
      {/* ========== HEADER ========== */}
      <div style={{
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        padding: "12px 16px",
        background: "rgba(0,0,0,0.35)",
        backdropFilter: "blur(8px)",
        borderBottom: "1px solid rgba(251,191,36,0.2)",
        position: "sticky",
        top: 0,
        zIndex: 50,
      }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <img
            src="/logo.png"
            alt="قويرة سوفت"
            style={{
              width: 46,
              height: 46,
              borderRadius: 10,
              boxShadow: "0 0 12px rgba(251,191,36,0.5)",
              objectFit: "contain",
            }}
          />
          <div>
            <div style={{ color: "#F59E0B", fontWeight: 800, fontSize: 18, lineHeight: 1.2, letterSpacing: 1 }}>
              قـويـره سوفـت
            </div>
            <div style={{ color: "#6EE7B7", fontSize: 11, fontWeight: 500 }}>
              للمحاسبة والإدارة المالية
            </div>
          </div>
        </div>
        <div style={{ display: "flex", gap: 6 }}>
          {[
            { icon: Share2, action: async () => { try { await navigator.share({ title: "قويرة سوفت", text: "نظام المحاسبة المتكامل — قويرة سوفت", url: window.location.href }); } catch { navigator.clipboard?.writeText(window.location.href); } }, color: "#34D399", badge: false },
            { icon: HelpCircle, action: () => setShowHelp(true), color: "#F59E0B", badge: false },
            { icon: Bell, action: () => setShowBell(true), color: "#FCD34D", badge: unreadCount > 0 },
            { icon: Settings, action: () => navigate("/settings"), color: "#C4B5FD", badge: false },
          ].map((btn, i) => (
            <button
              key={i}
              onClick={btn.action}
              style={{
                position: "relative",
                width: 38,
                height: 38,
                borderRadius: 10,
                background: "rgba(255,255,255,0.06)",
                border: "1px solid rgba(255,255,255,0.12)",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                cursor: "pointer",
                color: btn.color,
              }}
            >
              <btn.icon size={18} />
              {btn.badge && (
                <span style={{
                  position: "absolute", top: 4, right: 4,
                  width: 8, height: 8, borderRadius: "50%",
                  background: "#EF4444",
                }} />
              )}
            </button>
          ))}
        </div>
      </div>

      {/* ========== OP COUNTER ========== */}
      <div style={{
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        gap: 8,
        padding: "6px 16px",
        background: "rgba(0,0,0,0.25)",
      }}>
        <span style={{ color: "#6EE7B7", fontSize: 12 }}>العمليات المتبقية:</span>
        <div style={{
          display: "flex",
          alignItems: "center",
          gap: 6,
          background: "rgba(0,0,0,0.3)",
          borderRadius: 20,
          padding: "3px 12px",
          border: "1px solid rgba(251,191,36,0.3)",
        }}>
          <span style={{
            color: ops > 80 ? "#EF4444" : ops > 50 ? "#F59E0B" : "#22C55E",
            fontWeight: 800,
            fontSize: 15,
          }}>
            {ops}
          </span>
          <span style={{ color: "#9CA3AF", fontSize: 12 }}>/ {OPS_LIMIT}</span>
        </div>
        <div style={{
          flex: 1,
          maxWidth: 120,
          height: 6,
          background: "rgba(255,255,255,0.1)",
          borderRadius: 3,
          overflow: "hidden",
        }}>
          <div style={{
            height: "100%",
            width: `${(ops / OPS_LIMIT) * 100}%`,
            background: ops > 80 ? "#EF4444" : ops > 50 ? "#F59E0B" : "#22C55E",
            borderRadius: 3,
            boxShadow: `0 0 8px ${ops > 80 ? "#EF4444" : ops > 50 ? "#F59E0B" : "#22C55E"}`,
          }} />
        </div>
      </div>

      <div style={{ flex: 1, padding: "12px 12px 0" }}>

        {/* ========== 6 MAIN MODULES (2×3 grid) ========== */}
        <div style={{
          display: "grid",
          gridTemplateColumns: "1fr 1fr 1fr",
          gap: 10,
          marginBottom: 12,
        }}>
          {mainModules.map((mod) => (
            <button
              key={mod.route}
              onClick={() => navigate(mod.route)}
              style={{
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                justifyContent: "center",
                gap: 8,
                padding: "16px 8px",
                background: mod.bg,
                border: `1px solid ${mod.border}`,
                borderRadius: 16,
                cursor: "pointer",
                backdropFilter: "blur(6px)",
                transition: "all 0.2s",
                minHeight: 90,
              }}
              onMouseEnter={e => {
                (e.currentTarget as HTMLElement).style.transform = "scale(1.04)";
                (e.currentTarget as HTMLElement).style.boxShadow = mod.glow;
              }}
              onMouseLeave={e => {
                (e.currentTarget as HTMLElement).style.transform = "scale(1)";
                (e.currentTarget as HTMLElement).style.boxShadow = "none";
              }}
            >
              <div style={{
                width: 52,
                height: 52,
                borderRadius: 14,
                background: `${mod.color}22`,
                border: `2px solid ${mod.color}`,
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                boxShadow: `0 0 16px ${mod.color}88, inset 0 0 8px ${mod.color}22`,
              }}>
                <mod.icon
                  size={26}
                  color={mod.color}
                  style={{ filter: `drop-shadow(0 0 6px ${mod.color})` }}
                />
              </div>
              <span style={{
                color: mod.color,
                fontSize: 13,
                fontWeight: 700,
                textShadow: `0 0 8px ${mod.color}88`,
              }}>
                {mod.label}
              </span>
            </button>
          ))}
        </div>

        {/* ========== 5 SMALL MODULES ========== */}
        <div style={{
          display: "flex",
          justifyContent: "space-between",
          gap: 6,
          marginBottom: 12,
          background: "rgba(0,0,0,0.2)",
          borderRadius: 14,
          padding: "10px 8px",
          border: "1px solid rgba(255,255,255,0.08)",
        }}>
          {smallModules.map((mod) => (
            <button
              key={mod.route}
              onClick={() => navigate(mod.route)}
              style={{
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                gap: 5,
                flex: 1,
                background: "transparent",
                border: "none",
                cursor: "pointer",
                padding: "4px 2px",
              }}
            >
              <div style={{
                width: 42,
                height: 42,
                borderRadius: 12,
                background: `${mod.color}18`,
                border: `1.5px solid ${mod.color}66`,
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                boxShadow: `0 0 10px ${mod.color}44`,
              }}>
                <mod.icon
                  size={20}
                  color={mod.color}
                  style={{ filter: `drop-shadow(0 0 4px ${mod.color})` }}
                />
              </div>
              <span style={{ color: "#D1FAE5", fontSize: 11, fontWeight: 600 }}>
                {mod.label}
              </span>
            </button>
          ))}
        </div>

        {/* ========== ACTION BUTTONS: BACKUP / RESTORE ========== */}
        <div style={{
          display: "grid",
          gridTemplateColumns: "1fr 1fr",
          gap: 8,
          marginBottom: 10,
        }}>
          {actionButtons.map((btn) => (
            <button
              key={btn.label}
              onClick={() => navigate(btn.route)}
              style={{
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                gap: 8,
                padding: "11px 8px",
                background: btn.bg,
                border: `1px solid ${btn.color}44`,
                borderRadius: 12,
                cursor: "pointer",
                color: btn.color,
                fontWeight: 700,
                fontSize: 14,
              }}
            >
              <btn.icon size={18} color={btn.color} />
              {btn.label}
            </button>
          ))}
        </div>

        {/* ========== DOCUMENT BUTTONS: عرض سعر / طلب شراء ========== */}
        <div style={{
          display: "grid",
          gridTemplateColumns: "1fr 1fr",
          gap: 8,
          marginBottom: 60,
        }}>
          {docButtons.map((btn) => (
            <button
              key={btn.route}
              onClick={() => navigate(btn.route)}
              style={{
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                gap: 6,
                padding: "11px 8px",
                background: `${btn.color}15`,
                border: `1px solid ${btn.color}44`,
                borderRadius: 12,
                cursor: "pointer",
                color: btn.color,
                fontWeight: 700,
                fontSize: 14,
              }}
            >
              <btn.icon size={16} color={btn.color} />
              {btn.label}
            </button>
          ))}
        </div>
      </div>

      {/* ========== FIXED BOTTOM CORNERS: YouTube (right) + Telegram (left) ========== */}
      <a
        href="https://www.youtube.com/@qawera"
        target="_blank"
        rel="noreferrer"
        style={{
          position: "fixed",
          bottom: 18,
          right: 18,
          zIndex: 40,
          display: "flex",
          alignItems: "center",
          gap: 6,
          padding: "9px 14px",
          background: "rgba(239,68,68,0.9)",
          borderRadius: 30,
          color: "#fff",
          textDecoration: "none",
          fontWeight: 700,
          fontSize: 13,
          boxShadow: "0 0 18px rgba(239,68,68,0.7)",
          backdropFilter: "blur(6px)",
          border: "1px solid rgba(255,100,100,0.5)",
        }}
      >
        <Youtube size={17} />
        يوتيوب
      </a>
      <a
        href="https://t.me/qawera_soft"
        target="_blank"
        rel="noreferrer"
        style={{
          position: "fixed",
          bottom: 18,
          left: 18,
          zIndex: 40,
          display: "flex",
          alignItems: "center",
          gap: 6,
          padding: "9px 14px",
          background: "rgba(29,155,240,0.9)",
          borderRadius: 30,
          color: "#fff",
          textDecoration: "none",
          fontWeight: 700,
          fontSize: 13,
          boxShadow: "0 0 18px rgba(29,155,240,0.7)",
          backdropFilter: "blur(6px)",
          border: "1px solid rgba(100,180,255,0.5)",
        }}
      >
        <Send size={17} />
        تيليجرام
      </a>

      {/* ========== HELP GUIDE DIALOG ========== */}
      {showHelp && (
        <div style={{ position: "fixed", inset: 0, zIndex: 200, background: "rgba(0,0,0,0.75)", display: "flex", alignItems: "center", justifyContent: "center", padding: 12 }} onClick={() => setShowHelp(false)}>
          <div style={{ width: "100%", maxWidth: 520, maxHeight: "90vh", background: "linear-gradient(160deg,#011a13,#064E3B)", border: "1px solid rgba(245,158,11,0.35)", borderRadius: 22, overflow: "hidden", boxShadow: "0 24px 70px rgba(0,0,0,0.8)" }} onClick={e => e.stopPropagation()}>
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "14px 18px", background: "rgba(0,0,0,0.4)", borderBottom: "1px solid rgba(245,158,11,0.2)" }}>
              <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                <HelpCircle size={20} color="#F59E0B" />
                <span style={{ color: "#F59E0B", fontWeight: 800, fontSize: 17 }}>دليل استخدام قويرة سوفت</span>
              </div>
              <button onClick={() => setShowHelp(false)} style={{ background: "none", border: "none", color: "#6EE7B7", cursor: "pointer" }}><X size={22} /></button>
            </div>
            <div style={{ overflowY: "auto", maxHeight: "75vh" }} dir="rtl">
              <div style={{ padding: "10px 14px" }}>
                {helpGuide.map((item, i) => (
                  <div key={i} style={{ marginBottom: 6, borderRadius: 12, overflow: "hidden", border: `1px solid ${activeHelpIdx === i ? item.color + "60" : "rgba(255,255,255,0.06)"}` }}>
                    <button onClick={() => setActiveHelpIdx(activeHelpIdx === i ? null : i)} style={{ width: "100%", display: "flex", alignItems: "center", gap: 10, padding: "10px 12px", background: activeHelpIdx === i ? `${item.color}15` : "rgba(255,255,255,0.03)", border: "none", cursor: "pointer", textAlign: "right" }}>
                      <div style={{ width: 34, height: 34, borderRadius: 9, background: `${item.color}20`, border: `1.5px solid ${item.color}50`, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 17, flexShrink: 0 }}>{item.icon}</div>
                      <span style={{ color: item.color, fontWeight: 700, fontSize: 14, flex: 1 }}>{item.title}</span>
                      <span style={{ color: "rgba(255,255,255,0.3)", fontSize: 12 }}>{activeHelpIdx === i ? "▲" : "▼"}</span>
                    </button>
                    {activeHelpIdx === i && (
                      <div style={{ padding: "8px 12px 12px 12px", background: "rgba(0,0,0,0.2)" }}>
                        {item.steps.map((step, j) => (
                          <div key={j} style={{ display: "flex", gap: 8, marginBottom: 6, alignItems: "flex-start" }}>
                            <div style={{ width: 20, height: 20, borderRadius: 6, background: `${item.color}25`, border: `1px solid ${item.color}50`, display: "flex", alignItems: "center", justifyContent: "center", color: item.color, fontSize: 10, fontWeight: 800, flexShrink: 0, marginTop: 1 }}>{j + 1}</div>
                            <p style={{ color: "#A7F3D0", fontSize: 12.5, lineHeight: 1.55, margin: 0 }}>{step}</p>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                ))}
              </div>
              <div style={{ margin: "0 14px 14px", borderRadius: 14, overflow: "hidden", border: "1px solid rgba(239,68,68,0.4)" }}>
                <div style={{ display: "flex", alignItems: "center", gap: 8, padding: "10px 12px", background: "rgba(239,68,68,0.12)", borderBottom: "1px solid rgba(239,68,68,0.2)" }}>
                  <Youtube size={18} color="#EF4444" />
                  <span style={{ color: "#FCA5A5", fontWeight: 700, fontSize: 14 }}>شرح مرئي على يوتيوب</span>
                </div>
                <div style={{ background: "rgba(0,0,0,0.4)", padding: 12 }}>
                  <div style={{ borderRadius: 10, overflow: "hidden", marginBottom: 10, aspectRatio: "16/9" }}>
                    <iframe width="100%" height="100%" src="https://www.youtube.com/embed?listType=user_uploads&list=qawera" title="شرح قويرة سوفت" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowFullScreen style={{ display: "block", border: "none", borderRadius: 10 }} />
                  </div>
                  <a href="https://www.youtube.com/@qawera" target="_blank" rel="noreferrer" style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 6, padding: "8px 16px", background: "rgba(239,68,68,0.85)", borderRadius: 8, color: "#fff", textDecoration: "none", fontWeight: 700, fontSize: 13 }}>
                    <Youtube size={16} /> زيارة القناة على يوتيوب
                  </a>
                </div>
              </div>
              <div style={{ margin: "0 14px 16px", padding: 12, background: "rgba(245,158,11,0.08)", border: "1px solid rgba(245,158,11,0.25)", borderRadius: 12, textAlign: "center" }}>
                <p style={{ color: "#F59E0B", fontWeight: 700, fontSize: 13, marginBottom: 6 }}>📞 الدعم الفني — تواصل معنا</p>
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 6 }}>
                  {["+967 771 096 572", "+967 781 055 501", "+967 715 107 412", "+967 735 162 242"].map(num => (
                    <a key={num} href={`tel:${num.replace(/\s/g, "")}`} style={{ display: "block", padding: "6px 8px", background: "rgba(16,185,129,0.12)", border: "1px solid rgba(16,185,129,0.2)", borderRadius: 8, color: "#6EE7B7", textDecoration: "none", fontSize: 12, fontWeight: 600, direction: "ltr" }}>📱 {num}</a>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========== BELL / NOTIFICATIONS DIALOG ========== */}
      {showBell && (
        <div
          style={{
            position: "fixed", inset: 0, zIndex: 100,
            background: "rgba(0,0,0,0.7)",
            display: "flex", alignItems: "flex-start", justifyContent: "flex-end",
          }}
          onClick={() => setShowBell(false)}
        >
          <div
            style={{
              width: 320,
              margin: "60px 12px 0 0",
              background: "#064E3B",
              border: "1px solid rgba(251,191,36,0.3)",
              borderRadius: 16,
              overflow: "hidden",
              boxShadow: "0 20px 60px rgba(0,0,0,0.6)",
            }}
            onClick={e => e.stopPropagation()}
          >
            <div style={{
              display: "flex", alignItems: "center", justifyContent: "space-between",
              padding: "14px 16px",
              background: "rgba(0,0,0,0.3)",
              borderBottom: "1px solid rgba(251,191,36,0.2)",
            }}>
              <span style={{ color: "#F59E0B", fontWeight: 800, fontSize: 16 }}>
                الإشعارات ({unreadCount})
              </span>
              <button onClick={() => setShowBell(false)} style={{ background: "none", border: "none", color: "#6EE7B7", cursor: "pointer" }}>
                <X size={20} />
              </button>
            </div>
            {notifications.map(n => (
              <div
                key={n.id}
                onClick={() => {
                  setNotifications(prev => prev.map(x => x.id === n.id ? { ...x, read: true } : x));
                }}
                style={{
                  padding: "12px 16px",
                  borderBottom: "1px solid rgba(255,255,255,0.06)",
                  background: n.read ? "transparent" : "rgba(251,191,36,0.06)",
                  cursor: "pointer",
                  display: "flex",
                  gap: 10,
                  alignItems: "flex-start",
                }}
              >
                <div style={{
                  width: 8, height: 8, borderRadius: "50%", marginTop: 6,
                  background: n.read ? "transparent" : "#F59E0B",
                  border: `2px solid ${n.read ? "#374151" : "#F59E0B"}`,
                  flexShrink: 0,
                }} />
                <div>
                  <div style={{ color: n.read ? "#9CA3AF" : "#D1FAE5", fontSize: 13, marginBottom: 2 }}>{n.text}</div>
                  <div style={{ color: "#6B7280", fontSize: 11 }}>{n.time}</div>
                </div>
              </div>
            ))}
            <div style={{ padding: 12 }}>
              <button
                onClick={() => setNotifications(prev => prev.map(n => ({ ...n, read: true })))}
                style={{
                  width: "100%", padding: "8px", background: "rgba(251,191,36,0.1)",
                  border: "1px solid rgba(251,191,36,0.3)", borderRadius: 8,
                  color: "#F59E0B", cursor: "pointer", fontWeight: 600, fontSize: 13,
                }}
              >
                تحديد الكل كمقروء
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
