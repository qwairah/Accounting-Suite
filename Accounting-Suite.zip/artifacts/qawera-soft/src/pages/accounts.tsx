import React, { useState, useMemo, useRef, useEffect, useCallback, TouchEvent } from "react";
import { useListAccounts, useCreateAccount, useUpdateAccount, useDeleteAccount, useListCurrencies } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { getListAccountsQueryKey } from "@workspace/api-client-react";
import { getLedger } from "@/lib/ledger";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import {
  Plus, Search, Trash2, MessageCircle, Phone, Share2, Printer, FileText, X,
  ArrowLeftRight, ChevronLeft, ChevronRight, MoreVertical, Filter, Edit2,
  Send, Bell, ShoppingCart, ShoppingBag, PenLine, Download, Eye, ArrowLeft
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useSettings } from "@/contexts/SettingsContext";
import { sendWhatsApp, sendTelegram, printStatement } from "@/lib/printUtils";
import { getLedgerForAccount, docTypeLabel } from "@/lib/ledger";

// ====== هيكل الأقسام الرئيسية الأربعة ======
const SECTIONS = [
  { id: "assets",      label: "1. الأصول",      icon: "🏛️", color: "text-blue-400",   bg: "bg-blue-900/30 border-blue-600"   },
  { id: "liabilities", label: "2. الخصوم",      icon: "⚖️", color: "text-red-400",    bg: "bg-red-900/30 border-red-600"     },
  { id: "expenses",    label: "3. المصروفات",   icon: "💸", color: "text-amber-400",  bg: "bg-amber-900/30 border-amber-600" },
  { id: "revenue",     label: "4. الإيرادات",   icon: "💵", color: "text-green-400",  bg: "bg-green-900/30 border-green-600" },
];

// ====== صفحات الفئات (دليل الحسابات) ======
const categoryPages = [
  // ─── الأصول (1) ───────────────────────────────────────
  { id: "fixed_assets",     section: "assets",      code: "1.1",   label: "أصول ثابتة",        subLabel: "1-1", icon: "🏗️", color: "border-blue-500 bg-blue-900/20",    text: "text-blue-300",   type: "assets",      subType: "fixed_assets",       subSubType: undefined },
  { id: "cash",             section: "assets",      code: "1.2.1", label: "الصناديق",           subLabel: "1-2-1", icon: "💰", color: "border-emerald-500 bg-emerald-900/20", text: "text-emerald-300", type: "assets",   subType: "current_assets",     subSubType: "cash"     },
  { id: "bank",             section: "assets",      code: "1.2.2", label: "البنوك",             subLabel: "1-2-2", icon: "🏦", color: "border-teal-500 bg-teal-900/20",      text: "text-teal-300",    type: "assets",   subType: "current_assets",     subSubType: "bank"     },
  { id: "customer",         section: "assets",      code: "1.2.3", label: "العملاء",            subLabel: "1-2-3", icon: "👤", color: "border-amber-500 bg-amber-900/20",    text: "text-amber-300",   type: "assets",   subType: "current_assets",     subSubType: "customer" },
  { id: "inventory_acc",    section: "assets",      code: "1.2.4", label: "المخزون",            subLabel: "1-2-4", icon: "📦", color: "border-orange-500 bg-orange-900/20",  text: "text-orange-300",  type: "assets",   subType: "current_assets",     subSubType: "inventory"},
  // ─── الخصوم (2) ───────────────────────────────────────
  { id: "fixed_liab",       section: "liabilities", code: "2.1",   label: "التزامات ثابتة",    subLabel: "2-1", icon: "🏛️", color: "border-slate-500 bg-slate-900/20",   text: "text-slate-300",  type: "liabilities", subType: "fixed_liabilities",  subSubType: undefined },
  { id: "supplier",         section: "liabilities", code: "2.2.1", label: "الموردون",           subLabel: "2-2-1", icon: "🚚", color: "border-red-500 bg-red-900/20",        text: "text-red-300",     type: "liabilities", subType: "current_liabilities", subSubType: "supplier"    },
  { id: "creditor",         section: "liabilities", code: "2.2.2", label: "الدائنون",           subLabel: "2-2-2", icon: "👥", color: "border-rose-400 bg-rose-900/20",      text: "text-rose-300",    type: "liabilities", subType: "current_liabilities", subSubType: "creditor"    },
  { id: "other_liab",       section: "liabilities", code: "2.2.3", label: "التزامات أخرى",     subLabel: "2-2-3", icon: "📋", color: "border-gray-500 bg-gray-900/20",      text: "text-gray-300",    type: "liabilities", subType: "current_liabilities", subSubType: "other"       },
  { id: "capital",          section: "liabilities", code: "2.3.1", label: "رأس المال",          subLabel: "2-3-1", icon: "💎", color: "border-purple-500 bg-purple-900/20",  text: "text-purple-300",  type: "liabilities", subType: "equity",              subSubType: "capital"     },
  { id: "shareholders",     section: "liabilities", code: "2.3.2", label: "المساهمون",          subLabel: "2-3-2", icon: "🤝", color: "border-violet-500 bg-violet-900/20",  text: "text-violet-300",  type: "liabilities", subType: "equity",              subSubType: "shareholders"},
  { id: "drawings",         section: "liabilities", code: "2.3.3", label: "المسحوبات",          subLabel: "2-3-3", icon: "↩️", color: "border-rose-500 bg-rose-900/20",      text: "text-rose-300",    type: "liabilities", subType: "equity",              subSubType: "drawings"    },
  { id: "profit",           section: "liabilities", code: "2.3.4", label: "الأرباح والخسائر",  subLabel: "2-3-4", icon: "📈", color: "border-green-500 bg-green-900/20",    text: "text-green-300",   type: "liabilities", subType: "equity",              subSubType: "profit_loss" },
  // ─── المصروفات (3) ────────────────────────────────────
  { id: "purchases_cost",   section: "expenses",    code: "3.1.1", label: "المشتريات",          subLabel: "3-1-1", icon: "🛒", color: "border-pink-500 bg-pink-900/20",      text: "text-pink-300",    type: "expenses",    subType: "activity_costs",     subSubType: "purchases"        },
  { id: "sales_returns_c",  section: "expenses",    code: "3.1.2", label: "مردودات المبيعات",   subLabel: "3-1-2", icon: "↩️", color: "border-red-400 bg-red-900/20",        text: "text-red-300",     type: "expenses",    subType: "activity_costs",     subSubType: "sales_returns"    },
  { id: "cost_of_sales",    section: "expenses",    code: "3.1.3", label: "تكلفة المبيعات",    subLabel: "3-1-3", icon: "📊", color: "border-orange-500 bg-orange-900/20",  text: "text-orange-300",  type: "expenses",    subType: "activity_costs",     subSubType: "cost_of_sales"    },
  { id: "disc_allowed",     section: "expenses",    code: "3.1.4", label: "الخصم المسموح به",  subLabel: "3-1-4", icon: "🏷️", color: "border-yellow-500 bg-yellow-900/20",  text: "text-yellow-300",  type: "expenses",    subType: "activity_costs",     subSubType: "discount_allowed" },
  { id: "inv_settle",       section: "expenses",    code: "3.1.5", label: "تسوية المخزون",     subLabel: "3-1-5", icon: "🔄", color: "border-teal-500 bg-teal-900/20",      text: "text-teal-300",    type: "expenses",    subType: "activity_costs",     subSubType: "inv_settle"       },
  { id: "damaged",          section: "expenses",    code: "3.1.6", label: "الأصناف التالفة",   subLabel: "3-1-6", icon: "⚠️", color: "border-amber-600 bg-amber-900/20",   text: "text-amber-400",   type: "expenses",    subType: "activity_costs",     subSubType: "damaged"          },
  { id: "admin_exp",        section: "expenses",    code: "3.2",   label: "مصاريف إدارية",     subLabel: "3-2",   icon: "💸", color: "border-yellow-500 bg-yellow-900/20",  text: "text-yellow-300",  type: "expenses",    subType: "admin_expenses",     subSubType: undefined          },
  // ─── الإيرادات (4) ────────────────────────────────────
  { id: "sales_rev",        section: "revenue",     code: "4.1.1", label: "المبيعات",           subLabel: "4-1-1", icon: "🏪", color: "border-cyan-500 bg-cyan-900/20",      text: "text-cyan-300",    type: "revenue",     subType: "activity_revenue",   subSubType: "sales"        },
  { id: "purch_returns_r",  section: "revenue",     code: "4.1.2", label: "مردودات المشتريات", subLabel: "4-1-2", icon: "↩️", color: "border-teal-400 bg-teal-900/20",      text: "text-teal-300",    type: "revenue",     subType: "activity_revenue",   subSubType: "purch_returns"},
  { id: "disc_earned",      section: "revenue",     code: "4.1.3", label: "الخصم المكتسب",           subLabel: "4-1-3", icon: "🏷️", color: "border-emerald-500 bg-emerald-900/20",  text: "text-emerald-300",  type: "revenue",    subType: "activity_revenue",   subSubType: "disc_earned"    },
  { id: "currency_diff",    section: "revenue",     code: "4.1.4", label: "فوارق العملات",            subLabel: "4-1-4", icon: "💱", color: "border-yellow-500 bg-yellow-900/20",    text: "text-yellow-300",   type: "revenue",    subType: "activity_revenue",   subSubType: "currency_diff"  },
  { id: "other_rev",        section: "revenue",     code: "4.2",   label: "إيرادات أخرى",      subLabel: "4-2",   icon: "💵", color: "border-lime-500 bg-lime-900/20",       text: "text-lime-300",    type: "revenue",    subType: "other_revenue",      subSubType: undefined      },
];

const subTypes: Record<string, { value: string; label: string }[]> = {
  assets:      [{ value: "fixed_assets",       label: "1-1 أصول ثابتة" },          { value: "current_assets",     label: "1-2 أصول متداولة" }],
  liabilities: [{ value: "fixed_liabilities",  label: "2-1 التزامات ثابتة" },      { value: "current_liabilities", label: "2-2 التزامات متداولة" }, { value: "equity", label: "2-3 حقوق الملكية" }],
  expenses:    [{ value: "activity_costs",      label: "3-1 تكاليف النشاط" },       { value: "admin_expenses",     label: "3-2 مصاريف إدارية" }],
  revenue:     [{ value: "activity_revenue",    label: "4-1 إيرادات النشاط" },      { value: "other_revenue",      label: "4-2 إيرادات أخرى" }],
};

const subSubTypes: Record<string, { value: string; label: string }[]> = {
  fixed_assets:       [],
  current_assets:     [{ value: "cash", label: "الصناديق" }, { value: "bank", label: "البنوك" }, { value: "customer", label: "العملاء" }, { value: "inventory", label: "المخزون" }],
  fixed_liabilities:  [],
  current_liabilities:[{ value: "supplier", label: "الموردون" }, { value: "creditor", label: "الدائنون" }, { value: "other", label: "أخرى" }],
  equity:             [{ value: "capital", label: "رأس المال" }, { value: "shareholders", label: "المساهمون" }, { value: "drawings", label: "المسحوبات" }, { value: "profit_loss", label: "الأرباح والخسائر" }],
  activity_costs:     [{ value: "purchases", label: "المشتريات" }, { value: "sales_returns", label: "مردودات المبيعات" }, { value: "cost_of_sales", label: "تكلفة المبيعات" }, { value: "discount_allowed", label: "الخصم المسموح به" }, { value: "inv_settle", label: "تسوية المخزون" }, { value: "damaged", label: "الأصناف التالفة" }],
  admin_expenses:     [],
  activity_revenue:   [{ value: "sales", label: "المبيعات" }, { value: "purch_returns", label: "مردودات المشتريات" }, { value: "disc_earned", label: "الخصم المكتسب" }, { value: "currency_diff", label: "فوارق بيع وشراء العملات" }],
  other_revenue:      [],
};

const defaultForm = {
  nameAr: "", code: "", type: "assets" as string, subType: "current_assets", subSubType: "customer",
  phone: "", address: "", relatives: "", openingBalance: 0,
  enableWhatsapp: true, enableSms: false, enableTelegram: false,
  ceiling: 0, enableCeiling: false,
};

// ====== أرصدة متعددة العملات لكل حساب ======
function getCurrencyBalances(accountId: number): Record<string, number> {
  try { return JSON.parse(localStorage.getItem(`qawera_bal_${accountId}`) || "{}"); } catch { return {}; }
}
function saveCurrencyBalances(accountId: number, balances: Record<string, number>) {
  localStorage.setItem(`qawera_bal_${accountId}`, JSON.stringify(balances));
}

export default function AccountsPage() {
  const qc = useQueryClient();
  const { data: accounts = [], isLoading } = useListAccounts();
  const { data: currencies = [] } = useListCurrencies();
  const createAccount = useCreateAccount();
  const updateAccount = useUpdateAccount();
  const deleteAccount = useDeleteAccount();
  const { toast } = useToast();
  const { settings } = useSettings();
  const [pageIdx, setPageIdx] = useState(0);
  const [activeSection, setActiveSection] = useState("assets");
  const [search, setSearch] = useState("");
  const [open, setOpen] = useState(false);
  const [detailAccount, setDetailAccount] = useState<any | null>(null);
  const [menuOpen, setMenuOpen] = useState(false);
  const [editAccount, setEditAccount] = useState<any | null>(null);
  const [editForm, setEditForm] = useState({ ...defaultForm });
  const setE = (k: string, v: any) => setEditForm(f => ({ ...f, [k]: v }));
  const [form, setForm] = useState({ ...defaultForm });
  const scrollRef = useRef<HTMLDivElement>(null);
  const set = (k: string, v: any) => setForm(f => ({ ...f, [k]: v }));

  // ── صفحات العملات (السحب للأعلى/الأسفل للتنقل) ──────────────────────────
  const [currPageIdx, setCurrPageIdx] = useState(0);
  const touchStartY = useRef<number | null>(null);
  const touchStartX = useRef<number | null>(null);

  // قائمة العملات: "الكل" + كل عملة منشأة
  const currencyPages = useMemo(() => {
    const all = (currencies as any[]);
    return [{ symbol: "الكل", nameAr: "جميع العملات", isAll: true }, ...all.map(c => ({ symbol: c.symbol, nameAr: c.nameAr, isAll: false }))];
  }, [currencies]);

  const selectedCurr = currencyPages[currPageIdx] || currencyPages[0];

  // تحميل الدفتر مرة واحدة لكل رندر
  const allLedger = useMemo(() => getLedger(), []);

  // حساب رصيد الحساب من الدفتر حسب العملة المختارة
  const getBalance = useCallback((acc: any) => {
    const entries = allLedger.filter(e => e.accountId === acc.id);
    const filtered = selectedCurr.isAll
      ? entries
      : entries.filter(e => (e.currencySymbol || "ر.ي") === selectedCurr.symbol);
    const debit  = filtered.reduce((s, e) => s + (e.debit  || 0), 0);
    const credit = filtered.reduce((s, e) => s + (e.credit || 0), 0);
    // في حالة "الكل" نضيف الرصيد الافتتاحي
    const opening = selectedCurr.isAll ? Number(acc.openingBalance || 0) : 0;
    return opening + debit - credit;
  }, [allLedger, selectedCurr]);

  // الرصيد الكامل لجميع العملات (لعرض ملخص)
  const getBalanceByCurrency = useCallback((acc: any): { symbol: string; debit: number; credit: number; balance: number }[] => {
    const entries = allLedger.filter(e => e.accountId === acc.id);
    const map: Record<string, { debit: number; credit: number }> = {};
    entries.forEach(e => {
      const sym = e.currencySymbol || "ر.ي";
      if (!map[sym]) map[sym] = { debit: 0, credit: 0 };
      map[sym].debit  += e.debit  || 0;
      map[sym].credit += e.credit || 0;
    });
    return Object.entries(map).map(([symbol, { debit, credit }]) => ({ symbol, debit, credit, balance: debit - credit }));
  }, [allLedger]);

  // السحب للأعلى/الأسفل للتنقل بين العملات
  const handleTouchStart = (e: React.TouchEvent) => {
    touchStartY.current = e.touches[0].clientY;
    touchStartX.current = e.touches[0].clientX;
  };
  const handleTouchEnd = (e: React.TouchEvent) => {
    if (touchStartY.current === null || touchStartX.current === null) return;
    const dy = e.changedTouches[0].clientY - touchStartY.current;
    const dx = e.changedTouches[0].clientX - touchStartX.current;
    // فقط إذا كانت الحركة رأسية أكثر من الأفقية ومقدارها > 60px
    if (Math.abs(dy) > Math.abs(dx) && Math.abs(dy) > 60) {
      if (dy > 0) {
        // سحب للأسفل → العملة السابقة
        setCurrPageIdx(i => (i - 1 + currencyPages.length) % currencyPages.length);
      } else {
        // سحب للأعلى → العملة التالية
        setCurrPageIdx(i => (i + 1) % currencyPages.length);
      }
    }
    touchStartY.current = null;
    touchStartX.current = null;
  };
  // Multi-currency balances
  const [currencyBalances, setCurrencyBalances] = useState<Record<string, number>>({});
  const [editingBal, setEditingBal] = useState(false);
  const [newBalCurrency, setNewBalCurrency] = useState("");
  const [newBalAmount, setNewBalAmount] = useState(0);
  // Ledger currency tab
  const [ledgerCurrencyTab, setLedgerCurrencyTab] = useState<string>("all");

  useEffect(() => {
    if (detailAccount?.id) {
      setCurrencyBalances(getCurrencyBalances(detailAccount.id));
      setEditingBal(false);
      setNewBalCurrency("");
      setNewBalAmount(0);
      setLedgerCurrencyTab("all");
    }
  }, [detailAccount?.id]);

  // الصفحات المتاحة للقسم الحالي
  const sectionPages = useMemo(() => categoryPages.filter(p => p.section === activeSection), [activeSection]);
  // إذا تغير القسم، نعيد الصفحة إلى الأولى في القسم الجديد
  const currentPage = sectionPages[pageIdx] || sectionPages[0];

  const filteredAccounts = useMemo(() => {
    let list = (accounts as any[]).filter(a => !a.isMain);
    if (currentPage) {
      list = list.filter(a => {
        // دعم التوافق مع النوع القديم liabilities_equity
        const aType = a.type === "liabilities_equity" ? "liabilities" : a.type;
        if (aType !== currentPage.type) return false;
        if (currentPage.subType && a.subType !== currentPage.subType) return false;
        if (currentPage.subSubType && a.subSubType !== currentPage.subSubType) return false;
        return true;
      });
    }
    if (search) list = list.filter(a => a.nameAr?.includes(search) || a.code?.includes(search) || a.phone?.includes(search));
    return list;
  }, [accounts, pageIdx, activeSection, search, currentPage]);

  const handleSectionChange = (sectionId: string) => {
    setActiveSection(sectionId);
    setPageIdx(0);
  };

  const handleAddAccount = async () => {
    if (!form.nameAr.trim()) { toast({ title: "خطأ", description: "أدخل اسم الحساب", variant: "destructive" }); return; }
    const existing = (accounts as any[]).find(a => a.nameAr?.trim() === form.nameAr.trim() && !a.isMain);
    if (existing) { toast({ title: "خطأ", description: "يوجد حساب بنفس الاسم مسبقاً", variant: "destructive" }); return; }
    const code = String(100000001 + (accounts as any[]).filter(a => !a.isMain).length).padStart(9, "0");
    await createAccount.mutateAsync({ data: { ...form, code, isMain: false } });
    qc.invalidateQueries({ queryKey: getListAccountsQueryKey() });
    setOpen(false);
    setForm({ ...defaultForm, type: currentPage.type, subType: currentPage.subType || "current", subSubType: currentPage.subSubType || "customer" });
    toast({ title: "✅ تم إنشاء الحساب بنجاح" });
  };

  // تهيئة الحسابات الرئيسية
  const [initLoading, setInitLoading] = useState(false);
  const handleInitMain = useCallback(async () => {
    setInitLoading(true);
    try {
      const res = await fetch(`/api/accounts/init-main`, { method: "POST", headers: { "Content-Type": "application/json" } });
      const data = await res.json();
      qc.invalidateQueries({ queryKey: getListAccountsQueryKey() });
      toast({ title: `✅ ${data.message}`, description: data.created > 0 ? `أُنشئ ${data.created} حساباً` : "لا يوجد حسابات جديدة" });
    } catch (e) {
      toast({ title: "خطأ", description: "تعذّر تهيئة الحسابات", variant: "destructive" });
    } finally {
      setInitLoading(false);
    }
  }, [qc, toast]);

  // فتح نموذج التعديل
  const openEdit = useCallback((acc: any) => {
    setEditForm({
      nameAr: acc.nameAr || "",
      code: acc.code || "",
      type: acc.type || "assets",
      subType: acc.subType || "current",
      subSubType: acc.subSubType || "customer",
      phone: acc.phone || "",
      address: acc.address || "",
      relatives: acc.relatives || "",
      openingBalance: Number(acc.openingBalance || 0),
      enableWhatsapp: !!acc.enableWhatsapp,
      enableSms: !!acc.enableSms,
      enableTelegram: !!acc.enableTelegram,
      ceiling: Number(acc.ceiling || 0),
      enableCeiling: !!acc.enableCeiling,
    });
    setEditAccount(acc);
    setDetailAccount(null);
  }, []);

  const handleEditSave = async () => {
    if (!editForm.nameAr.trim()) { toast({ title: "خطأ", description: "أدخل اسم الحساب", variant: "destructive" }); return; }
    const duplicate = (accounts as any[]).find(a => a.nameAr?.trim() === editForm.nameAr.trim() && a.id !== editAccount.id && !a.isMain);
    if (duplicate) { toast({ title: "خطأ", description: "يوجد حساب آخر بنفس الاسم", variant: "destructive" }); return; }
    await updateAccount.mutateAsync({ id: editAccount.id, data: { ...editForm } });
    qc.invalidateQueries({ queryKey: getListAccountsQueryKey() });
    setEditAccount(null);
    toast({ title: "✅ تم تحديث الحساب بنجاح" });
  };

  // جلب رقم من جهات الاتصال
  const pickContactFor = useCallback(async (setter: (v: string) => void) => {
    if ("contacts" in navigator && "select" in (navigator as any).contacts) {
      try {
        const contacts = await (navigator as any).contacts.select(["tel"], { multiple: false });
        if (contacts.length > 0 && contacts[0].tel?.length > 0) {
          setter(contacts[0].tel[0]);
        }
      } catch {}
    } else {
      toast({ title: "غير مدعوم", description: "جهازك لا يدعم استيراد جهات الاتصال. أدخل الرقم يدوياً.", variant: "destructive" });
    }
  }, [toast]);
  const pickContact = useCallback(() => pickContactFor(v => set("phone", v)), [pickContactFor]);
  const pickEditContact = useCallback(() => pickContactFor(v => setE("phone", v)), [pickContactFor]);

  const handleDelete = async (id: number) => {
    await deleteAccount.mutateAsync({ id });
    qc.invalidateQueries({ queryKey: getListAccountsQueryKey() });
    setDetailAccount(null);
    toast({ title: "✅ تم حذف الحساب" });
  };

  const handlePrintStatement = (acc: any) => {
    printStatement(acc.nameAr, [
      { date: new Date().toLocaleDateString("ar"), description: "رصيد افتتاحي", debit: 0, credit: Number(acc.openingBalance || 0), balance: Number(acc.openingBalance || 0), currency: "ر.س" }
    ], { ...settings });
  };

  const openAddForm = () => {
    const pg = currentPage;
    setForm({
      ...defaultForm,
      type: pg?.type || "assets",
      subType: pg?.subType || "current_assets",
      subSubType: pg?.subSubType || "customer",
    });
    setOpen(true);
  };

  // إعادة بناء الحسابات الرئيسية مع ترحيل البيانات القديمة
  const [resetLoading, setResetLoading] = useState(false);
  const handleResetMain = useCallback(async () => {
    if (!confirm("⚠️ سيتم حذف الحسابات الرئيسية القديمة وإعادة بنائها وفق الدليل المحاسبي الجديد. هل تريد الاستمرار؟")) return;
    setResetLoading(true);
    try {
      const res = await fetch(`/api/accounts/reset-main`, { method: "POST", headers: { "Content-Type": "application/json" } });
      const data = await res.json();
      qc.invalidateQueries({ queryKey: getListAccountsQueryKey() });
      toast({ title: `✅ ${data.message}` });
    } catch {
      toast({ title: "خطأ", description: "تعذّر إعادة البناء", variant: "destructive" });
    } finally {
      setResetLoading(false);
    }
  }, [qc, toast]);

  const subs = subTypes[form.type] || [];
  const subSubs = subSubTypes[form.subType] || [];
  const editSubs = subTypes[editForm.type] || [];
  const editSubSubs = subSubTypes[editForm.subType] || [];

  return (
    <div className="space-y-3 animate-in fade-in duration-300" dir="rtl"
      onTouchStart={handleTouchStart} onTouchEnd={handleTouchEnd}>
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-amber-400">الحسابات</h1>
          <p className="text-emerald-200 mt-0.5 text-sm">دليل الحسابات — اسحب يميناً/يساراً للتنقل</p>
        </div>
        <div className="flex gap-2">
          <Button
            onClick={handleResetMain}
            disabled={resetLoading}
            variant="outline"
            size="sm"
            className="border-red-600 text-red-300 hover:bg-red-900/40 h-9 gap-1 text-xs"
            title="إعادة بناء الدليل المحاسبي الجديد (1-2-3-4) مع ترحيل البيانات">
            {resetLoading ? "⏳" : "🔄"} إعادة البناء
          </Button>
          <Button
            onClick={handleInitMain}
            disabled={initLoading}
            variant="outline"
            size="sm"
            className="border-purple-600 text-purple-300 hover:bg-purple-900/40 h-9 gap-1 text-xs"
            title="إنشاء شجرة الحسابات الرئيسية الموحدة"
          >
            {initLoading ? "⏳" : "🗂️"} تهيئة الرئيسية
          </Button>
          <Button onClick={openAddForm} className="bg-amber-500 hover:bg-amber-400 text-white gap-2 h-9 px-4 font-bold">
            <Plus className="w-4 h-4" /> حساب جديد
          </Button>
        </div>
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-emerald-400" />
        <Input value={search} onChange={e => setSearch(e.target.value)} placeholder="بحث عن حساب..." className="bg-emerald-900/50 border-emerald-700 text-white pr-10 placeholder:text-emerald-600" />
      </div>

      {/* ─── الأقسام الرئيسية الأربعة ─── */}
      <div className="grid grid-cols-4 gap-1.5">
        {SECTIONS.map(sec => (
          <button key={sec.id} onClick={() => handleSectionChange(sec.id)}
            className={`rounded-xl py-2 px-1 text-center text-xs font-bold border transition-all ${activeSection === sec.id ? `${sec.bg} ${sec.color} shadow-lg` : "border-white/10 text-white/50 hover:border-white/20 hover:bg-white/5"}`}>
            <div className="text-base mb-0.5">{sec.icon}</div>
            <div className="leading-tight">{sec.label.replace(/^\d+\. /, "")}</div>
            <div className="text-white/30 text-[10px] mt-0.5">{sec.label.split(".")[0]}</div>
          </button>
        ))}
      </div>

      {/* ─── الفئات الفرعية للقسم الحالي ─── */}
      <div className="flex items-center gap-1">
        <button onClick={() => setPageIdx(i => Math.max(0, i - 1))} disabled={pageIdx === 0} className="p-1.5 rounded-xl bg-white/10 hover:bg-white/20 disabled:opacity-30 shrink-0">
          <ChevronRight className="w-4 h-4 text-white" />
        </button>
        <div ref={scrollRef} className="flex gap-2 overflow-x-auto scrollbar-hide flex-1 scroll-smooth">
          {sectionPages.map((cat, idx) => (
            <button key={cat.id} onClick={() => setPageIdx(idx)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all border shrink-0 ${idx === pageIdx ? "bg-amber-500 text-white border-amber-400 shadow-lg" : "border-white/10 text-emerald-300 hover:border-white/20 hover:bg-white/5"}`}>
              <span>{cat.icon}</span> {cat.label}
              <span className="text-white/30 text-[10px] mr-0.5">{cat.code}</span>
            </button>
          ))}
        </div>
        <button onClick={() => setPageIdx(i => Math.min(sectionPages.length - 1, i + 1))} disabled={pageIdx === sectionPages.length - 1} className="p-1.5 rounded-xl bg-white/10 hover:bg-white/20 disabled:opacity-30 shrink-0">
          <ChevronLeft className="w-4 h-4 text-white" />
        </button>
      </div>

      {/* Current Category Info */}
      {currentPage && (
        <div className={`flex items-center justify-between rounded-xl p-3 border ${currentPage.color}`}>
          <div>
            <span className={`font-bold text-sm ${currentPage.text}`}>{currentPage.icon} {currentPage.label}</span>
            <span className="text-white/30 text-xs mr-2">({currentPage.code})</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-white/40 text-xs">{filteredAccounts.length} حساب</span>
            <span className="text-emerald-400 text-xs">{pageIdx + 1} / {sectionPages.length}</span>
          </div>
        </div>
      )}

      {/* ─── شريط العملات — اسحب للأعلى/الأسفل للتنقل ─── */}
      <div className="rounded-xl border border-amber-500/30 bg-amber-900/10 p-2.5 flex items-center justify-between gap-2">
        <div className="flex items-center gap-2 flex-1">
          <button onClick={() => setCurrPageIdx(i => (i - 1 + currencyPages.length) % currencyPages.length)}
            className="w-7 h-7 rounded-lg bg-amber-500/20 flex items-center justify-center hover:bg-amber-500/40 transition-colors shrink-0">
            <ChevronRight className="w-4 h-4 text-amber-400" />
          </button>
          <div className="flex-1 text-center">
            <p className="text-amber-400 font-black text-sm">{selectedCurr.nameAr}</p>
            {!selectedCurr.isAll && <p className="text-amber-300/60 text-xs">{selectedCurr.symbol}</p>}
          </div>
          <button onClick={() => setCurrPageIdx(i => (i + 1) % currencyPages.length)}
            className="w-7 h-7 rounded-lg bg-amber-500/20 flex items-center justify-center hover:bg-amber-500/40 transition-colors shrink-0">
            <ChevronLeft className="w-4 h-4 text-amber-400" />
          </button>
        </div>
        <div className="flex gap-1 flex-wrap justify-end">
          {currencyPages.map((c, i) => (
            <button key={c.symbol} onClick={() => setCurrPageIdx(i)}
              className={`w-2 h-2 rounded-full transition-all ${i === currPageIdx ? "bg-amber-400 scale-125" : "bg-amber-900/60 border border-amber-700/50"}`} />
          ))}
        </div>
        <p className="text-white/30 text-[10px] shrink-0">اسحب ↕</p>
      </div>

      {/* Accounts List */}
      <div className="space-y-2">
        {isLoading ? (
          <div className="text-center py-8 text-emerald-300">جاري التحميل...</div>
        ) : filteredAccounts.length === 0 ? (
          <div className="text-center py-12">
            <p className="text-5xl mb-3">{currentPage?.icon}</p>
            <p className="text-emerald-300 font-semibold">لا توجد حسابات في "{currentPage?.label}"</p>
            <p className="text-white/40 text-sm mt-1">اضغط "+ حساب جديد" لإضافة حساب</p>
          </div>
        ) : filteredAccounts.map((acc: any) => {
          const bal = getBalance(acc);
          const byCurr = getBalanceByCurrency(acc);
          return (
          <div key={acc.id} className="rounded-xl border border-white/10 overflow-hidden hover:border-amber-400/20 transition-all group cursor-pointer"
            style={{background: "rgba(6,78,59,0.3)"}}>
            <div className="p-3.5" onClick={() => setDetailAccount(acc)}>
              <div className="flex items-center justify-between gap-2">
                <div className="flex items-center gap-2 flex-1 min-w-0">
                  <div className="w-9 h-9 rounded-xl bg-amber-500/20 border border-amber-500/30 flex items-center justify-center shrink-0">
                    <span className="text-lg">{currentPage?.icon}</span>
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="text-white font-bold">{acc.nameAr}</p>
                    <p className="text-white/40 text-xs font-mono">{acc.code}</p>
                  </div>
                </div>
                <div className="flex items-center gap-1.5 shrink-0">
                  {/* الرصيد الحالي من الدفتر */}
                  <div className="text-left ml-1">
                    {selectedCurr.isAll ? (
                      /* عرض جميع العملات */
                      byCurr.length > 0 ? (
                        <div className="flex flex-col items-end gap-0.5">
                          {byCurr.map(r => (
                            <p key={r.symbol} className={`text-sm font-black leading-tight ${r.balance >= 0 ? "text-green-400" : "text-red-400"}`}>
                              {r.balance < 0 ? "(" : ""}{Math.abs(r.balance).toLocaleString("ar", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}{r.balance < 0 ? ")" : ""} <span className="text-[10px] text-white/40">{r.symbol}</span>
                            </p>
                          ))}
                          {Number(acc.openingBalance || 0) !== 0 && (
                            <p className="text-xs text-white/40">
                              افتتاحي: {Number(acc.openingBalance).toLocaleString("ar", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                            </p>
                          )}
                        </div>
                      ) : (
                        <div className="text-center">
                          <p className={`text-sm font-black ${Number(acc.openingBalance || 0) >= 0 ? "text-green-400" : "text-red-400"}`}>
                            {Math.abs(Number(acc.openingBalance || 0)).toLocaleString("ar", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                          </p>
                          <p className="text-white/30 text-xs">افتتاحي</p>
                        </div>
                      )
                    ) : (
                      /* عرض عملة واحدة */
                      <div className="text-left">
                        <p className={`text-sm font-black whitespace-nowrap ${bal >= 0 ? "text-green-400" : "text-red-400"}`}>
                          {bal < 0 ? "(" : ""}{Math.abs(bal).toLocaleString("ar", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}{bal < 0 ? ")" : ""} <span className="text-[10px] text-white/40">{selectedCurr.symbol}</span>
                        </p>
                        <p className="text-white/30 text-xs text-left">{bal >= 0 ? "مدين" : "دائن"}</p>
                      </div>
                    )}
                  </div>
                  {/* WhatsApp quick button */}
                  {acc.phone && acc.enableWhatsapp && (
                    <button onClick={e => { e.stopPropagation(); sendWhatsApp(acc.phone, `${settings.msgPrefix}\n*كشف حساب: ${acc.nameAr}*\nالرصيد الحالي: ${Math.abs(bal).toLocaleString("ar", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} ${selectedCurr.isAll ? "" : selectedCurr.symbol}\n${settings.msgSuffix}`); }}
                      className="w-8 h-8 rounded-xl bg-green-500/20 border border-green-500/30 flex items-center justify-center hover:bg-green-500/40 transition-colors">
                      <MessageCircle className="w-4 h-4 text-green-400" />
                    </button>
                  )}
                  {acc.phone && (
                    <button onClick={e => { e.stopPropagation(); window.location.href = `tel:${acc.phone}`; }}
                      className="w-8 h-8 rounded-xl bg-blue-500/20 border border-blue-500/30 flex items-center justify-center hover:bg-blue-500/40 transition-colors">
                      <Phone className="w-4 h-4 text-blue-400" />
                    </button>
                  )}
                  <button onClick={e => { e.stopPropagation(); handlePrintStatement(acc); }}
                    className="w-8 h-8 rounded-xl bg-amber-500/20 border border-amber-500/30 flex items-center justify-center hover:bg-amber-500/40 transition-colors">
                    <Printer className="w-4 h-4 text-amber-400" />
                  </button>
                  <button onClick={e => { e.stopPropagation(); openEdit(acc); }}
                    className="w-8 h-8 rounded-xl bg-amber-500/20 border border-amber-500/30 flex items-center justify-center hover:bg-amber-500/40 transition-colors opacity-0 group-hover:opacity-100">
                    <Edit2 className="w-4 h-4 text-amber-400" />
                  </button>
                  <button onClick={e => { e.stopPropagation(); handleDelete(acc.id); }}
                    className="w-8 h-8 rounded-xl bg-red-500/20 border border-red-500/30 flex items-center justify-center hover:bg-red-500/40 transition-colors opacity-0 group-hover:opacity-100">
                    <Trash2 className="w-4 h-4 text-red-400" />
                  </button>
                </div>
              </div>
              {(acc.phone || acc.address) && (
                <div className="flex items-center gap-3 mt-1.5 pr-11">
                  {acc.phone && <p className="text-white/40 text-xs" dir="ltr">{acc.phone}</p>}
                  {acc.address && <p className="text-white/40 text-xs">📍 {acc.address}</p>}
                </div>
              )}
            </div>
          </div>
          );
        })}
      </div>

      {/* Account Detail Dialog */}
      <Dialog open={!!detailAccount} onOpenChange={v => !v && setDetailAccount(null)}>
        <DialogContent className="max-w-lg text-white border-emerald-700 max-h-[90vh] overflow-y-auto" dir="rtl" style={{background: "linear-gradient(135deg, #022c22, #064E3B)"}}>
          {detailAccount && (
            <>
              <DialogHeader>
                <div className="flex items-center justify-between">
                  <DialogTitle className="text-amber-400 text-lg font-black">{detailAccount.nameAr}</DialogTitle>
                  <div className="flex gap-1">
                    {/* 3 dots menu */}
                    <div className="relative">
                      <button onClick={() => setMenuOpen(v => !v)} className="p-1.5 rounded-lg hover:bg-white/10"><MoreVertical className="w-5 h-5 text-white/60" /></button>
                      {menuOpen && (
                        <div className="absolute left-0 top-8 w-48 rounded-xl shadow-2xl border border-emerald-700 z-50 overflow-hidden" style={{background: "#022c22"}}>
                          {[
                            { icon: Search, label: "بحث متقدم" },
                            { icon: Share2, label: "مشاركة" },
                            { icon: Download, label: "تصدير Excel" },
                            { icon: MessageCircle, label: "إرسال واتساب", action: () => { if (detailAccount.phone) sendWhatsApp(detailAccount.phone, `${settings.msgPrefix}\nكشف حساب: ${detailAccount.nameAr}`); } },
                            { icon: Send, label: "إرسال تيليجرام", action: () => { if (detailAccount.phone) sendTelegram(detailAccount.phone, `كشف حساب: ${detailAccount.nameAr}`); } },
                            { icon: Printer, label: "طباعة PDF", action: () => handlePrintStatement(detailAccount) },
                            { icon: Bell, label: "التنبيهات" },
                          ].map((item, i) => (
                            <button key={i} onClick={() => { item.action?.(); setMenuOpen(false); }} className="flex items-center gap-2.5 w-full px-3 py-2 hover:bg-white/10 transition-colors text-sm text-white/80">
                              <item.icon className="w-4 h-4 text-emerald-400" />{item.label}
                            </button>
                          ))}
                        </div>
                      )}
                    </div>
                    <button onClick={() => openEdit(detailAccount)} className="p-1.5 rounded-lg hover:bg-white/10" title="تعديل الحساب"><Edit2 className="w-5 h-5 text-amber-400" /></button>
                    <button onClick={() => handlePrintStatement(detailAccount)} className="p-1.5 rounded-lg hover:bg-white/10" title="طباعة PDF"><FileText className="w-5 h-5 text-blue-400" /></button>
                    <button onClick={() => setDetailAccount(null)} className="p-1.5 rounded-lg hover:bg-white/10"><X className="w-5 h-5 text-white/60" /></button>
                  </div>
                </div>
              </DialogHeader>
              <div className="space-y-3">
                <div className="grid grid-cols-2 gap-3">
                  {[
                    { label: "رقم الحساب", value: detailAccount.code },
                    { label: "نوع الحساب", value: detailAccount.type },
                    { label: "رقم الجوال", value: detailAccount.phone || "-" },
                    { label: "العنوان", value: detailAccount.address || "-" },
                    { label: "الأقارب", value: detailAccount.relatives || "-" },
                    { label: "الرصيد الافتتاحي", value: `${Number(detailAccount.openingBalance || 0).toFixed(2)} ر.س` },
                  ].map((f, i) => (
                    <div key={i} className="bg-emerald-900/30 rounded-xl p-2.5 border border-emerald-700/20">
                      <p className="text-white/40 text-xs">{f.label}</p>
                      <p className="text-white font-semibold text-sm">{f.value}</p>
                    </div>
                  ))}
                </div>
                {/* Balance Summary */}
                <div className="rounded-xl p-3 text-center border border-amber-500/30 bg-amber-900/20">
                  <p className="text-amber-300 text-xs mb-1">الرصيد الحالي</p>
                  <p className={`text-2xl font-black ${Number(detailAccount.openingBalance || 0) >= 0 ? "text-green-400" : "text-red-400"}`}>
                    {Math.abs(Number(detailAccount.openingBalance || 0)).toFixed(2)} <span className="text-white/40 text-sm">ر.س</span>
                  </p>
                  <p className="text-white/40 text-xs">{Number(detailAccount.openingBalance || 0) >= 0 ? "دائن" : "مدين"}</p>
                </div>

                {/* ====== أرصدة متعددة العملات ====== */}
                <div className="rounded-xl border border-emerald-600/30 bg-emerald-950/30 overflow-hidden">
                  <div className="flex items-center justify-between px-3 py-2 border-b border-emerald-700/20">
                    <span className="text-emerald-300 text-xs font-bold">💱 الأرصدة بالعملات الأخرى</span>
                    <button onClick={() => setEditingBal(v => !v)} className="text-xs text-amber-400 hover:text-amber-300 font-bold">
                      {editingBal ? "✓ إغلاق" : "+ إضافة عملة"}
                    </button>
                  </div>
                  <div className="p-2 space-y-1">
                    {Object.keys(currencyBalances).length === 0 && !editingBal && (
                      <p className="text-white/25 text-xs text-center py-2">لا توجد أرصدة بعملات أخرى</p>
                    )}
                    {Object.entries(currencyBalances).map(([code, amount]) => (
                      <div key={code} className="flex items-center justify-between px-2 py-1.5 rounded-lg bg-white/5">
                        <span className="text-amber-300 text-sm font-bold">{code}</span>
                        <div className="flex items-center gap-2">
                          <span className="text-white font-mono text-sm">{Number(amount).toFixed(2)}</span>
                          <button onClick={() => {
                            const updated = { ...currencyBalances };
                            delete updated[code];
                            saveCurrencyBalances(detailAccount.id, updated);
                            setCurrencyBalances(updated);
                          }} className="text-red-400/60 hover:text-red-400 text-xs">✕</button>
                        </div>
                      </div>
                    ))}
                    {editingBal && (
                      <div className="flex gap-2 mt-2 items-center">
                        <select
                          value={newBalCurrency}
                          onChange={e => setNewBalCurrency(e.target.value)}
                          className="bg-emerald-900/60 border border-emerald-700 text-white text-xs rounded-lg px-2 py-1.5 flex-1"
                        >
                          <option value="">اختر العملة</option>
                          {(currencies as any[]).map((c: any) => (
                            <option key={c.code} value={c.code}>{c.code} - {c.nameAr}</option>
                          ))}
                        </select>
                        <input
                          type="number"
                          value={newBalAmount}
                          onChange={e => setNewBalAmount(parseFloat(e.target.value) || 0)}
                          placeholder="المبلغ"
                          className="bg-emerald-900/60 border border-emerald-700 text-white text-xs rounded-lg px-2 py-1.5 w-24"
                        />
                        <button onClick={() => {
                          if (!newBalCurrency) return;
                          const updated = { ...currencyBalances, [newBalCurrency]: newBalAmount };
                          saveCurrencyBalances(detailAccount.id, updated);
                          setCurrencyBalances(updated);
                          setNewBalCurrency("");
                          setNewBalAmount(0);
                          setEditingBal(false);
                          toast({ title: "✅ تم إضافة الرصيد", description: `${newBalAmount.toFixed(2)} ${newBalCurrency}` });
                        }} className="bg-emerald-700 hover:bg-emerald-600 text-white text-xs rounded-lg px-3 py-1.5 font-bold">
                          حفظ
                        </button>
                      </div>
                    )}
                  </div>
                </div>

                {/* Multi-Currency Balance Breakdown */}
                {(() => {
                  const allEntries = getLedgerForAccount(detailAccount.id);
                  const currencyMap: Record<string, { debit: number; credit: number }> = {};
                  allEntries.forEach(e => {
                    const sym = e.currencySymbol || "ر.ي";
                    if (!currencyMap[sym]) currencyMap[sym] = { debit: 0, credit: 0 };
                    currencyMap[sym].debit += (e.debit || 0);
                    currencyMap[sym].credit += (e.credit || 0);
                  });
                  const currencyEntries = Object.entries(currencyMap);
                  if (currencyEntries.length === 0) return null;
                  return (
                    <div className="rounded-xl border border-amber-600/30 overflow-hidden">
                      <div className="px-3 py-2 border-b border-amber-700/20 flex items-center justify-between" style={{background:"rgba(120,80,0,0.25)"}}>
                        <span className="text-amber-400 text-xs font-bold">💱 الأرصدة بجميع العملات</span>
                        <span className="text-white/40 text-xs">{currencyEntries.length} عملة</span>
                      </div>
                      <div className="grid grid-cols-2 gap-1.5 p-2">
                        {currencyEntries.map(([sym, { debit, credit }]) => {
                          const balance = debit - credit;
                          return (
                            <div key={sym} className="bg-white/5 rounded-lg p-2 border border-white/10">
                              <div className="flex items-center justify-between mb-1">
                                <span className="text-amber-300 font-black text-base">{sym}</span>
                                <span className={`text-xs font-black px-1.5 py-0.5 rounded ${balance >= 0 ? "bg-emerald-900/50 text-emerald-300" : "bg-red-900/50 text-red-300"}`}>
                                  {balance >= 0 ? "مدين" : "دائن"}
                                </span>
                              </div>
                              <div className="space-y-0.5 text-xs">
                                <div className="flex justify-between"><span className="text-white/50">مدين:</span><span className="text-orange-300 font-bold">{debit.toFixed(2)}</span></div>
                                <div className="flex justify-between"><span className="text-white/50">دائن:</span><span className="text-green-300 font-bold">{credit.toFixed(2)}</span></div>
                                <div className="flex justify-between border-t border-white/10 pt-0.5"><span className="text-white/60 font-bold">الرصيد:</span><span className={`font-black ${balance >= 0 ? "text-amber-300" : "text-red-400"}`}>{Math.abs(balance).toFixed(2)}</span></div>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  );
                })()}

                {/* Ledger Statement — Multi-Currency Tabs */}
                {(() => {
                  const allEntries = getLedgerForAccount(detailAccount.id);
                  // Build list of available currencies from transactions
                  const currSymbols = Array.from(new Set(allEntries.map(e => e.currencySymbol || "ر.ي")));
                  const filteredEntries = ledgerCurrencyTab === "all"
                    ? allEntries
                    : allEntries.filter(e => (e.currencySymbol || "ر.ي") === ledgerCurrencyTab);
                  const openBal = Number(detailAccount.openingBalance || 0);
                  let runningBalance = ledgerCurrencyTab === "all" ? openBal : 0;
                  const totalDebit  = filteredEntries.reduce((s, e) => s + (e.debit  || 0), 0);
                  const totalCredit = filteredEntries.reduce((s, e) => s + (e.credit || 0), 0);
                  return (
                    <div className="rounded-xl border border-emerald-600/30 overflow-hidden">
                      {/* Header */}
                      <div className="flex items-center justify-between px-3 py-2 border-b border-emerald-700/20" style={{background:"rgba(4,120,87,0.25)"}}>
                        <span className="text-emerald-300 text-xs font-bold">📋 كشف الحساب (الأستاذ)</span>
                        <span className="text-white/40 text-xs">{filteredEntries.length} حركة</span>
                      </div>

                      {/* Currency Tabs */}
                      {currSymbols.length > 0 && (
                        <div className="flex gap-1 p-2 flex-wrap border-b border-white/10" style={{background:"rgba(4,78,59,0.2)"}}>
                          <button
                            onClick={() => setLedgerCurrencyTab("all")}
                            className={`px-3 py-1 rounded-lg text-xs font-bold transition-all ${ledgerCurrencyTab === "all" ? "bg-amber-500 text-white shadow" : "bg-white/10 text-white/60 hover:bg-white/20"}`}
                          >
                            🌐 جميع العملات
                          </button>
                          {currSymbols.map(sym => (
                            <button
                              key={sym}
                              onClick={() => setLedgerCurrencyTab(sym)}
                              className={`px-3 py-1 rounded-lg text-xs font-black transition-all ${ledgerCurrencyTab === sym ? "bg-emerald-600 text-white shadow" : "bg-emerald-900/50 text-emerald-300 hover:bg-emerald-800/60 border border-emerald-700/40"}`}
                            >
                              {sym}
                            </button>
                          ))}
                        </div>
                      )}

                      {/* Currency Summary for selected tab */}
                      {ledgerCurrencyTab !== "all" && filteredEntries.length > 0 && (
                        <div className="grid grid-cols-3 gap-1.5 p-2 border-b border-white/10" style={{background:"rgba(4,78,59,0.15)"}}>
                          <div className="bg-orange-900/30 rounded-lg p-2 text-center border border-orange-700/30">
                            <p className="text-orange-300 text-xs">{settings.debitLabel || "مدين"}</p>
                            <p className="text-orange-300 font-black text-sm">{totalDebit.toFixed(2)}</p>
                          </div>
                          <div className="bg-green-900/30 rounded-lg p-2 text-center border border-green-700/30">
                            <p className="text-green-300 text-xs">{settings.creditLabel || "دائن"}</p>
                            <p className="text-green-300 font-black text-sm">{totalCredit.toFixed(2)}</p>
                          </div>
                          <div className={`rounded-lg p-2 text-center border ${(totalDebit-totalCredit) >= 0 ? "bg-amber-900/30 border-amber-700/30" : "bg-red-900/30 border-red-700/30"}`}>
                            <p className="text-amber-300 text-xs">الرصيد</p>
                            <p className={`font-black text-sm ${(totalDebit-totalCredit) >= 0 ? "text-amber-300" : "text-red-400"}`}>{(totalDebit-totalCredit).toFixed(2)} {ledgerCurrencyTab}</p>
                          </div>
                        </div>
                      )}

                      <div className="overflow-x-auto">
                        <table className="w-full text-xs">
                          <thead>
                            <tr style={{background:"rgba(4,78,59,0.4)"}}>
                              <th className="p-2 text-right text-amber-300">التاريخ</th>
                              <th className="p-2 text-right text-amber-300">البيان</th>
                              <th className="p-2 text-right text-amber-300">النوع</th>
                              {ledgerCurrencyTab === "all" && <th className="p-2 text-center text-cyan-300">العملة</th>}
                              <th className="p-2 text-left text-orange-300">{settings.debitLabel || "مدين"}</th>
                              <th className="p-2 text-left text-green-300">{settings.creditLabel || "دائن"}</th>
                              <th className="p-2 text-left text-amber-300">الرصيد</th>
                            </tr>
                          </thead>
                          <tbody>
                            {ledgerCurrencyTab === "all" && (
                              <tr className="border-b border-white/5 bg-white/5">
                                <td className="p-2 text-white/60">—</td>
                                <td className="p-2 text-white/80 font-bold" colSpan={2}>رصيد افتتاحي</td>
                                <td className="p-2 text-center text-white/40">—</td>
                                <td className="p-2 text-left">{openBal > 0 ? <span className="text-orange-300 font-bold">{openBal.toFixed(2)}</span> : "—"}</td>
                                <td className="p-2 text-left">{openBal < 0 ? <span className="text-green-300 font-bold">{Math.abs(openBal).toFixed(2)}</span> : "—"}</td>
                                <td className="p-2 text-left font-bold text-amber-300">{openBal.toFixed(2)}</td>
                              </tr>
                            )}
                            {filteredEntries.length === 0 && (
                              <tr><td colSpan={ledgerCurrencyTab === "all" ? 7 : 6} className="p-5 text-center text-white/30">
                                {ledgerCurrencyTab === "all" ? "لا توجد حركات مرحّلة بعد" : `لا توجد حركات بعملة ${ledgerCurrencyTab}`}
                              </td></tr>
                            )}
                            {filteredEntries.map(e => {
                              runningBalance = runningBalance + (e.debit || 0) - (e.credit || 0);
                              return (
                                <tr key={e.id} className="border-b border-white/5 hover:bg-white/5">
                                  <td className="p-2 text-white/50 font-mono">{e.date}</td>
                                  <td className="p-2 text-white/80 max-w-[110px] truncate">{e.description}</td>
                                  <td className="p-2"><span className="text-xs px-1.5 py-0.5 rounded bg-white/10 text-white/60">{docTypeLabel[e.docType] || e.docType}</span></td>
                                  {ledgerCurrencyTab === "all" && (
                                    <td className="p-2 text-center">
                                      <span className="text-xs font-black px-1.5 py-0.5 rounded bg-emerald-900/60 text-emerald-300 border border-emerald-700/40">{e.currencySymbol || "ر.ي"}</span>
                                    </td>
                                  )}
                                  <td className="p-2 text-left font-bold text-orange-300">{e.debit > 0 ? e.debit.toFixed(2) : "—"}</td>
                                  <td className="p-2 text-left font-bold text-green-300">{e.credit > 0 ? e.credit.toFixed(2) : "—"}</td>
                                  <td className={`p-2 text-left font-black text-xs ${runningBalance >= 0 ? "text-amber-300" : "text-red-400"}`}>{runningBalance.toFixed(2)}</td>
                                </tr>
                              );
                            })}
                          </tbody>
                        </table>
                      </div>
                      {filteredEntries.length > 0 && (
                        <div className="px-3 py-2 border-t border-emerald-700/30 flex justify-between items-center" style={{background:"rgba(4,78,59,0.2)"}}>
                          <span className="text-white/50 text-xs">الرصيد النهائي {ledgerCurrencyTab !== "all" ? `(${ledgerCurrencyTab})` : ""}</span>
                          <span className={`font-black text-sm ${runningBalance >= 0 ? "text-green-400" : "text-red-400"}`}>
                            {runningBalance.toFixed(2)} {ledgerCurrencyTab !== "all" ? ledgerCurrencyTab : (filteredEntries[0]?.currencySymbol || "ر.ي")}
                          </span>
                        </div>
                      )}
                    </div>
                  );
                })()}

                {/* Bottom Action Icons */}
                <div className="grid grid-cols-6 gap-1.5">
                  {[
                    { icon: Plus, label: "إضافة", color: "text-emerald-400", bg: "bg-emerald-900/40", action: () => { setDetailAccount(null); setOpen(true); } },
                    { icon: ArrowLeftRight, label: "قيد", color: "text-indigo-400", bg: "bg-indigo-900/40", action: () => {} },
                    { icon: Eye, label: "الرصيد", color: "text-amber-400", bg: "bg-amber-900/40", action: () => {} },
                    { icon: Phone, label: "اتصال", color: "text-blue-400", bg: "bg-blue-900/40", action: () => { if (detailAccount.phone) window.location.href = `tel:${detailAccount.phone}`; } },
                    { icon: MessageCircle, label: "واتساب", color: "text-green-400", bg: "bg-green-900/40", action: () => { if (detailAccount.phone) sendWhatsApp(detailAccount.phone, `${settings.msgPrefix}\nكشف حساب: ${detailAccount.nameAr}\nالرصيد: ${Math.abs(Number(detailAccount.openingBalance||0)).toFixed(2)} ر.س\n${settings.msgSuffix}`); } },
                    { icon: Send, label: "تيليجرام", color: "text-cyan-400", bg: "bg-cyan-900/40", action: () => { if (detailAccount.phone) sendTelegram(detailAccount.phone, `كشف حساب: ${detailAccount.nameAr}`); } },
                  ].map((btn, i) => (
                    <button key={i} onClick={btn.action} className={`flex flex-col items-center gap-1 p-2 rounded-xl ${btn.bg} border border-white/10 hover:brightness-125 transition-all`}>
                      <btn.icon className={`w-5 h-5 ${btn.color}`} />
                      <span className={`text-xs font-bold ${btn.color}`}>{btn.label}</span>
                    </button>
                  ))}
                </div>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>

      {/* Edit Account Dialog */}
      <Dialog open={!!editAccount} onOpenChange={v => !v && setEditAccount(null)}>
        <DialogContent className="max-w-lg text-white border-emerald-700 max-h-[90vh] overflow-y-auto" dir="rtl" style={{background: "linear-gradient(135deg, #022c22, #064E3B)"}}>
          <DialogHeader>
            <DialogTitle className="text-amber-400 text-xl">✏️ تعديل الحساب — {editAccount?.nameAr}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <div className="col-span-2">
                <Label className="text-emerald-200 text-xs">اسم الحساب *</Label>
                <Input value={editForm.nameAr} onChange={e => setE("nameAr", e.target.value)} className="bg-emerald-900/50 border-emerald-700 text-white mt-1 text-base" placeholder="اسم الحساب..." />
              </div>
              <div className="col-span-2">
                <Label className="text-emerald-200 text-xs">رقم الحساب</Label>
                <Input value={editForm.code} readOnly className="bg-emerald-900/30 border-emerald-800 text-white/50 mt-1 font-mono text-sm cursor-not-allowed" />
              </div>
              <div>
                <Label className="text-emerald-200 text-xs">نوع الحساب</Label>
                <Select value={editForm.type} onValueChange={v => setE("type", v)}>
                  <SelectTrigger className="bg-emerald-900/50 border-emerald-700 text-white mt-1"><SelectValue /></SelectTrigger>
                  <SelectContent className="bg-emerald-900 border-emerald-700">
                    <SelectItem value="assets" className="text-white">1. الأصول</SelectItem>
                    <SelectItem value="liabilities" className="text-white">2. الخصوم</SelectItem>
                    <SelectItem value="expenses" className="text-white">3. المصروفات</SelectItem>
                    <SelectItem value="revenue" className="text-white">4. الإيرادات</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              {editSubs.length > 0 && (
                <div>
                  <Label className="text-emerald-200 text-xs">التصنيف الفرعي</Label>
                  <Select value={editForm.subType} onValueChange={v => setE("subType", v)}>
                    <SelectTrigger className="bg-emerald-900/50 border-emerald-700 text-white mt-1"><SelectValue /></SelectTrigger>
                    <SelectContent className="bg-emerald-900 border-emerald-700">
                      {editSubs.map(s => <SelectItem key={s.value} value={s.value} className="text-white">{s.label}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
              )}
              {editSubSubs.length > 0 && (
                <div className="col-span-2">
                  <Label className="text-emerald-200 text-xs">التصنيف التفصيلي</Label>
                  <Select value={editForm.subSubType} onValueChange={v => setE("subSubType", v)}>
                    <SelectTrigger className="bg-emerald-900/50 border-emerald-700 text-white mt-1"><SelectValue /></SelectTrigger>
                    <SelectContent className="bg-emerald-900 border-emerald-700">
                      {editSubSubs.map(s => <SelectItem key={s.value} value={s.value} className="text-white">{s.label}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
              )}
              <div>
                <Label className="text-emerald-200 text-xs">رقم الجوال</Label>
                <div className="flex gap-1.5 mt-1">
                  <Input value={editForm.phone} onChange={e => setE("phone", e.target.value)} className="bg-emerald-900/50 border-emerald-700 text-white flex-1" dir="ltr" placeholder="+967..." />
                  <button type="button" onClick={pickEditContact} title="استيراد من جهات الاتصال"
                    className="w-9 h-9 rounded-lg bg-emerald-800/60 border border-emerald-600 flex items-center justify-center hover:bg-emerald-700/60 transition-colors shrink-0">📱</button>
                </div>
              </div>
              <div>
                <Label className="text-emerald-200 text-xs">الرصيد الافتتاحي</Label>
                <Input type="number" step="0.01" value={editForm.openingBalance || ""} onChange={e => setE("openingBalance", parseFloat(e.target.value) || 0)} className="bg-emerald-900/50 border-emerald-700 text-white mt-1" />
              </div>
              <div className="col-span-2">
                <Label className="text-emerald-200 text-xs">العنوان</Label>
                <Input value={editForm.address} onChange={e => setE("address", e.target.value)} className="bg-emerald-900/50 border-emerald-700 text-white mt-1" />
              </div>
              <div className="col-span-2">
                <Label className="text-emerald-200 text-xs">الأقارب / جهة اتصال بديلة</Label>
                <Input value={editForm.relatives} onChange={e => setE("relatives", e.target.value)} className="bg-emerald-900/50 border-emerald-700 text-white mt-1" />
              </div>
            </div>
            <div className="bg-emerald-900/30 rounded-xl p-3 border border-emerald-700/30 space-y-2">
              <Label className="text-amber-300 font-bold text-sm">الإشعارات</Label>
              {[
                { key: "enableWhatsapp", label: "إشعار واتساب" },
                { key: "enableSms", label: "رسالة نصية" },
                { key: "enableTelegram", label: "إشعار تيليجرام" },
              ].map(r => (
                <div key={r.key} className="flex items-center justify-between">
                  <span className="text-white/80 text-sm">{r.label}</span>
                  <Switch checked={!!editForm[r.key as keyof typeof editForm]} onCheckedChange={v => setE(r.key, v)} />
                </div>
              ))}
            </div>
            <div className="bg-amber-900/20 rounded-xl p-3 border border-amber-700/30 space-y-2">
              <Label className="text-amber-300 font-bold text-sm">🔒 سقف الحساب</Label>
              <div className="flex items-center justify-between">
                <span className="text-white/80 text-sm">تفعيل السقف</span>
                <Switch checked={editForm.enableCeiling} onCheckedChange={v => setE("enableCeiling", v)} />
              </div>
              {editForm.enableCeiling && (
                <div>
                  <Label className="text-emerald-200 text-xs">الحد الأقصى للرصيد</Label>
                  <Input type="number" value={editForm.ceiling} onChange={e => setE("ceiling", parseFloat(e.target.value) || 0)} className="bg-amber-900/30 border-amber-700 text-white mt-1" />
                </div>
              )}
            </div>
            <div className="flex gap-2">
              <Button onClick={handleEditSave} disabled={updateAccount.isPending} className="bg-amber-500 hover:bg-amber-400 text-white flex-1 h-11 font-bold">
                {updateAccount.isPending ? "جاري الحفظ..." : "✅ حفظ التعديلات"}
              </Button>
              <Button variant="outline" onClick={() => setEditAccount(null)} className="border-emerald-600 text-emerald-200 h-11">إلغاء</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Add Account Dialog */}
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-lg text-white border-emerald-700 max-h-[90vh] overflow-y-auto" dir="rtl" style={{background: "linear-gradient(135deg, #022c22, #064E3B)"}}>
          <DialogHeader><DialogTitle className="text-amber-400 text-xl">📋 إضافة حساب جديد — {currentPage?.label}</DialogTitle></DialogHeader>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <div className="col-span-2"><Label className="text-emerald-200 text-xs">اسم الحساب *</Label><Input value={form.nameAr} onChange={e => set("nameAr", e.target.value)} className="bg-emerald-900/50 border-emerald-700 text-white mt-1 text-base" placeholder="اسم الحساب..." /></div>
              <div>
                <Label className="text-emerald-200 text-xs">نوع الحساب</Label>
                <Select value={form.type} onValueChange={v => set("type", v)}>
                  <SelectTrigger className="bg-emerald-900/50 border-emerald-700 text-white mt-1"><SelectValue /></SelectTrigger>
                  <SelectContent className="bg-emerald-900 border-emerald-700">
                    <SelectItem value="assets" className="text-white">1. الأصول</SelectItem>
                    <SelectItem value="liabilities" className="text-white">2. الخصوم</SelectItem>
                    <SelectItem value="expenses" className="text-white">3. المصروفات</SelectItem>
                    <SelectItem value="revenue" className="text-white">4. الإيرادات</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              {subs.length > 0 && (
                <div>
                  <Label className="text-emerald-200 text-xs">التصنيف الفرعي</Label>
                  <Select value={form.subType} onValueChange={v => set("subType", v)}>
                    <SelectTrigger className="bg-emerald-900/50 border-emerald-700 text-white mt-1"><SelectValue /></SelectTrigger>
                    <SelectContent className="bg-emerald-900 border-emerald-700">
                      {subs.map(s => <SelectItem key={s.value} value={s.value} className="text-white">{s.label}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
              )}
              {subSubs.length > 0 && (
                <div className="col-span-2">
                  <Label className="text-emerald-200 text-xs">التصنيف التفصيلي</Label>
                  <Select value={form.subSubType} onValueChange={v => set("subSubType", v)}>
                    <SelectTrigger className="bg-emerald-900/50 border-emerald-700 text-white mt-1"><SelectValue /></SelectTrigger>
                    <SelectContent className="bg-emerald-900 border-emerald-700">
                      {subSubs.map(s => <SelectItem key={s.value} value={s.value} className="text-white">{s.label}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
              )}
              <div>
                <Label className="text-emerald-200 text-xs">رقم الجوال</Label>
                <div className="flex gap-1.5 mt-1">
                  <Input value={form.phone} onChange={e => set("phone", e.target.value)} className="bg-emerald-900/50 border-emerald-700 text-white flex-1" dir="ltr" placeholder="+967..." />
                  <button
                    type="button"
                    onClick={pickContact}
                    title="استيراد من جهات الاتصال"
                    className="w-9 h-9 rounded-lg bg-emerald-800/60 border border-emerald-600 flex items-center justify-center hover:bg-emerald-700/60 transition-colors shrink-0"
                  >📱</button>
                </div>
              </div>
              <div><Label className="text-emerald-200 text-xs">الرصيد الافتتاحي</Label><Input type="number" step="0.01" value={form.openingBalance || ""} onChange={e => set("openingBalance", parseFloat(e.target.value) || 0)} className="bg-emerald-900/50 border-emerald-700 text-white mt-1" /></div>
              <div className="col-span-2"><Label className="text-emerald-200 text-xs">العنوان</Label><Input value={form.address} onChange={e => set("address", e.target.value)} className="bg-emerald-900/50 border-emerald-700 text-white mt-1" /></div>
              <div className="col-span-2"><Label className="text-emerald-200 text-xs">الأقارب / جهة اتصال بديلة</Label><Input value={form.relatives} onChange={e => set("relatives", e.target.value)} className="bg-emerald-900/50 border-emerald-700 text-white mt-1" /></div>
            </div>
            <div className="bg-emerald-900/30 rounded-xl p-3 border border-emerald-700/30 space-y-2">
              <Label className="text-amber-300 font-bold text-sm">الإشعارات</Label>
              {[
                { key: "enableWhatsapp", label: "إشعار واتساب" },
                { key: "enableSms", label: "رسالة نصية" },
                { key: "enableTelegram", label: "إشعار تيليجرام" },
              ].map(r => (
                <div key={r.key} className="flex items-center justify-between">
                  <span className="text-white/80 text-sm">{r.label}</span>
                  <Switch checked={!!form[r.key as keyof typeof form]} onCheckedChange={v => set(r.key, v)} />
                </div>
              ))}
            </div>
            <div className="bg-amber-900/20 rounded-xl p-3 border border-amber-700/30 space-y-2">
              <Label className="text-amber-300 font-bold text-sm">🔒 سقف الحساب</Label>
              <p className="text-white/40 text-xs">تحديد حد أقصى للرصيد — مفيد لحسابات العملاء والموردين</p>
              <div className="flex items-center justify-between"><span className="text-white/80 text-sm">تفعيل السقف</span><Switch checked={form.enableCeiling} onCheckedChange={v => set("enableCeiling", v)} /></div>
              {form.enableCeiling && (
                <div>
                  <Label className="text-emerald-200 text-xs">الحد الأقصى للرصيد</Label>
                  <Input type="number" value={form.ceiling} onChange={e => set("ceiling", parseFloat(e.target.value) || 0)} className="bg-amber-900/30 border-amber-700 text-white mt-1" placeholder="أدخل الحد الأقصى..." />
                </div>
              )}
            </div>
            <div className="flex gap-2">
              <Button onClick={handleAddAccount} disabled={createAccount.isPending} className="bg-amber-500 hover:bg-amber-400 text-white flex-1 h-11 font-bold">
                {createAccount.isPending ? "جاري الحفظ..." : "✅ حفظ الحساب"}
              </Button>
              <Button variant="outline" onClick={() => setOpen(false)} className="border-emerald-600 text-emerald-200 h-11">إلغاء</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
