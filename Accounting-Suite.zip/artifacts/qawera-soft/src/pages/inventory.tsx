import React, { useState, useMemo, useCallback } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useListItems } from "@workspace/api-client-react";
import { getListItemsQueryKey } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import {
  Plus, Trash2, ArrowDownCircle, ArrowUpCircle, ArrowLeftRight,
  RefreshCw, Warehouse, ClipboardList, Search, Printer, AlertCircle, Package
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";

// ── أنواع العمليات ──────────────────────────────────────────────────────────
type OpType = "in" | "out" | "transfer" | "adjust" | "warehouse" | "count";
type AdjType = "opening" | "increase" | "deficit" | "damaged";

interface OpItem { itemId: number; quantity: number; unitCost: number; itemName?: string; }

const OP_TABS: { id: OpType; label: string; icon: any; color: string; border: string; badgeClass: string }[] = [
  { id: "in",        label: "توريد مخزني",    icon: ArrowDownCircle, color: "text-green-400",  border: "border-green-500",  badgeClass: "bg-green-900/60 text-green-300 border-green-600" },
  { id: "out",       label: "صرف مخزني",     icon: ArrowUpCircle,   color: "text-red-400",    border: "border-red-500",    badgeClass: "bg-red-900/60 text-red-300 border-red-600" },
  { id: "transfer",  label: "تحويل مخزني",   icon: ArrowLeftRight,  color: "text-blue-400",   border: "border-blue-500",   badgeClass: "bg-blue-900/60 text-blue-300 border-blue-600" },
  { id: "adjust",    label: "تسوية مخزنية",  icon: RefreshCw,       color: "text-amber-400",  border: "border-amber-500",  badgeClass: "bg-amber-900/60 text-amber-300 border-amber-600" },
  { id: "warehouse", label: "إضافة مخزن",    icon: Warehouse,       color: "text-purple-400", border: "border-purple-500", badgeClass: "bg-purple-900/60 text-purple-300 border-purple-600" },
  { id: "count",     label: "جرد مخزني",     icon: ClipboardList,   color: "text-teal-400",   border: "border-teal-500",   badgeClass: "bg-teal-900/60 text-teal-300 border-teal-600" },
];

const ADJ_TYPES: { id: AdjType; label: string; desc: string; color: string; badge: string; sign: string }[] = [
  { id: "opening", label: "افتتاحي",  desc: "تعيين رصيد أول المدة",           color: "text-blue-300",   badge: "bg-blue-900/50 text-blue-300",   sign: "=" },
  { id: "increase",label: "زيادة",    desc: "مخزون زائد عند الجرد",           color: "text-green-300",  badge: "bg-green-900/50 text-green-300", sign: "+" },
  { id: "deficit", label: "عجز",      desc: "نقص مخزون — يخصم من الكمية",    color: "text-red-300",    badge: "bg-red-900/50 text-red-300",     sign: "-" },
  { id: "damaged", label: "تالف",     desc: "بضاعة تالفة — تخصم وتسجَّل خسارة", color: "text-orange-300", badge: "bg-orange-900/50 text-orange-300", sign: "⚠" },
];

const typeLabel: Record<string, string> = {
  in: "توريد", out: "صرف", transfer: "تحويل", adjust: "تسوية", count: "جرد",
};
const adjLabel: Record<string, string> = {
  opening: "افتتاحي", increase: "زيادة", deficit: "عجز", damaged: "تالف",
};

// ── دوال الطباعة ──────────────────────────────────────────────────────────
const printOperation = (op: any, warehouses: any[]) => {
  const wh = warehouses.find(w => w.id === op.warehouseId)?.nameAr || "الرئيسي";
  const toWh = op.toWarehouseId ? (warehouses.find(w => w.id === op.toWarehouseId)?.nameAr || "") : "";
  const w = window.open("", "_blank");
  if (!w) return;
  const items = (op.items || []).map((it: any) =>
    `<tr><td>${it.itemName || it.itemId}</td><td style="text-align:center">${it.quantity}</td><td style="text-align:center">${Number(it.unitCost || 0).toFixed(2)}</td><td style="text-align:center">${(Number(it.quantity) * Number(it.unitCost || 0)).toFixed(2)}</td></tr>`
  ).join("");
  const totalVal = (op.items || []).reduce((s: number, it: any) => s + Number(it.quantity) * Number(it.unitCost || 0), 0);
  w.document.write(`<!DOCTYPE html><html dir="rtl"><head><meta charset="utf-8">
  <title>عملية مخزنية - ${op.operationNumber}</title>
  <style>
    body{font-family:Arial,sans-serif;padding:30px;direction:rtl;color:#222}
    h2{color:#064E3B;border-bottom:3px solid #F59E0B;padding-bottom:12px;margin-bottom:20px}
    .meta{display:flex;gap:30px;margin-bottom:20px;background:#f0fdf4;padding:12px;border-radius:8px}
    .meta span{font-size:14px}.meta b{color:#064E3B}
    table{width:100%;border-collapse:collapse;margin-top:15px;font-size:13px}
    td,th{padding:10px 12px;border:1px solid #d1fae5;text-align:right}
    thead tr{background:#064E3B;color:white}
    tr:nth-child(even){background:#f0fdf4}
    .total-row{background:#022c22;color:white;font-weight:bold;font-size:14px}
    .badge{display:inline-block;padding:3px 10px;border-radius:20px;font-size:12px;font-weight:bold;background:#064E3B;color:white}
    @media print{body{padding:10px}}
  </style></head>
  <body>
    <h2>🏭 قـويـره سوفت — عملية مخزنية</h2>
    <div class="meta">
      <span><b>رقم العملية:</b> ${op.operationNumber}</span>
      <span><b>النوع:</b> <span class="badge">${typeLabel[op.type] || op.type}${op.adjustType ? " — " + adjLabel[op.adjustType] : ""}</span></span>
      <span><b>التاريخ:</b> ${op.date}</span>
      <span><b>المخزن:</b> ${wh}${toWh ? " ← " + toWh : ""}</span>
    </div>
    ${op.notes ? `<p><b>ملاحظات:</b> ${op.notes}</p>` : ""}
    <table>
      <thead><tr><th>الصنف</th><th style="text-align:center">الكمية</th><th style="text-align:center">سعر الوحدة</th><th style="text-align:center">الإجمالي</th></tr></thead>
      <tbody>${items}</tbody>
      <tfoot><tr class="total-row"><td colspan="2">الإجمالي الكلي</td><td colspan="2" style="text-align:center">${totalVal.toFixed(2)}</td></tr></tfoot>
    </table>
    <p style="margin-top:30px;font-size:11px;color:#999;text-align:center">نظام قـويـره سوفت للمحاسبة المتكاملة</p>
    <script>window.onload=()=>{window.print();}</script>
  </body></html>`);
  w.document.close();
};

// ── API Fetching ────────────────────────────────────────────────────────────
const API = "/api/inventory";
const fetchWarehouses = () => fetch(`${API}/warehouses`).then(r => r.json());
const fetchOperations = () => fetch(`${API}/operations`).then(r => r.json());
const fetchStockSummary = () => fetch(`${API}/stock-summary`).then(r => r.json());

// ── الصفحة الرئيسية ─────────────────────────────────────────────────────────
export default function InventoryPage() {
  const qc = useQueryClient();
  const { toast } = useToast();

  const { data: warehouses = [], isLoading: wLoading } = useQuery({ queryKey: ["warehouses"], queryFn: fetchWarehouses });
  const { data: operations = [], isLoading: opLoading } = useQuery({ queryKey: ["inv-ops"], queryFn: fetchOperations });
  const { data: stockSummary = [], isLoading: stockLoading } = useQuery({ queryKey: ["stock-summary"], queryFn: fetchStockSummary });
  const { data: items = [] } = useListItems();

  const [activeTab, setActiveTab] = useState<OpType>("in");
  const [open, setOpen] = useState(false);
  const [warehouseOpen, setWarehouseOpen] = useState(false);
  const [search, setSearch] = useState("");
  const [typeFilter, setTypeFilter] = useState<string>("all");

  const [date, setDate] = useState(new Date().toISOString().split("T")[0]);
  const [notes, setNotes] = useState("");
  const [warehouseId, setWarehouseId] = useState<string>("");
  const [toWarehouseId, setToWarehouseId] = useState<string>("");
  const [adjustType, setAdjustType] = useState<AdjType>("opening");
  const [opItems, setOpItems] = useState<OpItem[]>([{ itemId: 0, quantity: 1, unitCost: 0 }]);

  const [newWarehouseName, setNewWarehouseName] = useState("");
  const [newWarehouseCode, setNewWarehouseCode] = useState("");
  const [newWarehouseAddr, setNewWarehouseAddr] = useState("");

  const mainWarehouse = useMemo(() => (warehouses as any[]).find((w: any) => w.isMain) || (warehouses as any[])[0], [warehouses]);

  const openForm = useCallback(() => {
    if (activeTab === "warehouse") { setWarehouseOpen(true); return; }
    setDate(new Date().toISOString().split("T")[0]);
    setNotes(""); setOpItems([{ itemId: 0, quantity: 1, unitCost: 0 }]);
    setWarehouseId(String(mainWarehouse?.id || 1));
    setToWarehouseId(""); setAdjustType("opening");
    setOpen(true);
  }, [activeTab, mainWarehouse]);

  const addRow = () => setOpItems(p => [...p, { itemId: 0, quantity: 1, unitCost: 0 }]);
  const removeRow = (i: number) => setOpItems(p => p.filter((_, idx) => idx !== i));
  const updateRow = (i: number, field: keyof OpItem, val: any) => setOpItems(p => p.map((it, idx) => {
    if (idx !== i) return it;
    if (field === "itemId") {
      const item = (items as any[]).find((x: any) => x.id === parseInt(val));
      return { ...it, itemId: parseInt(val), unitCost: Number(item?.costPrice || 0), itemName: item?.nameAr || "" };
    }
    return { ...it, [field]: field === "itemId" ? parseInt(val) : parseFloat(val) || 0 };
  }));

  const createOp = useMutation({
    mutationFn: (body: any) => fetch(`${API}/operations`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) }).then(async r => { if (!r.ok) throw new Error((await r.json()).message); return r.json(); }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["inv-ops"] });
      qc.invalidateQueries({ queryKey: ["stock-summary"] });
      qc.invalidateQueries({ queryKey: getListItemsQueryKey() });
      setOpen(false);
      toast({ title: `✅ تم تسجيل ${curTab.label} بنجاح` });
    },
    onError: (e: any) => toast({ title: "خطأ", description: e.message, variant: "destructive" }),
  });

  const deleteOp = useMutation({
    mutationFn: (id: number) => fetch(`${API}/operations/${id}`, { method: "DELETE" }).then(r => r.json()),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["inv-ops"] });
      qc.invalidateQueries({ queryKey: ["stock-summary"] });
      qc.invalidateQueries({ queryKey: getListItemsQueryKey() });
      toast({ title: "✅ تم حذف العملية وعكس أثرها على المخزون" });
    },
  });

  const createWarehouse = useMutation({
    mutationFn: (body: any) => fetch(`${API}/warehouses`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) }).then(async r => { if (!r.ok) throw new Error((await r.json()).message); return r.json(); }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["warehouses"] });
      setWarehouseOpen(false);
      setNewWarehouseName(""); setNewWarehouseCode(""); setNewWarehouseAddr("");
      toast({ title: "✅ تم إنشاء المخزن" });
    },
    onError: (e: any) => toast({ title: "خطأ", description: e.message, variant: "destructive" }),
  });

  const deleteWarehouse = useMutation({
    mutationFn: (id: number) => fetch(`${API}/warehouses/${id}`, { method: "DELETE" }).then(r => r.json()),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["warehouses"] }); toast({ title: "✅ تم حذف المخزن" }); },
  });

  const handleSubmit = () => {
    const validItems = opItems.filter(it => it.itemId > 0 && it.quantity > 0);
    if (activeTab !== "count" && validItems.length === 0) {
      toast({ title: "خطأ", description: "أضف صنفاً بكمية صحيحة على الأقل", variant: "destructive" }); return;
    }
    if (activeTab === "transfer" && !toWarehouseId) {
      toast({ title: "خطأ", description: "حدد مخزن الوجهة", variant: "destructive" }); return;
    }
    createOp.mutate({
      type: activeTab,
      adjustType: activeTab === "adjust" ? adjustType : undefined,
      date,
      warehouseId: parseInt(warehouseId) || 1,
      toWarehouseId: activeTab === "transfer" ? parseInt(toWarehouseId) : undefined,
      items: validItems,
      notes,
    });
  };

  const totalQty = opItems.reduce((s, it) => s + (it.quantity || 0), 0);
  const totalVal = opItems.reduce((s, it) => s + (it.quantity || 0) * (it.unitCost || 0), 0);

  const filtered = useMemo(() => {
    let list = operations as any[];
    if (typeFilter !== "all") list = list.filter((o: any) => o.type === typeFilter);
    if (search) list = list.filter((o: any) =>
      o.operationNumber?.includes(search) || o.notes?.includes(search) ||
      (o.items || []).some((it: any) => it.itemName?.includes(search))
    );
    return list;
  }, [operations, typeFilter, search]);

  const curTab = OP_TABS.find(t => t.id === activeTab)!;
  const adjCfg = ADJ_TYPES.find(a => a.id === adjustType)!;

  const warehouseName = (id: number) => (warehouses as any[]).find((w: any) => w.id === id)?.nameAr || `مخزن #${id}`;

  const opCount = (type: string) => (operations as any[]).filter((o: any) => o.type === type).length;

  return (
    <div className="space-y-4 animate-in fade-in duration-300" dir="rtl">
      {/* ── Header ─────────────────────────────────────────── */}
      <div className="flex justify-between items-center flex-wrap gap-3">
        <div>
          <h1 className="text-3xl font-bold text-amber-400">العمليات المخزنية</h1>
          <p className="text-emerald-200 mt-1 text-sm">إدارة المخزون والحركات المخزنية</p>
        </div>
        <Button onClick={openForm} className="bg-amber-500 hover:bg-amber-400 text-white gap-2 h-11 px-5 font-bold shadow-lg">
          <Plus className="w-4 h-4" />
          {activeTab === "warehouse" ? "إضافة مخزن جديد" : curTab.label}
        </Button>
      </div>

      {/* ── Operation Tabs ─────────────────────────────────── */}
      <div className="grid grid-cols-3 lg:grid-cols-6 gap-2">
        {OP_TABS.map(tab => {
          const cnt = tab.id === "warehouse" ? (warehouses as any[]).length : opCount(tab.id === "count" ? "count" : tab.id);
          return (
            <button key={tab.id} onClick={() => setActiveTab(tab.id)}
              className={`rounded-2xl p-3.5 flex flex-col items-center gap-2 transition-all border-2 text-center relative ${
                activeTab === tab.id
                  ? `${tab.border} bg-white/10 shadow-xl scale-[1.03]`
                  : "border-white/10 hover:border-white/25 bg-white/5 hover:bg-white/10"
              }`}>
              <tab.icon className={`w-5 h-5 ${activeTab === tab.id ? tab.color : "text-emerald-400"}`} />
              <span className={`text-xs font-bold leading-tight ${activeTab === tab.id ? "text-white" : "text-emerald-200"}`}>{tab.label}</span>
              {cnt > 0 && (
                <span className={`absolute -top-1.5 -left-1.5 text-[10px] font-bold px-1.5 py-0.5 rounded-full border ${tab.badgeClass}`}>{cnt}</span>
              )}
            </button>
          );
        })}
      </div>

      {/* ── Warehouses List (when warehouse tab) ──────────── */}
      {activeTab === "warehouse" && (
        <div className="bg-white/5 rounded-2xl border border-white/10 overflow-hidden">
          <div className="p-3 bg-purple-900/30 border-b border-white/10 flex items-center justify-between">
            <h3 className="text-purple-300 font-bold flex items-center gap-2"><Warehouse className="w-4 h-4" /> قائمة المخازن</h3>
            <span className="text-purple-400 text-xs">{(warehouses as any[]).length} مخازن</span>
          </div>
          {wLoading ? (
            <div className="p-6 text-center text-emerald-300">جاري التحميل...</div>
          ) : (warehouses as any[]).length === 0 ? (
            <div className="p-8 text-center text-emerald-400 text-sm">لا توجد مخازن. أضف مخزناً أولاً.</div>
          ) : (
            <table className="w-full text-sm">
              <thead className="bg-emerald-800/50">
                <tr>
                  <th className="p-3 text-right text-amber-300">الكود</th>
                  <th className="p-3 text-right text-amber-300">اسم المخزن</th>
                  <th className="p-3 text-right text-amber-300">العنوان</th>
                  <th className="p-3 text-right text-amber-300">النوع</th>
                  <th className="p-3 text-right text-amber-300">إجراءات</th>
                </tr>
              </thead>
              <tbody>
                {(warehouses as any[]).map((w: any) => (
                  <tr key={w.id} className="border-t border-white/10 hover:bg-white/5">
                    <td className="p-3 text-emerald-300 font-mono text-xs">{w.code}</td>
                    <td className="p-3 text-white font-semibold">{w.nameAr}</td>
                    <td className="p-3 text-white/60 text-xs">{w.address || "—"}</td>
                    <td className="p-3">
                      <Badge className={w.isMain ? "bg-amber-900/50 text-amber-300 border-amber-600" : "bg-white/10 text-white/60"}>
                        {w.isMain ? "رئيسي" : "فرعي"}
                      </Badge>
                    </td>
                    <td className="p-3">
                      {!w.isMain && (
                        <Button size="sm" variant="ghost" className="text-red-400 h-7 w-7 p-0 hover:bg-red-900/30"
                          onClick={() => { if (confirm("حذف المخزن؟")) deleteWarehouse.mutate(w.id); }}>
                          <Trash2 className="w-3.5 h-3.5" />
                        </Button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      )}

      {/* ── Stock Inventory (count tab) ────────────────────── */}
      {activeTab === "count" && (
        <div className="bg-white/5 rounded-2xl border border-white/10 overflow-hidden">
          <div className="p-3 bg-teal-900/30 border-b border-white/10 flex items-center justify-between">
            <h3 className="text-teal-300 font-bold flex items-center gap-2"><Package className="w-4 h-4" /> الجرد الفعلي — أرصدة المخزون</h3>
            <span className="text-teal-400 text-xs">{(stockSummary as any[]).length} صنف</span>
          </div>
          {stockLoading ? (
            <div className="p-6 text-center text-emerald-300">جاري التحميل...</div>
          ) : (stockSummary as any[]).length === 0 ? (
            <div className="p-8 text-center text-emerald-400 text-sm flex flex-col items-center gap-2">
              <AlertCircle className="w-8 h-8 text-amber-400" />
              <span>لا توجد أصناف في المخزن. أجرِ توريداً أو تسوية افتتاحية أولاً.</span>
            </div>
          ) : (
            <>
              <table className="w-full text-sm">
                <thead className="bg-emerald-800/50">
                  <tr>
                    <th className="p-3 text-right text-amber-300">الصنف</th>
                    <th className="p-3 text-center text-amber-300">الكمية</th>
                    <th className="p-3 text-center text-amber-300">الوحدة</th>
                    <th className="p-3 text-center text-amber-300">سعر التكلفة</th>
                    <th className="p-3 text-center text-amber-300">القيمة الإجمالية</th>
                  </tr>
                </thead>
                <tbody>
                  {(stockSummary as any[]).map((s: any, i: number) => (
                    <tr key={i} className="border-t border-white/10 hover:bg-white/5">
                      <td className="p-3 text-white font-medium">{s.itemName}</td>
                      <td className="p-3 text-center text-amber-300 font-bold text-base">{Number(s.quantity).toFixed(2)}</td>
                      <td className="p-3 text-center text-emerald-300 text-xs">{s.unit}</td>
                      <td className="p-3 text-center text-emerald-300">{Number(s.costPrice).toFixed(2)}</td>
                      <td className="p-3 text-center text-green-400 font-bold">{Number(s.totalValue).toFixed(2)}</td>
                    </tr>
                  ))}
                </tbody>
                <tfoot>
                  <tr className="bg-emerald-900/50 border-t-2 border-amber-500/50">
                    <td className="p-3 text-amber-300 font-bold" colSpan={4}>إجمالي قيمة المخزون</td>
                    <td className="p-3 text-center text-amber-400 font-bold text-base">
                      {(stockSummary as any[]).reduce((s: number, i: any) => s + Number(i.totalValue), 0).toFixed(2)}
                    </td>
                  </tr>
                </tfoot>
              </table>
            </>
          )}
        </div>
      )}

      {/* ── Operations List ────────────────────────────────── */}
      {activeTab !== "warehouse" && activeTab !== "count" && (
        <>
          <div className="flex gap-2 flex-wrap">
            <div className="relative flex-1 min-w-48">
              <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-emerald-400" />
              <Input value={search} onChange={e => setSearch(e.target.value)} placeholder="بحث بالصنف أو الملاحظات..." className="bg-emerald-900/50 border-emerald-700 text-white pr-10 placeholder:text-emerald-500" />
            </div>
            <Select value={typeFilter} onValueChange={setTypeFilter}>
              <SelectTrigger className="bg-emerald-900/50 border-emerald-700 text-white w-36">
                <SelectValue placeholder="كل الأنواع" />
              </SelectTrigger>
              <SelectContent className="bg-emerald-900 border-emerald-700">
                <SelectItem value="all" className="text-white">كل الأنواع</SelectItem>
                <SelectItem value="in" className="text-white">توريد</SelectItem>
                <SelectItem value="out" className="text-white">صرف</SelectItem>
                <SelectItem value="transfer" className="text-white">تحويل</SelectItem>
                <SelectItem value="adjust" className="text-white">تسوية</SelectItem>
                <SelectItem value="count" className="text-white">جرد</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="bg-white/5 rounded-2xl border border-white/10 overflow-hidden">
            <div className="p-3 bg-emerald-800/30 border-b border-white/10 flex items-center justify-between">
              <span className="text-emerald-300 text-sm font-medium">سجل العمليات المخزنية</span>
              <span className="text-amber-400 text-xs font-bold">{filtered.length} عملية</span>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-emerald-800/50">
                  <tr>
                    <th className="p-3 text-right text-amber-300">رقم العملية</th>
                    <th className="p-3 text-right text-amber-300">النوع</th>
                    <th className="p-3 text-right text-amber-300">التاريخ</th>
                    <th className="p-3 text-right text-amber-300">المخزن</th>
                    <th className="p-3 text-right text-amber-300">الأصناف</th>
                    <th className="p-3 text-center text-amber-300">القيمة</th>
                    <th className="p-3 text-right text-amber-300">ملاحظات</th>
                    <th className="p-3 text-center text-amber-300">إجراءات</th>
                  </tr>
                </thead>
                <tbody>
                  {opLoading ? (
                    <tr><td colSpan={8} className="p-6 text-center text-emerald-200">جاري التحميل...</td></tr>
                  ) : filtered.length === 0 ? (
                    <tr><td colSpan={8} className="p-8 text-center text-emerald-400">
                      <div className="flex flex-col items-center gap-2">
                        <Package className="w-8 h-8 text-amber-400/50" />
                        <span>لا توجد عمليات مخزنية</span>
                      </div>
                    </td></tr>
                  ) : filtered.map((op: any) => {
                    const cfg = OP_TABS.find(t => t.id === op.type);
                    const itemsTotal = (op.items || []).reduce((s: number, it: any) => s + Number(it.quantity || 0) * Number(it.unitCost || 0), 0);
                    return (
                      <tr key={op.id} className="border-t border-white/10 hover:bg-white/5 transition-colors">
                        <td className="p-3 text-emerald-300 font-mono text-xs">{op.operationNumber}</td>
                        <td className="p-3">
                          <div className="flex flex-col gap-1">
                            <Badge className={`text-xs ${cfg?.badgeClass || "bg-white/10 text-white"}`}>
                              {typeLabel[op.type] || op.type}
                            </Badge>
                            {op.adjustType && (
                              <Badge className={`text-[10px] ${ADJ_TYPES.find(a => a.id === op.adjustType)?.badge || ""}`}>
                                {adjLabel[op.adjustType]}
                              </Badge>
                            )}
                          </div>
                        </td>
                        <td className="p-3 text-white">{op.date}</td>
                        <td className="p-3 text-emerald-300 text-xs">
                          {warehouseName(op.warehouseId)}
                          {op.toWarehouseId && <span className="text-blue-400"> ← {warehouseName(op.toWarehouseId)}</span>}
                        </td>
                        <td className="p-3 text-white/70 text-xs">
                          {(op.items || []).slice(0, 2).map((it: any, i: number) => (
                            <div key={i}>{it.itemName || `صنف #${it.itemId}`} × {it.quantity}</div>
                          ))}
                          {(op.items || []).length > 2 && <div className="text-amber-400">+{(op.items || []).length - 2} أصناف</div>}
                        </td>
                        <td className="p-3 text-center text-amber-300 font-bold">{itemsTotal > 0 ? itemsTotal.toFixed(2) : "—"}</td>
                        <td className="p-3 text-white/50 text-xs max-w-28 truncate">{op.notes || "—"}</td>
                        <td className="p-3 text-center">
                          <div className="flex gap-1 justify-center">
                            <Button size="sm" variant="ghost" className="text-blue-400 h-7 w-7 p-0 hover:bg-blue-900/30"
                              onClick={() => printOperation(op, warehouses as any[])}>
                              <Printer className="w-3.5 h-3.5" />
                            </Button>
                            <Button size="sm" variant="ghost" className="text-red-400 h-7 w-7 p-0 hover:bg-red-900/30"
                              onClick={() => { if (confirm("حذف العملية وعكس أثرها على المخزون؟")) deleteOp.mutate(op.id); }}>
                              <Trash2 className="w-3.5 h-3.5" />
                            </Button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </>
      )}

      {/* ── Add Operation Dialog ─────────────────────────── */}
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-2xl text-white border-emerald-700 max-h-[90vh] overflow-y-auto" dir="rtl"
          style={{ background: "linear-gradient(135deg, #022c22 0%, #064E3B 100%)" }}>
          <DialogHeader>
            <DialogTitle className="text-amber-400 text-xl flex items-center gap-3">
              {React.createElement(curTab.icon, { className: `w-6 h-6 ${curTab.color}` })}
              <span>{curTab.label}</span>
              {activeTab === "adjust" && adjCfg && (
                <span className={`text-sm font-normal px-2 py-0.5 rounded-lg ${adjCfg.badge}`}>
                  {adjCfg.sign} {adjCfg.label}
                </span>
              )}
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-4 pt-1">
            {/* Meta Fields */}
            <div className={`grid gap-3 ${activeTab === "transfer" ? "grid-cols-3" : activeTab === "adjust" ? "grid-cols-3" : "grid-cols-2"}`}>
              <div>
                <Label className="text-emerald-200 text-xs font-semibold">التاريخ</Label>
                <Input type="date" value={date} onChange={e => setDate(e.target.value)} className="bg-emerald-900/60 border-emerald-600 text-white mt-1" />
              </div>
              <div>
                <Label className="text-emerald-200 text-xs font-semibold">المخزن {activeTab === "transfer" ? "(من)" : ""}</Label>
                <Select value={warehouseId} onValueChange={setWarehouseId}>
                  <SelectTrigger className="bg-emerald-900/60 border-emerald-600 text-white mt-1"><SelectValue placeholder="اختر مخزناً" /></SelectTrigger>
                  <SelectContent className="bg-emerald-900 border-emerald-700">
                    {(warehouses as any[]).map((w: any) => <SelectItem key={w.id} value={String(w.id)} className="text-white">{w.nameAr}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>

              {activeTab === "transfer" && (
                <div>
                  <Label className="text-emerald-200 text-xs font-semibold">إلى مخزن</Label>
                  <Select value={toWarehouseId} onValueChange={setToWarehouseId}>
                    <SelectTrigger className="bg-emerald-900/60 border-blue-600 text-white mt-1 border-2"><SelectValue placeholder="مخزن الوجهة" /></SelectTrigger>
                    <SelectContent className="bg-emerald-900 border-emerald-700">
                      {(warehouses as any[]).filter((w: any) => String(w.id) !== warehouseId).map((w: any) =>
                        <SelectItem key={w.id} value={String(w.id)} className="text-white">{w.nameAr}</SelectItem>
                      )}
                    </SelectContent>
                  </Select>
                </div>
              )}

              {activeTab === "adjust" && (
                <div>
                  <Label className="text-emerald-200 text-xs font-semibold">نوع التسوية</Label>
                  <Select value={adjustType} onValueChange={v => setAdjustType(v as AdjType)}>
                    <SelectTrigger className="bg-emerald-900/60 border-amber-600 text-white mt-1 border-2"><SelectValue /></SelectTrigger>
                    <SelectContent className="bg-emerald-900 border-emerald-700">
                      {ADJ_TYPES.map(a => (
                        <SelectItem key={a.id} value={a.id} className="text-white">
                          <span className={a.color}>{a.sign} {a.label} — {a.desc}</span>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              )}
            </div>

            {/* Adjust type info bar */}
            {activeTab === "adjust" && adjCfg && (
              <div className={`rounded-xl px-3 py-2 text-sm font-semibold flex items-center gap-2 ${adjCfg.badge}`}>
                <span className="text-lg">{adjCfg.sign}</span>
                <span>{adjCfg.label} — {adjCfg.desc}</span>
              </div>
            )}

            {/* Items Table */}
            <div>
              <div className="flex justify-between items-center mb-2">
                <Label className="text-emerald-200 text-sm font-bold">
                  {activeTab === "count" ? "أصناف الجرد (الكمية الفعلية)" : "الأصناف"}
                </Label>
                <Button type="button" size="sm" onClick={addRow} className="bg-amber-600 hover:bg-amber-500 text-white gap-1 h-7 text-xs px-3">
                  <Plus className="w-3 h-3" /> إضافة صنف
                </Button>
              </div>
              <div className="rounded-xl border border-emerald-700 overflow-hidden">
                <table className="w-full text-xs">
                  <thead className="bg-emerald-800">
                    <tr>
                      <th className="p-2 text-right text-amber-300">الصنف</th>
                      <th className="p-2 text-center text-amber-300 w-24">{activeTab === "count" ? "الكمية الفعلية" : "الكمية"}</th>
                      {activeTab !== "count" && <th className="p-2 text-center text-amber-300 w-24">سعر الوحدة</th>}
                      {activeTab !== "count" && <th className="p-2 text-center text-amber-300 w-24">الإجمالي</th>}
                      <th className="p-2 w-8"></th>
                    </tr>
                  </thead>
                  <tbody>
                    {opItems.map((item, i) => (
                      <tr key={i} className="border-t border-emerald-700/50">
                        <td className="p-1">
                          <Select value={item.itemId ? String(item.itemId) : ""} onValueChange={v => updateRow(i, "itemId", v)}>
                            <SelectTrigger className="bg-emerald-900/50 border-0 text-white h-8 text-xs">
                              <SelectValue placeholder="اختر صنفاً" />
                            </SelectTrigger>
                            <SelectContent className="bg-emerald-900 border-emerald-700">
                              {(items as any[]).map((it: any) =>
                                <SelectItem key={it.id} value={String(it.id)} className="text-white text-xs">
                                  {it.nameAr} {it.stockQuantity ? `(${Number(it.stockQuantity).toFixed(0)} ${it.unit || ""})` : ""}
                                </SelectItem>
                              )}
                            </SelectContent>
                          </Select>
                        </td>
                        <td className="p-1">
                          <Input type="number" min="0" step="0.01" value={item.quantity || ""} onChange={e => updateRow(i, "quantity", e.target.value)} className="bg-emerald-900/50 border-0 text-white h-8 text-xs text-center" />
                        </td>
                        {activeTab !== "count" && (
                          <td className="p-1">
                            <Input type="number" min="0" step="0.01" value={item.unitCost || ""} onChange={e => updateRow(i, "unitCost", e.target.value)} className="bg-emerald-900/50 border-0 text-white h-8 text-xs text-center" />
                          </td>
                        )}
                        {activeTab !== "count" && (
                          <td className="p-1 text-center text-amber-300 font-bold">
                            {((item.quantity || 0) * (item.unitCost || 0)).toFixed(2)}
                          </td>
                        )}
                        <td className="p-1">
                          <Button type="button" size="sm" variant="ghost" onClick={() => removeRow(i)} className="text-red-400 h-7 w-7 p-0">
                            <Trash2 className="w-3 h-3" />
                          </Button>
                        </td>
                      </tr>
                    ))}
                    {activeTab !== "count" && opItems.length > 0 && (
                      <tr className="border-t-2 border-amber-500/50 bg-emerald-900/40">
                        <td colSpan={2} className="p-2 text-amber-300 font-bold text-xs">الإجمالي — الكمية: {totalQty.toFixed(2)}</td>
                        <td colSpan={2} className="p-2 text-amber-400 font-bold text-xs text-center">القيمة: {totalVal.toFixed(2)}</td>
                        <td></td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Notes */}
            <div>
              <Label className="text-emerald-200 text-xs font-semibold">ملاحظات</Label>
              <Textarea value={notes} onChange={e => setNotes(e.target.value)} className="bg-emerald-900/60 border-emerald-700 text-white mt-1 resize-none text-sm" rows={2} placeholder="أي ملاحظات إضافية..." />
            </div>

            {/* Actions */}
            <div className="flex gap-2 pt-1">
              <Button onClick={handleSubmit} disabled={createOp.isPending} className="bg-amber-500 hover:bg-amber-400 text-white flex-1 h-11 font-bold text-base">
                {createOp.isPending ? "جاري الحفظ..." : `✅ حفظ — ${curTab.label}`}
              </Button>
              <Button variant="outline" onClick={() => setOpen(false)} className="border-emerald-600 text-emerald-200 h-11 px-5">إلغاء</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* ── Add Warehouse Dialog ────────────────────────────── */}
      <Dialog open={warehouseOpen} onOpenChange={setWarehouseOpen}>
        <DialogContent className="max-w-md text-white border-emerald-700" dir="rtl"
          style={{ background: "linear-gradient(135deg, #022c22 0%, #064E3B 100%)" }}>
          <DialogHeader>
            <DialogTitle className="text-amber-400 text-xl flex items-center gap-2">
              <Warehouse className="w-5 h-5 text-purple-400" /> إضافة مخزن جديد
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label className="text-emerald-200 text-sm font-semibold">اسم المخزن *</Label>
              <Input value={newWarehouseName} onChange={e => setNewWarehouseName(e.target.value)} className="bg-emerald-900/60 border-emerald-700 text-white mt-1" placeholder="مثال: مخزن الفرع الثاني" />
            </div>
            <div>
              <Label className="text-emerald-200 text-sm font-semibold">كود المخزن (اختياري)</Label>
              <Input value={newWarehouseCode} onChange={e => setNewWarehouseCode(e.target.value)} className="bg-emerald-900/60 border-emerald-700 text-white mt-1" placeholder="مثال: WH-002" />
            </div>
            <div>
              <Label className="text-emerald-200 text-sm font-semibold">العنوان (اختياري)</Label>
              <Input value={newWarehouseAddr} onChange={e => setNewWarehouseAddr(e.target.value)} className="bg-emerald-900/60 border-emerald-700 text-white mt-1" placeholder="عنوان المخزن" />
            </div>
            <div className="flex gap-2 pt-1">
              <Button onClick={() => createWarehouse.mutate({ nameAr: newWarehouseName, code: newWarehouseCode || undefined, address: newWarehouseAddr || undefined })}
                disabled={createWarehouse.isPending || !newWarehouseName.trim()}
                className="bg-amber-500 hover:bg-amber-400 text-white flex-1 h-11 font-bold">
                {createWarehouse.isPending ? "جاري الحفظ..." : "✅ إضافة المخزن"}
              </Button>
              <Button variant="outline" onClick={() => setWarehouseOpen(false)} className="border-emerald-600 text-emerald-200 h-11">إلغاء</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
