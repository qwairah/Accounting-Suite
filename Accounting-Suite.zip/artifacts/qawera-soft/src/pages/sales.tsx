import { useState, useMemo } from "react";
import { useListSales, useCreateSale, useDeleteSale, useUpdateSale, useListCustomers, useListItems, useListCurrencies, useCreateCustomer, useCreateItem, useListAccounts } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { getListSalesQueryKey, getListCustomersQueryKey, getListItemsQueryKey, getListAccountsQueryKey } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Plus, Trash2, MessageCircle, Camera, UserPlus, Package, MoreVertical, ArrowRight, FileText, ImageIcon, Share2, Send, Search, X, Info, Edit2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { ShareDocumentDialog } from "@/components/ShareDocumentDialog";
import { buildDocumentHTML } from "@/lib/printUtils";
import { InvoicePrintOverlay } from "@/components/InvoicePrintOverlay";
import { useSettings } from "@/contexts/SettingsContext";
import { postToLedger, removeFromLedger, makeId } from "@/lib/ledger";

type PayType = "credit" | "cash";
type SaleItem = { itemId: number; quantity: number; unitPrice: number; discount: number; };
const defaultItem = (): SaleItem => ({ itemId: 0, quantity: 0, unitPrice: 0, discount: 0 });

const statusLabel: Record<string, string> = { posted: "مرحلة", paid: "مدفوع", draft: "مسودة", cancelled: "ملغي" };
const statusColor: Record<string, string> = { posted: "bg-blue-100 text-blue-700", paid: "bg-emerald-100 text-emerald-700", draft: "bg-gray-100 text-gray-600", cancelled: "bg-red-100 text-red-700" };

export default function SalesPage() {
  const qc = useQueryClient();
  const { settings } = useSettings();
  const { data: sales = [], isLoading } = useListSales();
  const { data: customers = [] } = useListCustomers();
  const { data: items = [] } = useListItems();
  const { data: currencies = [] } = useListCurrencies();
  const { data: allAccounts = [] } = useListAccounts();
  const createSale = useCreateSale();
  const deleteSale = useDeleteSale();
  const updateSale = useUpdateSale();
  const createCustomer = useCreateCustomer();
  const createItem = useCreateItem();
  const { toast } = useToast();

  const [open, setOpen] = useState(false);
  const [addCustomerOpen, setAddCustomerOpen] = useState(false);
  const [addItemOpen, setAddItemOpen] = useState(false);
  const [shareOpen, setShareOpen] = useState(false);
  const [sharePhone, setSharePhone] = useState("");
  const [shareMsg, setShareMsg] = useState("");
  const [shareHtmlContent, setShareHtmlContent] = useState<string | undefined>(undefined);
  const [customerName, setCustomerName] = useState("");            // اسم العميل (نص حر)
  const [custNameDropOpen, setCustNameDropOpen] = useState(false);
  const [listSearch, setListSearch] = useState("");
  const [pageSize, setPageSize] = useState(25);
  const [editSale, setEditSale] = useState<any>(null);
  const [editStatus, setEditStatus] = useState("");
  const [editPaid, setEditPaid] = useState(0);
  const [editNotes, setEditNotes] = useState("");
  const [editDate, setEditDate] = useState("");
  const [invoicePreviewHtml, setInvoicePreviewHtml] = useState<string | null>(null);
  const [invoicePreviewTitle, setInvoicePreviewTitle] = useState("فاتورة مبيعات");

  const [payType, setPayType] = useState<PayType>("credit");
  const [isReturn, setIsReturn] = useState(false);
  const [warehouseType, setWarehouseType] = useState("الرئيسي");
  const [currencyId, setCurrencyId] = useState("");
  const [exchangeRate, setExchangeRate] = useState(1);
  const [date, setDate] = useState(new Date().toISOString().split("T")[0]);
  const [saleItems, setSaleItems] = useState<SaleItem[]>([defaultItem()]);
  const [discount, setDiscount] = useState(0);
  const [otherFees, setOtherFees] = useState(0);
  const [otherFeesDesc, setOtherFeesDesc] = useState("");
  const [showOtherFeesDesc, setShowOtherFeesDesc] = useState(false);
  const [amountPaid, setAmountPaid] = useState(0);
  const [paymentAccountId, setPaymentAccountId] = useState("");
  const [notes, setNotes] = useState("");
  const [imagePreview, setImagePreview] = useState<string | null>(null);

  const [newCustName, setNewCustName] = useState("");
  const [newCustPhone, setNewCustPhone] = useState("");
  const [newItemName, setNewItemName] = useState("");
  const [newItemPrice, setNewItemPrice] = useState(0);

  const selectedCurrency = currencies.find(c => String(c.id) === currencyId);
  const isYER = !currencyId || (selectedCurrency as any)?.code === "YER";
  const currencySymbol = selectedCurrency?.symbol || "ر.ي";
  const currencyNameAr = selectedCurrency?.nameAr || "ريال يمني";
  const subtotal = saleItems.reduce((s, it) => s + it.quantity * it.unitPrice, 0);
  const total = subtotal - discount + otherFees;
  const remaining = total - amountPaid;
  const change = payType === "cash" && amountPaid > total ? amountPaid - total : 0;
  const fundAccounts = (allAccounts as any[]).filter(a => !a.isMain && (a.subSubType === "cash" || a.subSubType === "bank"));

  const addItem = () => setSaleItems(prev => [...prev, defaultItem()]);
  const removeItem = (i: number) => setSaleItems(prev => prev.filter((_, idx) => idx !== i));
  const updateItem = (i: number, field: keyof SaleItem, val: string | number) =>
    setSaleItems(prev => prev.map((it, idx) => {
      if (idx !== i) return it;
      if (field === "itemId") {
        const item = items.find(x => x.id === Number(val));
        return { ...it, itemId: Number(val), unitPrice: item?.salePrice ?? 0, quantity: settings.autoAddQty1 ? 1 : it.quantity };
      }
      const num = val === "" ? 0 : parseFloat(String(val));
      return { ...it, [field]: isNaN(num) ? 0 : num };
    }));

  const handleSubmit = async () => {
    const validItems = saleItems.filter(it => it.itemId > 0);
    if (!validItems.length) { toast({ title: "خطأ", description: "أضف صنفاً على الأقل", variant: "destructive" }); return; }
    if (!isReturn) {
      for (const it of validItems) {
        const item = items.find(x => x.id === it.itemId);
        const stock = Number((item as any)?.stockQuantity ?? (item as any)?.quantity ?? 0);
        if (stock <= 0) {
          toast({ title: "⛔ لا يوجد مخزون", description: `الصنف "${item?.nameAr}" غير متوفر في المخزون`, variant: "destructive" }); return;
        }
        if (it.quantity > stock) {
          toast({ title: "⛔ كمية تتجاوز المخزون", description: `الصنف "${item?.nameAr}": المطلوب ${it.quantity}، المتوفر ${stock}`, variant: "destructive" }); return;
        }
      }
    }
    const snapDate = date;
    const snapTotal = total;
    const snapCustName = customerName.trim() || "عميل نقدي";
    const saved = await createSale.mutateAsync({ data: { customerName: snapCustName, date, discount, notes, items: validItems } });

    // تحديث المخزون — خصم الكميات المباعة
    try {
      await fetch("/api/inventory/operations", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          type: "out",
          date: snapDate,
          notes: `مبيعات — فاتورة ${(saved as any)?.invoiceNumber || ""}`,
          items: validItems.map(it => ({
            itemId: it.itemId,
            quantity: it.quantity,
            unitCost: items.find(x => x.id === it.itemId)?.costPrice ?? it.unitPrice,
          })),
        }),
      });
    } catch { /* لا نوقف الحفظ إن فشل تحديث المخزون */ }

    // ✅ ترحيل محاسبي تلقائي: مدين العميل / دائن المخزون
    const docId = String((saved as any)?.id || Date.now());
    const docNum = (saved as any)?.invoiceNumber || docId;
    const ledgerEntries: any[] = [];

    // البحث عن حساب العميل (إن وُجد) أو حساب المخزون
    let custAccount = (allAccounts as any[]).find(a => !a.isMain && a.nameAr === snapCustName);
    if (!custAccount && snapCustName !== "عميل نقدي") {
      // إنشاء حساب العميل تلقائياً إن لم يوجد
      try {
        const res = await fetch("/api/accounts", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ nameAr: snapCustName, type: "assets", subSubType: "customer" }),
        });
        custAccount = await res.json();
        qc.invalidateQueries({ queryKey: getListAccountsQueryKey() });
      } catch { /**/ }
    }
    const inventoryAccount = (allAccounts as any[]).find(a => a.isMain && a.subSubType === "inventory");

    if (snapTotal > 0) {
      // ① مدين: حساب العميل بإجمالي الفاتورة
      if (custAccount?.id) {
        ledgerEntries.push({ id: makeId(), date: snapDate, docType: "sale" as const, docNumber: docNum, docId,
          accountId: custAccount.id, debit: snapTotal, credit: 0,
          description: `مبيعات — ${snapCustName}`, currencySymbol: currencySymbol, ref: docNum });
      }
      // ② دائن: حساب المخزون بإجمالي الفاتورة (خروج البضاعة)
      if (inventoryAccount?.id) {
        ledgerEntries.push({ id: makeId(), date: snapDate, docType: "sale" as const, docNumber: docNum, docId,
          accountId: inventoryAccount.id, debit: 0, credit: snapTotal,
          description: `مبيعات — ${snapCustName}`, currencySymbol: currencySymbol, ref: docNum });
      }
    }
    postToLedger(ledgerEntries);
    const autoShareMsg = settings.sendOnSave ? buildShareMsg() : "";
    const autoSharePhone = settings.sendOnSave ? (custAccount as any)?.phone || "" : "";
    const autoHtml = settings.sendOnSave ? buildSaleDocHtml() : undefined;
    qc.invalidateQueries({ queryKey: getListSalesQueryKey() });
    setOpen(false); resetForm();
    toast({ title: "✅ تم الحفظ", description: "تم إنشاء فاتورة المبيعات" });
    if (settings.sendOnSave) { setShareMsg(autoShareMsg); setSharePhone(autoSharePhone); setShareHtmlContent(autoHtml); setShareOpen(true); }
  };

  const filteredSales = useMemo(() => {
    const s = listSearch.toLowerCase();
    return (sales as any[]).filter(sale =>
      !s || (sale.invoiceNumber || "").toLowerCase().includes(s) ||
      (sale.customerName || "").toLowerCase().includes(s) ||
      (sale.date || "").includes(s) ||
      (sale.notes || "").toLowerCase().includes(s)
    );
  }, [sales, listSearch]);

  const displayedSales = pageSize === -1 ? filteredSales : filteredSales.slice(0, pageSize);

  const openEditSale = (sale: any) => {
    setEditSale(sale);
    setEditStatus(sale.status || "posted");
    setEditPaid(Number(sale.paidAmount || 0));
    setEditNotes(sale.notes || "");
    setEditDate(sale.date || "");
  };

  const handleEditSave = async () => {
    if (!editSale) return;
    const remaining = Number(editSale.total) - editPaid;
    const autoStatus = editPaid >= Number(editSale.total) ? "paid" : editPaid > 0 ? "posted" : editStatus;
    await updateSale.mutateAsync({ id: editSale.id, data: { status: autoStatus, paidAmount: editPaid, notes: editNotes, date: editDate } });
    qc.invalidateQueries({ queryKey: getListSalesQueryKey() });
    toast({ title: "✅ تم التعديل", description: "تم تحديث بيانات الفاتورة" });
    setEditSale(null);
  };

  const resetForm = () => {
    setSaleItems([defaultItem()]); setDiscount(0); setOtherFees(0); setOtherFeesDesc(""); setAmountPaid(0);
    const defFundId = settings.defaultFund ? String((fundAccounts as any[]).find(a => a.nameAr === settings.defaultFund)?.id || "") : "";
    setNotes(settings.invoiceNotes || ""); setCustomerName(""); setCurrencyId(""); setIsReturn(false); setImagePreview(null);
    setPaymentAccountId(defFundId); setShowOtherFeesDesc(false);
  };

  const buildSaleDocHtml = (sale?: any) => {
    const sym = sale ? (sale.currencySymbol || "ر.ي") : currencySymbol;
    const validItems = sale ? (sale.items || []) : saleItems.filter(it => it.itemId > 0);
    const customer = sale ? { nameAr: sale.customerName } : { nameAr: customerName.trim() || "عميل نقدي" };
    const totalVal = sale ? Number(sale.total) : total;
    const paidVal = sale ? Number(sale.amountPaid || 0) : amountPaid;
    const remVal = sale ? Number(sale.remaining || 0) : remaining;
    const rows = validItems.map((it: any) => [
      it.nameAr || items.find((x: any) => x.id === it.itemId)?.nameAr || "",
      String(it.quantity),
      Number(it.unitPrice).toFixed(2) + " " + sym,
      (it.quantity * it.unitPrice).toFixed(2) + " " + sym,
    ]);
    return buildDocumentHTML(
      isReturn ? "مردودات مبيعات" : "فاتورة مبيعات",
      [
        { label: "رقم الفاتورة", value: sale?.invoiceNumber || "—" },
        { label: "التاريخ", value: sale?.date || date },
        { label: "العميل", value: customer?.nameAr || "عميل نقدي" },
        { label: "طريقة الدفع", value: payType === "cash" ? "نقد" : "آجل" },
        { label: "العملة", value: currencyNameAr },
      ],
      ["الصنف", "الكمية", "السعر", "الإجمالي"],
      rows,
      [
        ...(discount > 0 ? [{ label: "الخصم", value: `-${discount.toFixed(2)} ${sym}` }] : []),
        ...(otherFees > 0 ? [{ label: "رسوم أخرى", value: `+${otherFees.toFixed(2)} ${sym}` }] : []),
        { label: "💰 الإجمالي الكلي", value: `${totalVal.toFixed(2)} ${sym}` },
        ...(paidVal > 0 ? [{ label: "✅ المدفوع", value: `${paidVal.toFixed(2)} ${sym}` }] : []),
        ...(remVal > 0 ? [{ label: "⚠️ المتبقي", value: `${remVal.toFixed(2)} ${sym}` }] : []),
      ],
      { ...settings, currencyNameAr },
      notes ? `ملاحظات: ${notes}` : ""
    );
  };

  const handleAddCustomer = async () => {
    if (!newCustName) return;
    await createCustomer.mutateAsync({ data: { nameAr: newCustName, phone: newCustPhone } });
    qc.invalidateQueries({ queryKey: getListCustomersQueryKey() });
    qc.invalidateQueries({ queryKey: getListAccountsQueryKey() });
    setCustomerName(newCustName);
    setAddCustomerOpen(false); setNewCustName(""); setNewCustPhone("");
  };

  const handleAddItem = async () => {
    if (!newItemName) return;
    await createItem.mutateAsync({ data: { nameAr: newItemName, salePrice: newItemPrice, costPrice: 0, unit: "قطعة", taxRate: 15 } });
    qc.invalidateQueries({ queryKey: getListItemsQueryKey() });
    setAddItemOpen(false); setNewItemName(""); setNewItemPrice(0);
  };

  const SEP = "─────────────────────";

  const buildShareMsg = (sale?: any) => {
    const sym = sale ? (sale.currencySymbol || "ر.ي") : currencySymbol;
    const fmt = (n: number) => Number(n).toLocaleString("ar-YE", { minimumFractionDigits: 0, maximumFractionDigits: 2 });
    if (sale) {
      const lineItems = (sale.items || []).map((it: any) =>
        `• ${it.nameAr || "صنف"}: ${it.quantity} × ${fmt(it.unitPrice)} = ${fmt(it.quantity * it.unitPrice)} ${sym}`
      ).join("\n");
      return [
        `🧾 *فاتورة مبيعات — قـويـره سوفت*`,
        `رقم الفاتورة: *${sale.invoiceNumber || ""}*`,
        `التاريخ: ${sale.date}`,
        `العميل: ${sale.customerName || "عميل نقدي"}`,
        SEP,
        lineItems || "─ لا توجد أصناف ─",
        SEP,
        `💰 *الإجمالي: ${fmt(sale.total)} ${sym}*`,
        Number(sale.amountPaid) > 0 ? `✅ المدفوع: ${fmt(sale.amountPaid)} ${sym}` : "",
        Number(sale.remaining) > 0 ? `⚠️ *المتبقي عليك: ${fmt(sale.remaining)} ${sym}*` : Number(sale.amountPaid) > 0 ? "✅ *مدفوع بالكامل*" : "",
        notes ? `📝 ملاحظة: ${notes}` : "",
        SEP,
        "شكراً لتعاملكم معنا 🌟"
      ].filter(Boolean).join("\n");
    } else {
      const validItems = saleItems.filter(it => it.itemId > 0);
      const lineItems = validItems.map(it => {
        const item = items.find(x => x.id === it.itemId);
        return `• ${item?.nameAr || "صنف"}: ${it.quantity} × ${fmt(it.unitPrice)} = ${fmt(it.quantity * it.unitPrice)} ${sym}`;
      }).join("\n");
      return [
        `🧾 *فاتورة مبيعات — قـويـره سوفت*`,
        `التاريخ: ${date}`,
        `العميل: ${customerName.trim() || "عميل نقدي"}`,
        SEP,
        lineItems || "─ لا توجد أصناف ─",
        SEP,
        discount > 0 ? `الخصم: ${fmt(discount)} ${sym}` : "",
        otherFees > 0 ? `رسوم أخرى: ${fmt(otherFees)} ${sym}` : "",
        `💰 *الإجمالي: ${fmt(total)} ${sym}*`,
        amountPaid > 0 ? `✅ المدفوع: ${fmt(amountPaid)} ${sym}` : "",
        remaining > 0 ? `⚠️ *المتبقي عليك: ${fmt(remaining)} ${sym}*` : amountPaid > 0 ? "✅ *مدفوع بالكامل*" : "",
        notes ? `📝 ملاحظة: ${notes}` : "",
        SEP,
        "شكراً لتعاملكم معنا 🌟"
      ].filter(Boolean).join("\n");
    }
  };

  const openShareFromList = (sale: any) => {
    const custAcc = (allAccounts as any[]).find(a => a.nameAr === sale.customerName && !a.isMain);
    setSharePhone(custAcc?.phone || "");
    setShareMsg(buildShareMsg(sale));
    setShareHtmlContent(buildSaleDocHtml(sale));
    setShareOpen(true);
  };

  const openShareFromForm = () => {
    const custAcc = (allAccounts as any[]).find(a => a.nameAr === customerName && !a.isMain);
    setSharePhone(custAcc?.phone || "");
    setShareMsg(buildShareMsg());
    setShareHtmlContent(buildSaleDocHtml());
    setShareOpen(true);
  };

  const buildInvoiceHtml = (sale?: any) => {
    const sym = sale ? (sale.currencySymbol || "ر.ي") : currencySymbol;
    const validItems = sale ? (sale.items || []) : saleItems.filter(it => it.itemId > 0);
    const customer = sale ? { nameAr: sale.customerName } : { nameAr: customerName.trim() || "عميل نقدي" };
    const totalVal = sale ? Number(sale.total) : total;
    const paidVal = sale ? Number(sale.amountPaid || 0) : amountPaid;
    const remVal = sale ? Number(sale.remaining || 0) : remaining;
    const title = isReturn ? "مردودات مبيعات" : "فاتورة مبيعات";
    const rows = validItems.map((it: any) => [
      it.nameAr || items.find(x => x.id === it.itemId)?.nameAr || "",
      String(it.quantity),
      Number(it.unitPrice).toFixed(2) + " " + sym,
      (it.quantity * it.unitPrice).toFixed(2) + " " + sym,
    ]);
    return { title, html: buildDocumentHTML(
      title,
      [
        { label: "رقم الفاتورة", value: sale?.invoiceNumber || "—" },
        { label: "التاريخ", value: sale?.date || date },
        { label: "العميل", value: customer?.nameAr || "عميل نقدي" },
        { label: "طريقة الدفع", value: payType === "cash" ? "نقد" : "آجل" },
        { label: "المخزن", value: warehouseType },
        { label: "العملة", value: currencyNameAr },
      ],
      ["الصنف", "الكمية", "السعر", "الإجمالي"],
      rows,
      [
        ...(discount > 0 ? [{ label: "الخصم", value: `-${discount.toFixed(2)} ${sym}` }] : []),
        ...(otherFees > 0 ? [{ label: "رسوم أخرى", value: `+${otherFees.toFixed(2)} ${sym}` }] : []),
        { label: "💰 الإجمالي الكلي", value: `${totalVal.toFixed(2)} ${sym}` },
        ...(paidVal > 0 ? [{ label: "✅ المدفوع", value: `${paidVal.toFixed(2)} ${sym}` }] : []),
        ...(remVal > 0 ? [{ label: "⚠️ المتبقي", value: `${remVal.toFixed(2)} ${sym}` }] : []),
      ],
      { ...settings, currencyNameAr },
      notes ? `ملاحظات: ${notes}` : ""
    )};
  };

  const handlePrintPDF = (sale?: any) => {
    const { title, html } = buildInvoiceHtml(sale);
    setInvoicePreviewTitle(title);
    setInvoicePreviewHtml(html);
  };

  return (
    <div className="space-y-5 animate-in fade-in duration-300">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-amber-400">المبيعات</h1>
          <p className="text-emerald-200 mt-1">إدارة فواتير المبيعات — {filteredSales.length} فاتورة</p>
        </div>
        <Button onClick={() => setOpen(true)} className="bg-amber-500 hover:bg-amber-400 text-white gap-2 h-11">
          <Plus className="w-4 h-4" /> فاتورة جديدة
        </Button>
      </div>

      {/* Search + Count Filter */}
      <div className="flex gap-2 items-center">
        <div className="relative flex-1">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-emerald-400" />
          <Input value={listSearch} onChange={e => setListSearch(e.target.value)} placeholder="بحث برقم الفاتورة أو العميل أو التاريخ..." className="bg-emerald-900/50 border-emerald-700 text-white pr-10 placeholder:text-emerald-500" />
        </div>
        <Select value={String(pageSize)} onValueChange={v => setPageSize(Number(v))}>
          <SelectTrigger className="bg-emerald-900 border-emerald-700 text-white h-10 w-32 text-sm"><SelectValue /></SelectTrigger>
          <SelectContent className="bg-emerald-900 border-emerald-700">
            {[10, 25, 50, 100, -1].map(n => <SelectItem key={n} value={String(n)} className="text-white text-sm">{n === -1 ? "الكل" : `${n} سجل`}</SelectItem>)}
          </SelectContent>
        </Select>
      </div>

      <div className="bg-white/5 rounded-xl border border-white/10 overflow-x-auto">
        <table className="w-full text-sm min-w-max">
          <thead className="bg-emerald-800/60 sticky top-0">
            <tr>
              <th className="p-2.5 text-center text-amber-300 w-12">#</th>
              <th className="p-2.5 text-right text-amber-300">العميل</th>
              <th className="p-2.5 text-right text-amber-300">التاريخ</th>
              <th className="p-2.5 text-right text-amber-300">الأصناف</th>
              <th className="p-2.5 text-right text-amber-300">الإجمالي</th>
              <th className="p-2.5 text-center text-amber-300">إجراءات</th>
            </tr>
          </thead>
          <tbody>
            {isLoading ? <tr><td colSpan={6} className="p-6 text-center text-emerald-200">جاري التحميل...</td></tr>
            : displayedSales.length === 0 ? <tr><td colSpan={6} className="p-8 text-center text-emerald-300">لا توجد فواتير مبيعات</td></tr>
            : displayedSales.map((sale: any) => {
              const sym = sale.currencySymbol || "ر.ي";
              const paid = Number(sale.paidAmount || 0);
              const total = Number(sale.total || 0);
              const remaining = total - paid;
              const isPaid = remaining <= 0.01 && total > 0;
              return (
                <tr key={sale.id} className="border-t border-white/5 hover:bg-emerald-800/30 transition-colors">
                  <td className="p-2.5 text-center">
                    <span className="text-amber-400 font-black text-base">{sale.invoiceNumber}</span>
                  </td>
                  <td className="p-2.5">
                    <p className="text-white font-semibold text-sm">{sale.customerName ?? "عميل نقدي"}</p>
                    <p className="text-emerald-400 text-xs mt-0.5">{sale.isReturn ? "🔄 مردودات" : "🧾 مبيعات"} {sale.warehouseType ? `· ${sale.warehouseType}` : ""}</p>
                  </td>
                  <td className="p-2.5 text-emerald-200 text-sm whitespace-nowrap">{sale.date}</td>
                  <td className="p-2.5">
                    <span className="bg-emerald-800 text-emerald-200 text-xs rounded-full px-2 py-0.5">{(sale.items || []).length} صنف</span>
                  </td>
                  <td className="p-2.5">
                    <p className="text-amber-300 font-black text-sm">{total.toFixed(2)} <span className="text-amber-500 text-xs">{sym}</span></p>
                    {isPaid ? <p className="text-green-400 text-xs">✅ مسدد</p> : remaining > 0 ? <p className="text-red-400 text-xs">باقي {remaining.toFixed(2)}</p> : null}
                  </td>
                  <td className="p-2.5">
                    <div className="flex gap-1 justify-center">
                      {settings.allowEditInvoices && <Button size="sm" variant="ghost" className="text-amber-400 h-7 w-7 p-0" title="تعديل" onClick={() => openEditSale(sale)}><Edit2 className="w-3.5 h-3.5" /></Button>}
                      <Button size="sm" variant="ghost" className="text-blue-400 h-7 w-7 p-0" title="طباعة" onClick={() => handlePrintPDF(sale)}><FileText className="w-3.5 h-3.5" /></Button>
                      <Button size="sm" variant="ghost" className="text-green-400 h-7 w-7 p-0" title="مشاركة" onClick={() => openShareFromList(sale)}><Share2 className="w-3.5 h-3.5" /></Button>
                      {settings.allowDeleteInvoices && <Button size="sm" variant="ghost" className="text-red-400 h-7 w-7 p-0" title="حذف" onClick={async () => { await deleteSale.mutateAsync({ id: sale.id }); removeFromLedger(sale.id, "sale"); qc.invalidateQueries({ queryKey: getListSalesQueryKey() }); }}><Trash2 className="w-3.5 h-3.5" /></Button>}
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
        {pageSize !== -1 && filteredSales.length > pageSize && (
          <div className="p-3 text-center text-emerald-400 text-sm border-t border-white/10">
            يُعرض {pageSize} من {filteredSales.length} — <button className="text-amber-400 underline" onClick={() => setPageSize(-1)}>عرض الكل</button>
          </div>
        )}
      </div>

      <ShareDocumentDialog
        open={shareOpen}
        onClose={() => setShareOpen(false)}
        docTitle="فاتورة مبيعات"
        message={shareMsg}
        phone={sharePhone}
        onPrintPDF={() => handlePrintPDF()}
        htmlContent={shareHtmlContent}
      />

      {/* Edit Sale Dialog */}
      <Dialog open={!!editSale} onOpenChange={v => !v && setEditSale(null)}>
        <DialogContent className="max-w-sm text-white border-amber-700" dir="rtl" style={{background: "linear-gradient(135deg, #022c22, #064E3B)"}}>
          <DialogHeader><DialogTitle className="text-amber-400">✏️ تعديل الفاتورة</DialogTitle></DialogHeader>
          <div className="space-y-4 py-2">
            <div className="bg-emerald-800/40 rounded-xl p-3 border border-emerald-700 text-sm space-y-1">
              <p className="text-emerald-300">رقم الفاتورة: <span className="text-white font-mono">{editSale?.invoiceNumber}</span></p>
              <p className="text-emerald-300">العميل: <span className="text-white">{editSale?.customerName || "عميل نقدي"}</span></p>
              <p className="text-emerald-300">الإجمالي: <span className="text-amber-300 font-bold">{Number(editSale?.total || 0).toFixed(2)} {editSale?.currencySymbol || "ر.ي"}</span></p>
            </div>
            <div>
              <Label className="text-emerald-300 text-sm">التاريخ</Label>
              <Input type="date" value={editDate} onChange={e => setEditDate(e.target.value)} className="bg-emerald-900 border-emerald-700 text-white mt-1 h-10 text-sm" />
            </div>
            <div>
              <Label className="text-emerald-300 text-sm">الحالة</Label>
              <Select value={editStatus} onValueChange={setEditStatus}>
                <SelectTrigger className="bg-emerald-900 border-emerald-700 text-white mt-1 h-10 text-sm"><SelectValue /></SelectTrigger>
                <SelectContent className="bg-emerald-900 border-emerald-700">
                  <SelectItem value="posted" className="text-white">مرحلة</SelectItem>
                  <SelectItem value="paid" className="text-white">مدفوع</SelectItem>
                  <SelectItem value="draft" className="text-white">مسودة</SelectItem>
                  <SelectItem value="cancelled" className="text-white">ملغي</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-emerald-300 text-sm">المبلغ المدفوع</Label>
              <Input type="number" step="0.01" min="0" value={editPaid} onChange={e => setEditPaid(parseFloat(e.target.value) || 0)} className="bg-emerald-900 border-emerald-700 text-amber-300 mt-1 h-10 text-sm font-bold text-center" />
              {editSale && <p className="text-xs text-emerald-400 mt-1">المتبقي: {Math.max(0, Number(editSale.total) - editPaid).toFixed(2)} {editSale.currencySymbol || "ر.ي"}</p>}
            </div>
            <div>
              <Label className="text-emerald-300 text-sm">ملاحظات</Label>
              <Input value={editNotes} onChange={e => setEditNotes(e.target.value)} className="bg-emerald-900 border-emerald-700 text-white mt-1 h-10 text-sm" placeholder="أضف ملاحظة..." />
            </div>
            <div className="flex gap-2">
              <Button onClick={handleEditSave} disabled={updateSale.isPending} className="flex-1 bg-amber-500 hover:bg-amber-400 text-white">{updateSale.isPending ? "..." : "حفظ التعديل"}</Button>
              <Button variant="ghost" onClick={() => setEditSale(null)} className="text-emerald-300 border border-emerald-700">إلغاء</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Invoice Dialog */}
      <Dialog open={open} onOpenChange={v => { if (!v) resetForm(); setOpen(v); }}>
        <DialogContent className="max-w-xl p-0 bg-emerald-950 border-emerald-700 text-white overflow-hidden" dir="rtl">
          {/* Top Action Bar */}
          <div className="sticky top-0 z-20 flex items-center gap-1.5 px-3 py-2.5 bg-emerald-900 border-b border-emerald-700">
            <Button size="sm" variant="ghost" onClick={() => { setOpen(false); resetForm(); }} className="text-emerald-200 hover:text-white h-8 w-8 p-0">
              <ArrowRight className="w-4 h-4" />
            </Button>
            <span className="flex-1 text-center text-amber-400 font-bold text-sm">
              {isReturn ? "🔄 مردودات مبيعات" : "🧾 فاتورة مبيعات"}
            </span>
            <Button size="sm" onClick={handleSubmit} disabled={createSale.isPending} className="bg-amber-500 hover:bg-amber-400 text-white h-8 px-3 text-xs font-bold gap-1">
              {createSale.isPending ? "..." : <><FileText className="w-3 h-3" /> حفظ</>}
            </Button>
            <Button size="sm" variant="ghost" onClick={() => handlePrintPDF()} className="text-red-400 hover:text-red-300 h-8 w-8 p-0">
              <FileText className="w-4 h-4" />
            </Button>
            <Button size="sm" variant="ghost" onClick={openShareFromForm} className="text-blue-400 hover:text-blue-300 h-8 w-8 p-0">
              <ImageIcon className="w-4 h-4" />
            </Button>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button size="sm" variant="ghost" className="text-emerald-300 hover:text-white h-8 w-8 p-0">
                  <MoreVertical className="w-4 h-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent className="bg-emerald-900 border-emerald-700 text-white" align="end">
                <DropdownMenuItem className="text-red-400 gap-2 cursor-pointer" onClick={() => { setOpen(false); resetForm(); }}><Trash2 className="w-4 h-4" /> حذف</DropdownMenuItem>
                <DropdownMenuItem className="text-white gap-2 cursor-pointer" onClick={openShareFromForm}><Share2 className="w-4 h-4 text-blue-400" /> مشاركة</DropdownMenuItem>
                <DropdownMenuItem className="text-white gap-2 cursor-pointer" onClick={() => { const custAcc = (allAccounts as any[]).find(a => a.nameAr === customerName && !a.isMain); const m = buildShareMsg(); const url = `sms:${(custAcc?.phone || "").replace(/\D/g, "")}?body=${encodeURIComponent(m)}`; window.location.href = url; }}><Send className="w-4 h-4 text-purple-400" /> SMS</DropdownMenuItem>
                <DropdownMenuItem className="text-green-400 gap-2 cursor-pointer" onClick={() => { const custAcc = (allAccounts as any[]).find(a => a.nameAr === customerName && !a.isMain); const m = encodeURIComponent(buildShareMsg()); const ph = (custAcc?.phone || "").replace(/\D/g, ""); window.open(ph ? `https://wa.me/${ph}?text=${m}` : `https://wa.me/?text=${m}`, "_blank"); }}><MessageCircle className="w-4 h-4" /> واتساب</DropdownMenuItem>
                <DropdownMenuItem className="text-blue-400 gap-2 cursor-pointer" onClick={() => { window.open(`https://t.me/share/url?text=${encodeURIComponent(buildShareMsg())}`, "_blank"); }}><Send className="w-4 h-4" /> تيليجرام</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>

          <div className="overflow-y-auto max-h-[82vh] p-4 space-y-4">
            {/* Row 1: Pay type + Warehouse + Invoice/Return toggle */}
            <div className="flex gap-2">
              <div className="flex rounded-xl overflow-hidden border border-emerald-700 flex-1">
                {(["credit", "cash"] as const).map(t => (
                  <button key={t} onClick={() => setPayType(t)} className={`flex-1 py-2.5 text-sm font-bold transition-all ${payType === t ? "bg-amber-500 text-white" : "text-emerald-300 hover:bg-white/10"}`}>
                    {t === "credit" ? "آجل" : "نقد"}
                  </button>
                ))}
              </div>
              <Select value={warehouseType} onValueChange={setWarehouseType}>
                <SelectTrigger className="bg-emerald-900 border-emerald-700 text-white h-10 text-sm w-32"><SelectValue /></SelectTrigger>
                <SelectContent className="bg-emerald-900 border-emerald-700">
                  {["الرئيسي", "الفرعي", "المستودع 1", "المستودع 2"].map(w => <SelectItem key={w} value={w} className="text-white text-sm">{w}</SelectItem>)}
                </SelectContent>
              </Select>
              <div className="flex rounded-xl overflow-hidden border border-emerald-700">
                <button onClick={() => setIsReturn(false)} className={`px-3 py-2 text-sm font-bold transition-all ${!isReturn ? "bg-emerald-600 text-white" : "text-emerald-300 hover:bg-white/10"}`}>فاتورة</button>
                <button onClick={() => setIsReturn(true)} className={`px-3 py-2 text-sm font-bold transition-all ${isReturn ? "bg-orange-600 text-white" : "text-emerald-300 hover:bg-white/10"}`}>مرتجع</button>
              </div>
            </div>

            {/* Currency row */}
            <div className="flex gap-2 items-end">
              <div className="flex-1">
                <Label className="text-emerald-300 text-sm">العملة</Label>
                <Select value={currencyId} onValueChange={v => { setCurrencyId(v); const c = currencies.find(x => String(x.id) === v); setExchangeRate((c as any)?.exchangeRate || 1); }}>
                  <SelectTrigger className="bg-emerald-900 border-emerald-700 text-white mt-1 h-10 text-sm"><SelectValue placeholder="ريال يمني (رسمي)" /></SelectTrigger>
                  <SelectContent className="bg-emerald-900 border-emerald-700">
                    {currencies.map(c => <SelectItem key={c.id} value={String(c.id)} className="text-white text-sm">{c.nameAr || c.code} ({c.symbol})</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              {currencyId && !isYER && (
                <div className="w-32">
                  <Label className="text-amber-300 text-sm">سعر الصرف</Label>
                  <Input type="number" step="0.0001" min="0" value={exchangeRate || ""} onChange={e => setExchangeRate(parseFloat(e.target.value) || 1)} className="bg-emerald-900 border-amber-600 text-amber-300 mt-1 h-10 text-sm text-center" />
                </div>
              )}
              {currencyId && <span className="text-emerald-400 text-sm pb-2">{currencyNameAr}</span>}
            </div>

            {/* اسم العميل + التاريخ */}
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label className="text-emerald-300 text-sm mb-1 block">اسم العميل</Label>
                <div className="relative">
                  <Input
                    value={customerName}
                    onChange={e => { setCustomerName(e.target.value); setCustNameDropOpen(true); }}
                    onFocus={() => setCustNameDropOpen(true)}
                    onBlur={() => setTimeout(() => setCustNameDropOpen(false), 180)}
                    placeholder="اكتب اسم العميل..."
                    className="bg-emerald-900 border-emerald-700 text-white h-10 text-sm pr-8"
                  />
                  <Search className="absolute right-2.5 top-3 w-3.5 h-3.5 text-emerald-400 pointer-events-none" />
                  {custNameDropOpen && customerName && (
                    <div className="absolute z-50 w-full top-full mt-1 bg-emerald-900 border border-emerald-600 rounded-xl shadow-2xl max-h-44 overflow-y-auto">
                      {(allAccounts as any[])
                        .filter(a => !a.isMain && a.nameAr?.includes(customerName))
                        .slice(0, 8)
                        .map((a: any) => (
                          <button key={a.id} onClick={() => { setCustomerName(a.nameAr); setCustNameDropOpen(false); }}
                            className="w-full text-right px-3 py-2 hover:bg-emerald-700 text-white text-sm border-b border-emerald-800/50 last:border-0">
                            {a.nameAr}
                          </button>
                        ))}
                      {(allAccounts as any[]).filter(a => !a.isMain && a.nameAr?.includes(customerName)).length === 0 && (
                        <div className="px-3 py-2.5 text-center">
                          <p className="text-white/50 text-xs mb-1">سيُنشأ الحساب تلقائياً</p>
                          <button onClick={() => { setCustNameDropOpen(false); setAddCustomerOpen(true); setNewCustName(customerName); }}
                            className="text-amber-400 text-xs font-bold hover:text-amber-300 flex items-center gap-1 mx-auto">
                            <UserPlus className="w-3 h-3" /> إضافة "{customerName}" الآن
                          </button>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              </div>
              <div>
                <Label className="text-emerald-300 text-sm">التاريخ</Label>
                <Input type="date" value={date} onChange={e => setDate(e.target.value)} className="bg-emerald-900 border-emerald-700 text-white mt-1 h-10 text-sm" />
              </div>
            </div>

            {/* ملخص القيد التلقائي */}
            {total > 0 && (
              <div className="rounded-xl border border-emerald-700/30 bg-emerald-950/40 p-2.5 text-xs space-y-1">
                <p className="text-emerald-400 font-bold text-center text-xs mb-1.5">⚙️ الترحيل التلقائي</p>
                <div className="flex justify-between items-center">
                  <span className="text-amber-300">↑ مدين — {customerName.trim() || "عميل نقدي"}</span>
                  <span className="text-amber-200 font-bold">{total.toFixed(2)} {currencySymbol}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-emerald-300">↓ دائن — المخزون</span>
                  <span className="text-emerald-200 font-bold">{total.toFixed(2)} {currencySymbol}</span>
                </div>
              </div>
            )}

            {/* Notes + Camera */}
            <div className="flex gap-2 items-end">
              <div className="flex-1">
                <Label className="text-emerald-300 text-sm">بيانات / ملاحظات</Label>
                <Input value={notes} onChange={e => setNotes(e.target.value)} className="bg-emerald-900 border-emerald-700 text-white mt-1 h-10 text-sm" placeholder="ملاحظات الفاتورة..." />
              </div>
              <label className="cursor-pointer">
                <div className={`h-10 w-11 rounded-lg border-2 border-dashed flex items-center justify-center transition-colors ${imagePreview ? "border-emerald-500 bg-emerald-800" : "border-emerald-700 hover:border-amber-400"}`}>
                  {imagePreview ? <img src={imagePreview} alt="" className="h-9 w-10 object-cover rounded" /> : <Camera className="w-5 h-5 text-emerald-400" />}
                </div>
                <input type="file" accept="image/*" capture="environment" className="hidden" onChange={e => { const f = e.target.files?.[0]; if (f) setImagePreview(URL.createObjectURL(f)); }} />
              </label>
            </div>

            {/* Items Section */}
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <Label className="text-amber-300 font-bold text-base">الأصناف</Label>
                <button onClick={() => setAddItemOpen(true)} className="text-emerald-400 text-sm flex items-center gap-1 hover:text-emerald-300">
                  <Package className="w-4 h-4" /> صنف جديد
                </button>
              </div>
              {saleItems.map((it, i) => (
                <div key={i} className="rounded-xl border border-emerald-700/60 p-4 space-y-3 bg-emerald-900/30">
                  {/* Item name */}
                  <Select value={String(it.itemId)} onValueChange={v => updateItem(i, "itemId", v)}>
                    <SelectTrigger className="bg-emerald-900 border-emerald-700 text-white h-11 text-sm w-full"><SelectValue placeholder="اختر الصنف..." /></SelectTrigger>
                    <SelectContent className="bg-emerald-900 border-emerald-700">
                      {items.map(item => <SelectItem key={item.id} value={String(item.id)} className="text-white text-sm">{item.nameAr}</SelectItem>)}
                    </SelectContent>
                  </Select>
                  {/* Qty / Price / Total */}
                  <div className="grid grid-cols-3 gap-2">
                    <div>
                      <Label className="text-emerald-400 text-sm">الكمية</Label>
                      <Input
                        type="number"
                        min="0"
                        value={it.quantity === 0 ? "" : it.quantity}
                        onChange={e => updateItem(i, "quantity", e.target.value)}
                        className="bg-emerald-900 border-emerald-600 text-white mt-1 h-12 text-base font-bold text-center"
                        placeholder="0"
                      />
                    </div>
                    <div>
                      <Label className="text-emerald-400 text-sm">السعر</Label>
                      <Input
                        type="number"
                        min="0"
                        value={it.unitPrice === 0 ? "" : it.unitPrice}
                        onChange={e => updateItem(i, "unitPrice", e.target.value)}
                        className="bg-emerald-900 border-emerald-600 text-white mt-1 h-12 text-base font-bold text-center"
                        placeholder="0"
                      />
                    </div>
                    <div>
                      <Label className="text-emerald-400 text-sm">الإجمالي</Label>
                      <div className="mt-1 h-12 flex items-center justify-center bg-amber-900/30 rounded-md border border-amber-700/40">
                        <span className="text-amber-400 font-bold text-base">{(it.quantity * it.unitPrice).toLocaleString("ar-YE", { minimumFractionDigits: 0, maximumFractionDigits: 2 })}</span>
                      </div>
                    </div>
                  </div>
                  {/* Add / Close buttons */}
                  <div className="flex gap-2">
                    <button onClick={addItem} className="flex-1 flex items-center justify-center gap-1 py-2 rounded-lg bg-emerald-800/60 hover:bg-emerald-700/60 text-emerald-300 text-sm transition-colors border border-emerald-700/40">
                      <Plus className="w-4 h-4" /> إضافة صنف
                    </button>
                    {saleItems.length > 1 && (
                      <button onClick={() => removeItem(i)} className="flex items-center justify-center gap-1 px-4 py-2 rounded-lg hover:bg-red-900/30 text-red-400 text-sm transition-colors border border-red-800/30">
                        <X className="w-4 h-4" /> حذف
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>

            {/* Footer Totals */}
            <div className="rounded-xl border border-emerald-700/50 p-4 bg-emerald-900/30 space-y-3">
              {/* Discount */}
              <div className="flex items-center gap-3">
                <Label className="text-emerald-300 text-sm w-28 shrink-0">الخصم</Label>
                <Input type="number" min="0" value={discount || ""} onChange={e => setDiscount(parseFloat(e.target.value) || 0)} className="flex-1 bg-emerald-900 border-emerald-700 text-white h-11 text-sm" placeholder="0" />
                <span className="text-emerald-400 text-sm font-bold">{currencySymbol}</span>
              </div>
              {/* Amount Paid + Account */}
              <div className="flex items-center gap-2">
                <Label className="text-emerald-300 text-sm w-28 shrink-0">{payType === "cash" ? "المستلم" : "المدفوع"}</Label>
                <Input type="number" min="0" value={amountPaid || ""} onChange={e => setAmountPaid(parseFloat(e.target.value) || 0)} className="flex-1 bg-emerald-900 border-emerald-700 text-white h-11 text-sm" placeholder="0" />
                <Select value={paymentAccountId} onValueChange={setPaymentAccountId}>
                  <SelectTrigger className="w-32 bg-emerald-900 border-emerald-700 text-white h-11 text-sm"><SelectValue placeholder="الحساب" /></SelectTrigger>
                  <SelectContent className="bg-emerald-900 border-emerald-700">
                    {fundAccounts.map((a: any) => <SelectItem key={a.id} value={String(a.id)} className="text-white text-sm">{a.nameAr}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              {/* Other Fees */}
              <div className="space-y-1.5">
                <div className="flex items-center gap-2">
                  <Label className="text-emerald-300 text-sm w-28 shrink-0">رسوم أخرى</Label>
                  <Input type="number" min="0" value={otherFees || ""} onChange={e => setOtherFees(parseFloat(e.target.value) || 0)} className="flex-1 bg-emerald-900 border-emerald-700 text-white h-11 text-sm" placeholder="0" />
                  <button onClick={() => setShowOtherFeesDesc(v => !v)} className="text-emerald-400 hover:text-amber-400 transition-colors">
                    <Info className="w-5 h-5" />
                  </button>
                </div>
                {showOtherFeesDesc && (
                  <Input value={otherFeesDesc} onChange={e => setOtherFeesDesc(e.target.value)} className="bg-emerald-900 border-emerald-700/60 text-white h-9 text-sm mr-28" placeholder="تفاصيل الرسوم..." />
                )}
              </div>
              {/* Total */}
              <div className="border-t border-emerald-700/50 pt-3 flex items-center justify-between">
                <span className="text-amber-300 font-bold text-base">الإجمالي الكلي</span>
                <span className="text-amber-400 font-black text-2xl">{total.toLocaleString("ar-YE", { minimumFractionDigits: 0, maximumFractionDigits: 2 })} <span className="text-base font-bold">{currencySymbol}</span></span>
              </div>
              {subtotal !== total && (
                <div className="text-sm text-emerald-500 space-y-0.5">
                  {discount > 0 && <div className="flex justify-between"><span>المجموع قبل الخصم</span><span>{subtotal.toFixed(2)}</span></div>}
                  {otherFees > 0 && <div className="flex justify-between"><span>رسوم أخرى</span><span>+{otherFees.toFixed(2)}</span></div>}
                </div>
              )}
              {amountPaid > 0 && (
                payType === "cash" && change > 0 ? (
                  <div className="flex items-center justify-between bg-blue-900/30 rounded-xl px-4 py-3">
                    <span className="text-blue-300 text-base font-bold">الباقي للعميل</span>
                    <span className="text-blue-400 font-black text-2xl">{change.toFixed(2)} {currencySymbol}</span>
                  </div>
                ) : (
                  <div className={`flex items-center justify-between rounded-xl px-4 py-3 ${remaining > 0 ? "bg-red-900/30" : "bg-green-900/30"}`}>
                    <span className={`text-base font-bold ${remaining > 0 ? "text-red-300" : "text-green-300"}`}>المتبقي</span>
                    <span className={`font-black text-2xl ${remaining > 0 ? "text-red-400" : "text-green-400"}`}>{Math.abs(remaining).toFixed(2)} {currencySymbol}</span>
                  </div>
                )
              )}
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Quick Add Customer */}
      <Dialog open={addCustomerOpen} onOpenChange={setAddCustomerOpen}>
        <DialogContent className="max-w-sm bg-emerald-950 border-emerald-700 text-white" dir="rtl">
          <DialogHeader><DialogTitle className="text-amber-400">عميل جديد</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <div><Label className="text-emerald-200">اسم العميل *</Label><Input value={newCustName} onChange={e => setNewCustName(e.target.value)} className="bg-emerald-900 border-emerald-700 text-white mt-1 h-11" /></div>
            <div><Label className="text-emerald-200">رقم الجوال</Label><Input value={newCustPhone} onChange={e => setNewCustPhone(e.target.value)} className="bg-emerald-900 border-emerald-700 text-white mt-1 h-11" /></div>
            <div className="flex gap-2"><Button onClick={handleAddCustomer} className="bg-amber-500 hover:bg-amber-400 text-white flex-1 h-11">حفظ</Button><Button variant="outline" onClick={() => setAddCustomerOpen(false)} className="border-emerald-600 text-emerald-200 h-11">إلغاء</Button></div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Quick Add Item */}
      <Dialog open={addItemOpen} onOpenChange={setAddItemOpen}>
        <DialogContent className="max-w-sm bg-emerald-950 border-emerald-700 text-white" dir="rtl">
          <DialogHeader><DialogTitle className="text-amber-400">صنف جديد</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <div><Label className="text-emerald-200">اسم الصنف *</Label><Input value={newItemName} onChange={e => setNewItemName(e.target.value)} className="bg-emerald-900 border-emerald-700 text-white mt-1 h-11" /></div>
            <div><Label className="text-emerald-200">سعر البيع</Label><Input type="number" min="0" value={newItemPrice || ""} onChange={e => setNewItemPrice(parseFloat(e.target.value) || 0)} className="bg-emerald-900 border-emerald-700 text-white mt-1 h-11" placeholder="0" /></div>
            <div className="flex gap-2"><Button onClick={handleAddItem} className="bg-amber-500 hover:bg-amber-400 text-white flex-1 h-11">حفظ</Button><Button variant="outline" onClick={() => setAddItemOpen(false)} className="border-emerald-600 text-emerald-200 h-11">إلغاء</Button></div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Invoice Full-Screen Preview */}
      {invoicePreviewHtml && (
        <InvoicePrintOverlay
          html={invoicePreviewHtml}
          title={invoicePreviewTitle}
          onClose={() => setInvoicePreviewHtml(null)}
          onShare={() => { setInvoicePreviewHtml(null); openShareFromForm(); }}
        />
      )}
    </div>
  );
}
