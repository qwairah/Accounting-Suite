import React, { useState, useMemo } from "react";
import { useListItems, useCreateItem, useDeleteItem } from "@workspace/api-client-react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { getListItemsQueryKey } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Plus, Trash2, AlertTriangle, Search, Printer, Edit2, Save, X, Tag, Package, Ruler } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

type SubPage = "items" | "prices" | "units";
type ItemForm = {
  nameAr: string; nameEn: string; code: string; barcode: string;
  category: string; unit: string;
  costPrice: number; salePrice: number; minStock: number; taxRate: number;
};
const defaultForm: ItemForm = {
  nameAr: "", nameEn: "", code: "", barcode: "",
  category: "عام", unit: "قطعة",
  costPrice: 0, salePrice: 0, minStock: 0, taxRate: 0,
};

const DEFAULT_UNITS = ["قطعة", "لتر", "كيلو", "كيس", "كرتون", "علبة", "صندوق", "طن", "متر", "زوج", "دزينة", "رطل", "غرام", "حبة", "سلة"];
const DEFAULT_CATS  = ["عام", "مواد غذائية", "مستلزمات", "أثاث", "إلكترونيات", "أدوية", "مواد بناء"];

const SUB_PAGES: { id: SubPage; label: string; icon: any; color: string; border: string }[] = [
  { id: "items",  label: "الأصناف",     icon: Package, color: "text-emerald-400", border: "border-emerald-500" },
  { id: "prices", label: "أسعار البيع", icon: Tag,     color: "text-amber-400",  border: "border-amber-500"  },
  { id: "units",  label: "وحدات الصنف", icon: Ruler,   color: "text-blue-400",   border: "border-blue-500"   },
];

const printItemCard = (item: any) => {
  const w = window.open("", "_blank");
  if (!w) return;
  w.document.write(`<!DOCTYPE html><html dir="rtl"><head><meta charset="utf-8"><title>بطاقة صنف</title>
  <style>body{font-family:Arial;padding:30px;direction:rtl}h2{color:#064E3B;border-bottom:3px solid #F59E0B;padding-bottom:10px}
  .grid{display:grid;grid-template-columns:1fr 1fr;gap:15px;margin-top:15px}.card{background:#f0fdf4;padding:12px;border-radius:8px;border:1px solid #d1fae5}
  .lbl{color:#666;font-size:12px;margin-bottom:4px}.val{font-weight:bold;font-size:15px;color:#064E3B}
  .price-box{background:#064E3B;color:white;padding:12px;border-radius:8px;text-align:center;margin-top:15px}
  </style></head>
  <body><h2>🏷️ قـويـره سوفت — بطاقة صنف</h2>
  <div class="grid">
    <div class="card"><div class="lbl">اسم الصنف</div><div class="val">${item.nameAr}</div></div>
    <div class="card"><div class="lbl">الكود</div><div class="val">${item.code || "—"}</div></div>
    <div class="card"><div class="lbl">الوحدة</div><div class="val">${item.unit}</div></div>
    <div class="card"><div class="lbl">الفئة</div><div class="val">${item.category || "عام"}</div></div>
    <div class="card"><div class="lbl">المخزون الحالي</div><div class="val">${Number(item.stockQuantity || 0).toFixed(2)}</div></div>
    <div class="card"><div class="lbl">الحد الأدنى</div><div class="val">${Number(item.minStock || 0).toFixed(2)}</div></div>
  </div>
  <div class="price-box">
    <div style="font-size:12px;opacity:0.7;margin-bottom:8px">أسعار البيع</div>
    <div style="display:flex;justify-content:center;gap:30px">
      <div><div style="font-size:11px;opacity:0.7">التكلفة</div><div style="font-size:18px;font-weight:bold">${Number(item.costPrice).toFixed(2)}</div></div>
      <div><div style="font-size:11px;opacity:0.7">سعر البيع</div><div style="font-size:22px;font-weight:bold;color:#F59E0B">${Number(item.salePrice).toFixed(2)}</div></div>
    </div>
  </div>
  <p style="margin-top:20px;text-align:center;color:#999;font-size:11px">نظام قـويـره سوفت للمحاسبة المتكاملة</p>
  <script>window.onload=()=>window.print()</script>
  </body></html>`);
  w.document.close();
};

export default function ItemsPage() {
  const qc = useQueryClient();
  const { toast } = useToast();
  const { data: items = [], isLoading } = useListItems();
  const { data: stockSummary = [] } = useQuery({ queryKey: ["stock-summary"], queryFn: () => fetch("/api/inventory/stock-summary").then(r => r.json()) });
  const createItem = useCreateItem();
  const deleteItem = useDeleteItem();

  const [activePage, setActivePage] = useState<SubPage>("items");
  const [open, setOpen] = useState(false);
  const [search, setSearch] = useState("");
  const [form, setForm] = useState<ItemForm>(defaultForm);
  const [units, setUnits] = useState<string[]>(DEFAULT_UNITS);
  const [newUnit, setNewUnit] = useState("");
  const [editPrices, setEditPrices] = useState<Record<number, { cost: string; sale: string; saving: boolean }>>({});

  // ── Edit item dialog ──
  const [editItemData, setEditItemData] = useState<any>(null);
  const [editItemForm, setEditItemForm] = useState<ItemForm>(defaultForm);
  const setEIF = (k: keyof ItemForm, v: any) => setEditItemForm(f => ({ ...f, [k]: v }));

  const openEditItem = (item: any) => {
    setEditItemData(item);
    setEditItemForm({
      nameAr: item.nameAr || "", nameEn: item.nameEn || "", code: item.code || "", barcode: item.barcode || "",
      category: item.category || "عام", unit: item.unit || "قطعة",
      costPrice: Number(item.costPrice) || 0, salePrice: Number(item.salePrice) || 0,
      minStock: Number(item.minStock) || 0, taxRate: Number(item.taxRate) || 0,
    });
  };

  const handleSaveEditItem = async () => {
    if (!editItemForm.nameAr.trim()) { toast({ title: "خطأ", description: "اسم الصنف مطلوب", variant: "destructive" }); return; }
    await updateItem.mutateAsync({ id: editItemData.id, data: { ...editItemForm } });
    setEditItemData(null);
    toast({ title: "✅ تم تحديث بيانات الصنف" });
  };

  const set = (k: keyof ItemForm, v: any) => setForm(f => ({ ...f, [k]: v }));

  // ── Update item (prices) ──
  const updateItem = useMutation({
    mutationFn: ({ id, data }: { id: number; data: any }) =>
      fetch(`/api/items/${id}`, { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify(data) }).then(r => r.json()),
    onSuccess: () => qc.invalidateQueries({ queryKey: getListItemsQueryKey() }),
  });

  const handleCreate = async () => {
    if (!form.nameAr.trim()) { toast({ title: "خطأ", description: "أدخل اسم الصنف", variant: "destructive" }); return; }
    const exists = (items as any[]).find(it => it.nameAr.trim().toLowerCase() === form.nameAr.trim().toLowerCase());
    if (exists) { toast({ title: "خطأ", description: "يوجد صنف بنفس الاسم", variant: "destructive" }); return; }
    await createItem.mutateAsync({ data: { ...form } });
    qc.invalidateQueries({ queryKey: getListItemsQueryKey() });
    setOpen(false);
    setForm(defaultForm);
    toast({ title: "✅ تم إضافة الصنف" });
  };

  const handleDeleteItem = async (id: number) => {
    if (!confirm("حذف الصنف؟")) return;
    await deleteItem.mutateAsync({ id });
    qc.invalidateQueries({ queryKey: getListItemsQueryKey() });
    toast({ title: "✅ تم حذف الصنف" });
  };

  const startEditPrice = (item: any) => {
    setEditPrices(p => ({ ...p, [item.id]: { cost: String(item.costPrice), sale: String(item.salePrice), saving: false } }));
  };
  const cancelEditPrice = (id: number) => setEditPrices(p => { const n = { ...p }; delete n[id]; return n; });
  const savePrice = async (item: any) => {
    const ep = editPrices[item.id];
    if (!ep) return;
    setEditPrices(p => ({ ...p, [item.id]: { ...p[item.id], saving: true } }));
    await updateItem.mutateAsync({ id: item.id, data: { ...item, costPrice: parseFloat(ep.cost) || 0, salePrice: parseFloat(ep.sale) || 0 } });
    cancelEditPrice(item.id);
    toast({ title: "✅ تم تحديث الأسعار" });
  };

  const filtered = useMemo(() => {
    if (!search) return items as any[];
    return (items as any[]).filter(it => it.nameAr?.includes(search) || it.code?.includes(search) || it.barcode?.includes(search));
  }, [items, search]);

  const lowStockCount = (items as any[]).filter((it: any) => {
    const s = (stockSummary as any[]).find(ss => ss.itemId === it.id);
    return Number(s?.quantity || 0) <= Number(it.minStock || 0) && Number(it.minStock) > 0;
  }).length;

  // ── Render Items ────────────────────────────────────────────────────────────
  const renderItems = () => (
    <div className="space-y-3">
      {/* Stats */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
        <div className="rounded-xl p-3 border border-emerald-600/30 bg-emerald-900/20 text-center">
          <p className="text-emerald-300 text-xs">عدد الأصناف</p>
          <p className="text-amber-400 text-2xl font-black">{(items as any[]).length}</p>
        </div>
        <div className="rounded-xl p-3 border border-red-600/30 bg-red-900/20 text-center">
          <p className="text-red-300 text-xs">أصناف ناقصة</p>
          <p className="text-red-400 text-2xl font-black">{lowStockCount}</p>
        </div>
        <div className="rounded-xl p-3 border border-blue-600/30 bg-blue-900/20 text-center">
          <p className="text-blue-300 text-xs">قيمة المخزون</p>
          <p className="text-blue-400 text-2xl font-black">{(stockSummary as any[]).reduce((s: number, x: any) => s + (Number(x.quantity) * Number(x.costPrice)), 0).toFixed(0)}</p>
        </div>
        <div className="rounded-xl p-3 border border-purple-600/30 bg-purple-900/20 text-center">
          <p className="text-purple-300 text-xs">إجمالي الكميات</p>
          <p className="text-purple-400 text-2xl font-black">{(stockSummary as any[]).reduce((s: number, x: any) => s + Number(x.quantity || 0), 0).toFixed(0)}</p>
        </div>
      </div>
      {/* Search */}
      <div className="relative">
        <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-emerald-400" />
        <Input value={search} onChange={e => setSearch(e.target.value)} placeholder="بحث باسم الصنف أو الكود أو الباركود..." className="bg-emerald-900/50 border-emerald-700 text-white pr-10 placeholder:text-emerald-500" />
      </div>
      {/* Table */}
      <div className="bg-white/5 rounded-2xl border border-white/10 overflow-hidden">
        <div className="p-3 bg-emerald-800/30 border-b border-white/10 flex justify-between items-center">
          <span className="text-emerald-300 text-sm font-medium">قائمة الأصناف</span>
          <span className="text-amber-400 text-xs font-bold">{filtered.length} صنف</span>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-emerald-800/50">
              <tr>
                <th className="p-3 text-right text-amber-300">الصنف</th>
                <th className="p-3 text-right text-amber-300">الكود</th>
                <th className="p-3 text-right text-amber-300">الوحدة</th>
                <th className="p-3 text-center text-amber-300">التكلفة</th>
                <th className="p-3 text-center text-amber-300">سعر البيع</th>
                <th className="p-3 text-center text-amber-300">المخزون</th>
                <th className="p-3 text-center text-amber-300">إجراءات</th>
              </tr>
            </thead>
            <tbody>
              {isLoading ? <tr><td colSpan={7} className="p-6 text-center text-emerald-200">جاري التحميل...</td></tr>
              : filtered.length === 0 ? <tr><td colSpan={7} className="p-8 text-center"><div className="flex flex-col items-center gap-2 text-emerald-400"><Package className="w-8 h-8 opacity-50" /><span>لا توجد أصناف. أضف صنفاً جديداً.</span></div></td></tr>
              : filtered.map((item: any) => {
                const stock = (stockSummary as any[]).find(s => s.itemId === item.id);
                const qty = Number(stock?.quantity || 0);
                const isLow = qty <= Number(item.minStock || 0) && Number(item.minStock) > 0;
                return (
                  <tr key={item.id} className={`border-t border-white/10 hover:bg-white/5 transition-colors ${isLow ? "bg-red-900/10" : ""}`}>
                    <td className="p-3">
                      <div className="flex items-center gap-2">
                        {isLow && <AlertTriangle className="w-3.5 h-3.5 text-red-400 shrink-0" />}
                        <div>
                          <p className="text-white font-semibold">{item.nameAr}</p>
                          {item.nameEn && <p className="text-white/40 text-xs" dir="ltr">{item.nameEn}</p>}
                          {item.category && <Badge className="text-[9px] px-1.5 py-0 mt-0.5 bg-emerald-900/60 text-emerald-300 border-emerald-600">{item.category}</Badge>}
                        </div>
                      </div>
                    </td>
                    <td className="p-3 text-emerald-300 font-mono text-xs">{item.code || "—"}</td>
                    <td className="p-3 text-white/80">{item.unit}</td>
                    <td className="p-3 text-center text-amber-300 font-bold">{Number(item.costPrice).toFixed(2)}</td>
                    <td className="p-3 text-center text-green-400 font-bold">{Number(item.salePrice).toFixed(2)}</td>
                    <td className="p-3 text-center">
                      <span className={`font-bold text-sm ${isLow ? "text-red-400" : "text-blue-400"}`}>{qty.toFixed(2)}</span>
                      {isLow && <p className="text-red-400 text-[9px]">أقل من الحد</p>}
                    </td>
                    <td className="p-3 text-center">
                      <div className="flex gap-1 justify-center">
                        <Button size="sm" variant="ghost" className="text-amber-400 h-7 w-7 p-0 hover:bg-amber-900/30" onClick={() => openEditItem(item)} title="تعديل الصنف"><Edit2 className="w-3.5 h-3.5" /></Button>
                        <Button size="sm" variant="ghost" className="text-blue-400 h-7 w-7 p-0 hover:bg-blue-900/30" onClick={() => printItemCard(item)}><Printer className="w-3.5 h-3.5" /></Button>
                        <Button size="sm" variant="ghost" className="text-red-400 h-7 w-7 p-0 hover:bg-red-900/30" onClick={() => handleDeleteItem(item.id)}><Trash2 className="w-3.5 h-3.5" /></Button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );

  // ── Render Prices ───────────────────────────────────────────────────────────
  const renderPrices = () => (
    <div className="space-y-3">
      <div className="bg-amber-900/20 border border-amber-700/30 rounded-xl p-3 text-xs text-amber-300 flex items-center gap-2">
        <Edit2 className="w-4 h-4 shrink-0" />
        <span>اضغط على أيقونة التعديل لتغيير سعر التكلفة أو سعر البيع لأي صنف مباشرةً</span>
      </div>
      <div className="bg-white/5 rounded-2xl border border-white/10 overflow-hidden">
        <div className="p-3 bg-amber-900/20 border-b border-white/10 flex justify-between">
          <span className="text-amber-300 font-bold text-sm">جدول أسعار الأصناف</span>
          <span className="text-white/50 text-xs">{(items as any[]).length} صنف</span>
        </div>
        <table className="w-full text-sm">
          <thead className="bg-emerald-800/50">
            <tr>
              <th className="p-3 text-right text-amber-300">الصنف</th>
              <th className="p-3 text-right text-amber-300">الوحدة</th>
              <th className="p-3 text-center text-amber-300 w-36">سعر التكلفة</th>
              <th className="p-3 text-center text-amber-300 w-36">سعر البيع</th>
              <th className="p-3 text-center text-amber-300 w-24">الربح %</th>
              <th className="p-3 text-center text-amber-300 w-20">تعديل</th>
            </tr>
          </thead>
          <tbody>
            {(items as any[]).length === 0 ? (
              <tr><td colSpan={6} className="p-8 text-center text-emerald-400">لا توجد أصناف</td></tr>
            ) : (items as any[]).map((item: any) => {
              const ep = editPrices[item.id];
              const cost = ep ? parseFloat(ep.cost) || 0 : Number(item.costPrice);
              const sale = ep ? parseFloat(ep.sale) || 0 : Number(item.salePrice);
              const margin = profitMargin(cost, sale);
              return (
                <tr key={item.id} className={`border-t border-white/10 hover:bg-white/5 transition-colors ${ep ? "bg-amber-900/10" : ""}`}>
                  <td className="p-3 text-white font-semibold">{item.nameAr}</td>
                  <td className="p-3 text-white/60 text-xs">{item.unit}</td>
                  <td className="p-3">
                    {ep ? (
                      <Input type="number" min="0" step="0.01" value={ep.cost} onChange={e => setEditPrices(p => ({ ...p, [item.id]: { ...p[item.id], cost: e.target.value } }))}
                        className="bg-emerald-900/60 border-emerald-600 text-white h-8 text-xs text-center w-full" autoFocus />
                    ) : (
                      <span className="text-red-400 font-bold block text-center">{Number(item.costPrice).toFixed(2)}</span>
                    )}
                  </td>
                  <td className="p-3">
                    {ep ? (
                      <Input type="number" min="0" step="0.01" value={ep.sale} onChange={e => setEditPrices(p => ({ ...p, [item.id]: { ...p[item.id], sale: e.target.value } }))}
                        className="bg-amber-900/60 border-amber-600 text-amber-300 h-8 text-xs text-center w-full" />
                    ) : (
                      <span className="text-green-400 font-bold block text-center">{Number(item.salePrice).toFixed(2)}</span>
                    )}
                  </td>
                  <td className="p-3 text-center">
                    {margin ? (
                      <span className={`text-xs font-bold px-2 py-0.5 rounded-full ${Number(margin) >= 0 ? "bg-green-900/50 text-green-400" : "bg-red-900/50 text-red-400"}`}>
                        {margin}%
                      </span>
                    ) : <span className="text-white/30">—</span>}
                  </td>
                  <td className="p-3 text-center">
                    {ep ? (
                      <div className="flex gap-1 justify-center">
                        <Button size="sm" variant="ghost" className="text-green-400 h-7 w-7 p-0 hover:bg-green-900/30" onClick={() => savePrice(item)} disabled={ep.saving}><Save className="w-3.5 h-3.5" /></Button>
                        <Button size="sm" variant="ghost" className="text-white/40 h-7 w-7 p-0" onClick={() => cancelEditPrice(item.id)}><X className="w-3.5 h-3.5" /></Button>
                      </div>
                    ) : (
                      <Button size="sm" variant="ghost" className="text-amber-400 h-7 w-7 p-0 hover:bg-amber-900/30" onClick={() => startEditPrice(item)}><Edit2 className="w-3.5 h-3.5" /></Button>
                    )}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );

  // ── Render Units ────────────────────────────────────────────────────────────
  const renderUnits = () => (
    <div className="space-y-4">
      <div className="bg-blue-900/20 border border-blue-700/30 rounded-xl p-3 text-xs text-blue-300 flex items-center gap-2">
        <Ruler className="w-4 h-4 shrink-0" />
        <span>وحدات القياس تُستخدم عند إنشاء الأصناف. يمكنك إضافة وحدات مخصصة أو حذف غير المستخدمة.</span>
      </div>
      <div className="flex gap-2">
        <div className="relative flex-1">
          <Input value={newUnit} onChange={e => setNewUnit(e.target.value)} placeholder="أضف وحدة قياس جديدة..." className="bg-emerald-900/50 border-emerald-700 text-white placeholder:text-emerald-500"
            onKeyDown={e => { if (e.key === "Enter" && newUnit.trim()) { if (!units.includes(newUnit.trim())) { setUnits(u => [...u, newUnit.trim()]); setNewUnit(""); toast({ title: "✅ تمت إضافة الوحدة" }); } else toast({ title: "موجودة مسبقاً", variant: "destructive" }); } }} />
        </div>
        <Button onClick={() => { if (newUnit.trim()) { if (!units.includes(newUnit.trim())) { setUnits(u => [...u, newUnit.trim()]); setNewUnit(""); toast({ title: "✅ تمت إضافة الوحدة" }); } else toast({ title: "موجودة مسبقاً", variant: "destructive" }); } }}
          className="bg-amber-500 hover:bg-amber-400 text-white gap-1 font-bold">
          <Plus className="w-4 h-4" /> إضافة
        </Button>
      </div>
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-2">
        {units.map((u, i) => {
          const usedByCount = (items as any[]).filter((it: any) => it.unit === u).length;
          return (
            <div key={i} className="flex items-center justify-between p-3 rounded-xl bg-emerald-900/40 border border-emerald-700/30 hover:border-emerald-600/50 transition-colors group">
              <div>
                <span className="text-white font-bold">{u}</span>
                {usedByCount > 0 && <p className="text-emerald-400 text-[10px] mt-0.5">{usedByCount} صنف</p>}
              </div>
              <Button size="sm" variant="ghost" onClick={() => { if (usedByCount > 0) { toast({ title: "تحذير", description: `الوحدة مستخدمة في ${usedByCount} صنف`, variant: "destructive" }); return; } setUnits(p => p.filter((_, idx) => idx !== i)); }}
                className="text-red-400 h-7 w-7 p-0 opacity-0 group-hover:opacity-100 transition-opacity"><Trash2 className="w-3 h-3" /></Button>
            </div>
          );
        })}
      </div>
      {units.length === 0 && (
        <div className="text-center py-8 text-emerald-400">
          <Ruler className="w-10 h-10 mx-auto mb-2 opacity-40" />
          <p>لا توجد وحدات. أضف وحدات قياس للأصناف.</p>
        </div>
      )}
    </div>
  );

  return (
    <div className="space-y-4 animate-in fade-in duration-300" dir="rtl">
      {/* ── Header ── */}
      <div className="flex justify-between items-center flex-wrap gap-3">
        <div>
          <h1 className="text-3xl font-bold text-amber-400">الأصناف</h1>
          <p className="text-emerald-200 mt-1 text-sm">إدارة الأصناف والمنتجات وأسعار البيع</p>
        </div>
        <Button onClick={() => setOpen(true)} className="bg-amber-500 hover:bg-amber-400 text-white gap-2 h-11 px-5 font-bold shadow-lg">
          <Plus className="w-4 h-4" /> صنف جديد
        </Button>
      </div>

      {/* ── Sub Page Tabs ── */}
      <div className="flex gap-2">
        {SUB_PAGES.map(p => (
          <button key={p.id} onClick={() => setActivePage(p.id)}
            className={`flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-bold transition-all border-2 ${activePage === p.id ? `${p.border} bg-white/10 text-white shadow-md` : "border-white/10 text-emerald-300 hover:bg-white/10 hover:border-white/20"}`}>
            <p.icon className={`w-4 h-4 ${activePage === p.id ? p.color : "text-emerald-400"}`} />
            {p.label}
          </button>
        ))}
      </div>

      {/* ── Content ── */}
      {activePage === "items" && renderItems()}
      {activePage === "prices" && renderPrices()}
      {activePage === "units" && renderUnits()}

      {/* ── Add Item Dialog ── */}
      <Dialog open={open} onOpenChange={v => { setOpen(v); if (!v) setForm(defaultForm); }}>
        <DialogContent className="max-w-2xl text-white border-emerald-700 max-h-[90vh] overflow-y-auto" dir="rtl"
          style={{ background: "linear-gradient(135deg, #022c22 0%, #064E3B 100%)" }}>
          <DialogHeader>
            <DialogTitle className="text-amber-400 text-xl flex items-center gap-2">
              <Package className="w-6 h-6 text-emerald-300" /> إضافة صنف جديد
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <div className="col-span-2">
                <Label className="text-emerald-200 text-xs font-semibold">اسم الصنف (عربي) *</Label>
                <Input value={form.nameAr} onChange={e => set("nameAr", e.target.value)} className="bg-emerald-900/60 border-emerald-700 text-white mt-1 text-base" placeholder="اسم الصنف..." />
              </div>
              <div>
                <Label className="text-emerald-200 text-xs font-semibold">اسم الصنف (إنجليزي)</Label>
                <Input value={form.nameEn} onChange={e => set("nameEn", e.target.value)} className="bg-emerald-900/60 border-emerald-700 text-white mt-1" dir="ltr" />
              </div>
              <div>
                <Label className="text-emerald-200 text-xs font-semibold">كود الصنف</Label>
                <Input value={form.code} onChange={e => set("code", e.target.value)} className="bg-emerald-900/60 border-emerald-700 text-white mt-1" dir="ltr" placeholder="يُولَّد تلقائياً إذا تُرك فارغاً" />
              </div>
              <div>
                <Label className="text-emerald-200 text-xs font-semibold">الباركود</Label>
                <Input value={form.barcode} onChange={e => set("barcode", e.target.value)} className="bg-emerald-900/60 border-emerald-700 text-white mt-1" dir="ltr" />
              </div>
              <div>
                <Label className="text-emerald-200 text-xs font-semibold">وحدة القياس</Label>
                <Select value={form.unit} onValueChange={v => set("unit", v)}>
                  <SelectTrigger className="bg-emerald-900/60 border-emerald-700 text-white mt-1"><SelectValue /></SelectTrigger>
                  <SelectContent className="bg-emerald-900 border-emerald-700">
                    {units.map(u => <SelectItem key={u} value={u} className="text-white">{u}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label className="text-emerald-200 text-xs font-semibold">الفئة</Label>
                <Select value={form.category} onValueChange={v => set("category", v)}>
                  <SelectTrigger className="bg-emerald-900/60 border-emerald-700 text-white mt-1"><SelectValue /></SelectTrigger>
                  <SelectContent className="bg-emerald-900 border-emerald-700">
                    {DEFAULT_CATS.map(c => <SelectItem key={c} value={c} className="text-white">{c}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Pricing */}
            <div className="bg-emerald-900/30 rounded-xl p-4 border border-emerald-700/30 space-y-3">
              <Label className="text-amber-300 font-bold text-sm">الأسعار والمخزون</Label>
              <div className="grid grid-cols-3 gap-3">
                <div>
                  <Label className="text-emerald-200 text-xs">سعر التكلفة</Label>
                  <Input type="number" step="0.01" min="0" value={form.costPrice || ""} onChange={e => set("costPrice", parseFloat(e.target.value) || 0)} className="bg-emerald-900/60 border-emerald-700 text-white mt-1" />
                </div>
                <div>
                  <Label className="text-emerald-200 text-xs">سعر البيع *</Label>
                  <Input type="number" step="0.01" min="0" value={form.salePrice || ""} onChange={e => set("salePrice", parseFloat(e.target.value) || 0)} className="bg-emerald-900/60 border-amber-600/70 text-amber-300 mt-1 border" />
                </div>
                <div>
                  <Label className="text-emerald-200 text-xs">الضريبة %</Label>
                  <Input type="number" step="0.01" min="0" value={form.taxRate || ""} onChange={e => set("taxRate", parseFloat(e.target.value) || 0)} className="bg-emerald-900/60 border-emerald-700 text-white mt-1" />
                </div>
                <div>
                  <Label className="text-emerald-200 text-xs">الحد الأدنى للمخزون</Label>
                  <Input type="number" min="0" value={form.minStock || ""} onChange={e => set("minStock", parseFloat(e.target.value) || 0)} className="bg-emerald-900/60 border-emerald-700 text-white mt-1" />
                </div>
              </div>
              {/* Profit margin preview */}
              {form.salePrice > 0 && form.costPrice > 0 && (
                <div className={`flex items-center gap-3 rounded-xl p-3 border ${form.salePrice > form.costPrice ? "bg-green-900/20 border-green-700/30" : "bg-red-900/20 border-red-700/30"}`}>
                  <span className="text-white/60 text-sm">هامش الربح:</span>
                  <span className={`font-black text-xl ${form.salePrice > form.costPrice ? "text-green-400" : "text-red-400"}`}>
                    {(((form.salePrice - form.costPrice) / form.costPrice) * 100).toFixed(1)}%
                  </span>
                  <span className="text-white/50 text-sm">| ربح الوحدة: {(form.salePrice - form.costPrice).toFixed(2)}</span>
                </div>
              )}
            </div>

            <div className="flex gap-2">
              <Button onClick={handleCreate} disabled={createItem.isPending} className="bg-amber-500 hover:bg-amber-400 text-white flex-1 h-11 font-bold">
                {createItem.isPending ? "جاري الحفظ..." : "✅ حفظ الصنف"}
              </Button>
              <Button variant="outline" onClick={() => { setOpen(false); setForm(defaultForm); }} className="border-emerald-600 text-emerald-200 h-11">إلغاء</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* ── Edit Item Dialog ── */}
      <Dialog open={!!editItemData} onOpenChange={v => !v && setEditItemData(null)}>
        <DialogContent className="max-w-md text-white border-amber-600 overflow-hidden p-0" dir="rtl" style={{background: "linear-gradient(135deg, #022c22, #064E3B)"}}>
          <div className="flex items-center gap-2 px-4 py-3 border-b border-emerald-700 bg-emerald-900/60">
            <Edit2 className="w-4 h-4 text-amber-400" />
            <h2 className="text-amber-400 font-bold text-base flex-1">تعديل الصنف — {editItemData?.nameAr}</h2>
          </div>
          <div className="overflow-y-auto max-h-[80vh] p-4 space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <div className="col-span-2">
                <Label className="text-emerald-200 text-xs font-semibold">اسم الصنف بالعربي *</Label>
                <Input value={editItemForm.nameAr} onChange={e => setEIF("nameAr", e.target.value)} className="bg-emerald-900/60 border-emerald-700 text-white mt-1 h-11" placeholder="اسم الصنف..." />
              </div>
              <div className="col-span-2">
                <Label className="text-emerald-200 text-xs font-semibold">الاسم بالإنجليزي</Label>
                <Input value={editItemForm.nameEn} onChange={e => setEIF("nameEn", e.target.value)} className="bg-emerald-900/60 border-emerald-700 text-white mt-1 h-10" dir="ltr" placeholder="Item name in English" />
              </div>
              <div>
                <Label className="text-emerald-200 text-xs font-semibold">الكود</Label>
                <Input value={editItemForm.code} onChange={e => setEIF("code", e.target.value)} className="bg-emerald-900/60 border-emerald-700 text-white mt-1 h-10" dir="ltr" />
              </div>
              <div>
                <Label className="text-emerald-200 text-xs font-semibold">الباركود</Label>
                <Input value={editItemForm.barcode} onChange={e => setEIF("barcode", e.target.value)} className="bg-emerald-900/60 border-emerald-700 text-white mt-1 h-10" dir="ltr" />
              </div>
              <div>
                <Label className="text-emerald-200 text-xs font-semibold">وحدة القياس</Label>
                <Select value={editItemForm.unit} onValueChange={v => setEIF("unit", v)}>
                  <SelectTrigger className="bg-emerald-900/60 border-emerald-700 text-white mt-1 h-10"><SelectValue /></SelectTrigger>
                  <SelectContent className="bg-emerald-900 border-emerald-700">
                    {units.map(u => <SelectItem key={u} value={u} className="text-white">{u}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label className="text-emerald-200 text-xs font-semibold">الفئة</Label>
                <Select value={editItemForm.category} onValueChange={v => setEIF("category", v)}>
                  <SelectTrigger className="bg-emerald-900/60 border-emerald-700 text-white mt-1 h-10"><SelectValue /></SelectTrigger>
                  <SelectContent className="bg-emerald-900 border-emerald-700">
                    {DEFAULT_CATS.map(c => <SelectItem key={c} value={c} className="text-white">{c}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="bg-emerald-900/30 rounded-xl p-3 border border-emerald-700/30 space-y-3">
              <Label className="text-amber-300 font-bold text-sm">الأسعار والمخزون</Label>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label className="text-emerald-200 text-xs">سعر التكلفة</Label>
                  <Input type="number" step="0.01" min="0" value={editItemForm.costPrice || ""} onChange={e => setEIF("costPrice", parseFloat(e.target.value) || 0)} className="bg-emerald-900/60 border-emerald-700 text-white mt-1 h-10" />
                </div>
                <div>
                  <Label className="text-emerald-200 text-xs">سعر البيع</Label>
                  <Input type="number" step="0.01" min="0" value={editItemForm.salePrice || ""} onChange={e => setEIF("salePrice", parseFloat(e.target.value) || 0)} className="bg-emerald-900/60 border-amber-600/70 text-amber-300 mt-1 border h-10" />
                </div>
                <div>
                  <Label className="text-emerald-200 text-xs">الحد الأدنى للمخزون</Label>
                  <Input type="number" min="0" value={editItemForm.minStock || ""} onChange={e => setEIF("minStock", parseFloat(e.target.value) || 0)} className="bg-emerald-900/60 border-emerald-700 text-white mt-1 h-10" />
                </div>
                <div>
                  <Label className="text-emerald-200 text-xs">الضريبة %</Label>
                  <Input type="number" step="0.01" min="0" value={editItemForm.taxRate || ""} onChange={e => setEIF("taxRate", parseFloat(e.target.value) || 0)} className="bg-emerald-900/60 border-emerald-700 text-white mt-1 h-10" />
                </div>
              </div>
            </div>
            <div className="flex gap-2">
              <Button onClick={handleSaveEditItem} disabled={updateItem.isPending} className="flex-1 bg-amber-500 hover:bg-amber-400 text-white h-11 font-bold gap-2">
                <Save className="w-4 h-4" /> {updateItem.isPending ? "جاري الحفظ..." : "حفظ التعديلات"}
              </Button>
              <Button variant="ghost" onClick={() => setEditItemData(null)} className="text-emerald-300 border border-emerald-700 h-11 px-4">إلغاء</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
