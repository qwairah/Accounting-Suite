import { useState, useMemo } from "react";
import { useListPurchases, useCreatePurchase, useDeletePurchase, useUpdatePurchase, useListSuppliers, useListItems, useListCurrencies, useCreateSupplier, useCreateItem, useListAccounts } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { getListPurchasesQueryKey, getListSuppliersQueryKey, getListItemsQueryKey, getListAccountsQueryKey } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Plus, Trash2, Camera, UserPlus, Package, MoreVertical, ArrowRight, FileText, ImageIcon, Share2, Send, Search, X, Info, MessageCircle, Edit2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { ShareDocumentDialog } from "@/components/ShareDocumentDialog";
import { buildDocumentHTML } from "@/lib/printUtils";
import { InvoicePrintOverlay } from "@/components/InvoicePrintOverlay";
import { useSettings } from "@/contexts/SettingsContext";
import { postToLedger, removeFromLedger, makeId } from "@/lib/ledger";

type PayType = "credit" | "cash";
type PurchItem = { itemId: number; quantity: number; unitPrice: number; discount: number; };
const defaultItem = (): PurchItem => ({ itemId: 0, quantity: 0, unitPrice: 0, discount: 0 });

const statusLabel: Record<string, string> = { posted: "مرحلة", paid: "مدفوع", draft: "مسودة", cancelled: "ملغي" };
const statusColor: Record<string, string> = { posted: "bg-blue-100 text-blue-700", paid: "bg-emerald-100 text-emerald-700", draft: "bg-gray-100 text-gray-600", cancelled: "bg-red-100 text-red-700" };

export default function PurchasesPage() {
  const qc = useQueryClient();
  const { settings } = useSettings();
  const { data: purchases = [], isLoading } = useListPurchases();
  const { data: suppliers = [] } = useListSuppliers();
  const { data: items = [] } = useListItems();
  const { data: currencies = [] } = useListCurrencies();
  const { data: allAccounts = [] } = useListAccounts();
  const createPurchase = useCreatePurchase();
  const deletePurchase = useDeletePurchase();
  const updatePurchase = useUpdatePurchase();
  const createSupplier = useCreateSupplier();
  const createItem = useCreateItem();
  const { toast } = useToast();

  const [open, setOpen] = useState(false);
  const [addSupplierOpen, setAddSupplierOpen] = useState(false);
  const [addItemOpen, setAddItemOpen] = useState(false);
  const [shareOpen, setShareOpen] = useState(false);
  const [sharePhone, setSharePhone] = useState("");
  const [shareMsg, setShareMsg] = useState("");
  const [shareHtmlContent, setShareHtmlContent] = useState<string | undefined>(undefined);
  const [supplierName, setSupplierName] = useState("");            // اسم المورد (نص حر)
  const [suppNameDropOpen, setSuppNameDropOpen] = useState(false);
  const [listSearch, setListSearch] = useState("");
  const [pageSize, setPageSize] = useState(25);
  const [editPurch, setEditPurch] = useState<any>(null);
  const [editStatus, setEditStatus] = useState("");
  const [editPaid, setEditPaid] = useState(0);
  const [editNotes, setEditNotes] = useState("");
  const [editDate, setEditDate] = useState("");
  const [invoicePreviewHtml, setInvoicePreviewHtml] = useState<string | null>(null);
  const [invoicePreviewTitle, setInvoicePreviewTitle] = useState("فاتورة مشتريات");

  const [payType, setPayType] = useState<PayType>("credit");
  const [isReturn, setIsReturn] = useState(false);
  const [warehouseType, setWarehouseType] = useState("الرئيسي");
  const [currencyId, setCurrencyId] = useState("");
  const [exchangeRate, setExchangeRate] = useState(1);
  const [date, setDate] = useState(new Date().toISOString().split("T")[0]);
  const [purchItems, setPurchItems] = useState<PurchItem[]>([defaultItem()]);
  const [discount, setDiscount] = useState(0);
  const [otherFees, setOtherFees] = useState(0);
  const [otherFeesDesc, setOtherFeesDesc] = useState("");
  const [showOtherFeesDesc, setShowOtherFeesDesc] = useState(false);
  const [amountPaid, setAmountPaid] = useState(0);
  const [paymentAccountId, setPaymentAccountId] = useState("");
  const [notes, setNotes] = useState("");
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [newSuppName, setNewSuppName] = useState("");
  const [newSuppPhone, setNewSuppPhone] = useState("");
  const [newItemName, setNewItemName] = useState("");
  const [newItemPrice, setNewItemPrice] = useState(0);

  const selectedCurrency = currencies.find(c => String(c.id) === currencyId);
  const isYER = !currencyId || (selectedCurrency as any)?.code === "YER";
  const currencySymbol = selectedCurrency?.symbol || "ر.ي";
  const currencyNameAr = selectedCurrency?.nameAr || "ريال يمني";
  const subtotal = purchItems.reduce((s, it) => s + it.quantity * it.unitPrice, 0);
  const total = subtotal - discount + otherFees;
  const remaining = total - amountPaid;
  const change = payType === "cash" && amountPaid > total ? amountPaid - total : 0;
  const fundAccounts = (allAccounts as any[]).filter(a => !a.isMain && (a.subSubType === "cash" || a.subSubType === "bank"));

  const addItem = () => setPurchItems(prev => [...prev, defaultItem()]);
  const removeItem = (i: number) => setPurchItems(prev => prev.filter((_, idx) => idx !== i));
  const updateItem = (i: number, field: keyof PurchItem, val: string | number) =>
    setPurchItems(prev => prev.map((it, idx) => {
      if (idx !== i) return it;
      if (field === "itemId") {
        const item = items.find(x => x.id === Number(val));
        return { ...it, itemId: Number(val), unitPrice: item?.costPrice ?? 0, quantity: settings.autoAddQty1 ? 1 : it.quantity };
      }
      const num = val === "" ? 0 : parseFloat(String(val));
      return { ...it, [field]: isNaN(num) ? 0 : num };
    }));

  const handleSubmit = async () => {
    const validItems = purchItems.filter(it => it.itemId > 0);
    if (!validItems.length) { toast({ title: "خطأ", description: "أضف صنفاً على الأقل", variant: "destructive" }); return; }
    const snapDate = date;
    const snapTotal = total;
    const snapSuppName = supplierName.trim() || "مورد نقدي";
    const saved = await createPurchase.mutateAsync({ data: { supplierName: snapSuppName, date, discount, notes, items: validItems } });

    // تحديث المخزون — إضافة الكميات المشتراة
    try {
      await fetch("/api/inventory/operations", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          type: "in",
          date: snapDate,
          notes: `مشتريات — فاتورة ${(saved as any)?.invoiceNumber || ""}`,
          items: validItems.map(it => ({
            itemId: it.itemId,
            quantity: it.quantity,
            unitCost: it.unitPrice,
          })),
        }),
      });
    } catch { /* لا نوقف الحفظ إن فشل تحديث المخزون */ }
    // ✅ ترحيل محاسبي تلقائي: مدين المخزون / دائن المورد
    const docId = String((saved as any)?.id || Date.now());
    const docNum = (saved as any)?.invoiceNumber || docId;
    const ledgerEntries: any[] = [];

    // البحث عن حساب المورد (إن وُجد) وحساب المخزون
    let suppAccount = (allAccounts as any[]).find(a => !a.isMain && a.nameAr === snapSuppName);
    if (!suppAccount && snapSuppName !== "مورد نقدي") {
      // إنشاء حساب المورد تلقائياً إن لم يوجد
      try {
        const res = await fetch("/api/accounts", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ nameAr: snapSuppName, type: "liabilities", subSubType: "supplier" }),
        });
        suppAccount = await res.json();
        qc.invalidateQueries({ queryKey: getListAccountsQueryKey() });
      } catch { /**/ }
    }
    const inventoryAccount = (allAccounts as any[]).find(a => a.isMain && a.subSubType === "inventory");

    if (snapTotal > 0) {
      // ① مدين: حساب المخزون بإجمالي الفاتورة (دخول البضاعة)
      if (inventoryAccount?.id) {
        ledgerEntries.push({ id: makeId(), date: snapDate, docType: "purchase" as const, docNumber: docNum, docId,
          accountId: inventoryAccount.id, debit: snapTotal, credit: 0,
          description: `مشتريات — ${snapSuppName}`, currencySymbol: currencySymbol, ref: docNum });
      }
      // ② دائن: حساب المورد بإجمالي الفاتورة
      if (suppAccount?.id) {
        ledgerEntries.push({ id: makeId(), date: snapDate, docType: "purchase" as const, docNumber: docNum, docId,
          accountId: suppAccount.id, debit: 0, credit: snapTotal,
          description: `مشتريات — ${snapSuppName}`, currencySymbol: currencySymbol, ref: docNum });
      }
    }
    postToLedger(ledgerEntries);
    const autoShareMsg = settings.sendOnSave ? buildShareMsg() : "";
    const autoSharePhone = settings.sendOnSave ? (suppAccount as any)?.phone || "" : "";
    const autoHtml = settings.sendOnSave ? buildPurchDocHtml() : undefined;
    qc.invalidateQueries({ queryKey: getListPurchasesQueryKey() });
    setOpen(false); resetForm();
    toast({ title: "✅ تم الحفظ", description: "تم إنشاء فاتورة المشتريات" });
    if (settings.sendOnSave) { setShareMsg(autoShareMsg); setSharePhone(autoSharePhone); setShareHtmlContent(autoHtml); setShareOpen(true); }
  };

  const resetForm = () => {
    setPurchItems([defaultItem()]); setDiscount(0); setOtherFees(0); setOtherFeesDesc(""); setAmountPaid(0);
    const defFundId = settings.defaultFund ? String((fundAccounts as any[]).find(a => a.nameAr === settings.defaultFund)?.id || "") : "";
    setNotes(settings.invoiceNotes || ""); setSupplierName(""); setCurrencyId(""); setIsReturn(false); setImagePreview(null);
    setPaymentAccountId(defFundId); setShowOtherFeesDesc(false);
  };

  const filteredPurchases = useMemo(() => {
    const s = listSearch.toLowerCase();
    return (purchases as any[]).filter(p =>
      !s || (p.invoiceNumber || "").toLowerCase().includes(s) ||
      (p.supplierName || "").toLowerCase().includes(s) ||
      (p.date || "").includes(s) ||
      (p.notes || "").toLowerCase().includes(s)
    );
  }, [purchases, listSearch]);

  const displayedPurchases = pageSize === -1 ? filteredPurchases : filteredPurchases.slice(0, pageSize);

  const openEditPurch = (p: any) => {
    setEditPurch(p);
    setEditStatus(p.status || "posted");
    setEditPaid(Number(p.paidAmount || 0));
    setEditNotes(p.notes || "");
    setEditDate(p.date || "");
  };

  const handleEditSave = async () => {
    if (!editPurch) return;
    const autoStatus = editPaid >= Number(editPurch.total) ? "paid" : editPaid > 0 ? "posted" : editStatus;
    await updatePurchase.mutateAsync({ id: editPurch.id, data: { status: autoStatus, paidAmount: editPaid, notes: editNotes, date: editDate } });
    qc.invalidateQueries({ queryKey: getListPurchasesQueryKey() });
    toast({ title: "✅ تم التعديل", description: "تم تحديث بيانات فاتورة المشتريات" });
    setEditPurch(null);
  };

  const buildPurchDocHtml = (purchase?: any) => {
    const sym = purchase ? (purchase.currencySymbol || "ر.ي") : currencySymbol;
    const validItems = purchase ? (purchase.items || []) : purchItems.filter(it => it.itemId > 0);
    const supplier = purchase ? { nameAr: purchase.supplierName } : { nameAr: supplierName.trim() || "مورد نقدي" };
    const totalVal = purchase ? Number(purchase.total) : total;
    const paidVal = purchase ? Number(purchase.amountPaid || 0) : amountPaid;
    const remVal = purchase ? Number(purchase.remaining || 0) : remaining;
    const rows = validItems.map((it: any) => [
      it.nameAr || items.find((x: any) => x.id === it.itemId)?.nameAr || "",
      String(it.quantity),
      Number(it.unitPrice).toFixed(2) + " " + sym,
      (it.quantity * it.unitPrice).toFixed(2) + " " + sym,
    ]);
    return buildDocumentHTML(
      isReturn ? "مردودات مشتريات" : "فاتورة مشتريات",
      [
        { label: "رقم الفاتورة", value: purchase?.invoiceNumber || "—" },
        { label: "التاريخ", value: purchase?.date || date },
        { label: "المورد", value: supplier?.nameAr || "مورد نقدي" },
        { label: "طريقة الدفع", value: payType === "cash" ? "نقد" : "آجل" },
        { label: "العملة", value: currencyNameAr },
      ],
      ["الصنف", "الكمية", "السعر", "الإجمالي"],
      rows,
      [
        ...(discount > 0 ? [{ label: "الخصم", value: `-${discount.toFixed(2)} ${sym}` }] : []),
        ...(otherFees > 0 ? [{ label: "رسوم أخرى", value: `+${otherFees.toFixed(2)} ${sym}` }] : []),
        { label: "💰 الإجمالي الكلي", value: `${totalVal.toFixed(2)} ${sym}` },
        ...(paidVal > 0 ? [{ label: "✅ المدفوع", value: `${paidVal.toFixed(2)} ${sym}` }] : []),
        ...(remVal > 0 ? [{ label: "⚠️ المتبقي", value: `${remVal.toFixed(2)} ${sym}` }] : []),
      ],
      { ...settings, currencyNameAr },
      notes ? `ملاحظات: ${notes}` : ""
    );
  };

  const handleAddSupplier = async () => {
    if (!newSuppName) return;
    await createSupplier.mutateAsync({ data: { nameAr: newSuppName, phone: newSuppPhone } });
    qc.invalidateQueries({ queryKey: getListSuppliersQueryKey() });
    qc.invalidateQueries({ queryKey: getListAccountsQueryKey() });
    setSupplierName(newSuppName);
    setAddSupplierOpen(false); setNewSuppName(""); setNewSuppPhone("");
  };

  const handleAddItem = async () => {
    if (!newItemName) return;
    await createItem.mutateAsync({ data: { nameAr: newItemName, costPrice: newItemPrice, salePrice: newItemPrice, unit: "قطعة", taxRate: 15 } });
    qc.invalidateQueries({ queryKey: getListItemsQueryKey() });
    setAddItemOpen(false); setNewItemName(""); setNewItemPrice(0);
  };

  const SEP = "─────────────────────";

  const buildShareMsg = (purchase?: any) => {
    const sym = purchase ? (purchase.currencySymbol || "ر.ي") : currencySymbol;
    const fmt = (n: number) => Number(n).toLocaleString("ar-YE", { minimumFractionDigits: 0, maximumFractionDigits: 2 });
    if (purchase) {
      const lineItems = (purchase.items || []).map((it: any) =>
        `• ${it.nameAr || "صنف"}: ${it.quantity} × ${fmt(it.unitPrice)} = ${fmt(it.quantity * it.unitPrice)} ${sym}`
      ).join("\n");
      return [
        `🛒 *فاتورة مشتريات — قـويـره سوفت*`,
        `رقم الفاتورة: *${purchase.invoiceNumber || ""}*`,
        `التاريخ: ${purchase.date}`,
        `المورد: ${purchase.supplierName || "مورد نقدي"}`,
        SEP,
        lineItems || "─ لا توجد أصناف ─",
        SEP,
        `💰 *الإجمالي: ${fmt(purchase.total)} ${sym}*`,
        Number(purchase.amountPaid) > 0 ? `✅ المدفوع: ${fmt(purchase.amountPaid)} ${sym}` : "",
        Number(purchase.remaining) > 0 ? `⚠️ *المتبقي لكم: ${fmt(purchase.remaining)} ${sym}*` : Number(purchase.amountPaid) > 0 ? "✅ *مدفوع بالكامل*" : "",
        notes ? `📝 ملاحظة: ${notes}` : "",
        SEP,
        "شكراً لتعاملكم معنا 🌟"
      ].filter(Boolean).join("\n");
    } else {
      const validItems = purchItems.filter(it => it.itemId > 0);
      const lineItems = validItems.map(it => {
        const item = items.find(x => x.id === it.itemId);
        return `• ${item?.nameAr || "صنف"}: ${it.quantity} × ${fmt(it.unitPrice)} = ${fmt(it.quantity * it.unitPrice)} ${sym}`;
      }).join("\n");
      return [
        `🛒 *فاتورة مشتريات — قـويـره سوفت*`,
        `التاريخ: ${date}`,
        `المورد: ${supplierName.trim() || "مورد نقدي"}`,
        SEP,
        lineItems || "─ لا توجد أصناف ─",
        SEP,
        discount > 0 ? `الخصم: ${fmt(discount)} ${sym}` : "",
        otherFees > 0 ? `رسوم أخرى: ${fmt(otherFees)} ${sym}` : "",
        `💰 *الإجمالي: ${fmt(total)} ${sym}*`,
        amountPaid > 0 ? `✅ المدفوع: ${fmt(amountPaid)} ${sym}` : "",
        remaining > 0 ? `⚠️ *المتبقي لكم: ${fmt(remaining)} ${sym}*` : amountPaid > 0 ? "✅ *مدفوع بالكامل*" : "",
        notes ? `📝 ملاحظة: ${notes}` : "",
        SEP,
        "شكراً لتعاملكم معنا 🌟"
      ].filter(Boolean).join("\n");
    }
  };

  const openShareFromList = (purchase: any) => {
    const suppAcc = (allAccounts as any[]).find(a => a.nameAr === purchase.supplierName && !a.isMain);
    setSharePhone(suppAcc?.phone || "");
    setShareMsg(buildShareMsg(purchase));
    setShareHtmlContent(buildPurchDocHtml(purchase));
    setShareOpen(true);
  };

  const openShareFromForm = () => {
    const suppAcc = (allAccounts as any[]).find(a => a.nameAr === supplierName && !a.isMain);
    setSharePhone(suppAcc?.phone || "");
    setShareMsg(buildShareMsg());
    setShareHtmlContent(buildPurchDocHtml());
    setShareOpen(true);
  };

  const handlePrintPDF = (purchase?: any) => {
    const sym = purchase ? (purchase.currencySymbol || "ر.ي") : currencySymbol;
    const validItems = purchase ? (purchase.items || []) : purchItems.filter(it => it.itemId > 0);
    const supplier = purchase ? { nameAr: purchase.supplierName } : { nameAr: supplierName.trim() || "مورد نقدي" };
    const totalVal = purchase ? Number(purchase.total) : total;
    const paidVal = purchase ? Number(purchase.amountPaid || 0) : amountPaid;
    const remVal = purchase ? Number(purchase.remaining || 0) : remaining;
    const title = isReturn ? "مردودات مشتريات" : "فاتورة مشتريات";
    const rows = validItems.map((it: any) => [
      it.nameAr || items.find(x => x.id === it.itemId)?.nameAr || "",
      String(it.quantity),
      Number(it.unitPrice).toFixed(2) + " " + sym,
      (it.quantity * it.unitPrice).toFixed(2) + " " + sym,
    ]);
    const html = buildDocumentHTML(
      title,
      [
        { label: "رقم الفاتورة", value: purchase?.invoiceNumber || "—" },
        { label: "التاريخ", value: purchase?.date || date },
        { label: "المورد", value: supplier?.nameAr || "مورد نقدي" },
        { label: "طريقة الدفع", value: payType === "cash" ? "نقد" : "آجل" },
        { label: "المخزن", value: warehouseType },
        { label: "العملة", value: currencyNameAr },
      ],
      ["الصنف", "الكمية", "السعر", "الإجمالي"],
      rows,
      [
        ...(discount > 0 ? [{ label: "الخصم", value: `-${discount.toFixed(2)} ${sym}` }] : []),
        ...(otherFees > 0 ? [{ label: "رسوم أخرى", value: `+${otherFees.toFixed(2)} ${sym}` }] : []),
        { label: "💰 الإجمالي الكلي", value: `${totalVal.toFixed(2)} ${sym}` },
        ...(paidVal > 0 ? [{ label: "✅ المدفوع", value: `${paidVal.toFixed(2)} ${sym}` }] : []),
        ...(remVal > 0 ? [{ label: "⚠️ المتبقي", value: `${remVal.toFixed(2)} ${sym}` }] : []),
      ],
      { ...settings, currencyNameAr },
      notes ? `ملاحظات: ${notes}` : ""
    );
    setInvoicePreviewTitle(title);
    setInvoicePreviewHtml(html);
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-amber-400">المشتريات</h1>
          <p className="text-emerald-200 mt-1">إدارة فواتير المشتريات — {filteredPurchases.length} فاتورة</p>
        </div>
        <Button onClick={() => setOpen(true)} className="bg-amber-500 hover:bg-amber-400 text-white gap-2 h-11">
          <Plus className="w-4 h-4" /> فاتورة جديدة
        </Button>
      </div>

      {/* Search + Count Filter */}
      <div className="flex gap-2 items-center">
        <div className="relative flex-1">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-emerald-400" />
          <Input value={listSearch} onChange={e => setListSearch(e.target.value)} placeholder="بحث برقم الفاتورة أو المورد أو التاريخ..." className="bg-emerald-900/50 border-emerald-700 text-white pr-10 placeholder:text-emerald-500" />
        </div>
        <Select value={String(pageSize)} onValueChange={v => setPageSize(Number(v))}>
          <SelectTrigger className="bg-emerald-900 border-emerald-700 text-white h-10 w-32 text-sm"><SelectValue /></SelectTrigger>
          <SelectContent className="bg-emerald-900 border-emerald-700">
            {[10, 25, 50, 100, -1].map(n => <SelectItem key={n} value={String(n)} className="text-white text-sm">{n === -1 ? "الكل" : `${n} سجل`}</SelectItem>)}
          </SelectContent>
        </Select>
      </div>

      <div className="bg-white/5 rounded-xl border border-white/10 overflow-x-auto">
        <table className="w-full text-sm min-w-max">
          <thead className="bg-emerald-800/60 sticky top-0">
            <tr>
              <th className="p-2.5 text-center text-amber-300 w-12">#</th>
              <th className="p-2.5 text-right text-amber-300">المورد</th>
              <th className="p-2.5 text-right text-amber-300">التاريخ</th>
              <th className="p-2.5 text-right text-amber-300">الأصناف</th>
              <th className="p-2.5 text-right text-amber-300">الإجمالي</th>
              <th className="p-2.5 text-center text-amber-300">إجراءات</th>
            </tr>
          </thead>
          <tbody>
            {isLoading ? <tr><td colSpan={6} className="p-6 text-center text-emerald-200">جاري التحميل...</td></tr>
            : displayedPurchases.length === 0 ? <tr><td colSpan={6} className="p-8 text-center text-emerald-300">لا توجد فواتير مشتريات</td></tr>
            : displayedPurchases.map((p: any) => {
              const sym = p.currencySymbol || "ر.ي";
              const paid = Number(p.paidAmount || 0);
              const tot = Number(p.total || 0);
              const rem = tot - paid;
              const isPaid = rem <= 0.01 && tot > 0;
              return (
                <tr key={p.id} className="border-t border-white/5 hover:bg-emerald-800/30 transition-colors">
                  <td className="p-2.5 text-center">
                    <span className="text-amber-400 font-black text-base">{p.invoiceNumber}</span>
                  </td>
                  <td className="p-2.5">
                    <p className="text-white font-semibold text-sm">{p.supplierName ?? "مورد نقدي"}</p>
                    <p className="text-emerald-400 text-xs mt-0.5">📦 مشتريات</p>
                  </td>
                  <td className="p-2.5 text-emerald-200 text-sm whitespace-nowrap">{p.date}</td>
                  <td className="p-2.5">
                    <span className="bg-emerald-800 text-emerald-200 text-xs rounded-full px-2 py-0.5">{(p.items || []).length} صنف</span>
                  </td>
                  <td className="p-2.5">
                    <p className="text-amber-300 font-black text-sm">{tot.toFixed(2)} <span className="text-amber-500 text-xs">{sym}</span></p>
                    {isPaid ? <p className="text-green-400 text-xs">✅ مسدد</p> : rem > 0 ? <p className="text-red-400 text-xs">باقي {rem.toFixed(2)}</p> : null}
                  </td>
                  <td className="p-2.5">
                    <div className="flex gap-1 justify-center">
                      {settings.allowEditInvoices && <Button size="sm" variant="ghost" className="text-amber-400 h-7 w-7 p-0" title="تعديل" onClick={() => openEditPurch(p)}><Edit2 className="w-3.5 h-3.5" /></Button>}
                      <Button size="sm" variant="ghost" className="text-blue-400 h-7 w-7 p-0" title="طباعة" onClick={() => handlePrintPDF(p)}><FileText className="w-3.5 h-3.5" /></Button>
                      <Button size="sm" variant="ghost" className="text-green-400 h-7 w-7 p-0" title="مشاركة" onClick={() => openShareFromList(p)}><Share2 className="w-3.5 h-3.5" /></Button>
                      {settings.allowDeleteInvoices && <Button size="sm" variant="ghost" className="text-red-400 h-7 w-7 p-0" title="حذف" onClick={async () => { await deletePurchase.mutateAsync({ id: p.id }); removeFromLedger(p.id, "purchase"); qc.invalidateQueries({ queryKey: getListPurchasesQueryKey() }); }}><Trash2 className="w-3.5 h-3.5" /></Button>}
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
        {pageSize !== -1 && filteredPurchases.length > pageSize && (
          <div className="p-3 text-center text-emerald-400 text-sm border-t border-white/10">
            يُعرض {pageSize} من {filteredPurchases.length} — <button className="text-amber-400 underline" onClick={() => setPageSize(-1)}>عرض الكل</button>
          </div>
        )}
      </div>

      <ShareDocumentDialog
        open={shareOpen}
        onClose={() => setShareOpen(false)}
        docTitle="فاتورة مشتريات"
        message={shareMsg}
        phone={sharePhone}
        onPrintPDF={() => handlePrintPDF()}
        htmlContent={shareHtmlContent}
      />

      {/* Edit Purchase Dialog */}
      <Dialog open={!!editPurch} onOpenChange={v => !v && setEditPurch(null)}>
        <DialogContent className="max-w-sm text-white border-amber-700" dir="rtl" style={{background: "linear-gradient(135deg, #022c22, #064E3B)"}}>
          <DialogHeader><DialogTitle className="text-amber-400">✏️ تعديل فاتورة مشتريات</DialogTitle></DialogHeader>
          <div className="space-y-4 py-2">
            <div className="bg-emerald-800/40 rounded-xl p-3 border border-emerald-700 text-sm space-y-1">
              <p className="text-emerald-300">رقم الفاتورة: <span className="text-white font-mono">{editPurch?.invoiceNumber}</span></p>
              <p className="text-emerald-300">المورد: <span className="text-white">{editPurch?.supplierName || "مورد نقدي"}</span></p>
              <p className="text-emerald-300">الإجمالي: <span className="text-amber-300 font-bold">{Number(editPurch?.total || 0).toFixed(2)} {editPurch?.currencySymbol || "ر.ي"}</span></p>
            </div>
            <div>
              <Label className="text-emerald-300 text-sm">التاريخ</Label>
              <Input type="date" value={editDate} onChange={e => setEditDate(e.target.value)} className="bg-emerald-900 border-emerald-700 text-white mt-1 h-10 text-sm" />
            </div>
            <div>
              <Label className="text-emerald-300 text-sm">الحالة</Label>
              <Select value={editStatus} onValueChange={setEditStatus}>
                <SelectTrigger className="bg-emerald-900 border-emerald-700 text-white mt-1 h-10 text-sm"><SelectValue /></SelectTrigger>
                <SelectContent className="bg-emerald-900 border-emerald-700">
                  <SelectItem value="posted" className="text-white">مرحلة</SelectItem>
                  <SelectItem value="paid" className="text-white">مدفوع</SelectItem>
                  <SelectItem value="draft" className="text-white">مسودة</SelectItem>
                  <SelectItem value="cancelled" className="text-white">ملغي</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-emerald-300 text-sm">المبلغ المدفوع</Label>
              <Input type="number" step="0.01" min="0" value={editPaid} onChange={e => setEditPaid(parseFloat(e.target.value) || 0)} className="bg-emerald-900 border-emerald-700 text-amber-300 mt-1 h-10 text-sm font-bold text-center" />
              {editPurch && <p className="text-xs text-emerald-400 mt-1">المتبقي: {Math.max(0, Number(editPurch.total) - editPaid).toFixed(2)} {editPurch.currencySymbol || "ر.ي"}</p>}
            </div>
            <div>
              <Label className="text-emerald-300 text-sm">ملاحظات</Label>
              <Input value={editNotes} onChange={e => setEditNotes(e.target.value)} className="bg-emerald-900 border-emerald-700 text-white mt-1 h-10 text-sm" placeholder="أضف ملاحظة..." />
            </div>
            <div className="flex gap-2">
              <Button onClick={handleEditSave} disabled={updatePurchase.isPending} className="flex-1 bg-amber-500 hover:bg-amber-400 text-white">{updatePurchase.isPending ? "..." : "حفظ التعديل"}</Button>
              <Button variant="ghost" onClick={() => setEditPurch(null)} className="text-emerald-300 border border-emerald-700">إلغاء</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Purchase Invoice Dialog */}
      <Dialog open={open} onOpenChange={v => { if (!v) resetForm(); setOpen(v); }}>
        <DialogContent className="max-w-xl p-0 bg-emerald-950 border-emerald-700 text-white overflow-hidden" dir="rtl">
          <div className="sticky top-0 z-20 flex items-center gap-1.5 px-3 py-2.5 bg-emerald-900 border-b border-emerald-700">
            <Button size="sm" variant="ghost" onClick={() => { setOpen(false); resetForm(); }} className="text-emerald-200 hover:text-white h-8 w-8 p-0">
              <ArrowRight className="w-4 h-4" />
            </Button>
            <span className="flex-1 text-center text-amber-400 font-bold text-sm">
              {isReturn ? "🔄 مردودات مشتريات" : "🛒 فاتورة مشتريات"}
            </span>
            <Button size="sm" onClick={handleSubmit} disabled={createPurchase.isPending} className="bg-amber-500 hover:bg-amber-400 text-white h-8 px-3 text-xs font-bold gap-1">
              {createPurchase.isPending ? "..." : <><FileText className="w-3 h-3" /> حفظ</>}
            </Button>
            <Button size="sm" variant="ghost" onClick={() => handlePrintPDF()} className="text-red-400 hover:text-red-300 h-8 w-8 p-0">
              <FileText className="w-4 h-4" />
            </Button>
            <Button size="sm" variant="ghost" onClick={openShareFromForm} className="text-blue-400 hover:text-blue-300 h-8 w-8 p-0">
              <ImageIcon className="w-4 h-4" />
            </Button>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button size="sm" variant="ghost" className="text-emerald-300 hover:text-white h-8 w-8 p-0">
                  <MoreVertical className="w-4 h-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent className="bg-emerald-900 border-emerald-700 text-white" align="end">
                <DropdownMenuItem className="text-red-400 gap-2 cursor-pointer" onClick={() => { setOpen(false); resetForm(); }}><Trash2 className="w-4 h-4" /> حذف</DropdownMenuItem>
                <DropdownMenuItem className="text-white gap-2 cursor-pointer" onClick={openShareFromForm}><Share2 className="w-4 h-4 text-blue-400" /> مشاركة</DropdownMenuItem>
                <DropdownMenuItem className="text-white gap-2 cursor-pointer" onClick={() => { const suppAcc = (allAccounts as any[]).find(a => a.nameAr === supplierName && !a.isMain); const m = buildShareMsg(); window.location.href = `sms:${(suppAcc?.phone || "").replace(/\D/g, "")}?body=${encodeURIComponent(m)}`; }}><Send className="w-4 h-4 text-purple-400" /> SMS</DropdownMenuItem>
                <DropdownMenuItem className="text-green-400 gap-2 cursor-pointer" onClick={() => { const suppAcc = (allAccounts as any[]).find(a => a.nameAr === supplierName && !a.isMain); const m = encodeURIComponent(buildShareMsg()); const ph = (suppAcc?.phone || "").replace(/\D/g, ""); window.open(ph ? `https://wa.me/${ph}?text=${m}` : `https://wa.me/?text=${m}`, "_blank"); }}><MessageCircle className="w-4 h-4" /> واتساب</DropdownMenuItem>
                <DropdownMenuItem className="text-blue-400 gap-2 cursor-pointer" onClick={() => { window.open(`https://t.me/share/url?text=${encodeURIComponent(buildShareMsg())}`, "_blank"); }}><Send className="w-4 h-4" /> تيليجرام</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>

          <div className="overflow-y-auto max-h-[82vh] p-4 space-y-4">
            <div className="flex gap-2">
              <div className="flex rounded-xl overflow-hidden border border-emerald-700 flex-1">
                {(["credit", "cash"] as const).map(t => (
                  <button key={t} onClick={() => setPayType(t)} className={`flex-1 py-2.5 text-sm font-bold transition-all ${payType === t ? "bg-amber-500 text-white" : "text-emerald-300 hover:bg-white/10"}`}>
                    {t === "credit" ? "آجل" : "نقد"}
                  </button>
                ))}
              </div>
              <Select value={warehouseType} onValueChange={setWarehouseType}>
                <SelectTrigger className="bg-emerald-900 border-emerald-700 text-white h-10 text-sm w-32"><SelectValue /></SelectTrigger>
                <SelectContent className="bg-emerald-900 border-emerald-700">
                  {["الرئيسي", "الفرعي", "المستودع 1", "المستودع 2"].map(w => <SelectItem key={w} value={w} className="text-white text-sm">{w}</SelectItem>)}
                </SelectContent>
              </Select>
              <div className="flex rounded-xl overflow-hidden border border-emerald-700">
                <button onClick={() => setIsReturn(false)} className={`px-3 py-2 text-sm font-bold transition-all ${!isReturn ? "bg-emerald-600 text-white" : "text-emerald-300 hover:bg-white/10"}`}>فاتورة</button>
                <button onClick={() => setIsReturn(true)} className={`px-3 py-2 text-sm font-bold transition-all ${isReturn ? "bg-orange-600 text-white" : "text-emerald-300 hover:bg-white/10"}`}>مرتجع</button>
              </div>
            </div>

            <div className="flex gap-2 items-end">
              <div className="flex-1">
                <Label className="text-emerald-300 text-sm">العملة</Label>
                <Select value={currencyId} onValueChange={v => { setCurrencyId(v); const c = currencies.find(x => String(x.id) === v); setExchangeRate((c as any)?.exchangeRate || 1); }}>
                  <SelectTrigger className="bg-emerald-900 border-emerald-700 text-white mt-1 h-10 text-sm"><SelectValue placeholder="ريال يمني (رسمي)" /></SelectTrigger>
                  <SelectContent className="bg-emerald-900 border-emerald-700">
                    {currencies.map(c => <SelectItem key={c.id} value={String(c.id)} className="text-white text-sm">{c.nameAr || c.code} ({c.symbol})</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              {currencyId && !isYER && (
                <div className="w-32">
                  <Label className="text-amber-300 text-sm">سعر الصرف</Label>
                  <Input type="number" step="0.0001" min="0" value={exchangeRate || ""} onChange={e => setExchangeRate(parseFloat(e.target.value) || 1)} className="bg-emerald-900 border-amber-600 text-amber-300 mt-1 h-10 text-sm text-center" />
                </div>
              )}
              {currencyId && <span className="text-emerald-400 text-sm pb-2">{currencyNameAr}</span>}
            </div>

            {/* اسم المورد + التاريخ */}
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label className="text-emerald-300 text-sm mb-1 block">اسم المورد</Label>
                <div className="relative">
                  <Input
                    value={supplierName}
                    onChange={e => { setSupplierName(e.target.value); setSuppNameDropOpen(true); }}
                    onFocus={() => setSuppNameDropOpen(true)}
                    onBlur={() => setTimeout(() => setSuppNameDropOpen(false), 180)}
                    placeholder="اكتب اسم المورد..."
                    className="bg-emerald-900 border-emerald-700 text-white h-10 text-sm pr-8"
                  />
                  <Search className="absolute right-2.5 top-3 w-3.5 h-3.5 text-emerald-400 pointer-events-none" />
                  {suppNameDropOpen && supplierName && (
                    <div className="absolute z-50 w-full top-full mt-1 bg-emerald-900 border border-emerald-600 rounded-xl shadow-2xl max-h-44 overflow-y-auto">
                      {(allAccounts as any[])
                        .filter(a => !a.isMain && a.nameAr?.includes(supplierName))
                        .slice(0, 8)
                        .map((a: any) => (
                          <button key={a.id} onClick={() => { setSupplierName(a.nameAr); setSuppNameDropOpen(false); }}
                            className="w-full text-right px-3 py-2 hover:bg-emerald-700 text-white text-sm border-b border-emerald-800/50 last:border-0">
                            {a.nameAr}
                          </button>
                        ))}
                      {(allAccounts as any[]).filter(a => !a.isMain && a.nameAr?.includes(supplierName)).length === 0 && (
                        <div className="px-3 py-2.5 text-center">
                          <p className="text-white/50 text-xs mb-1">سيُنشأ الحساب تلقائياً</p>
                          <button onClick={() => { setSuppNameDropOpen(false); setAddSupplierOpen(true); setNewSuppName(supplierName); }}
                            className="text-amber-400 text-xs font-bold hover:text-amber-300 flex items-center gap-1 mx-auto">
                            <UserPlus className="w-3 h-3" /> إضافة "{supplierName}" الآن
                          </button>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              </div>
              <div>
                <Label className="text-emerald-300 text-sm">التاريخ</Label>
                <Input type="date" value={date} onChange={e => setDate(e.target.value)} className="bg-emerald-900 border-emerald-700 text-white mt-1 h-10 text-sm" />
              </div>
            </div>

            {/* ملخص القيد التلقائي */}
            {total > 0 && (
              <div className="rounded-xl border border-emerald-700/30 bg-emerald-950/40 p-2.5 text-xs space-y-1">
                <p className="text-emerald-400 font-bold text-center text-xs mb-1.5">⚙️ الترحيل التلقائي</p>
                <div className="flex justify-between items-center">
                  <span className="text-amber-300">↑ مدين — المخزون</span>
                  <span className="text-amber-200 font-bold">{total.toFixed(2)} {currencySymbol}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-emerald-300">↓ دائن — {supplierName.trim() || "مورد نقدي"}</span>
                  <span className="text-emerald-200 font-bold">{total.toFixed(2)} {currencySymbol}</span>
                </div>
              </div>
            )}

            <div className="flex gap-2 items-end">
              <div className="flex-1">
                <Label className="text-emerald-300 text-sm">بيانات / ملاحظات</Label>
                <Input value={notes} onChange={e => setNotes(e.target.value)} className="bg-emerald-900 border-emerald-700 text-white mt-1 h-10 text-sm" placeholder="ملاحظات الفاتورة..." />
              </div>
              <label className="cursor-pointer">
                <div className={`h-10 w-11 rounded-lg border-2 border-dashed flex items-center justify-center transition-colors ${imagePreview ? "border-emerald-500 bg-emerald-800" : "border-emerald-700 hover:border-amber-400"}`}>
                  {imagePreview ? <img src={imagePreview} alt="" className="h-9 w-10 object-cover rounded" /> : <Camera className="w-5 h-5 text-emerald-400" />}
                </div>
                <input type="file" accept="image/*" capture="environment" className="hidden" onChange={e => { const f = e.target.files?.[0]; if (f) setImagePreview(URL.createObjectURL(f)); }} />
              </label>
            </div>

            {/* Items */}
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <Label className="text-amber-300 font-bold text-base">الأصناف</Label>
                <button onClick={() => setAddItemOpen(true)} className="text-emerald-400 text-sm flex items-center gap-1 hover:text-emerald-300">
                  <Package className="w-4 h-4" /> صنف جديد
                </button>
              </div>
              {purchItems.map((it, i) => (
                <div key={i} className="rounded-xl border border-emerald-700/60 p-4 space-y-3 bg-emerald-900/30">
                  <Select value={String(it.itemId)} onValueChange={v => updateItem(i, "itemId", v)}>
                    <SelectTrigger className="bg-emerald-900 border-emerald-700 text-white h-11 text-sm w-full"><SelectValue placeholder="اختر الصنف..." /></SelectTrigger>
                    <SelectContent className="bg-emerald-900 border-emerald-700">
                      {items.map(item => <SelectItem key={item.id} value={String(item.id)} className="text-white text-sm">{item.nameAr}</SelectItem>)}
                    </SelectContent>
                  </Select>
                  <div className="grid grid-cols-3 gap-2">
                    <div>
                      <Label className="text-emerald-400 text-sm">الكمية</Label>
                      <Input
                        type="number"
                        min="0"
                        value={it.quantity === 0 ? "" : it.quantity}
                        onChange={e => updateItem(i, "quantity", e.target.value)}
                        className="bg-emerald-900 border-emerald-600 text-white mt-1 h-12 text-base font-bold text-center"
                        placeholder="0"
                      />
                    </div>
                    <div>
                      <Label className="text-emerald-400 text-sm">السعر</Label>
                      <Input
                        type="number"
                        min="0"
                        value={it.unitPrice === 0 ? "" : it.unitPrice}
                        onChange={e => updateItem(i, "unitPrice", e.target.value)}
                        className="bg-emerald-900 border-emerald-600 text-white mt-1 h-12 text-base font-bold text-center"
                        placeholder="0"
                      />
                    </div>
                    <div>
                      <Label className="text-emerald-400 text-sm">الإجمالي</Label>
                      <div className="mt-1 h-12 flex items-center justify-center bg-amber-900/30 rounded-md border border-amber-700/40">
                        <span className="text-amber-400 font-bold text-base">{(it.quantity * it.unitPrice).toLocaleString("ar-YE", { minimumFractionDigits: 0, maximumFractionDigits: 2 })}</span>
                      </div>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <button onClick={addItem} className="flex-1 flex items-center justify-center gap-1 py-2 rounded-lg bg-emerald-800/60 hover:bg-emerald-700/60 text-emerald-300 text-sm transition-colors border border-emerald-700/40">
                      <Plus className="w-4 h-4" /> إضافة صنف
                    </button>
                    {purchItems.length > 1 && (
                      <button onClick={() => removeItem(i)} className="flex items-center justify-center gap-1 px-4 py-2 rounded-lg hover:bg-red-900/30 text-red-400 text-sm transition-colors border border-red-800/30">
                        <X className="w-4 h-4" /> حذف
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>

            {/* Footer Totals */}
            <div className="rounded-xl border border-emerald-700/50 p-4 bg-emerald-900/30 space-y-3">
              <div className="flex items-center gap-3">
                <Label className="text-emerald-300 text-sm w-28 shrink-0">الخصم</Label>
                <Input type="number" min="0" value={discount || ""} onChange={e => setDiscount(parseFloat(e.target.value) || 0)} className="flex-1 bg-emerald-900 border-emerald-700 text-white h-11 text-sm" placeholder="0" />
                <span className="text-emerald-400 text-sm font-bold">{currencySymbol}</span>
              </div>
              <div className="flex items-center gap-2">
                <Label className="text-emerald-300 text-sm w-28 shrink-0">{payType === "cash" ? "المدفوع" : "المقدم"}</Label>
                <Input type="number" min="0" value={amountPaid || ""} onChange={e => setAmountPaid(parseFloat(e.target.value) || 0)} className="flex-1 bg-emerald-900 border-emerald-700 text-white h-11 text-sm" placeholder="0" />
                <Select value={paymentAccountId} onValueChange={setPaymentAccountId}>
                  <SelectTrigger className="w-32 bg-emerald-900 border-emerald-700 text-white h-11 text-sm"><SelectValue placeholder="الحساب" /></SelectTrigger>
                  <SelectContent className="bg-emerald-900 border-emerald-700">
                    {fundAccounts.map((a: any) => <SelectItem key={a.id} value={String(a.id)} className="text-white text-sm">{a.nameAr}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <div className="flex items-center gap-2">
                  <Label className="text-emerald-300 text-sm w-28 shrink-0">رسوم أخرى</Label>
                  <Input type="number" min="0" value={otherFees || ""} onChange={e => setOtherFees(parseFloat(e.target.value) || 0)} className="flex-1 bg-emerald-900 border-emerald-700 text-white h-11 text-sm" placeholder="0" />
                  <button onClick={() => setShowOtherFeesDesc(v => !v)} className="text-emerald-400 hover:text-amber-400 transition-colors">
                    <Info className="w-5 h-5" />
                  </button>
                </div>
                {showOtherFeesDesc && (
                  <Input value={otherFeesDesc} onChange={e => setOtherFeesDesc(e.target.value)} className="bg-emerald-900 border-emerald-700/60 text-white h-9 text-sm mr-28" placeholder="تفاصيل الرسوم..." />
                )}
              </div>
              <div className="border-t border-emerald-700/50 pt-3 flex items-center justify-between">
                <span className="text-amber-300 font-bold text-base">الإجمالي الكلي</span>
                <span className="text-amber-400 font-black text-2xl">{total.toLocaleString("ar-YE", { minimumFractionDigits: 0, maximumFractionDigits: 2 })} <span className="text-base font-bold">{currencySymbol}</span></span>
              </div>
              {subtotal !== total && (
                <div className="text-sm text-emerald-500 space-y-0.5">
                  {discount > 0 && <div className="flex justify-between"><span>المجموع قبل الخصم</span><span>{subtotal.toFixed(2)}</span></div>}
                  {otherFees > 0 && <div className="flex justify-between"><span>رسوم أخرى</span><span>+{otherFees.toFixed(2)}</span></div>}
                </div>
              )}
              {amountPaid > 0 && (
                payType === "cash" && change > 0 ? (
                  <div className="flex items-center justify-between bg-blue-900/30 rounded-xl px-4 py-3">
                    <span className="text-blue-300 text-base font-bold">الباقي</span>
                    <span className="text-blue-400 font-black text-2xl">{change.toFixed(2)} {currencySymbol}</span>
                  </div>
                ) : (
                  <div className={`flex items-center justify-between rounded-xl px-4 py-3 ${remaining > 0 ? "bg-red-900/30" : "bg-green-900/30"}`}>
                    <span className={`text-base font-bold ${remaining > 0 ? "text-red-300" : "text-green-300"}`}>المتبقي</span>
                    <span className={`font-black text-2xl ${remaining > 0 ? "text-red-400" : "text-green-400"}`}>{Math.abs(remaining).toFixed(2)} {currencySymbol}</span>
                  </div>
                )
              )}
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Quick Add Supplier */}
      <Dialog open={addSupplierOpen} onOpenChange={setAddSupplierOpen}>
        <DialogContent className="max-w-sm bg-emerald-950 border-emerald-700 text-white" dir="rtl">
          <DialogHeader><DialogTitle className="text-amber-400">مورد جديد</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <div><Label className="text-emerald-200">اسم المورد *</Label><Input value={newSuppName} onChange={e => setNewSuppName(e.target.value)} className="bg-emerald-900 border-emerald-700 text-white mt-1 h-11" /></div>
            <div><Label className="text-emerald-200">رقم الجوال</Label><Input value={newSuppPhone} onChange={e => setNewSuppPhone(e.target.value)} className="bg-emerald-900 border-emerald-700 text-white mt-1 h-11" /></div>
            <div className="flex gap-2"><Button onClick={handleAddSupplier} className="bg-amber-500 hover:bg-amber-400 text-white flex-1 h-11">حفظ</Button><Button variant="outline" onClick={() => setAddSupplierOpen(false)} className="border-emerald-600 text-emerald-200 h-11">إلغاء</Button></div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Quick Add Item */}
      <Dialog open={addItemOpen} onOpenChange={setAddItemOpen}>
        <DialogContent className="max-w-sm bg-emerald-950 border-emerald-700 text-white" dir="rtl">
          <DialogHeader><DialogTitle className="text-amber-400">صنف جديد</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <div><Label className="text-emerald-200">اسم الصنف *</Label><Input value={newItemName} onChange={e => setNewItemName(e.target.value)} className="bg-emerald-900 border-emerald-700 text-white mt-1 h-11" /></div>
            <div><Label className="text-emerald-200">سعر التكلفة</Label><Input type="number" min="0" value={newItemPrice || ""} onChange={e => setNewItemPrice(parseFloat(e.target.value) || 0)} className="bg-emerald-900 border-emerald-700 text-white mt-1 h-11" placeholder="0" /></div>
            <div className="flex gap-2"><Button onClick={handleAddItem} className="bg-amber-500 hover:bg-amber-400 text-white flex-1 h-11">حفظ</Button><Button variant="outline" onClick={() => setAddItemOpen(false)} className="border-emerald-600 text-emerald-200 h-11">إلغاء</Button></div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Invoice Full-Screen Preview */}
      {invoicePreviewHtml && (
        <InvoicePrintOverlay
          html={invoicePreviewHtml}
          title={invoicePreviewTitle}
          onClose={() => setInvoicePreviewHtml(null)}
          onShare={() => { setInvoicePreviewHtml(null); openShareFromForm(); }}
        />
      )}
    </div>
  );
}
