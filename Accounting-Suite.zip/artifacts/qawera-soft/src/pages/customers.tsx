import { useState } from "react";
import { useListCustomers, useCreateCustomer, useDeleteCustomer } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { getListCustomersQueryKey } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Plus, Trash2, MessageCircle } from "lucide-react";

type CustomerForm = { nameAr: string; code: string; phone: string; address: string; relatives: string; creditLimit: number; openingBalance: number; whatsappNotify: boolean; smsNotify: boolean; };
const defaultForm: CustomerForm = { nameAr: "", code: "", phone: "", address: "", relatives: "", creditLimit: 0, openingBalance: 0, whatsappNotify: false, smsNotify: false };

export default function CustomersPage() {
  const qc = useQueryClient();
  const { data: customers = [], isLoading } = useListCustomers();
  const createCustomer = useCreateCustomer();
  const deleteCustomer = useDeleteCustomer();
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState<CustomerForm>(defaultForm);

  const handleSubmit = async () => {
    if (!form.nameAr) return;
    await createCustomer.mutateAsync({ data: { ...form } });
    qc.invalidateQueries({ queryKey: getListCustomersQueryKey() });
    setOpen(false);
    setForm(defaultForm);
  };

  const sendWhatsApp = (customer: typeof customers[0]) => {
    if (!customer.phone) return alert("لا يوجد رقم جوال");
    window.open(`https://wa.me/${customer.phone}?text=${encodeURIComponent(`مرحباً ${customer.nameAr}`)}`, "_blank");
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-amber-400">العملاء</h1>
          <p className="text-emerald-200 mt-1">إدارة بيانات العملاء</p>
        </div>
        <Button onClick={() => setOpen(true)} className="bg-amber-500 hover:bg-amber-600 text-white gap-2">
          <Plus className="w-4 h-4" /> عميل جديد
        </Button>
      </div>

      <div className="bg-white/5 rounded-xl border border-white/10 overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-emerald-800/50">
            <tr>
              <th className="p-3 text-right text-amber-300">الكود</th>
              <th className="p-3 text-right text-amber-300">الاسم</th>
              <th className="p-3 text-right text-amber-300">الجوال</th>
              <th className="p-3 text-right text-amber-300">الرصيد</th>
              <th className="p-3 text-right text-amber-300">حد الائتمان</th>
              <th className="p-3 text-right text-amber-300">إجراءات</th>
            </tr>
          </thead>
          <tbody>
            {isLoading ? (
              <tr><td colSpan={6} className="p-6 text-center text-emerald-200">جاري التحميل...</td></tr>
            ) : customers.length === 0 ? (
              <tr><td colSpan={6} className="p-6 text-center text-emerald-200">لا يوجد عملاء</td></tr>
            ) : customers.map(c => (
              <tr key={c.id} data-testid={`row-customer-${c.id}`} className="border-t border-white/10 hover:bg-white/5">
                <td className="p-3 text-emerald-300 font-mono text-xs">{c.code}</td>
                <td className="p-3 text-white font-bold">{c.nameAr}</td>
                <td className="p-3 text-emerald-200">{c.phone || "-"}</td>
                <td className="p-3 text-amber-300 font-bold">{Number(c.balance).toFixed(2)} ر.س</td>
                <td className="p-3 text-emerald-200">{Number(c.creditLimit).toFixed(2)} ر.س</td>
                <td className="p-3">
                  <div className="flex gap-2">
                    {c.phone && (
                      <Button size="sm" variant="ghost" className="text-green-400 h-8 w-8 p-0" onClick={() => sendWhatsApp(c)} title="واتساب">
                        <MessageCircle className="w-4 h-4" />
                      </Button>
                    )}
                    <Button size="sm" variant="ghost" className="text-red-400 h-8 w-8 p-0"
                      onClick={async () => { await deleteCustomer.mutateAsync({ id: c.id }); qc.invalidateQueries({ queryKey: getListCustomersQueryKey() }); }}>
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-xl bg-emerald-950 border-emerald-700 text-white" dir="rtl">
          <DialogHeader><DialogTitle className="text-amber-400 text-xl">إضافة عميل جديد</DialogTitle></DialogHeader>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label className="text-emerald-200">اسم العميل *</Label>
                <Input value={form.nameAr} onChange={e => setForm(f => ({ ...f, nameAr: e.target.value }))} className="bg-emerald-900 border-emerald-700 text-white" placeholder="اسم العميل" />
              </div>
              <div>
                <Label className="text-emerald-200">رقم الحساب</Label>
                <Input value={form.code} onChange={e => setForm(f => ({ ...f, code: e.target.value }))} className="bg-emerald-900 border-emerald-700 text-white" placeholder="مثال: CUS-001" />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label className="text-emerald-200">رقم الجوال</Label>
                <Input value={form.phone} onChange={e => setForm(f => ({ ...f, phone: e.target.value }))} className="bg-emerald-900 border-emerald-700 text-white" placeholder="05XXXXXXXX" />
              </div>
              <div>
                <Label className="text-emerald-200">حد الائتمان</Label>
                <Input type="number" value={form.creditLimit} onChange={e => setForm(f => ({ ...f, creditLimit: parseFloat(e.target.value) || 0 }))} className="bg-emerald-900 border-emerald-700 text-white" />
              </div>
            </div>
            <div>
              <Label className="text-emerald-200">العنوان</Label>
              <Input value={form.address} onChange={e => setForm(f => ({ ...f, address: e.target.value }))} className="bg-emerald-900 border-emerald-700 text-white" placeholder="العنوان" />
            </div>
            <div>
              <Label className="text-emerald-200">الأقارب</Label>
              <Input value={form.relatives} onChange={e => setForm(f => ({ ...f, relatives: e.target.value }))} className="bg-emerald-900 border-emerald-700 text-white" placeholder="الأقارب" />
            </div>
            <div>
              <Label className="text-emerald-200">الرصيد الافتتاحي</Label>
              <Input type="number" value={form.openingBalance} onChange={e => setForm(f => ({ ...f, openingBalance: parseFloat(e.target.value) || 0 }))} className="bg-emerald-900 border-emerald-700 text-white" />
            </div>
            <div className="flex gap-8">
              <div className="flex items-center gap-3">
                <Switch checked={form.whatsappNotify} onCheckedChange={v => setForm(f => ({ ...f, whatsappNotify: v }))} />
                <Label className="text-emerald-200">اشعار واتساب</Label>
              </div>
              <div className="flex items-center gap-3">
                <Switch checked={form.smsNotify} onCheckedChange={v => setForm(f => ({ ...f, smsNotify: v }))} />
                <Label className="text-emerald-200">اشعار رسالة نصية</Label>
              </div>
            </div>
            <div className="flex gap-2 pt-2">
              <Button onClick={handleSubmit} disabled={createCustomer.isPending} className="bg-amber-500 hover:bg-amber-600 text-white flex-1">
                {createCustomer.isPending ? "جاري الحفظ..." : "حفظ"}
              </Button>
              <Button variant="outline" onClick={() => setOpen(false)} className="border-emerald-600 text-emerald-200">إلغاء</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
