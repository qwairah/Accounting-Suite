import { useState, useMemo, useRef } from "react";
import { useListJournalEntries, useCreateJournalEntry, useListAccounts, useListCurrencies, useCreateAccount } from "@workspace/api-client-react";
import { useQueryClient, useMutation } from "@tanstack/react-query";
import { getListJournalEntriesQueryKey, getListAccountsQueryKey } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, Trash2, Camera, Search, Printer, MessageCircle, UserPlus, MoreVertical, ArrowRight, FileText, Share2, Edit2, Calculator, ChevronDown } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { ShareDocumentDialog } from "@/components/ShareDocumentDialog";
import { printDocument } from "@/lib/printUtils";
import { postToLedger, makeId } from "@/lib/ledger";
import { useSettings } from "@/contexts/SettingsContext";

type EntryLine = { accountId: number; accountName: string; debit: number; credit: number; description: string };
const defLine = (): EntryLine => ({ accountId: 0, accountName: "", debit: 0, credit: 0, description: "" });

export default function JournalPage() {
  const qc = useQueryClient();
  const { settings } = useSettings();
  const { data: entries = [], isLoading } = useListJournalEntries();
  const { data: allAccounts = [] } = useListAccounts();
  const { data: currencies = [] } = useListCurrencies();
  const createEntry = useCreateJournalEntry();
  const createAccount = useCreateAccount();
  const { toast } = useToast();
  const debitLabel = settings.debitLabel || "مدين";
  const creditLabel = settings.creditLabel || "دائن";

  const [open, setOpen] = useState(false);
  const [addAccOpen, setAddAccOpen] = useState(false);
  const [shareOpen, setShareOpen] = useState(false);
  const [shareMsg, setShareMsg] = useState("");
  const [search, setSearch] = useState("");
  const [date, setDate] = useState(new Date().toISOString().split("T")[0]);
  const [description, setDescription] = useState("");
  const [notes, setNotes] = useState("");
  const [currencyId, setCurrencyId] = useState("");
  const [exchangeRate, setExchangeRate] = useState(1);
  const [lines, setLines] = useState<EntryLine[]>([defLine(), defLine()]);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [newAcc, setNewAcc] = useState({ nameAr: "", type: "assets", phone: "", address: "" });
  const [pageSize, setPageSize] = useState(25);
  const [editEntry, setEditEntry] = useState<any>(null);
  const [editDescription, setEditDescription] = useState("");
  const [editNotes, setEditNotes] = useState("");
  const [editDate, setEditDate] = useState("");
  // Simplified two-account form
  const [fromAccId, setFromAccId] = useState("");
  const [fromAccSearch, setFromAccSearch] = useState("");
  const [fromAccOpen, setFromAccOpen] = useState(false);
  const [toAccId, setToAccId] = useState("");
  const [toAccSearch, setToAccSearch] = useState("");
  const [toAccOpen, setToAccOpen] = useState(false);
  const [amount, setAmount] = useState<number>(0);
  const [showCalc, setShowCalc] = useState(false);
  const [calcExpr, setCalcExpr] = useState("");
  const [editingExchangeRate, setEditingExchangeRate] = useState(false);
  const amountRef = useRef<HTMLInputElement>(null);

  const deleteEntryMutation = useMutation({
    mutationFn: async (id: number) => {
      const res = await fetch(`/api/journal/${id}`, { method: "DELETE" });
      return res.json();
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: getListJournalEntriesQueryKey() });
      toast({ title: "✅ تم حذف القيد" });
    }
  });

  const updateEntryMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: any }) => {
      const res = await fetch(`/api/journal/${id}`, { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify(data) });
      return res.json();
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: getListJournalEntriesQueryKey() });
      toast({ title: "✅ تم تعديل القيد" });
      setEditEntry(null);
    }
  });

  const accounts = useMemo(() => (allAccounts as any[]).filter(a => !a.isMain), [allAccounts]);
  const selectedCurrency = (currencies as any[]).find((c: any) => String(c.id) === currencyId);

  const totalDebit = lines.reduce((s, l) => s + (l.debit || 0), 0);
  const totalCredit = lines.reduce((s, l) => s + (l.credit || 0), 0);
  const isBalanced = Math.abs(totalDebit - totalCredit) < 0.01;

  const filteredFromAccs = useMemo(() => {
    const base = fromAccSearch ? accounts.filter(a => a.nameAr?.includes(fromAccSearch)) : accounts;
    return base.filter(a => String(a.id) !== toAccId);
  }, [accounts, fromAccSearch, toAccId]);

  const filteredToAccs = useMemo(() => {
    const base = toAccSearch ? accounts.filter(a => a.nameAr?.includes(toAccSearch)) : accounts;
    return base.filter(a => String(a.id) !== fromAccId);
  }, [accounts, toAccSearch, fromAccId]);

  const fromAcc = accounts.find(a => String(a.id) === fromAccId);
  const toAcc = accounts.find(a => String(a.id) === toAccId);
  const nextEntryId = (entries as any[]).length + 1;
  const simpleReady = fromAccId && toAccId && fromAccId !== toAccId && amount > 0;

  const resetForm = () => {
    setFromAccId(""); setFromAccSearch(""); setFromAccOpen(false);
    setToAccId(""); setToAccSearch(""); setToAccOpen(false);
    setAmount(0); setDescription(""); setNotes(""); setImagePreview(null);
    setCurrencyId(""); setExchangeRate(1);
    setLines([defLine(), defLine()]);
    setShowCalc(false); setCalcExpr(""); setEditingExchangeRate(false);
  };

  const handleSubmit = async () => {
    if (!fromAccId || !toAccId) { toast({ title: "خطأ", description: "اختر من حساب وإلى حساب", variant: "destructive" }); return; }
    if (fromAccId === toAccId) { toast({ title: "⛔ خطأ", description: "لا يمكن أن يكون من حساب وإلى حساب نفس الحساب", variant: "destructive" }); return; }
    if (!amount || amount <= 0) { toast({ title: "خطأ", description: "أدخل المبلغ", variant: "destructive" }); return; }

    const validLines: EntryLine[] = [
      { accountId: parseInt(fromAccId), accountName: fromAcc?.nameAr || "", debit: amount, credit: 0, description },
      { accountId: parseInt(toAccId),   accountName: toAcc?.nameAr || "",   debit: 0, credit: amount, description },
    ];
    const snapDate = date; const snapDesc = description;
    const saved = await createEntry.mutateAsync({ data: {
      date, description, notes, lines: validLines,
      currencyId: currencyId ? parseInt(currencyId) : undefined, exchangeRate,
    }});
    const docId = String((saved as any)?.id || Date.now());
    const docNum = (saved as any)?.entryNumber || docId;
    const sym = (selectedCurrency as any)?.symbol || "ر.ي";
    const ledgerEntries = validLines.map(l => ({
      id: makeId(), date: snapDate, docType: "journal" as const, docNumber: docNum, docId,
      accountId: l.accountId, debit: l.debit || 0, credit: l.credit || 0,
      description: snapDesc || "قيد يومي",
      currencySymbol: sym, ref: "",
    }));
    postToLedger(ledgerEntries);
    qc.invalidateQueries({ queryKey: getListJournalEntriesQueryKey() });
    setOpen(false);
    resetForm();
    toast({ title: "✅ تم حفظ القيد اليومي" });
  };

  const handleAddAccount = async () => {
    if (!newAcc.nameAr) return;
    const res = await createAccount.mutateAsync({ data: newAcc });
    qc.invalidateQueries({ queryKey: getListAccountsQueryKey() });
    setAddAccOpen(false);
    setNewAcc({ nameAr: "", type: "assets", phone: "", address: "" });
    toast({ title: "✅ تم إنشاء الحساب" });
  };

  const SEP = "─────────────────────";

  const buildJournalMsg = (entry?: any) => {
    const sym = selectedCurrency?.symbol || "ر.ي";
    if (entry) {
      const lineRows = (entry.lines || []).map((l: any) =>
        l.debit > 0
          ? `  ${l.accountName}: مدين ${Number(l.debit).toFixed(2)} ${sym}`
          : `  ${l.accountName}: دائن ${Number(l.credit).toFixed(2)} ${sym}`
      ).join("\n");
      return [
        "📋 *قيد يومي — قـويـره سوفت*",
        `رقم القيد: *${entry.entryNumber || ""}*`,
        `التاريخ: ${entry.date}`,
        `البيان: ${entry.description || "—"}`,
        SEP,
        lineRows,
        SEP,
        `💰 المدين: ${Number(entry.totalDebit || 0).toFixed(2)} ${sym}`,
        `💰 الدائن: ${Number(entry.totalCredit || 0).toFixed(2)} ${sym}`,
        entry.notes ? `📝 ملاحظة: ${entry.notes}` : "",
        SEP,
        "قـويـره سوفت — نظام المحاسبة المتكامل"
      ].filter(Boolean).join("\n");
    } else {
      const validLines = lines.filter(l => l.accountId > 0 && (l.debit > 0 || l.credit > 0));
      const lineRows = validLines.map(l =>
        l.debit > 0
          ? `  ${l.accountName}: مدين ${l.debit.toFixed(2)} ${sym}`
          : `  ${l.accountName}: دائن ${l.credit.toFixed(2)} ${sym}`
      ).join("\n");
      return [
        "📋 *قيد يومي — قـويـره سوفت*",
        `التاريخ: ${date}`,
        `البيان: ${description || "—"}`,
        SEP,
        lineRows || "─ لا توجد سطور ─",
        SEP,
        `💰 المدين: ${totalDebit.toFixed(2)} ${sym}`,
        `💰 الدائن: ${totalCredit.toFixed(2)} ${sym}`,
        isBalanced ? "✅ القيد متوازن" : "⚠️ القيد غير متوازن",
        notes ? `📝 ملاحظة: ${notes}` : "",
        SEP,
        "قـويـره سوفت — نظام المحاسبة المتكامل"
      ].filter(Boolean).join("\n");
    }
  };

  const handlePrintEntryFormatted = (entry?: any) => {
    const sym = selectedCurrency?.symbol || "ر.ي";
    const e = entry;
    const validLines = e ? (e.lines || []) : lines.filter(l => l.accountId > 0 && (l.debit > 0 || l.credit > 0));
    const rows = validLines.map((l: any) => [l.accountName, l.debit ? Number(l.debit).toFixed(2) : "─", l.credit ? Number(l.credit).toFixed(2) : "─", l.description || ""]);
    const totDebit = e ? Number(e.totalDebit || 0) : totalDebit;
    const totCredit = e ? Number(e.totalCredit || 0) : totalCredit;
    printDocument(
      "قيد يومي",
      [
        { label: "رقم القيد", value: e?.entryNumber || "—" },
        { label: "التاريخ", value: e?.date || date },
        { label: "البيان", value: e?.description || description || "—" },
        { label: "العملة", value: sym },
      ],
      ["الحساب", "مدين", "دائن", "بيان السطر"],
      rows,
      [
        { label: "إجمالي المدين", value: `${totDebit.toFixed(2)} ${sym}` },
        { label: "إجمالي الدائن", value: `${totCredit.toFixed(2)} ${sym}` },
      ],
      { companyName: "قـويـره سوفت", companyNameEn: "Qwairah Soft", printHeader: true, printSignature: true },
      (e?.notes || notes) ? `ملاحظات: ${e?.notes || notes}` : ""
    );
  };

  const printEntry = (entry: any) => {
    const w = window.open("", "_blank");
    if (!w) return;
    w.document.write(`<!DOCTYPE html><html dir="rtl"><head><meta charset="utf-8"><title>قيد يومي</title>
    <style>body{font-family:Arial;padding:30px;direction:rtl}h2{color:#064E3B;border-bottom:2px solid #064E3B;padding-bottom:10px}
    table{width:100%;border-collapse:collapse;margin-top:20px}td,th{padding:10px;border:1px solid #ccc;text-align:right}
    th{background:#064E3B;color:white}.balanced{color:green;font-weight:bold}</style></head>
    <body><h2>قـويـره سوفت - قيد يومي</h2>
    <p><b>رقم القيد:</b> ${entry.entryNumber || ""} | <b>التاريخ:</b> ${entry.date} | <b>البيان:</b> ${entry.description || ""}</p>
    <table><thead><tr><th>الحساب</th><th>مدين</th><th>دائن</th><th>البيان</th></tr></thead>
    <tbody>${(entry.lines || []).map((l: any) => `<tr><td>${l.accountName}</td><td>${l.debit ? Number(l.debit).toFixed(2) : ""}</td><td>${l.credit ? Number(l.credit).toFixed(2) : ""}</td><td>${l.description || ""}</td></tr>`).join("")}
    <tr><td><b>الإجمالي</b></td><td class="balanced">${Number(entry.totalDebit).toFixed(2)}</td><td class="balanced">${Number(entry.totalCredit).toFixed(2)}</td><td></td></tr>
    </tbody></table></body></html>`);
    w.print();
  };

  const filteredEntries = useMemo(() => {
    if (!search) return entries as any[];
    return (entries as any[]).filter(e => e.description?.includes(search) || e.entryNumber?.includes(search) || e.notes?.includes(search));
  }, [entries, search]);

  const displayedEntries = pageSize === -1 ? filteredEntries : filteredEntries.slice(0, pageSize);

  const openEditEntry = (e: any) => {
    setEditEntry(e);
    setEditDescription(e.description || "");
    setEditNotes(e.notes || "");
    setEditDate(e.date || "");
  };

  return (
    <div className="space-y-5 animate-in fade-in duration-300">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-amber-400">القيود اليومية</h1>
          <p className="text-emerald-200 mt-1">القيد المحاسبي من حساب إلى حساب</p>
        </div>
        <Button onClick={() => { setNotes(settings.entryNotes || ""); setOpen(true); }} className="bg-emerald-700 hover:bg-emerald-600 text-white gap-2 h-11 px-5 font-bold border border-emerald-500/40">
          <Plus className="w-4 h-4" /> قيد جديد
        </Button>
      </div>

      <div className="flex gap-2 items-center">
        <div className="relative flex-1">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-emerald-400" />
          <Input value={search} onChange={e => setSearch(e.target.value)} placeholder="بحث في القيود..." className="bg-emerald-900/50 border-emerald-700 text-white pr-10 placeholder:text-emerald-500" />
        </div>
        <Select value={String(pageSize)} onValueChange={v => setPageSize(Number(v))}>
          <SelectTrigger className="bg-emerald-900 border-emerald-700 text-white h-10 w-32 text-sm"><SelectValue /></SelectTrigger>
          <SelectContent className="bg-emerald-900 border-emerald-700">
            {[10, 25, 50, 100, -1].map(n => <SelectItem key={n} value={String(n)} className="text-white text-sm">{n === -1 ? "الكل" : `${n} سجل`}</SelectItem>)}
          </SelectContent>
        </Select>
      </div>

      <div className="bg-white/5 rounded-xl border border-white/10 overflow-x-auto">
        <table className="w-full text-sm min-w-max">
          <thead className="bg-emerald-800/60 sticky top-0">
            <tr>
              <th className="p-2.5 text-center text-amber-300 w-12">#</th>
              <th className="p-2.5 text-right text-amber-300">التاريخ</th>
              <th className="p-2.5 text-right text-amber-300">البيان</th>
              <th className="p-2.5 text-right text-amber-300">{debitLabel}</th>
              <th className="p-2.5 text-right text-amber-300">{creditLabel}</th>
              <th className="p-2.5 text-center text-amber-300">إجراءات</th>
            </tr>
          </thead>
          <tbody>
            {isLoading ? <tr><td colSpan={6} className="p-6 text-center text-emerald-200">جاري التحميل...</td></tr>
            : displayedEntries.length === 0 ? <tr><td colSpan={6} className="p-8 text-center text-emerald-300">لا توجد قيود. أنشئ قيداً جديداً</td></tr>
            : displayedEntries.map((e: any) => (
              <tr key={e.id} className="border-t border-white/5 hover:bg-emerald-800/30 transition-colors">
                <td className="p-2.5 text-center">
                  <span className="text-amber-400 font-black text-base">{e.entryNumber}</span>
                </td>
                <td className="p-2.5 text-emerald-200 text-sm whitespace-nowrap">{e.date}</td>
                <td className="p-2.5 text-white text-sm max-w-[200px] truncate">{e.description}</td>
                <td className="p-2.5 text-green-400 font-black text-sm whitespace-nowrap">{Number(e.totalDebit || 0).toFixed(2)}</td>
                <td className="p-2.5 text-red-400 font-black text-sm whitespace-nowrap">{Number(e.totalCredit || 0).toFixed(2)}</td>
                <td className="p-2.5">
                  <div className="flex gap-1 justify-center">
                    <Button size="sm" variant="ghost" className="text-amber-400 h-7 w-7 p-0" title="تعديل" onClick={() => openEditEntry(e)}><Edit2 className="w-3.5 h-3.5" /></Button>
                    <Button size="sm" variant="ghost" className="text-blue-400 h-7 w-7 p-0" onClick={() => handlePrintEntryFormatted(e)}><Printer className="w-3.5 h-3.5" /></Button>
                    <Button size="sm" variant="ghost" className="text-green-400 h-7 w-7 p-0" onClick={() => { setShareMsg(buildJournalMsg(e)); setShareOpen(true); }}><Share2 className="w-3.5 h-3.5" /></Button>
                    {settings.allowDeleteInvoices && <Button size="sm" variant="ghost" className="text-red-400 h-7 w-7 p-0" title="حذف" onClick={() => deleteEntryMutation.mutate(e.id)}><Trash2 className="w-3.5 h-3.5" /></Button>}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {pageSize !== -1 && filteredEntries.length > pageSize && (
        <div className="text-center text-emerald-400 text-sm">
          يُعرض {pageSize} من {filteredEntries.length} — <button className="text-amber-400 underline" onClick={() => setPageSize(-1)}>عرض الكل</button>
        </div>
      )}

      <ShareDocumentDialog
        open={shareOpen}
        onClose={() => setShareOpen(false)}
        docTitle="قيد يومي"
        message={shareMsg}
        onPrintPDF={() => handlePrintEntryFormatted()}
      />

      {/* Edit Journal Entry Dialog */}
      <Dialog open={!!editEntry} onOpenChange={v => !v && setEditEntry(null)}>
        <DialogContent className="max-w-sm text-white border-amber-700" dir="rtl" style={{background: "linear-gradient(135deg, #1e1b4b, #312e81)"}}>
          <DialogHeader><DialogTitle className="text-amber-400">✏️ تعديل القيد</DialogTitle></DialogHeader>
          <div className="space-y-4 py-2">
            <div className="bg-indigo-800/40 rounded-xl p-3 border border-indigo-700 text-sm space-y-1">
              <p className="text-indigo-300">رقم القيد: <span className="text-white font-mono">{editEntry?.entryNumber}</span></p>
              <div className="flex gap-2 mt-1">
                <span className="text-indigo-300 text-xs">المدين: <span className="text-amber-300 font-bold">{Number(editEntry?.totalDebit || 0).toFixed(2)}</span></span>
                <span className="text-indigo-300 text-xs">الدائن: <span className="text-amber-300 font-bold">{Number(editEntry?.totalCredit || 0).toFixed(2)}</span></span>
              </div>
              {/* Show entry lines read-only */}
              {(editEntry?.lines || []).length > 0 && (
                <div className="mt-2 space-y-1">
                  {(editEntry.lines as any[]).map((l: any, i: number) => (
                    <div key={i} className="flex justify-between text-xs bg-indigo-900/40 rounded px-2 py-1">
                      <span className="text-white">{l.accountName}</span>
                      <span className="text-amber-300">{l.debit > 0 ? `م: ${Number(l.debit).toFixed(2)}` : `د: ${Number(l.credit).toFixed(2)}`}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>
            <div>
              <Label className="text-indigo-300 text-sm">التاريخ</Label>
              <Input type="date" value={editDate} onChange={e => setEditDate(e.target.value)} className="bg-indigo-900 border-indigo-700 text-white mt-1 h-10 text-sm" />
            </div>
            <div>
              <Label className="text-indigo-300 text-sm">البيان</Label>
              <Input value={editDescription} onChange={e => setEditDescription(e.target.value)} className="bg-indigo-900 border-indigo-700 text-white mt-1 h-10 text-sm" placeholder="وصف القيد..." />
            </div>
            <div>
              <Label className="text-indigo-300 text-sm">ملاحظات</Label>
              <Input value={editNotes} onChange={e => setEditNotes(e.target.value)} className="bg-indigo-900 border-indigo-700 text-white mt-1 h-10 text-sm" placeholder="أضف ملاحظة..." />
            </div>
            <div className="flex gap-2">
              <Button onClick={() => updateEntryMutation.mutate({ id: editEntry.id, data: { description: editDescription, notes: editNotes, date: editDate } })} disabled={updateEntryMutation.isPending} className="flex-1 bg-amber-500 hover:bg-amber-400 text-white">{updateEntryMutation.isPending ? "..." : "حفظ التعديل"}</Button>
              <Button variant="ghost" onClick={() => setEditEntry(null)} className="text-indigo-300 border border-indigo-700">إلغاء</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Journal Entry Dialog — redesigned per user specs */}
      <Dialog open={open} onOpenChange={v => { if (!v) resetForm(); setOpen(v); }}>
        <DialogContent className="max-w-md p-0 text-white border-emerald-700/60 overflow-hidden" dir="rtl"
          style={{background: "linear-gradient(160deg, #022c22 0%, #064E3B 60%, #047857 100%)"}}>

          {/* ── Top Action Bar (same style as invoices/receipts) ── */}
          <div className="sticky top-0 z-20 flex items-center gap-1.5 px-2 py-2 border-b border-emerald-700/50"
            style={{background:"rgba(2,44,34,0.97)"}}>
            {/* رجوع */}
            <Button size="sm" variant="ghost" onClick={() => { setOpen(false); resetForm(); }}
              className="text-emerald-300 hover:text-white h-9 w-9 p-0 rounded-lg hover:bg-emerald-800/60">
              <ArrowRight className="w-4 h-4" />
            </Button>
            {/* عنوان */}
            <span className="flex-1 text-center text-amber-400 font-black text-sm">📋 قيد يومي جديد</span>
            {/* طباعة */}
            <Button size="sm" variant="ghost" onClick={() => handlePrintEntryFormatted()}
              className="text-red-400 hover:text-red-300 h-9 w-9 p-0 rounded-lg hover:bg-red-900/30" title="طباعة">
              <FileText className="w-4 h-4" />
            </Button>
            {/* مشاركة */}
            <Button size="sm" variant="ghost"
              onClick={() => { setShareMsg(buildJournalMsg()); setShareOpen(true); }}
              className="text-blue-400 hover:text-blue-300 h-9 w-9 p-0 rounded-lg hover:bg-blue-900/30" title="مشاركة">
              <Share2 className="w-4 h-4" />
            </Button>
            {/* واتساب */}
            <Button size="sm" variant="ghost"
              onClick={() => { window.open(`https://wa.me/?text=${encodeURIComponent(buildJournalMsg())}`, "_blank"); }}
              className="text-green-400 hover:text-green-300 h-9 w-9 p-0 rounded-lg hover:bg-green-900/30" title="واتساب">
              <MessageCircle className="w-4 h-4" />
            </Button>
            {/* قائمة */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button size="sm" variant="ghost" className="text-emerald-300 hover:text-white h-9 w-9 p-0 rounded-lg hover:bg-emerald-800/60">
                  <MoreVertical className="w-4 h-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent className="bg-emerald-900 border-emerald-700 text-white" align="end">
                <DropdownMenuItem className="text-blue-400 gap-2 cursor-pointer" onClick={() => setAddAccOpen(true)}>
                  <UserPlus className="w-4 h-4" /> إنشاء حساب جديد
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
            {/* حفظ */}
            <Button size="sm" onClick={handleSubmit} disabled={createEntry.isPending || !simpleReady}
              className="bg-amber-500 hover:bg-amber-400 text-white h-9 px-4 font-black rounded-lg text-sm">
              {createEntry.isPending ? "..." : "💾 حفظ"}
            </Button>
          </div>

          <div className="overflow-y-auto max-h-[85vh] p-3 space-y-3" onClick={() => { setFromAccOpen(false); setToAccOpen(false); }}>

            {/* ① رقم القيد + التاريخ */}
            <div className="flex items-center gap-2 bg-emerald-900/40 rounded-xl px-3 py-2.5 border border-emerald-700/40">
              <div className="flex items-center gap-2 shrink-0">
                <span className="text-emerald-400 text-xs">رقم القيد</span>
                <span className="text-amber-400 font-black text-base bg-amber-500/15 px-2.5 py-0.5 rounded-lg border border-amber-500/30">#{nextEntryId}</span>
              </div>
              <div className="w-px h-7 bg-white/10 mx-1" />
              <div className="flex items-center gap-2 flex-1 min-w-0">
                <span className="text-emerald-400 text-xs shrink-0">التاريخ</span>
                <Input type="date" value={date} onChange={e => setDate(e.target.value)}
                  className="bg-transparent border-none text-white text-sm p-0 h-auto focus-visible:ring-0 flex-1 min-w-0" />
              </div>
            </div>

            {/* ② العملة + سعر الصرف */}
            {(currencies as any[]).length > 0 && (
              <div className="flex items-center gap-2 bg-emerald-900/40 rounded-xl px-3 py-2 border border-emerald-700/40">
                <span className="text-emerald-400 text-xs shrink-0">💱 العملة</span>
                <Select value={currencyId} onValueChange={v => {
                  setCurrencyId(v);
                  const c = (currencies as any[]).find((x: any) => String(x.id) === v);
                  setExchangeRate(c?.exchangeRate || 1);
                  setEditingExchangeRate(false);
                }}>
                  <SelectTrigger className="bg-emerald-800/50 border-emerald-600/50 text-white h-8 w-28 text-xs">
                    <SelectValue placeholder="اختر العملة" />
                  </SelectTrigger>
                  <SelectContent className="bg-emerald-900 border-emerald-700">
                    {(currencies as any[]).map((c: any) => (
                      <SelectItem key={c.id} value={String(c.id)} className="text-white text-xs">
                        {c.symbol} — {c.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {/* سعر الصرف: يظهر فقط إذا العملة غير رسمية (سعر ≠ 1) */}
                {currencyId && exchangeRate !== 1 && (
                  <div className="flex items-center gap-1.5 flex-1 justify-end">
                    <span className="text-white/50 text-xs">سعر الصرف:</span>
                    {editingExchangeRate ? (
                      <Input
                        type="number" step="0.0001" min="0"
                        value={exchangeRate}
                        onChange={e => setExchangeRate(parseFloat(e.target.value) || 1)}
                        onBlur={() => setEditingExchangeRate(false)}
                        autoFocus
                        className="bg-amber-900/40 border-amber-600/60 text-amber-300 h-7 w-24 text-xs text-center"
                      />
                    ) : (
                      <button
                        onClick={() => setEditingExchangeRate(true)}
                        className="flex items-center gap-1 bg-amber-600/20 hover:bg-amber-600/40 border border-amber-600/40 rounded-lg px-2 py-0.5 text-amber-300 text-xs font-bold transition-all"
                      >
                        {exchangeRate.toFixed(4)}
                        <Edit2 className="w-3 h-3" />
                      </button>
                    )}
                  </div>
                )}
                {/* عملة رسمية */}
                {currencyId && exchangeRate === 1 && (
                  <span className="text-emerald-400/60 text-xs mr-auto">✓ العملة الرسمية</span>
                )}
              </div>
            )}

            {/* ③ من حساب — autocomplete بالكتابة */}
            <div className="relative" onClick={e => e.stopPropagation()}>
              <Label className="text-emerald-300 text-xs font-bold mb-1.5 block">
                ③ من حساب <span className="text-orange-400 text-xs font-black">({debitLabel})</span>
              </Label>
              <div className="relative">
                <Input
                  value={fromAccId ? (fromAcc?.nameAr || fromAccSearch) : fromAccSearch}
                  onChange={e => {
                    setFromAccSearch(e.target.value);
                    if (fromAccId) setFromAccId("");
                    setFromAccOpen(true);
                  }}
                  onFocus={() => setFromAccOpen(true)}
                  placeholder="اكتب اسم الحساب المدين..."
                  className={`h-12 text-sm pr-3 pl-10 ${fromAccId ? "bg-orange-900/30 border-orange-600/60 text-orange-300 font-bold" : "bg-emerald-900/50 border-emerald-700/50 text-white"}`}
                />
                {fromAccId ? (
                  <button onClick={() => { setFromAccId(""); setFromAccSearch(""); }} className="absolute left-2 top-1/2 -translate-y-1/2 text-white/40 hover:text-red-400">✕</button>
                ) : (
                  <ChevronDown className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-emerald-500" />
                )}
              </div>
              {fromAccOpen && !fromAccId && filteredFromAccs.length > 0 && (
                <div className="absolute z-50 w-full mt-1 rounded-xl border border-emerald-700/60 overflow-hidden shadow-2xl max-h-48 overflow-y-auto"
                  style={{background:"#022c22"}}>
                  {filteredFromAccs.slice(0, 8).map((a: any) => (
                    <button key={a.id} className="w-full text-right px-3 py-2.5 hover:bg-emerald-800/60 text-white text-sm flex items-center gap-2 border-b border-white/5"
                      onMouseDown={e => { e.preventDefault(); setFromAccId(String(a.id)); setFromAccSearch(a.nameAr); setFromAccOpen(false); }}>
                      <span className="text-emerald-500 text-xs font-mono">{a.accountNumber}</span>
                      <span>{a.nameAr}</span>
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* ④ المبلغ + آلة حاسبة */}
            <div>
              <Label className="text-emerald-300 text-xs font-bold mb-1.5 block">④ المبلغ</Label>
              <div className="flex gap-2">
                <div className="relative flex-1">
                  <Input
                    ref={amountRef}
                    type="number" step="0.01" min="0"
                    value={amount || ""}
                    onChange={e => setAmount(parseFloat(e.target.value) || 0)}
                    className="bg-emerald-900/50 border-amber-600/60 text-amber-300 h-14 text-2xl font-black text-center pr-3"
                    placeholder="0.00"
                  />
                  {currencyId && (
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-amber-400/50 text-xs font-bold">
                      {(currencies as any[]).find((c: any) => String(c.id) === currencyId)?.symbol || ""}
                    </span>
                  )}
                </div>
                {/* زر الآلة الحاسبة */}
                <button
                  onClick={() => setShowCalc(v => !v)}
                  className={`h-14 w-14 rounded-xl border-2 flex flex-col items-center justify-center gap-0.5 transition-all shrink-0 ${showCalc ? "border-amber-500 bg-amber-600/30 text-amber-300" : "border-emerald-700/50 bg-emerald-900/50 text-emerald-400 hover:border-amber-500/50 hover:text-amber-400"}`}
                  title="آلة حاسبة">
                  <Calculator className="w-5 h-5" />
                  <span className="text-[9px] font-bold">حاسبة</span>
                </button>
              </div>

              {/* الآلة الحاسبة المضمنة */}
              {showCalc && (
                <div className="mt-2 rounded-xl border border-amber-700/40 overflow-hidden" style={{background:"rgba(2,44,34,0.95)"}}>
                  {/* شاشة العرض */}
                  <div className="px-3 py-2 border-b border-amber-700/20 flex items-center justify-between">
                    <span className="text-amber-300/60 text-sm font-mono">{calcExpr || "0"}</span>
                    <span className="text-amber-400 font-black text-lg font-mono">
                      {(() => { try { return calcExpr ? String(eval(calcExpr.replace(/×/g,"*").replace(/÷/g,"/"))) : "0"; } catch { return "خطأ"; } })()}
                    </span>
                  </div>
                  {/* أزرار الحاسبة */}
                  <div className="grid grid-cols-4 gap-px p-1.5" style={{background:"rgba(4,78,59,0.2)"}}>
                    {["C", "±", "%", "÷", "7","8","9","×", "4","5","6","−", "1","2","3","+", "00","0",".","="].map(btn => (
                      <button key={btn}
                        className={`rounded-lg py-2.5 text-sm font-black transition-all active:scale-95
                          ${btn === "=" ? "bg-amber-500 text-white hover:bg-amber-400" :
                            ["÷","×","−","+"].includes(btn) ? "bg-emerald-700/60 text-amber-300 hover:bg-emerald-600/60" :
                            ["C","±","%"].includes(btn) ? "bg-emerald-800/80 text-emerald-300 hover:bg-emerald-700/80" :
                            "bg-emerald-900/60 text-white hover:bg-emerald-800/60"}`}
                        onMouseDown={e => {
                          e.preventDefault();
                          if (btn === "C") { setCalcExpr(""); return; }
                          if (btn === "=") {
                            try {
                              const result = eval(calcExpr.replace(/×/g,"*").replace(/÷/g,"/").replace(/−/g,"-"));
                              setAmount(parseFloat(String(result)) || 0);
                              setCalcExpr(String(result));
                            } catch { setCalcExpr(""); }
                            return;
                          }
                          if (btn === "±") { setCalcExpr(p => p.startsWith("-") ? p.slice(1) : "-"+p); return; }
                          if (btn === "%") { try { setCalcExpr(p => String(eval(p)/100)); } catch {} return; }
                          setCalcExpr(p => p + btn);
                        }}>
                        {btn}
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* ⑤ إلى حساب — autocomplete بالكتابة */}
            <div className="relative" onClick={e => e.stopPropagation()}>
              <Label className="text-emerald-300 text-xs font-bold mb-1.5 block">
                ⑤ إلى حساب <span className="text-green-400 text-xs font-black">({creditLabel})</span>
              </Label>
              <div className="relative">
                <Input
                  value={toAccId ? (toAcc?.nameAr || toAccSearch) : toAccSearch}
                  onChange={e => {
                    setToAccSearch(e.target.value);
                    if (toAccId) setToAccId("");
                    setToAccOpen(true);
                  }}
                  onFocus={() => setToAccOpen(true)}
                  placeholder="اكتب اسم الحساب الدائن..."
                  className={`h-12 text-sm pr-3 pl-10 ${toAccId ? "bg-green-900/30 border-green-600/60 text-green-300 font-bold" : "bg-emerald-900/50 border-emerald-700/50 text-white"}`}
                />
                {toAccId ? (
                  <button onClick={() => { setToAccId(""); setToAccSearch(""); }} className="absolute left-2 top-1/2 -translate-y-1/2 text-white/40 hover:text-red-400">✕</button>
                ) : (
                  <ChevronDown className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-emerald-500" />
                )}
              </div>
              {toAccOpen && !toAccId && filteredToAccs.length > 0 && (
                <div className="absolute z-50 w-full mt-1 rounded-xl border border-emerald-700/60 overflow-hidden shadow-2xl max-h-48 overflow-y-auto"
                  style={{background:"#022c22"}}>
                  {filteredToAccs.slice(0, 8).map((a: any) => (
                    <button key={a.id} className="w-full text-right px-3 py-2.5 hover:bg-emerald-800/60 text-white text-sm flex items-center gap-2 border-b border-white/5"
                      onMouseDown={e => { e.preventDefault(); setToAccId(String(a.id)); setToAccSearch(a.nameAr); setToAccOpen(false); }}>
                      <span className="text-emerald-500 text-xs font-mono">{a.accountNumber}</span>
                      <span>{a.nameAr}</span>
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* ⑥ البيان + زر الكاميرا */}
            <div>
              <Label className="text-emerald-300 text-xs font-bold mb-1.5 block">⑥ البيان</Label>
              <div className="flex gap-2 items-center">
                <Input value={description} onChange={e => setDescription(e.target.value)}
                  className="bg-emerald-900/50 border-emerald-700/50 text-white flex-1 h-11" placeholder="اكتب البيان هنا..." />
                <label className="cursor-pointer shrink-0">
                  <div className={`h-11 w-11 rounded-xl border-2 border-dashed flex items-center justify-center transition-all hover:scale-105 ${imagePreview ? "border-emerald-500 bg-emerald-800/50" : "border-emerald-700 hover:border-amber-400"}`}>
                    {imagePreview ? <img src={imagePreview} alt="" className="h-10 w-10 object-cover rounded-lg" /> : <Camera className="w-5 h-5 text-amber-400" />}
                  </div>
                  <input type="file" accept="image/*" capture="environment" className="hidden" onChange={e => { const f = e.target.files?.[0]; if (f) setImagePreview(URL.createObjectURL(f)); }} />
                </label>
              </div>
            </div>

            {/* ⑦ الإجمالي — ملخص القيد */}
            {simpleReady && (
              <div className="rounded-xl border border-emerald-700/30 overflow-hidden">
                <div className="px-3 py-1.5 border-b border-emerald-700/20 text-center" style={{background:"rgba(4,120,87,0.2)"}}>
                  <span className="text-emerald-300 text-xs font-bold">📊 إجمالي القيد</span>
                </div>
                <div className="p-2.5 space-y-1.5" style={{background:"rgba(4,78,59,0.15)"}}>
                  <div className="flex justify-between items-center text-sm">
                    <div className="flex items-center gap-2">
                      <span className="text-xs px-2 py-0.5 rounded-md bg-orange-900/40 text-orange-300 font-bold">{debitLabel}</span>
                      <span className="text-white/80">{fromAcc?.nameAr}</span>
                    </div>
                    <span className="text-orange-300 font-black">{amount.toFixed(2)} {selectedCurrency?.symbol || "ر.ي"}</span>
                  </div>
                  <div className="flex justify-between items-center text-sm">
                    <div className="flex items-center gap-2">
                      <span className="text-xs px-2 py-0.5 rounded-md bg-green-900/40 text-green-300 font-bold">{creditLabel}</span>
                      <span className="text-white/80">{toAcc?.nameAr}</span>
                    </div>
                    <span className="text-green-300 font-black">{amount.toFixed(2)} {selectedCurrency?.symbol || "ر.ي"}</span>
                  </div>
                  <div className="border-t border-white/10 pt-1.5 flex justify-between items-center">
                    <span className="text-white/50 text-xs">✅ القيد متوازن</span>
                    <span className="text-amber-400 font-black">{amount.toFixed(2)} {selectedCurrency?.symbol || "ر.ي"}</span>
                  </div>
                </div>
              </div>
            )}

          </div>
        </DialogContent>
      </Dialog>

      {/* Add Account Dialog */}
      <Dialog open={addAccOpen} onOpenChange={setAddAccOpen}>
        <DialogContent className="max-w-sm text-white border-emerald-700" dir="rtl" style={{background: "linear-gradient(135deg, #022c22, #064E3B)"}}>
          <DialogHeader><DialogTitle className="text-amber-400">إنشاء حساب جديد</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <div><Label className="text-emerald-200">اسم الحساب *</Label><Input value={newAcc.nameAr} onChange={e => setNewAcc(a => ({ ...a, nameAr: e.target.value }))} className="bg-emerald-900 border-emerald-700 text-white mt-1" /></div>
            <div>
              <Label className="text-emerald-200">نوع الحساب</Label>
              <Select value={newAcc.type} onValueChange={v => setNewAcc(a => ({ ...a, type: v }))}>
                <SelectTrigger className="bg-emerald-900 border-emerald-700 text-white mt-1"><SelectValue /></SelectTrigger>
                <SelectContent className="bg-emerald-900 border-emerald-700">
                  <SelectItem value="assets" className="text-white">1. الأصول</SelectItem>
                  <SelectItem value="liabilities" className="text-white">2. الخصوم</SelectItem>
                  <SelectItem value="expenses" className="text-white">3. المصروفات</SelectItem>
                  <SelectItem value="revenue" className="text-white">4. الإيرادات</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div><Label className="text-emerald-200">رقم الجوال</Label><Input value={newAcc.phone} onChange={e => setNewAcc(a => ({ ...a, phone: e.target.value }))} className="bg-emerald-900 border-emerald-700 text-white mt-1" /></div>
            <div className="flex gap-2">
              <Button onClick={handleAddAccount} className="bg-amber-500 hover:bg-amber-400 text-white flex-1">✅ حفظ</Button>
              <Button variant="outline" onClick={() => setAddAccOpen(false)} className="border-emerald-600 text-emerald-200">إلغاء</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
