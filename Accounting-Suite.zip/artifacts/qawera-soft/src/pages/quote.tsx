import React, { useState, useMemo } from "react";
import { useListItems, useListCustomers, useListCurrencies } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Plus, Trash2, Printer, Share2, Save, Tag, X, MessageCircle, MoreVertical, Camera, ArrowLeft } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useSettings } from "@/contexts/SettingsContext";
import { sendWhatsApp, printDocument } from "@/lib/printUtils";
import { Link } from "wouter";

type LineItem = { id: number; itemId: string; itemName: string; qty: number; price: number; total: number };

export default function QuotePage() {
  const { data: items = [] } = useListItems();
  const { data: customers = [] } = useListCustomers();
  const { data: currencies = [] } = useListCurrencies();
  const { toast } = useToast();
  const { settings } = useSettings();

  const [quoteNo, setQuoteNo] = useState(1);
  const [date, setDate] = useState(new Date().toISOString().split("T")[0]);
  const [validDays, setValidDays] = useState(7);
  const [customerId, setCustomerId] = useState("");
  const [customerSearch, setCustomerSearch] = useState("");
  const [currencyId, setCurrencyId] = useState("");
  const [notes, setNotes] = useState("");
  const [discount, setDiscount] = useState(0);
  const [lines, setLines] = useState<LineItem[]>([]);
  const [nextLine, setNextLine] = useState(1);

  const selectedCustomer = (customers as any[]).find(c => String(c.id) === customerId);
  const selectedCurrency = (currencies as any[]).find(c => String(c.id) === currencyId);

  const subtotal = useMemo(() => lines.reduce((s, l) => s + l.total, 0), [lines]);
  const total = subtotal - discount;

  const addLine = () => {
    setLines(prev => [...prev, { id: nextLine, itemId: "", itemName: "", qty: 1, price: 0, total: 0 }]);
    setNextLine(n => n + 1);
  };

  const updateLine = (id: number, field: string, value: any) => {
    setLines(prev => prev.map(l => {
      if (l.id !== id) return l;
      const updated = { ...l, [field]: value };
      if (field === "itemId") {
        const item = (items as any[]).find(i => String(i.id) === value);
        if (item) { updated.itemName = item.nameAr; updated.price = Number(item.salePrice || 0); }
      }
      if (field === "qty" || field === "price" || field === "itemId") {
        updated.total = parseFloat(((field === "qty" ? value : updated.qty) * (field === "price" ? value : updated.price)).toFixed(2));
      }
      return updated;
    }));
  };

  const removeLine = (id: number) => setLines(prev => prev.filter(l => l.id !== id));

  const handlePrint = () => {
    printDocument(
      `عرض سعر رقم: ${quoteNo}`,
      [
        { label: "التاريخ", value: date },
        { label: "صالح لـ", value: `${validDays} يوم` },
        { label: "العميل", value: selectedCustomer?.nameAr || "-" },
        { label: "العملة", value: selectedCurrency?.nameAr || "ريال سعودي" },
      ],
      ["#", "اسم الصنف", "الكمية", "السعر", "الإجمالي"],
      lines.map((l, i) => [String(i + 1), l.itemName, String(l.qty), l.price.toFixed(2), l.total.toFixed(2)]),
      [
        { label: "المجموع", value: subtotal.toFixed(2) },
        { label: "الخصم", value: discount.toFixed(2) },
        { label: "الإجمالي النهائي", value: total.toFixed(2) },
      ],
      settings,
      notes ? `ملاحظات: ${notes}` : ""
    );
  };

  const handleWhatsApp = () => {
    if (!selectedCustomer?.phone) { toast({ title: "لا يوجد رقم جوال للعميل", variant: "destructive" }); return; }
    const msg = `${settings.msgPrefix}\n*عرض سعر رقم: ${quoteNo}*\n📋 العميل: ${selectedCustomer.nameAr}\n💰 الإجمالي: ${total.toFixed(2)} ${selectedCurrency?.code || "ر.س"}\n📅 صالح لـ ${validDays} يوم\n${notes ? "ملاحظة: " + notes : ""}\n${settings.msgSuffix}`;
    sendWhatsApp(selectedCustomer.phone, msg);
  };

  return (
    <div className="space-y-4 animate-in fade-in duration-300" dir="rtl">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Link href="/items"><button className="p-2 rounded-xl bg-white/10 hover:bg-white/20"><ArrowLeft className="w-5 h-5 text-white" /></button></Link>
          <div>
            <h1 className="text-2xl font-bold text-amber-400 flex items-center gap-2"><Tag className="w-6 h-6" />فاتورة عرض سعر</h1>
            <p className="text-emerald-200 text-sm">إنشاء عرض سعر وإرساله للعميل</p>
          </div>
        </div>
        <div className="flex gap-2">
          <button onClick={() => {}} className="p-2 rounded-xl bg-white/10 hover:bg-white/20"><MoreVertical className="w-5 h-5 text-white/60" /></button>
          <button onClick={handleWhatsApp} className="p-2 rounded-xl bg-green-700/60 hover:bg-green-600/80 border border-green-600/30"><MessageCircle className="w-5 h-5 text-green-400" /></button>
          <button onClick={handlePrint} className="p-2 rounded-xl bg-blue-700/60 hover:bg-blue-600/80 border border-blue-600/30"><Printer className="w-5 h-5 text-blue-400" /></button>
          <Button onClick={() => { toast({ title: "✅ تم حفظ عرض السعر" }); }} className="bg-amber-500 hover:bg-amber-400 text-white gap-2 h-9"><Save className="w-4 h-4" />حفظ</Button>
        </div>
      </div>

      {/* Form */}
      <div className="rounded-2xl border border-amber-500/20 p-5 space-y-4" style={{ background: "rgba(6,78,59,0.25)" }}>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
          <div><Label className="text-emerald-200 text-xs">رقم عرض السعر</Label><Input type="number" value={quoteNo} onChange={e => setQuoteNo(parseInt(e.target.value))} className="bg-emerald-900/50 border-emerald-700 text-white mt-1 font-bold" /></div>
          <div><Label className="text-emerald-200 text-xs">التاريخ</Label><Input type="date" value={date} onChange={e => setDate(e.target.value)} className="bg-emerald-900/50 border-emerald-700 text-white mt-1" /></div>
          <div><Label className="text-emerald-200 text-xs">صالح لـ (أيام)</Label><Input type="number" value={validDays} onChange={e => setValidDays(parseInt(e.target.value))} className="bg-emerald-900/50 border-emerald-700 text-white mt-1" /></div>
          <div>
            <Label className="text-emerald-200 text-xs">العملة</Label>
            <Select value={currencyId} onValueChange={setCurrencyId}>
              <SelectTrigger className="bg-emerald-900/50 border-emerald-700 text-white mt-1"><SelectValue placeholder="ريال سعودي" /></SelectTrigger>
              <SelectContent className="bg-emerald-900 border-emerald-700">
                {(currencies as any[]).map(c => <SelectItem key={c.id} value={String(c.id)} className="text-white">{c.code} — {c.nameAr}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div className="col-span-2">
            <Label className="text-emerald-200 text-xs">العميل</Label>
            <Select value={customerId} onValueChange={setCustomerId}>
              <SelectTrigger className="bg-emerald-900/50 border-emerald-700 text-white mt-1"><SelectValue placeholder="اختر العميل..." /></SelectTrigger>
              <SelectContent className="bg-emerald-900 border-emerald-700">
                <div className="p-2"><Input value={customerSearch} onChange={e => setCustomerSearch(e.target.value)} placeholder="بحث..." className="bg-emerald-800 border-emerald-600 text-white h-8 text-sm" /></div>
                {(customers as any[]).filter(c => !customerSearch || c.nameAr?.includes(customerSearch)).map(c => <SelectItem key={c.id} value={String(c.id)} className="text-white">{c.nameAr}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div className="col-span-2">
            <Label className="text-emerald-200 text-xs">ملاحظات / بيان عرض السعر</Label>
            <div className="flex gap-2 mt-1">
              <Textarea value={notes} onChange={e => setNotes(e.target.value)} className="bg-emerald-900/50 border-emerald-700 text-white resize-none h-9 py-1.5" placeholder="بيانات وشروط عرض السعر..." />
              <button className="p-2 rounded-xl bg-white/10 hover:bg-white/20 shrink-0"><Camera className="w-5 h-5 text-amber-400" /></button>
            </div>
          </div>
        </div>

        {/* Items Table */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <Label className="text-amber-300 font-bold">الأصناف</Label>
            <Button type="button" size="sm" onClick={addLine} className="bg-emerald-700 hover:bg-emerald-600 text-white gap-1 h-8"><Plus className="w-3 h-3" />إضافة صنف</Button>
          </div>
          <div className="rounded-xl border border-white/10 overflow-hidden">
            <table className="w-full text-sm">
              <thead><tr style={{ background: "#064E3B" }}>
                <th className="p-2 text-right text-amber-300 text-xs">#</th>
                <th className="p-2 text-right text-amber-300 text-xs">اسم الصنف</th>
                <th className="p-2 text-right text-amber-300 text-xs">الكمية</th>
                <th className="p-2 text-right text-amber-300 text-xs">السعر</th>
                <th className="p-2 text-right text-amber-300 text-xs">الإجمالي</th>
                <th className="p-2 text-amber-300 text-xs"></th>
              </tr></thead>
              <tbody>
                {lines.length === 0 && <tr><td colSpan={6} className="p-6 text-center text-emerald-400 text-sm">اضغط "إضافة صنف" للبدء</td></tr>}
                {lines.map((line, i) => (
                  <tr key={line.id} className="border-b border-white/5">
                    <td className="p-2 text-white/40 text-xs text-center">{i + 1}</td>
                    <td className="p-2">
                      <Select value={line.itemId} onValueChange={v => updateLine(line.id, "itemId", v)}>
                        <SelectTrigger className="bg-transparent border-emerald-700/50 text-white h-8 text-xs"><SelectValue placeholder="اختر الصنف..." /></SelectTrigger>
                        <SelectContent className="bg-emerald-900 border-emerald-700">
                          {(items as any[]).map(it => <SelectItem key={it.id} value={String(it.id)} className="text-white text-xs">{it.nameAr}</SelectItem>)}
                        </SelectContent>
                      </Select>
                    </td>
                    <td className="p-2"><Input type="number" step="0.01" value={line.qty} onChange={e => updateLine(line.id, "qty", parseFloat(e.target.value) || 0)} className="bg-transparent border-emerald-700/50 text-white h-8 text-xs text-center w-16" /></td>
                    <td className="p-2"><Input type="number" step="0.01" value={line.price} onChange={e => updateLine(line.id, "price", parseFloat(e.target.value) || 0)} className="bg-transparent border-emerald-700/50 text-white h-8 text-xs text-center w-24" /></td>
                    <td className="p-2 text-amber-400 font-bold text-xs">{line.total.toFixed(2)}</td>
                    <td className="p-2"><button onClick={() => removeLine(line.id)} className="text-red-400 hover:text-red-300"><X className="w-4 h-4" /></button></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Totals */}
        <div className="flex justify-end">
          <div className="space-y-2 min-w-64">
            <div className="flex justify-between text-sm"><span className="text-white/60">المجموع الفرعي:</span><span className="text-white font-bold">{subtotal.toFixed(2)}</span></div>
            <div className="flex justify-between items-center text-sm">
              <span className="text-white/60">الخصم:</span>
              <Input type="number" step="0.01" value={discount} onChange={e => setDiscount(parseFloat(e.target.value) || 0)} className="bg-emerald-900/50 border-emerald-700 text-white h-7 text-xs w-28 text-center" />
            </div>
            <div className="flex justify-between text-base font-black border-t border-amber-500/30 pt-2">
              <span className="text-amber-300">الإجمالي النهائي:</span>
              <span className="text-amber-400 text-lg">{total.toFixed(2)} {selectedCurrency?.code || "ر.س"}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
