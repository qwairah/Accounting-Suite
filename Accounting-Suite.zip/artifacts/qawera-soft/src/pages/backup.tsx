import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import {
  DatabaseBackup, Cloud, RotateCcw, Download, Upload, CheckCircle,
  FolderOpen, Mail, Clock, HardDrive, Wifi, WifiOff, FileJson, ArrowLeftRight,
  Table2, AlertTriangle, Info, Loader2
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useSettings } from "@/contexts/SettingsContext";
import {
  useListSales, useListPurchases, useListAccounts, useListCustomers,
  useListSuppliers, useListItems, useListCurrencies, useListJournalEntries
} from "@workspace/api-client-react";

type BackupTab = "restore-local" | "restore-drive" | "save-local" | "save-drive" | "import-external";

const tabConfig: { id: BackupTab; label: string; icon: any; color: string; bg: string; desc: string }[] = [
  { id: "restore-local", label: "استرجاع من الهاتف", icon: HardDrive, color: "text-blue-400", bg: "bg-blue-700 hover:bg-blue-600", desc: "استرجاع نسخة احتياطية محفوظة في مجلدات الهاتف" },
  { id: "restore-drive", label: "استرجاع من درايف", icon: Cloud, color: "text-purple-400", bg: "bg-purple-700 hover:bg-purple-600", desc: "استرجاع نسخة احتياطية من جوجل درايف" },
  { id: "save-local", label: "حفظ في الهاتف", icon: Download, color: "text-green-400", bg: "bg-green-700 hover:bg-green-600", desc: "إنشاء نسخة احتياطية وحفظها في مجلدات الهاتف" },
  { id: "save-drive", label: "رفع إلى درايف", icon: Upload, color: "text-amber-400", bg: "bg-amber-700 hover:bg-amber-600", desc: "رفع نسخة احتياطية إلى جوجل درايف" },
  { id: "import-external", label: "استيراد من تطبيق آخر", icon: ArrowLeftRight, color: "text-rose-400", bg: "bg-rose-700 hover:bg-rose-600", desc: "استيراد بيانات من أي تطبيق محاسبي آخر بصيغة .db أو .json" },
];

export default function BackupPage() {
  const { toast } = useToast();
  const { settings, updateSettings } = useSettings();
  const [activeTab, setActiveTab] = useState<BackupTab>("save-local");
  const [isWorking, setIsWorking] = useState(false);
  const [success, setSuccess] = useState(false);
  const [driveEmail, setDriveEmail] = useState(settings.backupEmail || "");
  const [driveFolder, setDriveFolder] = useState(settings.googleDriveFolder || "قـويـره سوفت - نسخ احتياطية");
  const [localFolder, setLocalFolder] = useState(settings.backupFolder || "/storage/QWAIRAH_Backups");
  const [backupTime, setBackupTime] = useState(settings.backupTime || "23:00");
  const [autoBackup, setAutoBackup] = useState(settings.backupDaily || false);
  const [addImages, setAddImages] = useState(settings.addImages || false);
  const [backupHistory, setBackupHistory] = useState<{date: string; name: string; size: string; type: string}[]>([]);
  const [restoreProgress, setRestoreProgress] = useState<{done: boolean; results?: Record<string,number>; errors?: string[]; total?: number} | null>(null);

  type SqliteTable = { name: string; rowCount: number; columns: string[]; rows: any[]; mappedAs: string };
  type ExternalImportResult = {
    fileName: string; fileSize: string; detectedFormat: string; isSqlite: boolean;
    tables: SqliteTable[];
    accounts: any[]; customers: any[]; suppliers: any[]; items: any[];
    sales: any[]; purchases: any[]; currencies: any[]; journal: any[];
    unknownKeys: string[]; rawPreview: string;
  };
  const [externalResult, setExternalResult] = useState<ExternalImportResult | null>(null);
  const [externalImporting, setExternalImporting] = useState(false);
  const [importStep, setImportStep] = useState<"idle"|"reading"|"parsing"|"done"|"error">("idle");
  const [importError, setImportError] = useState("");

  const { data: sales = [] } = useListSales();
  const { data: purchases = [] } = useListPurchases();
  const { data: accounts = [] } = useListAccounts();
  const { data: customers = [] } = useListCustomers();
  const { data: suppliers = [] } = useListSuppliers();
  const { data: items = [] } = useListItems();
  const { data: currencies = [] } = useListCurrencies();
  const { data: journal = [] } = useListJournalEntries();

  const buildBackupData = () => ({
    meta: {
      appName: "قـويـره سوفت", appNameEn: "Qwairah Soft",
      version: "2.0", format: "QWAIRAH_DB_v2",
      date: new Date().toISOString(), platform: "web",
    },
    accounts, customers, suppliers, items, currencies, sales, purchases, journal,
  });

  const getBackupFileName = () => {
    const d = new Date();
    const dateStr = `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`;
    return `QWAIRAH_Backup_${dateStr}.db`;
  };

  const handleSaveLocal = async () => {
    setIsWorking(true);
    setSuccess(false);
    try {
      const data = buildBackupData();
      const json = JSON.stringify(data, null, 2);
      const blob = new Blob([json], { type: "application/octet-stream" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = getBackupFileName();
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      const newRecord = {
        date: new Date().toLocaleString("ar"),
        name: getBackupFileName(),
        size: `${(blob.size / 1024).toFixed(1)} KB`,
        type: "محلي"
      };
      setBackupHistory(prev => [newRecord, ...prev.slice(0, 9)]);
      setSuccess(true);
      updateSettings({ backupFolder: localFolder, backupTime, backupDaily: autoBackup, addImages });
      toast({ title: "✅ تم حفظ النسخة الاحتياطية", description: `ملف: ${getBackupFileName()}` });
    } catch {
      toast({ title: "خطأ في الحفظ", variant: "destructive" });
    }
    setIsWorking(false);
    setTimeout(() => setSuccess(false), 3000);
  };

  // ── دالة الاستعادة الفعلية إلى قاعدة البيانات ───────────────────────────
  const doActualRestore = async (
    data: { accounts?: any[]; customers?: any[]; suppliers?: any[]; items?: any[]; currencies?: any[]; sales?: any[]; purchases?: any[]; journal?: any[] },
    label: string
  ) => {
    setRestoreProgress(null);
    setIsWorking(true);
    try {
      const resp = await fetch("/api/backup/restore", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
      const result = await resp.json();
      setRestoreProgress({ done: true, results: result.results, errors: result.errors, total: result.total });
      toast({
        title: `✅ تم الاستعادة — ${result.total} سجل`,
        description: Object.entries(result.results as Record<string,number>)
          .filter(([, v]) => v > 0)
          .map(([k, v]) => `${k}: ${v}`)
          .join(" · "),
      });
      const newRecord = { date: new Date().toLocaleString("ar"), name: label, size: "", type: "مستعادة" };
      setBackupHistory(prev => [newRecord, ...prev.slice(0, 9)]);
      setSuccess(true);
      setTimeout(() => setSuccess(false), 4000);
    } catch (err: any) {
      toast({ title: "❌ فشل الاستعادة", description: err?.message || "خطأ غير معروف", variant: "destructive" });
    }
    setIsWorking(false);
  };

  const handleRestoreLocal = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setIsWorking(true);
    setRestoreProgress(null);
    const reader = new FileReader();
    reader.onload = async (ev) => {
      try {
        const raw = ev.target?.result as string;
        const data = JSON.parse(raw);
        if (data.meta?.appName) {
          await doActualRestore(data, file.name);
        } else {
          toast({ title: "⚠️ تحذير", description: "ملف النسخة الاحتياطية غير متوافق مع النظام", variant: "destructive" });
          setIsWorking(false);
        }
      } catch {
        toast({ title: "❌ خطأ", description: "فشل قراءة الملف. تأكد أن الملف صحيح (.db)", variant: "destructive" });
        setIsWorking(false);
      }
    };
    reader.readAsText(file);
    e.target.value = "";
  };

  const handleSaveDrive = async () => {
    setIsWorking(true);
    try {
      const data = buildBackupData();
      const json = JSON.stringify(data, null, 2);
      const blob = new Blob([json], { type: "application/octet-stream" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = getBackupFileName();
      a.click();
      URL.revokeObjectURL(url);
      updateSettings({ backupEmail: driveEmail, googleDriveFolder: driveFolder, backupDaily: autoBackup, backupTime });
      toast({
        title: "✅ تم تحميل النسخة",
        description: `ارفع الملف ${getBackupFileName()} يدوياً إلى مجلد "${driveFolder}" في جوجل درايف`,
      });
      const newRecord = { date: new Date().toLocaleString("ar"), name: getBackupFileName(), size: `${(blob.size / 1024).toFixed(1)} KB`, type: "درايف" };
      setBackupHistory(prev => [newRecord, ...prev.slice(0, 9)]);
      setSuccess(true);
    } catch {
      toast({ title: "❌ خطأ في الرفع", variant: "destructive" });
    }
    setIsWorking(false);
    setTimeout(() => setSuccess(false), 3000);
  };

  const totalRecords = (accounts as any[]).length + (customers as any[]).length + (suppliers as any[]).length +
    (items as any[]).length + (sales as any[]).length + (purchases as any[]).length + (journal as any[]).length;

  const renderRestoreLocal = () => (
    <div className="space-y-5">
      <div className="text-center">
        <HardDrive className="w-16 h-16 mx-auto text-blue-400 mb-3 opacity-80" style={{filter: "drop-shadow(0 0 10px rgba(96,165,250,0.5))"}} />
        <h3 className="text-xl font-bold text-blue-300">استرجاع نسخة من الهاتف</h3>
        <p className="text-white/60 text-sm mt-1">اختر ملف .db محفوظ على جهازك</p>
      </div>
      <div className="bg-blue-900/20 rounded-xl border border-blue-700/30 p-4 space-y-3">
        <p className="text-blue-300 text-sm font-semibold">التعليمات:</p>
        <ol className="text-white/70 text-xs space-y-1.5 list-decimal list-inside">
          <li>اضغط على زر "اختر ملف النسخة الاحتياطية" أدناه</li>
          <li>انتقل إلى المجلد الذي يحتوي على ملفات النسخة الاحتياطية</li>
          <li>اختر الملف بصيغة .db أو QWAIRAH_Backup_</li>
          <li>سيتم استرجاع البيانات تلقائياً</li>
        </ol>
      </div>
      <div>
        <Label className="text-blue-200 text-sm font-semibold">مجلد البحث عن النسخ</Label>
        <div className="flex gap-2 mt-1">
          <Input value={localFolder} onChange={e => setLocalFolder(e.target.value)} className="bg-blue-900/30 border-blue-700 text-white" dir="ltr" placeholder="/storage/QWAIRAH_Backups" />
          <Button type="button" size="sm" className="bg-blue-700 hover:bg-blue-600 text-white gap-1 shrink-0"><FolderOpen className="w-4 h-4" /></Button>
        </div>
      </div>
      <label className="cursor-pointer block">
        <Button type="button" className="w-full h-14 text-lg font-bold bg-blue-700 hover:bg-blue-600 text-white gap-3 shadow-lg" disabled={isWorking} asChild>
          <span><HardDrive className="w-6 h-6" />{isWorking ? "جاري الاسترجاع..." : "اختر ملف النسخة الاحتياطية (.db)"}</span>
        </Button>
        <input type="file" accept=".db,.json,.sql" className="hidden" onChange={handleRestoreLocal} />
      </label>
      {isWorking && <div className="flex items-center gap-3 bg-blue-900/30 rounded-xl p-3 border border-blue-600/40"><Loader2 className="w-5 h-5 text-blue-400 animate-spin" /><span className="text-blue-300 font-semibold">جاري استعادة البيانات إلى قاعدة البيانات...</span></div>}
      {restoreProgress?.done && (
        <div className="space-y-2">
          <div className="flex items-center gap-2 bg-green-900/30 rounded-xl p-3 border border-green-600/40">
            <CheckCircle className="w-5 h-5 text-green-400" />
            <span className="text-green-300 font-semibold">✅ تم الاستعادة — {restoreProgress.total} سجل</span>
          </div>
          <div className="grid grid-cols-3 gap-1.5 text-center">
            {Object.entries(restoreProgress.results || {}).map(([k, v]) => (
              <div key={k} className="rounded-lg bg-white/5 p-2">
                <p className="text-amber-400 font-bold text-lg">{v}</p>
                <p className="text-white/40 text-xs">{k === "accounts" ? "حسابات" : k === "customers" ? "عملاء" : k === "suppliers" ? "موردون" : k === "items" ? "أصناف" : k === "currencies" ? "عملات" : k === "sales" ? "مبيعات" : k === "purchases" ? "مشتريات" : k === "journal" ? "قيود" : k}</p>
              </div>
            ))}
          </div>
          {(restoreProgress.errors?.length ?? 0) > 0 && (
            <div className="bg-amber-900/20 rounded-xl p-3 border border-amber-700/30">
              <p className="text-amber-300 text-xs font-bold mb-1">⚠️ تحذيرات ({restoreProgress.errors?.length}):</p>
              <div className="space-y-0.5 max-h-24 overflow-y-auto">
                {restoreProgress.errors?.map((e, i) => <p key={i} className="text-white/40 text-xs">{e}</p>)}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );

  const renderRestoreDrive = () => (
    <div className="space-y-5">
      <div className="text-center">
        <Cloud className="w-16 h-16 mx-auto text-purple-400 mb-3 opacity-80" style={{filter: "drop-shadow(0 0 10px rgba(167,139,250,0.5))"}} />
        <h3 className="text-xl font-bold text-purple-300">استرجاع من جوجل درايف</h3>
        <p className="text-white/60 text-sm mt-1">استرجع نسختك الاحتياطية من السحابة</p>
      </div>
      <div className="space-y-3">
        <div>
          <Label className="text-purple-200 text-xs">حساب الجيميل / البريد الإلكتروني</Label>
          <div className="flex gap-2 mt-1">
            <Input value={driveEmail} onChange={e => setDriveEmail(e.target.value)} className="bg-purple-900/30 border-purple-700 text-white" dir="ltr" placeholder="example@gmail.com" />
            <div className="p-2 rounded-xl bg-purple-800/50 border border-purple-700"><Mail className="w-5 h-5 text-purple-300" /></div>
          </div>
        </div>
        <div>
          <Label className="text-purple-200 text-xs">اسم المجلد في جوجل درايف</Label>
          <Input value={driveFolder} onChange={e => setDriveFolder(e.target.value)} className="bg-purple-900/30 border-purple-700 text-white mt-1" placeholder="قـويـره سوفت - نسخ احتياطية" />
        </div>
      </div>
      <div className="bg-purple-900/20 rounded-xl border border-purple-700/30 p-4">
        <p className="text-purple-200 text-sm font-semibold mb-2">طريقة الاسترجاع من درايف:</p>
        <ol className="text-white/60 text-xs space-y-1 list-decimal list-inside">
          <li>افتح جوجل درايف على هاتفك أو المتصفح</li>
          <li>انتقل إلى المجلد "{driveFolder}"</li>
          <li>نزّل ملف النسخة (.db) إلى جهازك</li>
          <li>ثم استخدم "استرجاع من الهاتف" لتحميل الملف</li>
        </ol>
      </div>
      <Button onClick={() => window.open(`https://drive.google.com`, "_blank")} className="w-full h-12 bg-purple-700 hover:bg-purple-600 text-white font-bold gap-2">
        <Cloud className="w-5 h-5" />فتح جوجل درايف
      </Button>
      <label className="cursor-pointer block">
        <Button type="button" className="w-full h-12 bg-blue-700 hover:bg-blue-600 text-white gap-2 font-bold" asChild>
          <span><HardDrive className="w-5 h-5" />استرجاع من ملف محمّل</span>
        </Button>
        <input type="file" accept=".db,.json,.sql" className="hidden" onChange={handleRestoreLocal} />
      </label>
    </div>
  );

  const renderSaveLocal = () => (
    <div className="space-y-5">
      <div className="text-center">
        <Download className="w-16 h-16 mx-auto text-green-400 mb-3 opacity-80" style={{filter: "drop-shadow(0 0 10px rgba(74,222,128,0.5))"}} />
        <h3 className="text-xl font-bold text-green-300">حفظ نسخة في الهاتف</h3>
        <p className="text-white/60 text-sm mt-1">الملف: {getBackupFileName()}</p>
      </div>
      {/* Stats */}
      <div className="grid grid-cols-3 gap-2 text-center">
        {[
          { label: "الحسابات", val: (accounts as any[]).length },
          { label: "المبيعات", val: (sales as any[]).length },
          { label: "المشتريات", val: (purchases as any[]).length },
          { label: "العملاء", val: (customers as any[]).length },
          { label: "الموردين", val: (suppliers as any[]).length },
          { label: "الأصناف", val: (items as any[]).length },
        ].map((s, i) => (
          <div key={i} className="bg-green-900/20 rounded-xl p-2 border border-green-700/30">
            <p className="text-green-400 font-black text-lg">{s.val}</p>
            <p className="text-white/50 text-xs">{s.label}</p>
          </div>
        ))}
      </div>
      <div className="space-y-3">
        <div>
          <Label className="text-green-200 text-xs">مجلد الحفظ المحلي</Label>
          <div className="flex gap-2 mt-1">
            <Input value={localFolder} onChange={e => setLocalFolder(e.target.value)} className="bg-green-900/30 border-green-700 text-white" dir="ltr" />
            <Button type="button" size="sm" className="bg-green-700 hover:bg-green-600 text-white gap-1 shrink-0"><FolderOpen className="w-4 h-4" /></Button>
          </div>
        </div>
        <div className="flex items-center justify-between p-3 rounded-xl bg-green-900/20 border border-green-700/30">
          <div><p className="text-white font-semibold text-sm">حفظ تلقائي يومي</p><p className="text-white/40 text-xs">نسخة احتياطية كل يوم</p></div>
          <Switch checked={autoBackup} onCheckedChange={setAutoBackup} />
        </div>
        {autoBackup && (
          <div>
            <Label className="text-green-200 text-xs">وقت الحفظ التلقائي</Label>
            <div className="flex gap-2 mt-1 items-center">
              <Clock className="w-4 h-4 text-green-400" />
              <Input type="time" value={backupTime} onChange={e => setBackupTime(e.target.value)} className="bg-green-900/30 border-green-700 text-white w-36" />
            </div>
          </div>
        )}
        <div className="flex items-center justify-between p-3 rounded-xl bg-green-900/20 border border-green-700/30">
          <div><p className="text-white font-semibold text-sm">تضمين الصور</p><p className="text-white/40 text-xs">إضافة الصور المرفقة في النسخة</p></div>
          <Switch checked={addImages} onCheckedChange={setAddImages} />
        </div>
      </div>
      <Button onClick={handleSaveLocal} disabled={isWorking} className="w-full h-14 text-lg font-bold bg-green-700 hover:bg-green-600 text-white gap-3 shadow-lg">
        {success ? <><CheckCircle className="w-6 h-6" />✅ تم الحفظ!</> : isWorking ? "جاري الحفظ..." : <><Download className="w-6 h-6" />حفظ نسخة احتياطية</>}
      </Button>
    </div>
  );

  const renderSaveDrive = () => (
    <div className="space-y-5">
      <div className="text-center">
        <Upload className="w-16 h-16 mx-auto text-amber-400 mb-3 opacity-80" style={{filter: "drop-shadow(0 0 10px rgba(251,191,36,0.5))"}} />
        <h3 className="text-xl font-bold text-amber-300">رفع نسخة إلى جوجل درايف</h3>
        <p className="text-white/60 text-sm mt-1">احفظ بياناتك في السحابة</p>
      </div>
      <div className="space-y-3">
        <div>
          <Label className="text-amber-200 text-xs">حساب الجيميل للحفظ</Label>
          <div className="flex gap-2 mt-1">
            <Input value={driveEmail} onChange={e => setDriveEmail(e.target.value)} className="bg-amber-900/30 border-amber-700 text-white" dir="ltr" placeholder="example@gmail.com" />
            <div className="p-2 rounded-xl bg-amber-800/50 border border-amber-700"><Mail className="w-5 h-5 text-amber-300" /></div>
          </div>
          <p className="text-white/40 text-xs mt-1">الحساب الذي ستُحفظ فيه النسخ الاحتياطية</p>
        </div>
        <div>
          <Label className="text-amber-200 text-xs">اسم المجلد في جوجل درايف</Label>
          <div className="flex gap-2 mt-1">
            <Input value={driveFolder} onChange={e => setDriveFolder(e.target.value)} className="bg-amber-900/30 border-amber-700 text-white" placeholder="قـويـره سوفت - نسخ احتياطية" />
            <Button type="button" size="sm" className="bg-amber-700 hover:bg-amber-600 text-white gap-1 shrink-0"><FolderOpen className="w-4 h-4" /></Button>
          </div>
        </div>
        <div className="flex items-center justify-between p-3 rounded-xl bg-amber-900/20 border border-amber-700/30">
          <div><p className="text-white font-semibold text-sm">رفع تلقائي يومي</p><p className="text-white/40 text-xs">رفع نسخة كل يوم إلى الدرايف</p></div>
          <Switch checked={autoBackup} onCheckedChange={setAutoBackup} />
        </div>
        {autoBackup && (
          <div>
            <Label className="text-amber-200 text-xs">وقت الرفع التلقائي</Label>
            <div className="flex gap-2 mt-1 items-center">
              <Clock className="w-4 h-4 text-amber-400" />
              <Input type="time" value={backupTime} onChange={e => setBackupTime(e.target.value)} className="bg-amber-900/30 border-amber-700 text-white w-36" />
            </div>
          </div>
        )}
      </div>
      <Button onClick={handleSaveDrive} disabled={isWorking} className="w-full h-14 text-lg font-bold bg-amber-700 hover:bg-amber-600 text-white gap-3 shadow-lg">
        {success ? <><CheckCircle className="w-6 h-6" />✅ تم الرفع!</> : isWorking ? "جاري الرفع..." : <><Upload className="w-6 h-6" />رفع نسخة إلى جوجل درايف</>}
      </Button>
    </div>
  );

  // --- SQLite field mapping helpers ---
  const TABLE_MAP: Record<string, string> = {
    accounts: "accounts", acc_chart: "accounts", chart_of_accounts: "accounts",
    حسابات: "accounts", دليل_الحسابات: "accounts",
    customers: "customers", clients: "customers",
    عملاء: "customers", الزبائن: "customers",
    suppliers: "suppliers", vendors: "suppliers",
    موردين: "suppliers", الموردين: "suppliers",
    items: "items", products: "items", stock: "items", inventory: "items",
    أصناف: "items", مخزون: "items",
    sales: "sales", invoices: "sales", sales_invoices: "sales",
    مبيعات: "sales", فواتير_مبيعات: "sales",
    purchases: "purchases", bills: "purchases", purchase_invoices: "purchases",
    مشتريات: "purchases", فواتير_مشتريات: "purchases",
    currencies: "currencies", عملات: "currencies",
    journal: "journal", journal_entries: "journal", transactions: "journal",
    vouchers: "journal", قيود: "journal", القيود_اليومية: "journal",
    treasury: "journal", treasury_transactions: "journal",
  };

  const rowsToObjects = (result: any): any[] => {
    if (!result || result.values.length === 0) return [];
    return result.values.map((row: any[]) =>
      Object.fromEntries(result.columns.map((col: string, i: number) => [col, row[i]]))
    );
  };

  const mapAccount = (row: any) => ({
    nameAr: row.name || row.acc_name || row.account_name || row.nameAr || row.اسم_الحساب || row.الاسم || "",
    accountNumber: row.code || row.account_code || row.accountNumber || row.رقم_الحساب || "",
    openingBalance: parseFloat(row.balance || row.opening_balance || row.الرصيد || 0) || 0,
    type: row.type || row.account_type || "other",
  });

  const mapCustomer = (row: any) => ({
    nameAr: row.name || row.customer_name || row.client_name || row.nameAr || row.اسم_العميل || row.الاسم || "",
    phone: row.phone || row.mobile || row.tel || row.الهاتف || "",
    balance: parseFloat(row.balance || row.debt || row.الرصيد || 0) || 0,
  });

  const mapSupplier = (row: any) => ({
    nameAr: row.name || row.supplier_name || row.vendor_name || row.nameAr || row.اسم_المورد || row.الاسم || "",
    phone: row.phone || row.mobile || row.الهاتف || "",
    balance: parseFloat(row.balance || row.debt || row.الرصيد || 0) || 0,
  });

  const mapItem = (row: any) => ({
    nameAr: row.name || row.item_name || row.product_name || row.nameAr || row.اسم_الصنف || row.الصنف || "",
    code: row.code || row.sku || row.barcode || row.الكود || "",
    price: parseFloat(row.price || row.sale_price || row.unit_price || row.السعر || 0) || 0,
    cost: parseFloat(row.cost || row.purchase_price || row.التكلفة || 0) || 0,
    stock: parseFloat(row.stock || row.quantity || row.qty || row.الكمية || 0) || 0,
  });

  const mapJournal = (row: any) => ({
    date: row.date || row.تاريخ || row.voucher_date || new Date().toISOString().split("T")[0],
    description: row.details || row.description || row.notes || row.البيان || row.وصف || "",
    debit: parseFloat(row.debit || row.amount || row.المدين || 0) || 0,
    credit: parseFloat(row.credit || row.المدين || 0) || 0,
    account: row.account || row.account_name || row.الحساب || "",
  });

  const parseSqliteFile = async (buffer: ArrayBuffer, file: File): Promise<ExternalImportResult> => {
    const initSqlJs = (await import("sql.js")).default;
    const SQL = await initSqlJs({
      locateFile: () => "https://cdnjs.cloudflare.com/ajax/libs/sql.js/1.10.3/sql-wasm.wasm"
    });
    const db = new SQL.Database(new Uint8Array(buffer));

    const tablesResult = db.exec("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'");
    const tableNames: string[] = tablesResult.length ? tablesResult[0].values.flat() as string[] : [];

    const tables: SqliteTable[] = [];
    const result: ExternalImportResult = {
      fileName: file.name, fileSize: `${(file.size/1024).toFixed(1)} KB`,
      detectedFormat: "قاعدة بيانات SQLite",
      isSqlite: true, tables: [],
      accounts: [], customers: [], suppliers: [], items: [],
      sales: [], purchases: [], currencies: [], journal: [],
      unknownKeys: [], rawPreview: `جداول SQLite: ${tableNames.join(", ")}`,
    };

    for (const tbl of tableNames) {
      try {
        const countRes = db.exec(`SELECT COUNT(*) FROM "${tbl}"`);
        const rowCount = countRes.length ? Number(countRes[0].values[0][0]) : 0;
        const sampleRes = db.exec(`SELECT * FROM "${tbl}" LIMIT 100`);
        const rows = rowsToObjects(sampleRes[0]);
        const columns = sampleRes.length ? sampleRes[0].columns : [];
        const mappedAs = TABLE_MAP[tbl.toLowerCase()] || TABLE_MAP[tbl] || "unknown";

        tables.push({ name: tbl, rowCount, columns, rows, mappedAs });

        if (mappedAs === "accounts") result.accounts.push(...rows.map(mapAccount));
        else if (mappedAs === "customers") result.customers.push(...rows.map(mapCustomer));
        else if (mappedAs === "suppliers") result.suppliers.push(...rows.map(mapSupplier));
        else if (mappedAs === "items") result.items.push(...rows.map(mapItem));
        else if (mappedAs === "journal") result.journal.push(...rows.map(mapJournal));
        else if (mappedAs === "unknown") result.unknownKeys.push(tbl);
      } catch { result.unknownKeys.push(tbl); }
    }

    result.tables = tables;
    if (tableNames.length === 0) result.detectedFormat = "ملف غير معروف أو تالف";

    db.close();
    return result;
  };

  const parseJsonFile = (raw: string, file: File): ExternalImportResult => {
    let data: any = {};
    try { data = JSON.parse(raw); } catch { data = {}; }
    const fieldMap: Record<string, any> = {
      accounts: "accounts", customers: "customers", clients: "customers",
      suppliers: "suppliers", vendors: "suppliers",
      items: "items", products: "items",
      sales: "sales", invoices: "sales",
      purchases: "purchases", bills: "purchases",
      currencies: "currencies",
      journal: "journal", journal_entries: "journal", transactions: "journal",
    };
    const result: ExternalImportResult = {
      fileName: file.name, fileSize: `${(file.size/1024).toFixed(1)} KB`,
      detectedFormat: data.meta?.appName === "قـويـره سوفت" ? "قـويـره سوفت (متوافق)" : "JSON خارجي",
      isSqlite: false, tables: [],
      accounts: data.accounts || [], customers: data.customers || data.clients || [],
      suppliers: data.suppliers || data.vendors || [],
      items: data.items || data.products || [],
      sales: data.sales || data.invoices || [],
      purchases: data.purchases || data.bills || [],
      currencies: data.currencies || [],
      journal: data.journal || data.journal_entries || data.transactions || [],
      unknownKeys: Object.keys(data).filter(k => !fieldMap[k] && k !== "meta" && k !== "settings"),
      rawPreview: raw.slice(0, 500),
    };
    return result;
  };

  const handleExternalImport = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setExternalImporting(true);
    setExternalResult(null);
    setImportError("");
    setImportStep("reading");

    try {
      const isBinary = !file.name.endsWith(".json");
      if (isBinary) {
        setImportStep("parsing");
        const buffer = await file.arrayBuffer();
        // Check for SQLite magic bytes: "SQLite format 3\000"
        const magic = new Uint8Array(buffer.slice(0, 16));
        const sqliteMagic = [83,81,76,105,116,101,32,102,111,114,109,97,116,32,51,0];
        const isSqlite = sqliteMagic.every((b, i) => b === magic[i]);

        if (isSqlite) {
          const result = await parseSqliteFile(buffer, file);
          setExternalResult(result);
          setImportStep("done");
          const total = result.accounts.length + result.customers.length + result.suppliers.length +
            result.items.length + result.sales.length + result.purchases.length + result.journal.length;
          toast({ title: "✅ تم قراءة قاعدة البيانات", description: `${result.tables.length} جدول | ${total} سجل قابل للاستيراد` });
        } else {
          // Try as text JSON
          const decoder = new TextDecoder("utf-8");
          const raw = decoder.decode(buffer);
          const result = parseJsonFile(raw, file);
          setExternalResult(result);
          setImportStep("done");
          toast({ title: "✅ تم قراءة الملف", description: "تم معالجته كملف JSON" });
        }
      } else {
        const raw = await file.text();
        const result = parseJsonFile(raw, file);
        setExternalResult(result);
        setImportStep("done");
        const total = result.accounts.length + result.customers.length + result.suppliers.length;
        toast({ title: "✅ تم قراءة الملف", description: `${total} سجل قابل للاستيراد` });
      }
    } catch (err: any) {
      setImportStep("error");
      setImportError(err?.message || "خطأ غير معروف");
      toast({ title: "❌ فشل قراءة الملف", description: err?.message, variant: "destructive" });
    }

    setExternalImporting(false);
    e.target.value = "";
  };

  const renderImportExternal = () => {
    const totalMapped = externalResult
      ? externalResult.accounts.length + externalResult.customers.length + externalResult.suppliers.length +
        externalResult.items.length + externalResult.sales.length + externalResult.purchases.length + externalResult.journal.length
      : 0;

    return (
      <div className="space-y-5">
        {/* Header */}
        <div className="text-center">
          <ArrowLeftRight className="w-14 h-14 mx-auto text-rose-400 mb-3 opacity-80" style={{filter: "drop-shadow(0 0 10px rgba(251,113,133,0.5))"}} />
          <h3 className="text-xl font-bold text-rose-300">استيراد من برنامج محاسبي آخر</h3>
          <p className="text-white/60 text-sm mt-1">يدعم ملفات <span className="text-rose-300 font-bold">.db (SQLite)</span> و <span className="text-amber-300 font-bold">.json</span></p>
        </div>

        {/* Supported apps */}
        <div className="rounded-xl bg-rose-900/20 border border-rose-700/30 p-4 space-y-3">
          <p className="text-rose-300 text-sm font-bold flex items-center gap-2"><Info className="w-4 h-4" />البرامج المدعومة</p>
          <div className="grid grid-cols-2 gap-1.5 text-xs">
            {[
              { name: "تكاليف سوفت", color: "text-amber-300" },
              { name: "قويرة سوفت (نسخة قديمة)", color: "text-emerald-300" },
              { name: "أي برنامج يصدّر SQLite", color: "text-blue-300" },
              { name: "أي برنامج يصدّر JSON", color: "text-purple-300" },
              { name: "برامج المحاسبة الإندونيسية", color: "text-pink-300" },
              { name: "ملفات تصدير عامة", color: "text-white/60" },
            ].map((a, i) => (
              <div key={i} className="flex items-center gap-1.5 bg-white/5 rounded-lg px-2 py-1.5">
                <span className="text-green-400 text-base">✓</span>
                <span className={a.color}>{a.name}</span>
              </div>
            ))}
          </div>
          <div className="bg-amber-900/30 border border-amber-700/40 rounded-lg p-2 text-xs text-amber-300">
            <span className="font-bold">💡 تلقائي: </span>
            يقرأ قواعد البيانات SQLite الثنائية مباشرةً — لا حاجة لأي تحويل!
          </div>
        </div>

        {/* Upload button */}
        <label className="cursor-pointer block">
          <Button type="button" disabled={externalImporting} asChild
            className="w-full h-16 text-base font-bold bg-gradient-to-l from-rose-700 to-rose-800 hover:from-rose-600 hover:to-rose-700 text-white gap-3 shadow-xl border border-rose-600/50 rounded-2xl">
            <span>
              {externalImporting
                ? <><Loader2 className="w-6 h-6 animate-spin" />جاري قراءة قاعدة البيانات...</>
                : <><FileJson className="w-6 h-6" />اختر ملف قاعدة البيانات (.db / .json)</>
              }
            </span>
          </Button>
          <input type="file" accept=".db,.json,.sql,.bak,.backup,.sqlite,.sqlite3" className="hidden" onChange={handleExternalImport} />
        </label>

        {/* Error state */}
        {importStep === "error" && (
          <div className="rounded-xl bg-red-900/30 border border-red-600/40 p-4 flex gap-3">
            <AlertTriangle className="w-6 h-6 text-red-400 shrink-0 mt-0.5" />
            <div>
              <p className="text-red-300 font-bold text-sm">❌ فشل قراءة الملف</p>
              <p className="text-white/60 text-xs mt-1">{importError || "تأكد أن الملف غير تالف أو مشفّر"}</p>
            </div>
          </div>
        )}

        {/* Results */}
        {externalResult && (
          <div className="space-y-4">
            {/* File info */}
            <div className="rounded-xl border border-rose-500/40 p-4 space-y-4" style={{background:"rgba(136,19,55,0.18)"}}>
              <div className="flex items-center gap-3">
                <div className="p-2.5 bg-rose-800/60 rounded-xl border border-rose-600/40">
                  <FileJson className="w-5 h-5 text-rose-400" />
                </div>
                <div>
                  <p className="text-white font-bold">{externalResult.fileName}</p>
                  <p className="text-white/50 text-xs">{externalResult.fileSize} • {externalResult.detectedFormat}</p>
                </div>
                {externalResult.isSqlite && (
                  <span className="mr-auto bg-blue-700/60 border border-blue-500/40 text-blue-200 text-xs px-2 py-0.5 rounded-full font-bold">SQLite ✓</span>
                )}
              </div>

              {/* SQLite tables detail */}
              {externalResult.isSqlite && externalResult.tables.length > 0 && (
                <div className="space-y-2">
                  <p className="text-blue-300 text-sm font-bold flex items-center gap-1.5"><Table2 className="w-4 h-4" />جداول قاعدة البيانات ({externalResult.tables.length})</p>
                  <div className="space-y-1.5 max-h-52 overflow-y-auto">
                    {externalResult.tables.map((tbl, i) => (
                      <div key={i} className="flex items-center justify-between rounded-lg bg-white/5 px-3 py-2 border border-white/10">
                        <div className="flex items-center gap-2">
                          <span className={`w-2 h-2 rounded-full ${tbl.mappedAs !== "unknown" ? "bg-green-400" : "bg-white/20"}`} />
                          <span className="text-white text-sm font-mono">{tbl.name}</span>
                          {tbl.mappedAs !== "unknown" && (
                            <span className="text-xs bg-green-800/50 text-green-300 px-1.5 py-0.5 rounded-full border border-green-700/40">
                              → {tbl.mappedAs === "accounts" ? "حسابات" : tbl.mappedAs === "customers" ? "عملاء" : tbl.mappedAs === "suppliers" ? "موردون" : tbl.mappedAs === "items" ? "أصناف" : tbl.mappedAs === "journal" ? "قيود" : tbl.mappedAs === "sales" ? "مبيعات" : tbl.mappedAs === "purchases" ? "مشتريات" : tbl.mappedAs}
                            </span>
                          )}
                        </div>
                        <div className="text-left">
                          <span className="text-amber-400 text-xs font-bold">{tbl.rowCount} سجل</span>
                          <p className="text-white/30 text-xs">{tbl.columns.slice(0, 3).join(", ")}{tbl.columns.length > 3 ? "..." : ""}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Extracted counts */}
              <div>
                <p className="text-white/80 text-sm font-bold mb-2">📊 البيانات القابلة للاستيراد:</p>
                <div className="grid grid-cols-4 gap-2 text-center">
                  {[
                    { label: "حسابات", val: externalResult.accounts.length, color: "text-amber-400", bg: "bg-amber-900/20 border-amber-700/30" },
                    { label: "عملاء", val: externalResult.customers.length, color: "text-green-400", bg: "bg-green-900/20 border-green-700/30" },
                    { label: "موردون", val: externalResult.suppliers.length, color: "text-blue-400", bg: "bg-blue-900/20 border-blue-700/30" },
                    { label: "أصناف", val: externalResult.items.length, color: "text-purple-400", bg: "bg-purple-900/20 border-purple-700/30" },
                    { label: "مبيعات", val: externalResult.sales.length, color: "text-emerald-400", bg: "bg-emerald-900/20 border-emerald-700/30" },
                    { label: "مشتريات", val: externalResult.purchases.length, color: "text-teal-400", bg: "bg-teal-900/20 border-teal-700/30" },
                    { label: "عملات", val: externalResult.currencies.length, color: "text-yellow-400", bg: "bg-yellow-900/20 border-yellow-700/30" },
                    { label: "قيود", val: externalResult.journal.length, color: "text-pink-400", bg: "bg-pink-900/20 border-pink-700/30" },
                  ].map((s, i) => (
                    <div key={i} className={`rounded-xl p-2 border ${s.bg}`}>
                      <p className={`font-black text-xl ${s.color}`}>{s.val}</p>
                      <p className="text-white/40 text-xs">{s.label}</p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Preview first account */}
              {externalResult.accounts.length > 0 && (
                <div className="rounded-lg bg-black/20 border border-white/10 p-3">
                  <p className="text-white/50 text-xs mb-1.5">📋 معاينة أول حساب:</p>
                  <div className="text-xs text-emerald-300 space-y-0.5">
                    <p>الاسم: <span className="text-white">{externalResult.accounts[0]?.nameAr || "—"}</span></p>
                    <p>الرصيد: <span className="text-amber-300">{externalResult.accounts[0]?.openingBalance?.toFixed(2) || "0.00"}</span></p>
                    {externalResult.accounts[0]?.accountNumber && <p>رقم الحساب: <span className="text-white/70">{externalResult.accounts[0].accountNumber}</span></p>}
                  </div>
                </div>
              )}

              {/* Journal preview */}
              {externalResult.journal.length > 0 && (
                <div className="rounded-lg bg-black/20 border border-white/10 p-3">
                  <p className="text-white/50 text-xs mb-1.5">📋 معاينة أول قيد:</p>
                  <div className="text-xs text-pink-300 space-y-0.5">
                    <p>التاريخ: <span className="text-white">{externalResult.journal[0]?.date || "—"}</span></p>
                    <p>البيان: <span className="text-white">{externalResult.journal[0]?.description || "—"}</span></p>
                    <p>المبلغ: <span className="text-amber-300">{externalResult.journal[0]?.debit || externalResult.journal[0]?.amount || "—"}</span></p>
                  </div>
                </div>
              )}

              {/* Unknown tables */}
              {externalResult.unknownKeys.length > 0 && (
                <div className="flex gap-2 items-start text-xs text-white/40 bg-white/5 rounded-lg p-2">
                  <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                  <span>جداول لم يتم التعرف عليها: <span className="text-amber-400">{externalResult.unknownKeys.join("، ")}</span></span>
                </div>
              )}

              {/* Action buttons */}
              {totalMapped > 0 ? (
                <div className="space-y-2 pt-1">
                  <div className="bg-green-900/20 border border-green-700/30 rounded-xl p-3 text-center">
                    <p className="text-green-300 text-sm font-bold">✅ الملف متوافق — {totalMapped} سجل جاهز للاستيراد</p>
                    <p className="text-white/40 text-xs mt-0.5">سيتم دمج البيانات مع الموجود. لن تُحذف بيانات قديمة</p>
                  </div>
                  <Button onClick={async () => {
                    await doActualRestore({
                      accounts: externalResult.accounts,
                      customers: externalResult.customers,
                      suppliers: externalResult.suppliers,
                      items: externalResult.items,
                      currencies: externalResult.currencies,
                      sales: externalResult.sales,
                      purchases: externalResult.purchases,
                      journal: externalResult.journal,
                    }, externalResult.fileName);
                    setExternalResult(null);
                    setImportStep("idle");
                  }} disabled={isWorking} className="w-full bg-green-700 hover:bg-green-600 text-white font-bold h-12 gap-2 rounded-xl">
                    {isWorking ? <><Loader2 className="w-5 h-5 animate-spin" />جاري الاستيراد...</> : <><CheckCircle className="w-5 h-5" />تأكيد استيراد البيانات ({totalMapped} سجل)</>}
                  </Button>
                </div>
              ) : (
                <div className="bg-red-900/20 border border-red-700/30 rounded-xl p-3 text-center">
                  <p className="text-red-300 text-sm font-bold">❌ لم يتم استخراج بيانات قابلة للاستيراد</p>
                  <p className="text-white/40 text-xs mt-1">أسماء الجداول أو الأعمدة غير متوافقة — تواصل معنا لإضافة دعم هذا البرنامج</p>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    );
  };

  const renderContent = () => {
    switch (activeTab) {
      case "restore-local": return renderRestoreLocal();
      case "restore-drive": return renderRestoreDrive();
      case "save-local": return renderSaveLocal();
      case "save-drive": return renderSaveDrive();
      case "import-external": return renderImportExternal();
    }
  };

  return (
    <div className="space-y-4 animate-in fade-in duration-300" dir="rtl">
      <div>
        <h1 className="text-3xl font-bold text-amber-400">النسخ الاحتياطية</h1>
        <p className="text-emerald-200 mt-1">حفظ واسترجاع بيانات النظام بصيغة .db</p>
      </div>

      {/* 4 Operation Tabs */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {tabConfig.map(tab => (
          <button key={tab.id} onClick={() => setActiveTab(tab.id)}
            className={`rounded-2xl p-4 flex flex-col items-center gap-2 transition-all border text-center ${activeTab === tab.id ? tab.bg + " text-white border-transparent shadow-xl scale-[1.02]" : "border-white/10 hover:border-white/20 bg-white/5 hover:bg-white/10"}`}>
            <tab.icon className={`w-8 h-8 ${activeTab === tab.id ? "text-white" : tab.color}`} style={{filter: activeTab === tab.id ? "drop-shadow(0 0 8px rgba(255,255,255,0.4))" : ""}} />
            <div>
              <p className={`font-bold text-sm ${activeTab === tab.id ? "text-white" : "text-emerald-200"}`}>{tab.label}</p>
              <p className={`text-xs mt-0.5 ${activeTab === tab.id ? "text-white/70" : "text-white/30"}`}>{tab.desc}</p>
            </div>
          </button>
        ))}
      </div>

      {/* Main Content */}
      <div className="rounded-2xl border border-white/10 p-5" style={{background: "rgba(6,78,59,0.2)"}}>
        {renderContent()}
      </div>

      {/* History */}
      {backupHistory.length > 0 && (
        <div className="rounded-xl border border-white/10 overflow-hidden">
          <div className="p-3 bg-emerald-800/30 border-b border-white/10">
            <h3 className="text-amber-300 font-bold text-sm">📋 سجل العمليات الأخيرة</h3>
          </div>
          <div className="space-y-0">
            {backupHistory.slice(0, 5).map((record, i) => (
              <div key={i} className="flex items-center justify-between p-3 border-b border-white/5 last:border-0 hover:bg-white/5">
                <div className="flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-green-400" />
                  <div>
                    <p className="text-white text-sm font-semibold">{record.name}</p>
                    <p className="text-white/40 text-xs">{record.date}</p>
                  </div>
                </div>
                <div className="text-left">
                  <span className="text-amber-400 text-xs font-bold">{record.size}</span>
                  <p className="text-white/40 text-xs">{record.type}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Stats */}
      <div className="rounded-xl p-3 border border-emerald-600/30 bg-emerald-900/20">
        <p className="text-emerald-300 text-xs font-semibold mb-2">📊 إحصاءات البيانات الحالية</p>
        <div className="grid grid-cols-4 gap-2 text-center">
          <div><p className="text-amber-400 font-bold">{(accounts as any[]).length}</p><p className="text-white/40 text-xs">حساب</p></div>
          <div><p className="text-green-400 font-bold">{(sales as any[]).length}</p><p className="text-white/40 text-xs">فاتورة بيع</p></div>
          <div><p className="text-blue-400 font-bold">{(purchases as any[]).length}</p><p className="text-white/40 text-xs">فاتورة شراء</p></div>
          <div><p className="text-purple-400 font-bold">{(items as any[]).length}</p><p className="text-white/40 text-xs">صنف</p></div>
        </div>
      </div>

      {/* ─── ترحيل جماعي لجميع المسودات ─── */}
      <BulkPostSection />
    </div>
  );
}

function BulkPostSection() {
  const { toast } = useToast();
  const [working, setWorking] = React.useState(false);
  const [result, setResult] = React.useState<{total:number; results: Record<string,number>} | null>(null);

  const handleBulkPost = async () => {
    setWorking(true);
    setResult(null);
    try {
      const resp = await fetch("/api/backup/bulk-post", { method: "POST" });
      if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
      const data = await resp.json();
      setResult(data);
      if (data.total === 0) {
        toast({ title: "✅ لا توجد مسودات", description: "جميع العمليات مرحّلة مسبقاً" });
      } else {
        toast({ title: `✅ تم ترحيل ${data.total} عملية`, description: `مبيعات: ${data.results.sales} · مشتريات: ${data.results.purchases} · قيود: ${data.results.journal}` });
      }
    } catch (err: any) {
      toast({ title: "❌ خطأ", description: err?.message, variant: "destructive" });
    }
    setWorking(false);
  };

  return (
    <div className="rounded-xl border border-orange-500/30 bg-orange-900/10 p-4 space-y-3">
      <div className="flex items-center gap-2">
        <span className="text-orange-400 text-xl">⚡</span>
        <div>
          <p className="text-orange-300 font-bold text-sm">ترحيل جماعي للمسودات</p>
          <p className="text-white/40 text-xs">تحويل جميع العمليات بحالة "مسودة" إلى "مرحّلة" دفعةً واحدة</p>
        </div>
      </div>
      <Button onClick={handleBulkPost} disabled={working}
        className="w-full h-11 bg-orange-700 hover:bg-orange-600 text-white font-bold gap-2 rounded-xl">
        {working ? <><Loader2 className="w-4 h-4 animate-spin" />جاري الترحيل...</> : <>⚡ رحّل جميع المسودات</>}
      </Button>
      {result && (
        <div className="grid grid-cols-3 gap-2 text-center">
          {[
            { label: "مبيعات", val: result.results.sales, color: "text-green-400" },
            { label: "مشتريات", val: result.results.purchases, color: "text-blue-400" },
            { label: "قيود", val: result.results.journal, color: "text-pink-400" },
          ].map((s, i) => (
            <div key={i} className="rounded-lg bg-white/5 p-2">
              <p className={`font-bold text-lg ${s.color}`}>{s.val}</p>
              <p className="text-white/40 text-xs">{s.label}</p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
