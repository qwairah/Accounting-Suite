import React, { useState, useMemo, useRef } from "react";
import {
  useListSales, useListPurchases, useListAccounts, useListItems,
  useListJournalEntries, useListInventoryOperations, useListCurrencies,
} from "@workspace/api-client-react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  LineChart, BarChart2, TrendingUp, TrendingDown, Package, BookOpen,
  Wallet, Calendar, ArrowLeftRight, Coins, FileText, Printer,
  Users, Building2, Tag, Activity, Scale, ShoppingCart, ChevronLeft,
  ChevronRight, X, Warehouse, Search, ArrowLeft, Layers,
} from "lucide-react";
import { useSettings } from "@/contexts/SettingsContext";

// ─── Types ────────────────────────────────────────────────────────────────────
type MainTab = "item-movement" | "trial-balance" | "income" | "balance-sheet" | "other";
type OtherRpt =
  | "remaining-stock" | "account-balances" | "item-profits" | "daily-ops" | "daily-journal"
  | "fund-movement" | "account-movement" | "category-totals" | "currency-diff"
  | "working-capital" | "client-profit" | "sales-by-item" | "purchases-by-item" | "item-details";

// ─── Constants ────────────────────────────────────────────────────────────────
const MAIN_TABS = [
  { id: "item-movement"  as MainTab, label: "حركة الأصناف",    icon: Package,   grad: "from-emerald-800 to-emerald-700", desc: "حركة الأصناف في المخازن" },
  { id: "trial-balance"  as MainTab, label: "ميزان المراجعة",   icon: Scale,     grad: "from-blue-900 to-blue-800",       desc: "موازنة الحسابات والعملات" },
  { id: "income"         as MainTab, label: "قائمة الدخل",      icon: TrendingUp, grad: "from-amber-900 to-amber-800",    desc: "الإيرادات والمصروفات" },
  { id: "balance-sheet"  as MainTab, label: "المركز المالي",    icon: Building2, grad: "from-purple-900 to-purple-800",   desc: "الأصول والخصوم" },
  { id: "other"          as MainTab, label: "تقارير أخرى",      icon: BarChart2, grad: "from-rose-900 to-rose-800",       desc: "14 تقريراً تفصيلياً" },
];

const OTHER_RPTS: { id: OtherRpt; label: string; icon: any; color: string; grad: string }[] = [
  { id: "remaining-stock",   label: "المخزون المتبقي",           icon: Package,          color: "text-emerald-400",  grad: "from-emerald-900/60 to-emerald-800/60" },
  { id: "account-balances",  label: "أرصدة الحسابات",            icon: BookOpen,         color: "text-blue-400",     grad: "from-blue-900/60 to-blue-800/60"     },
  { id: "item-profits",      label: "أرباح الأصناف",             icon: TrendingUp,       color: "text-amber-400",    grad: "from-amber-900/60 to-amber-800/60"   },
  { id: "daily-ops",         label: "العمليات اليومية",           icon: Calendar,         color: "text-orange-400",   grad: "from-orange-900/60 to-orange-800/60" },
  { id: "daily-journal",     label: "القيود اليومية",             icon: FileText,         color: "text-indigo-400",   grad: "from-indigo-900/60 to-indigo-800/60" },
  { id: "fund-movement",     label: "حركة الصندوق",              icon: Wallet,           color: "text-green-400",    grad: "from-green-900/60 to-green-800/60"   },
  { id: "account-movement",  label: "حركة الحسابات",             icon: Activity,         color: "text-purple-400",   grad: "from-purple-900/60 to-purple-800/60" },
  { id: "category-totals",   label: "إجمالي التصنيفات",          icon: Tag,              color: "text-teal-400",     grad: "from-teal-900/60 to-teal-800/60"     },
  { id: "currency-diff",     label: "فوارق أسعار العملات",        icon: ArrowLeftRight,   color: "text-yellow-400",   grad: "from-yellow-900/60 to-yellow-800/60" },
  { id: "working-capital",   label: "رأس المال العامل",           icon: Coins,            color: "text-cyan-400",     grad: "from-cyan-900/60 to-cyan-800/60"     },
  { id: "client-profit",     label: "الربح على مستوى العميل",    icon: Users,            color: "text-pink-400",     grad: "from-pink-900/60 to-pink-800/60"     },
  { id: "sales-by-item",     label: "المبيعات حسب الصنف",        icon: ShoppingCart,     color: "text-rose-400",     grad: "from-rose-900/60 to-rose-800/60"     },
  { id: "purchases-by-item", label: "المشتريات حسب الصنف",       icon: Layers,           color: "text-violet-400",   grad: "from-violet-900/60 to-violet-800/60" },
  { id: "item-details",      label: "تفاصيل حركة الأصناف",       icon: LineChart,        color: "text-lime-400",     grad: "from-lime-900/60 to-lime-800/60"     },
];

const fmt = (n: number) => n.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });

// ─── Main Component ───────────────────────────────────────────────────────────
export default function ReportsPage() {
  const { settings } = useSettings();
  const cur = settings.defaultCurrency || "ر.ي";

  const [tab, setTab] = useState<MainTab | null>(null);
  const [otherRpt, setOtherRpt] = useState<OtherRpt | null>(null);
  const [fromDate, setFromDate] = useState(new Date(new Date().getFullYear(), 0, 1).toISOString().split("T")[0]);
  const [toDate, setToDate] = useState(new Date().toISOString().split("T")[0]);
  const [warehouseIdx, setWarehouseIdx] = useState(0);
  const [itemSearch, setItemSearch] = useState("");
  const [accSearch, setAccSearch] = useState("");

  // ── Data fetching ──
  const { data: sales = [] }      = useListSales();
  const { data: purchases = [] }  = useListPurchases();
  const { data: accounts = [] }   = useListAccounts();
  const { data: items = [] }      = useListItems();
  const { data: journal = [] }    = useListJournalEntries();
  const { data: invOps = [] }     = useListInventoryOperations();
  const { data: currencies = [] } = useListCurrencies();
  const { data: warehouses = [] } = useQuery({
    queryKey: ["warehouses"],
    queryFn: () => fetch("/api/inventory/warehouses").then(r => r.json()),
  });

  const inRange = (d: string) => (!fromDate || d >= fromDate) && (!toDate || d <= toDate);
  const fSales     = useMemo(() => (sales     as any[]).filter(s => inRange(s.date || "")), [sales, fromDate, toDate]);
  const fPurchases = useMemo(() => (purchases as any[]).filter(p => inRange(p.date || "")), [purchases, fromDate, toDate]);
  const fJournal   = useMemo(() => (journal   as any[]).filter(j => inRange(j.date || "")), [journal, fromDate, toDate]);
  const fInvOps    = useMemo(() => (invOps    as any[]).filter(o => inRange(o.date || "")), [invOps, fromDate, toDate]);

  // ── All journal lines ──
  const allLines = useMemo(() => (journal as any[]).flatMap((e: any) => e.lines || []), [journal]);
  const fLines   = useMemo(() => fJournal.flatMap((e: any) => e.lines || []), [fJournal]);

  // ── Account balance helper ──
  const getBalance = (a: any) => {
    const open = Number(a.openingBalance || 0);
    const ls = allLines.filter((l: any) => l.accountId === a.id);
    const dr = ls.reduce((s: number, l: any) => s + Number(l.debit  || 0), 0);
    const cr = ls.reduce((s: number, l: any) => s + Number(l.credit || 0), 0);
    const isDebitNormal = a.type === "assets" || a.type === "expenses";
    return isDebitNormal ? open + dr - cr : open + cr - dr;
  };

  // ── Aggregates ──
  const totalSalesRev   = useMemo(() => fSales.reduce((s: number, i: any) => s + Number(i.total || 0), 0), [fSales]);
  const totalPurchCost  = useMemo(() => fPurchases.reduce((s: number, i: any) => s + Number(i.total || 0), 0), [fPurchases]);
  const revenueAccs  = useMemo(() => (accounts as any[]).filter(a => !a.isMain && a.type === "revenue"), [accounts]);
  const expenseAccs  = useMemo(() => (accounts as any[]).filter(a => !a.isMain && a.type === "expenses"), [accounts]);
  const assetAccs    = useMemo(() => (accounts as any[]).filter(a => !a.isMain && a.type === "assets"), [accounts]);
  const liabAccs     = useMemo(() => (accounts as any[]).filter(a => !a.isMain && a.type === "liabilities"), [accounts]);
  const mainAssets   = useMemo(() => (accounts as any[]).filter(a => a.isMain && a.type === "assets" && a.subType), [accounts]);
  const mainLiabs    = useMemo(() => (accounts as any[]).filter(a => a.isMain && a.type === "liabilities" && a.subType), [accounts]);

  const jRevenue  = useMemo(() => revenueAccs.reduce((s, a) => s + getBalance(a), 0), [revenueAccs, allLines]);
  const jExpenses = useMemo(() => expenseAccs.reduce((s, a) => s + getBalance(a), 0), [expenseAccs, allLines]);

  // ── قيمة المخزون الختامي — مصدر واحد: invOps فقط ────────────────────────
  const closingStockValue = useMemo(() => {
    return (items as any[]).reduce((total: number, it: any) => {
      let inQty = 0, outQty = 0;
      (invOps as any[]).forEach((op: any) => {
        (op.items || []).forEach((line: any) => {
          if (line.itemId !== it.id) return;
          const q = Number(line.quantity || 0);
          if (op.type === "in" || op.type === "adjust") inQty  += q;
          else if (op.type === "out")                   outQty += q;
        });
      });
      const rem = inQty - outQty;
      return total + (rem > 0 ? rem * Number(it.costPrice || 0) : 0);
    }, 0);
  }, [items, invOps]);

  const totalRev  = totalSalesRev + jRevenue + closingStockValue;
  const totalExp  = totalPurchCost + jExpenses;
  const netProfit = totalRev - totalExp;

  const totalAssets  = useMemo(() => assetAccs.reduce((s, a) => s + getBalance(a), 0), [assetAccs, allLines]);
  const totalLiab    = useMemo(() => liabAccs.reduce((s, a) => s + getBalance(a), 0), [liabAccs, allLines]);
  const totalEquity  = totalLiab + netProfit;

  // ─── Print helper ──────────────────────────────────────────────────────────
  const print = (title: string, html: string) => {
    const w = window.open("", "_blank");
    if (!w) return;
    w.document.write(`<!DOCTYPE html><html dir="rtl"><head><meta charset="utf-8"><title>${title}</title>
    <style>body{font-family:Arial;padding:30px;direction:rtl;color:#111}
    h1{color:#064E3B;border-bottom:3px solid #F59E0B;padding-bottom:10px;font-size:20px}
    h2{color:#047857;font-size:14px;margin-top:18px;border-right:4px solid #F59E0B;padding-right:8px}
    table{width:100%;border-collapse:collapse;margin:12px 0;font-size:12px}
    th{background:#064E3B;color:white;padding:8px;text-align:right}
    td{padding:7px 9px;border-bottom:1px solid #e5e7eb;text-align:right}
    tr:nth-child(even){background:#f0fdf4}
    .tot{background:#064E3B!important;color:white;font-weight:bold}
    .hdr{display:flex;justify-content:space-between;margin-bottom:15px}
    .co{font-size:22px;font-weight:bold;color:#064E3B}
    .dt{font-size:11px;color:#6b7280;margin-top:4px}
    .neg{color:#dc2626}.pos{color:#059669}
    </style></head><body>
    <div class="hdr">
      <div><div class="co">${settings.companyName || "قـويـره سوفت"}</div>
      <div class="dt">الفترة: ${fromDate} — ${toDate} | طباعة: ${new Date().toLocaleDateString("ar")}</div></div>
      <div style="text-align:left;font-size:11px;color:#6b7280"><div>QWAIRAH SOFT</div></div>
    </div>
    <h1>${title}</h1>${html}
    <p style="margin-top:25px;font-size:10px;color:#9ca3af;border-top:1px solid #e5e7eb;padding-top:8px">
    نظام قـويـره سوفت — جميع الحقوق محفوظة © ${new Date().getFullYear()}</p>
    </body></html>`);
    w.print();
  };

  // ─── KPI card ─────────────────────────────────────────────────────────────
  const kpi = (label: string, val: string, color: string, Icon: any, sub?: string) => (
    <div className="rounded-xl p-4 border border-white/10 bg-white/5">
      <div className="flex items-center justify-between mb-2">
        <Icon className={`w-5 h-5 ${color}`} />
        <span className="text-white/40 text-xs">{label}</span>
      </div>
      <p className={`text-2xl font-black ${color}`}>{val}</p>
      {sub && <p className="text-white/40 text-xs mt-1">{sub}</p>}
    </div>
  );

  // ── Section header with back + print buttons ──
  const sectionHdr = (title: string, icon: string, color: string, printFn?: () => void) => (
    <div className="flex justify-between items-center flex-wrap gap-2">
      <h2 className={`font-bold text-lg ${color}`}>{icon} {title}</h2>
      <div className="flex gap-2 items-center">
        <div className="flex gap-2">
          <div className="flex items-center gap-1.5 bg-emerald-900/40 border border-emerald-700/40 rounded-xl px-3 py-1.5">
            <span className="text-emerald-400 text-xs">من</span>
            <Input type="date" value={fromDate} onChange={e => setFromDate(e.target.value)} className="bg-transparent border-0 text-white h-7 text-xs p-0 w-28" />
          </div>
          <div className="flex items-center gap-1.5 bg-emerald-900/40 border border-emerald-700/40 rounded-xl px-3 py-1.5">
            <span className="text-emerald-400 text-xs">إلى</span>
            <Input type="date" value={toDate} onChange={e => setToDate(e.target.value)} className="bg-transparent border-0 text-white h-7 text-xs p-0 w-28" />
          </div>
        </div>
        {printFn && (
          <Button size="sm" onClick={printFn} className="bg-blue-700 hover:bg-blue-600 text-white gap-1.5 h-9 text-xs px-3">
            <Printer className="w-3.5 h-3.5" /> طباعة
          </Button>
        )}
      </div>
    </div>
  );

  // ══════════════════════════════════════════════════════════════════════════
  // 1. حركة الأصناف
  // ══════════════════════════════════════════════════════════════════════════
  const renderItemMovement = () => {
    const whs: any[] = warehouses as any[];
    const allWh = [{ id: 0, nameAr: "جميع المخازن", code: "ALL" }, ...whs];
    const selWh = allWh[Math.min(warehouseIdx, allWh.length - 1)];

    // Build per-item movement
    const itemMap: Record<number, { item: any; inQty: number; outQty: number; transferIn: number; transferOut: number }> = {};
    (items as any[]).forEach((it: any) => {
      itemMap[it.id] = { item: it, inQty: 0, outQty: 0, transferIn: 0, transferOut: 0 };
    });

    fInvOps.forEach((op: any) => {
      const matchWh = selWh.id === 0 || op.warehouseId === selWh.id;
      if (!matchWh) return;
      (op.items || []).forEach((line: any) => {
        if (!itemMap[line.itemId]) return;
        const qty = Number(line.quantity || 0);
        if (op.type === "in" || op.type === "adjust") itemMap[line.itemId].inQty += qty;
        else if (op.type === "out") itemMap[line.itemId].outQty += qty;
        else if (op.type === "transfer") {
          if (op.warehouseId === selWh.id || selWh.id === 0) itemMap[line.itemId].transferOut += qty;
          if (op.toWarehouseId === selWh.id || selWh.id === 0) itemMap[line.itemId].transferIn  += qty;
        }
      });
    });

    // Add sales / purchases
    fSales.forEach((inv: any) => {
      (inv.items || []).forEach((line: any) => {
        if (!itemMap[line.itemId]) return;
        itemMap[line.itemId].outQty += Number(line.quantity || 0);
      });
    });
    fPurchases.forEach((inv: any) => {
      (inv.items || []).forEach((line: any) => {
        if (!itemMap[line.itemId]) return;
        itemMap[line.itemId].inQty += Number(line.quantity || 0);
      });
    });

    const rows = Object.values(itemMap).filter(r =>
      !itemSearch || r.item.nameAr?.includes(itemSearch) || r.item.code?.includes(itemSearch)
    );

    const printHtml = `<table><thead><tr>
      <th>الصنف</th><th>الوحدة</th><th>الوارد</th><th>الصادر</th><th>تحويل وارد</th><th>تحويل صادر</th><th>المتاح</th><th>القيمة</th>
    </tr></thead><tbody>
    ${rows.map(r => {
      const avail = r.inQty + r.transferIn - r.outQty - r.transferOut;
      return `<tr><td>${r.item.nameAr}</td><td>${r.item.unit}</td>
      <td class="pos">${fmt(r.inQty)}</td><td class="neg">${fmt(r.outQty)}</td>
      <td>${fmt(r.transferIn)}</td><td>${fmt(r.transferOut)}</td>
      <td class="${avail>=0?"pos":"neg"}">${fmt(avail)}</td>
      <td>${fmt(avail * Number(r.item.costPrice||0))}</td></tr>`;
    }).join("")}
    </tbody></table>`;

    return (
      <div className="space-y-4">
        {sectionHdr("حركة الأصناف في المخازن", "📦", "text-emerald-300", () => print("حركة الأصناف — " + selWh.nameAr, printHtml))}

        {/* Warehouse carousel */}
        <div className="relative">
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="sm" onClick={() => setWarehouseIdx(i => Math.max(0, i - 1))} disabled={warehouseIdx === 0} className="text-white/50 h-10 w-10 p-0 hover:bg-white/10 shrink-0">
              <ChevronRight className="w-5 h-5" />
            </Button>
            <div className="flex-1 overflow-x-auto">
              <div className="flex gap-2 min-w-max px-1">
                {allWh.map((wh, i) => (
                  <button key={i} onClick={() => setWarehouseIdx(i)}
                    className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-bold transition-all whitespace-nowrap ${i === warehouseIdx ? "bg-emerald-600 text-white shadow-lg" : "border border-white/10 text-emerald-300 hover:bg-white/10"}`}>
                    <Warehouse className="w-4 h-4" />
                    {wh.nameAr}
                  </button>
                ))}
              </div>
            </div>
            <Button variant="ghost" size="sm" onClick={() => setWarehouseIdx(i => Math.min(allWh.length - 1, i + 1))} disabled={warehouseIdx >= allWh.length - 1} className="text-white/50 h-10 w-10 p-0 hover:bg-white/10 shrink-0">
              <ChevronLeft className="w-5 h-5" />
            </Button>
          </div>
        </div>

        {/* Search */}
        <div className="relative">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-emerald-400" />
          <Input value={itemSearch} onChange={e => setItemSearch(e.target.value)} placeholder="بحث عن صنف..." className="bg-emerald-900/50 border-emerald-700 text-white pr-10 placeholder:text-emerald-500" />
        </div>

        {/* KPI summary */}
        <div className="grid grid-cols-4 gap-2">
          <div className="rounded-xl p-3 border border-emerald-600/30 bg-emerald-900/20 text-center">
            <p className="text-emerald-300 text-xs">عدد الأصناف</p>
            <p className="text-amber-400 text-xl font-black">{rows.length}</p>
          </div>
          <div className="rounded-xl p-3 border border-blue-600/30 bg-blue-900/20 text-center">
            <p className="text-blue-300 text-xs">إجمالي الوارد</p>
            <p className="text-blue-400 text-xl font-black">{fmt(rows.reduce((s, r) => s + r.inQty + r.transferIn, 0))}</p>
          </div>
          <div className="rounded-xl p-3 border border-red-600/30 bg-red-900/20 text-center">
            <p className="text-red-300 text-xs">إجمالي الصادر</p>
            <p className="text-red-400 text-xl font-black">{fmt(rows.reduce((s, r) => s + r.outQty + r.transferOut, 0))}</p>
          </div>
          <div className="rounded-xl p-3 border border-amber-600/30 bg-amber-900/20 text-center">
            <p className="text-amber-300 text-xs">إجمالي المتاح</p>
            <p className="text-amber-400 text-xl font-black">{fmt(rows.reduce((s, r) => s + r.inQty + r.transferIn - r.outQty - r.transferOut, 0))}</p>
          </div>
        </div>

        {/* Table */}
        <div className="bg-white/5 rounded-2xl border border-white/10 overflow-hidden">
          <div className="p-3 bg-emerald-800/30 border-b border-white/10 flex items-center gap-2">
            <Warehouse className="w-4 h-4 text-emerald-400" />
            <span className="text-emerald-300 font-bold text-sm">{selWh.nameAr}</span>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-emerald-800/50">
                <tr>
                  <th className="p-3 text-right text-amber-300">الصنف</th>
                  <th className="p-3 text-right text-amber-300">الوحدة</th>
                  <th className="p-3 text-center text-amber-300">الوارد</th>
                  <th className="p-3 text-center text-amber-300">الصادر</th>
                  <th className="p-3 text-center text-amber-300">تحويل وارد</th>
                  <th className="p-3 text-center text-amber-300">تحويل صادر</th>
                  <th className="p-3 text-center text-amber-300 font-black">المتاح</th>
                  <th className="p-3 text-center text-amber-300">القيمة</th>
                </tr>
              </thead>
              <tbody>
                {rows.length === 0 ? (
                  <tr><td colSpan={8} className="p-8 text-center text-emerald-400">
                    <Package className="w-8 h-8 mx-auto mb-2 opacity-40" />
                    <p>لا توجد حركة أصناف في هذه الفترة</p>
                  </td></tr>
                ) : rows.map(({ item, inQty, outQty, transferIn, transferOut }) => {
                  const avail = inQty + transferIn - outQty - transferOut;
                  const value = avail * Number(item.costPrice || 0);
                  return (
                    <tr key={item.id} className={`border-t border-white/10 hover:bg-white/5 ${avail < 0 ? "bg-red-900/10" : ""}`}>
                      <td className="p-3">
                        <p className="text-white font-semibold">{item.nameAr}</p>
                        {item.code && <p className="text-white/30 text-xs font-mono">{item.code}</p>}
                      </td>
                      <td className="p-3 text-white/50 text-xs">{item.unit}</td>
                      <td className="p-3 text-center text-blue-400 font-bold">{inQty > 0 ? fmt(inQty) : <span className="text-white/20">—</span>}</td>
                      <td className="p-3 text-center text-red-400 font-bold">{outQty > 0 ? fmt(outQty) : <span className="text-white/20">—</span>}</td>
                      <td className="p-3 text-center text-teal-400 font-bold">{transferIn > 0 ? fmt(transferIn) : <span className="text-white/20">—</span>}</td>
                      <td className="p-3 text-center text-orange-400 font-bold">{transferOut > 0 ? fmt(transferOut) : <span className="text-white/20">—</span>}</td>
                      <td className="p-3 text-center">
                        <span className={`font-black text-base px-2 py-0.5 rounded-lg ${avail >= 0 ? "text-amber-400 bg-amber-900/20" : "text-red-400 bg-red-900/20"}`}>{fmt(avail)}</span>
                      </td>
                      <td className="p-3 text-center text-emerald-300 font-bold text-xs">{fmt(value)}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    );
  };

  // ══════════════════════════════════════════════════════════════════════════
  // 2. ميزان المراجعة
  // ══════════════════════════════════════════════════════════════════════════
  const renderTrialBalance = () => {
    const subAccounts = (accounts as any[]).filter(a => !a.isMain);
    const ccyList = (currencies as any[]).filter(c => !c.isBase && c.code !== "YER");

    const rows = subAccounts.map((a: any) => {
      const lines = fLines.filter((l: any) => l.accountId === a.id);
      const dr = lines.reduce((s: number, l: any) => s + Number(l.debit  || 0), 0);
      const cr = lines.reduce((s: number, l: any) => s + Number(l.credit || 0), 0);
      const opening = Number(a.openingBalance || 0);
      const isDebitNormal = a.type === "assets" || a.type === "expenses";
      const balance = isDebitNormal ? opening + dr - cr : opening + cr - dr;
      return { ...a, dr, cr, opening, balance };
    });

    const grandDr  = rows.reduce((s, r) => s + r.dr, 0);
    const grandCr  = rows.reduce((s, r) => s + r.cr, 0);
    const diff     = Math.abs(grandDr - grandCr);
    const balanced = diff < 0.01;

    const typeLabel = (t: string) => {
      if (t === "assets") return { label: "أصول", cls: "bg-blue-900/50 text-blue-300" };
      if (t === "revenue") return { label: "إيرادات", cls: "bg-green-900/50 text-green-300" };
      if (t === "expenses") return { label: "مصروفات", cls: "bg-red-900/50 text-red-300" };
      return { label: "التزامات", cls: "bg-purple-900/50 text-purple-300" };
    };

    const printHtml = `<table><thead><tr>
      <th>كود</th><th>الحساب</th><th>النوع</th><th>رصيد افتتاحي</th><th>مدين</th><th>دائن</th><th>الرصيد</th>
      ${ccyList.map((c: any) => `<th>يكافئ ${c.code}</th>`).join("")}
    </tr></thead><tbody>
    ${rows.map(r => {
      const { label } = typeLabel(r.type);
      return `<tr><td>${r.code||""}</td><td>${r.nameAr}</td><td>${label}</td>
      <td>${fmt(r.opening)}</td><td class="pos">${r.dr>0?fmt(r.dr):"-"}</td><td class="neg">${r.cr>0?fmt(r.cr):"-"}</td>
      <td class="${r.balance>=0?"pos":"neg"}">${fmt(r.balance)}</td>
      ${ccyList.map((c: any) => { const rate = Number(c.exchangeRate||1); const eq = r.balance / rate; return `<td>${fmt(eq)} ${c.code}</td>`; }).join("")}
      </tr>`;
    }).join("")}
    <tr class="tot"><td colspan="4">الإجمالي</td><td>${fmt(grandDr)}</td><td>${fmt(grandCr)}</td>
    <td>${balanced ? "✅ متوازن" : `⚠️ فارق: ${fmt(diff)}`}</td></tr>
    </tbody></table>`;

    return (
      <div className="space-y-4">
        {sectionHdr("ميزان المراجعة", "⚖️", "text-blue-300", () => print("ميزان المراجعة", printHtml))}

        {/* KPIs */}
        <div className="grid grid-cols-3 gap-3">
          {kpi("إجمالي المدين",  `${fmt(grandDr)} ${cur}`, "text-orange-400", TrendingDown)}
          {kpi("إجمالي الدائن", `${fmt(grandCr)} ${cur}`, "text-green-400",  TrendingUp)}
          {kpi("الفارق", balanced ? "صفر — متوازن" : fmt(diff), balanced ? "text-green-400" : "text-red-400", Scale, balanced ? "✅ ميزان متوازن" : "⚠️ يوجد فارق")}
        </div>

        {/* Account search */}
        <div className="relative">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-blue-400" />
          <Input value={accSearch} onChange={e => setAccSearch(e.target.value)} placeholder="بحث في الحسابات..." className="bg-blue-900/20 border-blue-700/50 text-white pr-10" />
        </div>

        {/* Table */}
        <div className="bg-white/5 rounded-2xl border border-white/10 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm min-w-max">
              <thead className="bg-emerald-800/50">
                <tr>
                  <th className="p-3 text-right text-amber-300 w-24">كود</th>
                  <th className="p-3 text-right text-amber-300">اسم الحساب</th>
                  <th className="p-3 text-center text-amber-300 w-24">النوع</th>
                  <th className="p-3 text-center text-amber-300 w-28">رصيد افتتاحي</th>
                  <th className="p-3 text-center text-amber-300 w-28">مجموع المدين</th>
                  <th className="p-3 text-center text-amber-300 w-28">مجموع الدائن</th>
                  <th className="p-3 text-center text-amber-300 w-32">الرصيد الحالي</th>
                  {ccyList.map((c: any) => (
                    <th key={c.id} className="p-3 text-center text-amber-300 w-28">يكافئ {c.code}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {rows.filter(r => !accSearch || r.nameAr?.includes(accSearch) || r.code?.includes(accSearch)).length === 0 ? (
                  <tr><td colSpan={7 + ccyList.length} className="p-8 text-center text-blue-400">لا توجد حسابات فرعية</td></tr>
                ) : rows
                  .filter(r => !accSearch || r.nameAr?.includes(accSearch) || r.code?.includes(accSearch))
                  .map((r: any) => {
                    const { label, cls } = typeLabel(r.type);
                    return (
                      <tr key={r.id} className="border-t border-white/10 hover:bg-white/5">
                        <td className="p-3 text-white/40 font-mono text-xs">{r.code || "—"}</td>
                        <td className="p-3 text-white font-semibold">{r.nameAr}</td>
                        <td className="p-3 text-center"><span className={`text-xs px-2 py-0.5 rounded-full ${cls}`}>{label}</span></td>
                        <td className="p-3 text-center text-white/60 font-mono text-xs">{r.opening !== 0 ? fmt(r.opening) : "—"}</td>
                        <td className="p-3 text-center text-orange-300 font-bold">{r.dr > 0 ? fmt(r.dr) : <span className="text-white/20">—</span>}</td>
                        <td className="p-3 text-center text-green-300 font-bold">{r.cr > 0 ? fmt(r.cr) : <span className="text-white/20">—</span>}</td>
                        <td className="p-3 text-center">
                          <span className={`font-black px-2 py-0.5 rounded-lg ${r.balance >= 0 ? "text-emerald-400 bg-emerald-900/30" : "text-red-400 bg-red-900/30"}`}>{fmt(r.balance)}</span>
                        </td>
                        {ccyList.map((c: any) => {
                          const rate = Number(c.exchangeRate || 1);
                          const eq = r.balance / rate;
                          return (
                            <td key={c.id} className="p-3 text-center text-blue-300 text-xs font-mono">
                              {fmt(eq)} <span className="text-white/30">{c.code}</span>
                            </td>
                          );
                        })}
                      </tr>
                    );
                  })}
                {/* Grand Total Row */}
                <tr className="border-t-2 border-amber-500/50 bg-amber-900/20 font-bold">
                  <td className="p-3 text-amber-300 font-bold" colSpan={4}>الإجمالي</td>
                  <td className="p-3 text-center text-orange-400 font-black">{fmt(grandDr)}</td>
                  <td className="p-3 text-center text-green-400 font-black">{fmt(grandCr)}</td>
                  <td className="p-3 text-center">
                    <span className={`font-black px-2 py-0.5 rounded-lg ${balanced ? "text-green-400 bg-green-900/30" : "text-red-400 bg-red-900/30"}`}>
                      {balanced ? "✅ متوازن" : `⚠️ فارق: ${fmt(diff)}`}
                    </span>
                  </td>
                  {ccyList.map((c: any) => (
                    <td key={c.id} className="p-3 text-center text-white/40 text-xs">—</td>
                  ))}
                </tr>
                {/* Difference explanation */}
                {!balanced && (
                  <tr className="bg-red-900/20">
                    <td colSpan={7 + ccyList.length} className="p-3 text-center">
                      <span className="text-red-400 text-sm font-bold">⚠️ يوجد فارق في الميزان مقداره {fmt(diff)} — يرجى مراجعة القيود المحاسبية</span>
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    );
  };

  // ══════════════════════════════════════════════════════════════════════════
  // 3. قائمة الدخل
  // ══════════════════════════════════════════════════════════════════════════
  const renderIncome = () => {
    const grossProfit = totalSalesRev - totalPurchCost;

    const printHtml = `
      <h2>الإيرادات</h2>
      <table><thead><tr><th>كود</th><th>اسم الحساب</th><th>الرصيد</th></tr></thead><tbody>
      <tr><td>—</td><td>مبيعات البضاعة (فواتير)</td><td class="pos">${fmt(totalSalesRev)}</td></tr>
      ${revenueAccs.map(a => `<tr><td>${a.code||""}</td><td>${a.nameAr}</td><td class="pos">${fmt(getBalance(a))}</td></tr>`).join("")}
      <tr><td>📦</td><td>قيمة المخزون المتبقي (ختامي)</td><td class="pos">${fmt(closingStockValue)}</td></tr>
      <tr class="tot"><td colspan="2">إجمالي الإيرادات</td><td>${fmt(totalRev)}</td></tr>
      </tbody></table>
      <h2>المصروفات</h2>
      <table><thead><tr><th>كود</th><th>اسم الحساب</th><th>الرصيد</th></tr></thead><tbody>
      <tr><td>—</td><td>تكلفة المشتريات (فواتير)</td><td class="neg">${fmt(totalPurchCost)}</td></tr>
      ${expenseAccs.map(a => `<tr><td>${a.code||""}</td><td>${a.nameAr}</td><td class="neg">${fmt(getBalance(a))}</td></tr>`).join("")}
      <tr class="tot"><td colspan="2">إجمالي المصروفات</td><td>${fmt(totalExp)}</td></tr>
      </tbody></table>
      <table><tbody>
      <tr class="tot" style="font-size:15px"><td>${netProfit>=0?"✅ صافي الربح":"❌ صافي الخسارة"}</td>
      <td colspan="2" style="font-size:17px">${fmt(Math.abs(netProfit))} ${cur}</td></tr>
      </tbody></table>`;

    return (
      <div className="space-y-4">
        {sectionHdr("قائمة الدخل", "📊", "text-amber-300", () => print("قائمة الدخل", printHtml))}

        {/* KPIs */}
        <div className="grid grid-cols-3 gap-3">
          {kpi("إجمالي الإيرادات", `${fmt(totalRev)} ${cur}`, "text-emerald-400", TrendingUp)}
          {kpi("إجمالي المصروفات", `${fmt(totalExp)} ${cur}`, "text-orange-400", TrendingDown)}
          {netProfit >= 0
            ? kpi("✅ صافي الربح", `${fmt(netProfit)} ${cur}`, "text-green-400", TrendingUp, "إجمالي الإيرادات − إجمالي المصروفات")
            : kpi("❌ صافي الخسارة", `${fmt(Math.abs(netProfit))} ${cur}`, "text-red-400", TrendingDown, "المصروفات تتجاوز الإيرادات")}
        </div>

        <div className="grid grid-cols-2 gap-4">
          {/* Revenue column */}
          <div className="rounded-2xl border border-emerald-500/30 overflow-hidden">
            <div className="p-3 font-bold text-emerald-300 text-sm flex items-center gap-2 border-b border-emerald-600/30 bg-emerald-900/40">
              <TrendingUp className="w-4 h-4" /> الإيرادات
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-xs">
                <thead className="bg-emerald-900/30">
                  <tr>
                    <th className="p-2 text-right text-emerald-300">كود</th>
                    <th className="p-2 text-right text-emerald-300">الحساب</th>
                    <th className="p-2 text-left text-emerald-300">الرصيد ({cur})</th>
                  </tr>
                </thead>
                <tbody>
                  <tr className="border-b border-white/5">
                    <td className="p-2 text-white/30">—</td>
                    <td className="p-2 text-emerald-200">مبيعات البضاعة <span className="text-white/30">({fSales.length} فاتورة)</span></td>
                    <td className="p-2 text-emerald-400 font-bold text-left">{fmt(totalSalesRev)}</td>
                  </tr>
                  {revenueAccs.map((a: any) => {
                    const bal = getBalance(a);
                    return bal !== 0 ? (
                      <tr key={a.id} className="border-b border-white/5 hover:bg-white/5">
                        <td className="p-2 text-white/30 font-mono">{a.code || "—"}</td>
                        <td className="p-2 text-emerald-200">{a.nameAr}</td>
                        <td className="p-2 text-emerald-400 font-bold text-left">{fmt(bal)}</td>
                      </tr>
                    ) : null;
                  })}
                  {/* المخزون الختامي */}
                  <tr className="border-b border-white/5 bg-amber-900/10">
                    <td className="p-2 text-amber-400">📦</td>
                    <td className="p-2 text-amber-300 font-semibold">قيمة المخزون المتبقي <span className="text-white/30 font-normal">(ختامي)</span></td>
                    <td className="p-2 text-amber-400 font-bold text-left">{fmt(closingStockValue)}</td>
                  </tr>
                  <tr className="border-t-2 border-emerald-500/60 bg-emerald-900/30 font-bold">
                    <td className="p-2 text-emerald-300 font-black" colSpan={2}>إجمالي الإيرادات</td>
                    <td className="p-2 text-emerald-400 font-black text-left text-sm">{fmt(totalRev)}</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>

          {/* Expense column */}
          <div className="rounded-2xl border border-orange-500/30 overflow-hidden">
            <div className="p-3 font-bold text-orange-300 text-sm flex items-center gap-2 border-b border-orange-600/30 bg-orange-900/30">
              <TrendingDown className="w-4 h-4" /> المصروفات
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-xs">
                <thead className="bg-orange-900/20">
                  <tr>
                    <th className="p-2 text-right text-orange-300">كود</th>
                    <th className="p-2 text-right text-orange-300">الحساب</th>
                    <th className="p-2 text-left text-orange-300">الرصيد ({cur})</th>
                  </tr>
                </thead>
                <tbody>
                  <tr className="border-b border-white/5">
                    <td className="p-2 text-white/30">—</td>
                    <td className="p-2 text-orange-200">تكلفة المشتريات <span className="text-white/30">({fPurchases.length} فاتورة)</span></td>
                    <td className="p-2 text-orange-400 font-bold text-left">{fmt(totalPurchCost)}</td>
                  </tr>
                  {expenseAccs.map((a: any) => {
                    const bal = getBalance(a);
                    return bal !== 0 ? (
                      <tr key={a.id} className="border-b border-white/5 hover:bg-white/5">
                        <td className="p-2 text-white/30 font-mono">{a.code || "—"}</td>
                        <td className="p-2 text-orange-200">{a.nameAr}</td>
                        <td className="p-2 text-orange-400 font-bold text-left">{fmt(bal)}</td>
                      </tr>
                    ) : null;
                  })}
                  <tr className="border-t-2 border-orange-500/60 bg-orange-900/20 font-bold">
                    <td className="p-2 text-orange-300 font-black" colSpan={2}>إجمالي المصروفات</td>
                    <td className="p-2 text-orange-400 font-black text-left text-sm">{fmt(totalExp)}</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* Net Profit Summary */}
        <div className={`rounded-2xl p-5 border-2 ${netProfit >= 0 ? "border-green-500/40 bg-green-900/20" : "border-red-500/40 bg-red-900/20"}`}>
          <div className="flex items-center justify-between flex-wrap gap-4">
            <div>
              <p className={`text-xl font-black ${netProfit >= 0 ? "text-green-400" : "text-red-400"}`}>
                {netProfit >= 0 ? "✅ صافي الربح" : "❌ صافي الخسارة"}
              </p>
              <p className="text-white/50 text-sm mt-1">إجمالي الإيرادات ({fmt(totalRev)}) − إجمالي المصروفات ({fmt(totalExp)})</p>
            </div>
            <p className={`text-4xl font-black ${netProfit >= 0 ? "text-green-400" : "text-red-400"}`}>
              {netProfit < 0 ? "( " : ""}{fmt(Math.abs(netProfit))}{netProfit < 0 ? " )" : ""} <span className="text-base">{cur}</span>
            </p>
          </div>
          {/* mujmal ribbon */}
          <div className="mt-4 pt-3 border-t border-white/10 flex justify-between text-sm">
            <span className="text-white/50">مجمل الربح (الإيرادات − تكلفة المشتريات)</span>
            <span className={`font-bold ${grossProfit >= 0 ? "text-blue-300" : "text-red-400"}`}>{fmt(grossProfit)} {cur}</span>
          </div>
        </div>
      </div>
    );
  };

  // ══════════════════════════════════════════════════════════════════════════
  // 4. المركز المالي
  // ══════════════════════════════════════════════════════════════════════════
  const renderBalanceSheet = () => {
    // Use main accounts for display
    const assetRows  = mainAssets.filter(a => a.subType !== null);
    // استبعاد حساب الأرباح والخسائر من القائمة — سيُضاف صافي الربح المحسوب بدلاً منه
    const liabRows   = mainLiabs.filter(a => a.subType !== null && a.subSubType !== "profit_loss");
    const assetTotal = assetRows.reduce((s, a) => s + getBalance(a), 0);
    const liabTotal  = liabRows.reduce((s, a)  => s + getBalance(a), 0) + netProfit;
    const isBalanced = Math.abs(assetTotal - liabTotal) < 1;

    const printHtml = `
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:20px">
    <div>
      <h2>الأصول</h2>
      <table><thead><tr><th>الحساب</th><th>الرصيد</th></tr></thead><tbody>
      ${assetRows.map(a => `<tr><td>${a.nameAr}</td><td class="pos">${fmt(getBalance(a))}</td></tr>`).join("")}
      <tr class="tot"><td>إجمالي الأصول</td><td>${fmt(assetTotal)}</td></tr>
      </tbody></table>
    </div>
    <div>
      <h2>الخصوم وحقوق الملكية</h2>
      <table><thead><tr><th>الحساب</th><th>الرصيد</th></tr></thead><tbody>
      ${liabRows.map(a => `<tr><td>${a.nameAr}</td><td class="neg">${fmt(getBalance(a))}</td></tr>`).join("")}
      <tr><td>صافي الربح (الخسارة)</td><td class="${netProfit>=0?"pos":"neg"}">${fmt(netProfit)}</td></tr>
      <tr class="tot"><td>إجمالي الخصوم + حقوق الملكية</td><td>${fmt(liabTotal)}</td></tr>
      </tbody></table>
      <p style="font-weight:bold;color:${isBalanced?"#059669":"#dc2626"};margin-top:10px">
        ${isBalanced ? "✅ الميزانية متوازنة" : "⚠️ الميزانية غير متوازنة"}</p>
    </div></div>`;

    const typeColor = (subType: string) => {
      if (subType === "fixed_assets") return "border-r-2 border-blue-500 pr-2";
      if (subType === "current_assets") return "border-r-2 border-teal-500 pr-2";
      if (subType === "equity") return "border-r-2 border-purple-500 pr-2";
      if (subType === "current_liabilities") return "border-r-2 border-red-500 pr-2";
      return "border-r-2 border-gray-500 pr-2";
    };

    return (
      <div className="space-y-4">
        {sectionHdr("المركز المالي", "🏛️", "text-purple-300", () => print("المركز المالي", printHtml))}

        {/* Balance status */}
        <div className={`rounded-xl p-3 flex items-center justify-between border ${isBalanced ? "border-green-500/30 bg-green-900/20" : "border-red-500/30 bg-red-900/20"}`}>
          <span className={`font-bold text-sm ${isBalanced ? "text-green-300" : "text-red-300"}`}>
            {isBalanced ? "✅ الميزانية متوازنة — الأصول = الخصوم + حقوق الملكية" : "⚠️ الميزانية غير متوازنة"}
          </span>
          <div className="text-xs text-white/40 text-left">
            أصول: {fmt(assetTotal)} | خصوم+ملكية: {fmt(liabTotal)}
          </div>
        </div>

        {/* KPIs */}
        <div className="grid grid-cols-3 gap-3">
          {kpi("إجمالي الأصول",     `${fmt(assetTotal)} ${cur}`,  "text-blue-400",   Building2)}
          {kpi("إجمالي الخصوم",     `${fmt(liabTotal - netProfit)} ${cur}`, "text-red-400", TrendingDown)}
          {kpi("حقوق الملكية",      `${fmt(totalEquity)} ${cur}`, "text-amber-400",  Coins, "رأس المال + صافي الربح")}
        </div>

        {/* Two columns */}
        <div className="grid grid-cols-2 gap-4">
          {/* Assets */}
          <div className="rounded-2xl border border-blue-500/30 overflow-hidden">
            <div className="p-3 font-bold text-blue-300 text-sm flex items-center gap-2 border-b border-blue-600/30 bg-blue-900/30">
              <Building2 className="w-4 h-4" /> الأصول
            </div>
            <div className="p-3 space-y-1.5">
              {/* Fixed assets group */}
              {assetRows.filter(a => a.subType === "fixed_assets").length > 0 && (
                <p className="text-blue-400 font-bold text-xs mt-1 mb-2 flex items-center gap-1">
                  <span className="w-2 h-2 rounded-full bg-blue-400 inline-block"></span> أصول ثابتة
                </p>
              )}
              {assetRows.filter(a => a.subType === "fixed_assets").map((a: any) => {
                const bal = getBalance(a);
                return <div key={a.id} className="flex justify-between text-xs py-1.5 border-b border-white/5">
                  <span className={`text-white/70 ${typeColor(a.subType)}`}>{a.nameAr}</span>
                  <span className="text-blue-300 font-bold">{fmt(bal)}</span>
                </div>;
              })}
              {/* Current assets group */}
              {assetRows.filter(a => a.subType === "current_assets").length > 0 && (
                <p className="text-teal-400 font-bold text-xs mt-2 mb-2 flex items-center gap-1">
                  <span className="w-2 h-2 rounded-full bg-teal-400 inline-block"></span> أصول متداولة
                </p>
              )}
              {assetRows.filter(a => a.subType === "current_assets").map((a: any) => {
                const bal = getBalance(a);
                return <div key={a.id} className="flex justify-between text-xs py-1.5 border-b border-white/5">
                  <span className={`text-white/70 ${typeColor(a.subType)}`}>{a.nameAr}</span>
                  <span className="text-teal-300 font-bold">{fmt(bal)}</span>
                </div>;
              })}
              {assetRows.length === 0 && <p className="text-white/30 text-xs text-center py-4">لا توجد حسابات أصول رئيسية</p>}
              {/* Total */}
              <div className="pt-2 border-t-2 border-blue-500/50 flex justify-between font-bold text-sm">
                <span className="text-blue-300">إجمالي الأصول</span>
                <span className="text-blue-400 font-black">{fmt(assetTotal)}</span>
              </div>
            </div>
          </div>

          {/* Liabilities + Equity */}
          <div className="rounded-2xl border border-red-500/30 overflow-hidden">
            <div className="p-3 font-bold text-red-300 text-sm flex items-center gap-2 border-b border-red-600/30 bg-red-900/30">
              <Scale className="w-4 h-4" /> الخصوم وحقوق الملكية
            </div>
            <div className="p-3 space-y-1.5">
              {/* Current liabilities */}
              {liabRows.filter(a => a.subType === "current_liabilities").length > 0 && (
                <p className="text-red-400 font-bold text-xs mt-1 mb-2 flex items-center gap-1">
                  <span className="w-2 h-2 rounded-full bg-red-400 inline-block"></span> التزامات متداولة
                </p>
              )}
              {liabRows.filter(a => a.subType === "current_liabilities").map((a: any) => {
                const bal = getBalance(a);
                return <div key={a.id} className="flex justify-between text-xs py-1.5 border-b border-white/5">
                  <span className={`text-white/70 ${typeColor(a.subType)}`}>{a.nameAr}</span>
                  <span className="text-red-300 font-bold">{fmt(bal)}</span>
                </div>;
              })}
              {/* Fixed liabilities */}
              {liabRows.filter(a => a.subType === "fixed_liabilities").length > 0 && (
                <p className="text-orange-400 font-bold text-xs mt-2 mb-2 flex items-center gap-1">
                  <span className="w-2 h-2 rounded-full bg-orange-400 inline-block"></span> التزامات ثابتة
                </p>
              )}
              {liabRows.filter(a => a.subType === "fixed_liabilities").map((a: any) => {
                const bal = getBalance(a);
                return <div key={a.id} className="flex justify-between text-xs py-1.5 border-b border-white/5">
                  <span className={`text-white/70 border-r-2 border-orange-500 pr-2`}>{a.nameAr}</span>
                  <span className="text-orange-300 font-bold">{fmt(bal)}</span>
                </div>;
              })}
              {/* Equity */}
              <p className="text-purple-400 font-bold text-xs mt-2 mb-2 flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-purple-400 inline-block"></span> حقوق الملكية
              </p>
              {liabRows.filter(a => a.subType === "equity").map((a: any) => {
                const bal = getBalance(a);
                return <div key={a.id} className="flex justify-between text-xs py-1.5 border-b border-white/5">
                  <span className={`text-white/70 ${typeColor(a.subType)}`}>{a.nameAr}</span>
                  <span className="text-purple-300 font-bold">{fmt(bal)}</span>
                </div>;
              })}
              {/* صافي الربح (الخسارة) — يُحسب من قائمة الدخل دائماً */}
              <div className="flex justify-between text-xs py-1.5 border-b border-white/5 bg-white/5 px-1 rounded">
                <span className={`font-bold border-r-2 pr-2 ${netProfit >= 0 ? "text-green-300 border-green-500" : "text-red-300 border-red-500"}`}>
                  {netProfit >= 0 ? "صافي الربح" : "صافي الخسارة"}
                </span>
                <span className={`font-black text-sm ${netProfit >= 0 ? "text-green-400" : "text-red-400"}`}>
                  {netProfit < 0 ? "(" : ""}{fmt(Math.abs(netProfit))}{netProfit < 0 ? ")" : ""}
                </span>
              </div>
              {liabRows.length === 0 && <p className="text-white/30 text-xs text-center py-2">لا توجد حسابات خصوم رئيسية</p>}
              {/* Total */}
              <div className="pt-2 border-t-2 border-red-500/50 flex justify-between font-bold text-sm">
                <span className="text-red-300">إجمالي الخصوم + حقوق الملكية</span>
                <span className="text-red-400 font-black">{fmt(liabTotal)}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  };

  // ══════════════════════════════════════════════════════════════════════════
  // 5. تقارير أخرى — sub reports
  // ══════════════════════════════════════════════════════════════════════════
  const renderOtherMenu = () => (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h2 className="text-rose-300 font-bold text-lg">📋 تقارير أخرى</h2>
        <p className="text-white/40 text-sm">اختر تقريراً للعرض</p>
      </div>
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
        {OTHER_RPTS.map((r, i) => (
          <button key={r.id} onClick={() => setOtherRpt(r.id)}
            className={`bg-gradient-to-br ${r.grad} border border-white/10 rounded-2xl p-4 text-right hover:border-white/30 hover:scale-[1.02] transition-all active:scale-[0.98] group`}>
            <div className="flex items-start justify-between mb-2">
              <r.icon className={`w-6 h-6 ${r.color}`} />
              <span className="text-white/20 text-xs font-mono">{i + 1}</span>
            </div>
            <p className={`font-bold text-sm ${r.color} group-hover:text-white transition-colors`}>{r.label}</p>
          </button>
        ))}
      </div>
    </div>
  );

  // ── Remaining Stock ──
  const renderRemainingStock = () => {
    // ─── مصدر واحد للحقيقة: العمليات المخزنية فقط ────────────────────────────
    // المبيعات والمشتريات تُنشئ تلقائياً عمليات مخزنية عند الحفظ
    // لذا نستخدم invOps فقط لتجنب الازدواجية، ونُصنّف حسب الملاحظات
    const rows = (items as any[]).map((it: any) => {
      let purchaseQty = 0, saleQty = 0, supplyQty = 0, adjustQty = 0, issueQty = 0;

      (invOps as any[]).forEach((op: any) => {
        (op.items || []).forEach((line: any) => {
          if (line.itemId !== it.id) return;
          const q   = Number(line.quantity || 0);
          const notes = (op.notes || "").toString();
          if (op.type === "in") {
            // مشتريات تُنشئ type:"in" وتبدأ ملاحظاتها بـ "مشتريات"
            if (notes.includes("مشتريات")) purchaseQty += q;
            else                           supplyQty   += q;
          } else if (op.type === "adjust") {
            adjustQty += q;
          } else if (op.type === "out") {
            // مبيعات تُنشئ type:"out" وتبدأ ملاحظاتها بـ "مبيعات"
            if (notes.includes("مبيعات")) saleQty  += q;
            else                          issueQty  += q;
          }
        });
      });

      const inQty  = purchaseQty + supplyQty + adjustQty;
      const outQty = saleQty + issueQty;
      const rem    = inQty - outQty;
      const cost   = Number(it.costPrice || 0);
      return { ...it, purchaseQty, saleQty, supplyQty, adjustQty, issueQty, inQty, outQty, rem, cost, value: rem * cost };
    });

    // فقط الأصناف التي لها كمية موجودة
    const available = rows.filter(r => r.rem > 0);
    const totalVal  = available.reduce((s, r) => s + r.value, 0);

    // إجماليات حسب نوع العملية (بالكميات × سعر التكلفة)
    const totPurchase = rows.reduce((s, r) => s + r.purchaseQty * r.cost, 0);
    const totSale     = rows.reduce((s, r) => s + r.saleQty     * r.cost, 0);
    const totSupply   = rows.reduce((s, r) => s + r.supplyQty   * r.cost, 0);
    const totAdjust   = rows.reduce((s, r) => s + r.adjustQty   * r.cost, 0);
    const totIssue    = rows.reduce((s, r) => s + r.issueQty    * r.cost, 0);

    return (
      <div className="space-y-4">
        {/* KPIs */}
        <div className="grid grid-cols-3 gap-2">
          {kpi("أصناف موجودة", String(available.length), "text-emerald-400", Package)}
          {kpi("إجمالي قيمة المخزون", `${fmt(totalVal)} ${cur}`, "text-amber-400", Coins)}
          {kpi("أصناف ناقصة", String(rows.filter(r => r.rem < (r.minStock||0) && (r.minStock||0)>0).length), "text-red-400", TrendingDown)}
        </div>

        {/* جدول الكميات الموجودة فقط */}
        <div className="rounded-2xl border border-white/10 overflow-hidden">
          <table className="w-full text-xs">
            <thead className="bg-emerald-800/50">
              <tr>
                <th className="p-2.5 text-right text-amber-300">الصنف</th>
                <th className="p-2.5 text-center text-amber-300">الكمية المتبقية</th>
                <th className="p-2.5 text-center text-amber-300">سعر التكلفة</th>
                <th className="p-2.5 text-center text-amber-300">المبلغ</th>
              </tr>
            </thead>
            <tbody>
              {available.length === 0 && (
                <tr><td colSpan={4} className="p-6 text-center text-white/30">لا توجد أصناف بمخزون متبقٍ</td></tr>
              )}
              {available.map(r => (
                <tr key={r.id} className="border-t border-white/10 hover:bg-white/5">
                  <td className="p-2.5 text-white font-semibold">
                    {r.nameAr} <span className="text-white/30 text-[10px]">{r.unit}</span>
                  </td>
                  <td className="p-2.5 text-center">
                    <span className="font-black text-amber-400 bg-amber-900/20 px-2 py-0.5 rounded">{fmt(r.rem)}</span>
                  </td>
                  <td className="p-2.5 text-center text-white/60">{fmt(r.cost)}</td>
                  <td className="p-2.5 text-center text-emerald-300 font-bold">{fmt(r.value)}</td>
                </tr>
              ))}
              {/* إجمالي */}
              <tr className="border-t-2 border-amber-500/50 bg-amber-900/20">
                <td className="p-2.5 text-amber-300 font-black" colSpan={3}>إجمالي قيمة المخزون المتبقي</td>
                <td className="p-2.5 text-center text-amber-400 font-black text-sm">{fmt(totalVal)}</td>
              </tr>
            </tbody>
          </table>
        </div>

        {/* تفصيل الإجمالي حسب نوع العملية */}
        <div className="rounded-2xl border border-white/10 overflow-hidden">
          <div className="p-3 bg-emerald-900/40 border-b border-white/10 text-amber-300 font-bold text-sm flex items-center gap-2">
            <Package className="w-4 h-4" /> إجمالي المبالغ حسب نوع العملية
          </div>
          <table className="w-full text-xs">
            <thead className="bg-white/5">
              <tr>
                <th className="p-2.5 text-right text-white/60">نوع العملية</th>
                <th className="p-2.5 text-center text-white/60">المبلغ الإجمالي ({cur})</th>
              </tr>
            </thead>
            <tbody>
              <tr className="border-t border-white/10 hover:bg-white/5">
                <td className="p-2.5 font-semibold text-blue-300">📦 مشتريات</td>
                <td className="p-2.5 text-center text-blue-400 font-bold">{fmt(totPurchase)}</td>
              </tr>
              <tr className="border-t border-white/10 hover:bg-white/5">
                <td className="p-2.5 font-semibold text-green-300">🏭 توريد مخزني</td>
                <td className="p-2.5 text-center text-green-400 font-bold">{fmt(totSupply)}</td>
              </tr>
              <tr className="border-t border-white/10 hover:bg-white/5">
                <td className="p-2.5 font-semibold text-purple-300">⚖️ تسوية مخزنية</td>
                <td className="p-2.5 text-center text-purple-400 font-bold">{fmt(totAdjust)}</td>
              </tr>
              <tr className="border-t border-white/10 hover:bg-white/5">
                <td className="p-2.5 font-semibold text-red-300">🛒 مبيعات (تكلفة)</td>
                <td className="p-2.5 text-center text-red-400 font-bold">{fmt(totSale)}</td>
              </tr>
              <tr className="border-t border-white/10 hover:bg-white/5">
                <td className="p-2.5 font-semibold text-orange-300">📤 صرف مخزني</td>
                <td className="p-2.5 text-center text-orange-400 font-bold">{fmt(totIssue)}</td>
              </tr>
              {/* صافي = وارد − صادر */}
              <tr className="border-t-2 border-amber-500/50 bg-amber-900/20">
                <td className="p-2.5 text-amber-300 font-black">صافي قيمة المخزون المتبقي</td>
                <td className="p-2.5 text-center text-amber-400 font-black text-sm">{fmt(totPurchase + totSupply + totAdjust - totSale - totIssue)}</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    );
  };

  // ── Account Balances ──
  const renderAccountBalances = () => {
    const rows = (accounts as any[]).filter(a => !a.isMain).map(a => ({ ...a, balance: getBalance(a) }));
    const totalDr = rows.filter(r => r.type === "assets" || r.type === "expenses").reduce((s, r) => s + r.balance, 0);
    const totalCr = rows.filter(r => r.type === "revenue" || r.type === "liabilities").reduce((s, r) => s + r.balance, 0);
    return (
      <div className="space-y-3">
        <div className="grid grid-cols-2 gap-2">
          {kpi("مدين (أصول+مصروفات)", `${fmt(totalDr)} ${cur}`, "text-orange-400", TrendingDown)}
          {kpi("دائن (إيرادات+خصوم)", `${fmt(totalCr)} ${cur}`, "text-green-400", TrendingUp)}
        </div>
        <div className="rounded-2xl border border-white/10 overflow-hidden">
          <table className="w-full text-xs">
            <thead className="bg-emerald-800/50"><tr>
              <th className="p-2.5 text-right text-amber-300">كود</th>
              <th className="p-2.5 text-right text-amber-300">الحساب</th>
              <th className="p-2.5 text-center text-amber-300">النوع</th>
              <th className="p-2.5 text-center text-amber-300">رصيد افتتاحي</th>
              <th className="p-2.5 text-center text-amber-300">الرصيد الحالي</th>
            </tr></thead>
            <tbody>
              {rows.filter(r => !accSearch || r.nameAr?.includes(accSearch) || r.code?.includes(accSearch)).map(r => (
                <tr key={r.id} className="border-t border-white/10 hover:bg-white/5">
                  <td className="p-2.5 text-white/40 font-mono">{r.code || "—"}</td>
                  <td className="p-2.5 text-white font-semibold">{r.nameAr}</td>
                  <td className="p-2.5 text-center">
                    <span className={`text-xs px-1.5 py-0.5 rounded-full ${r.type === "assets" ? "bg-blue-900/50 text-blue-300" : r.type === "revenue" ? "bg-green-900/50 text-green-300" : r.type === "expenses" ? "bg-red-900/50 text-red-300" : "bg-purple-900/50 text-purple-300"}`}>
                      {r.type === "assets" ? "أصول" : r.type === "revenue" ? "إيرادات" : r.type === "expenses" ? "مصروفات" : "خصوم"}
                    </span>
                  </td>
                  <td className="p-2.5 text-center text-white/50">{fmt(Number(r.openingBalance || 0))}</td>
                  <td className="p-2.5 text-center"><span className={`font-black ${r.balance >= 0 ? "text-emerald-400" : "text-red-400"}`}>{fmt(r.balance)}</span></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    );
  };

  // ── Item Profits ──
  const renderItemProfits = () => {
    const rows = (items as any[]).map((it: any) => {
      const sold = fSales.flatMap((s: any) => (s.items || []).filter((l: any) => l.itemId === it.id));
      const soldQty = sold.reduce((s: number, l: any) => s + Number(l.quantity || 0), 0);
      const soldAmt = sold.reduce((s: number, l: any) => s + Number(l.total || l.quantity * l.price || 0), 0);
      const cost = soldQty * Number(it.costPrice || 0);
      const profit = soldAmt - cost;
      return { ...it, soldQty, soldAmt, cost, profit };
    }).filter(r => r.soldQty > 0).sort((a, b) => b.profit - a.profit);

    const totalProfit = rows.reduce((s, r) => s + r.profit, 0);
    return (
      <div className="space-y-3">
        <div className="grid grid-cols-2 gap-2">
          {kpi("إجمالي الربح", `${fmt(totalProfit)} ${cur}`, "text-green-400", TrendingUp)}
          {kpi("عدد الأصناف المباعة", String(rows.length), "text-amber-400", Package)}
        </div>
        <div className="rounded-2xl border border-white/10 overflow-hidden">
          <table className="w-full text-xs">
            <thead className="bg-emerald-800/50"><tr>
              <th className="p-2.5 text-right text-amber-300">الصنف</th>
              <th className="p-2.5 text-center text-amber-300">الكمية المباعة</th>
              <th className="p-2.5 text-center text-amber-300">إجمالي المبيعات</th>
              <th className="p-2.5 text-center text-amber-300">التكلفة</th>
              <th className="p-2.5 text-center text-amber-300">الربح</th>
            </tr></thead>
            <tbody>
              {rows.length === 0 ? <tr><td colSpan={5} className="p-6 text-center text-emerald-400">لا توجد مبيعات بأصناف في هذه الفترة</td></tr>
              : rows.map(r => {
                return (
                  <tr key={r.id} className="border-t border-white/10 hover:bg-white/5">
                    <td className="p-2.5 text-white font-semibold">{r.nameAr}</td>
                    <td className="p-2.5 text-center text-amber-300 font-bold">{fmt(r.soldQty)}</td>
                    <td className="p-2.5 text-center text-emerald-300 font-bold">{fmt(r.soldAmt)}</td>
                    <td className="p-2.5 text-center text-orange-300 font-bold">{fmt(r.cost)}</td>
                    <td className="p-2.5 text-center"><span className={`font-black px-1.5 py-0.5 rounded ${r.profit >= 0 ? "text-green-400 bg-green-900/20" : "text-red-400 bg-red-900/20"}`}>{fmt(r.profit)}</span></td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    );
  };

  // ── Daily Operations ──
  const renderDailyOps = () => {
    const opsByDate: Record<string, any[]> = {};
    fInvOps.forEach(op => {
      const d = (op.date || "").substring(0, 10);
      if (!opsByDate[d]) opsByDate[d] = [];
      opsByDate[d].push(op);
    });
    return (
      <div className="space-y-3">
        <div className="grid grid-cols-3 gap-2">
          {kpi("عدد العمليات", String(fInvOps.length), "text-orange-400", Activity)}
          {kpi("عمليات توريد", String(fInvOps.filter((o: any) => o.type === "in").length), "text-blue-400", TrendingUp)}
          {kpi("عمليات صرف",  String(fInvOps.filter((o: any) => o.type === "out").length), "text-red-400", TrendingDown)}
        </div>
        {Object.keys(opsByDate).sort().reverse().map(date => (
          <div key={date} className="rounded-xl border border-white/10 overflow-hidden">
            <div className="p-2.5 bg-emerald-900/30 border-b border-white/10 flex items-center gap-2">
              <Calendar className="w-4 h-4 text-amber-400" />
              <span className="text-amber-400 font-bold text-sm">{date}</span>
              <Badge className="bg-emerald-800 text-emerald-200 text-xs border-0">{opsByDate[date].length} عملية</Badge>
            </div>
            <table className="w-full text-xs">
              <tbody>
                {opsByDate[date].map((op: any) => (
                  <tr key={op.id} className="border-t border-white/5 hover:bg-white/5">
                    <td className="p-2.5 text-white/40 font-mono">{op.operationNumber || op.id}</td>
                    <td className="p-2.5"><span className={`px-2 py-0.5 rounded-full text-xs font-bold ${op.type === "in" ? "bg-blue-900/50 text-blue-300" : op.type === "out" ? "bg-red-900/50 text-red-300" : op.type === "transfer" ? "bg-teal-900/50 text-teal-300" : "bg-amber-900/50 text-amber-300"}`}>
                      {op.type === "in" ? "توريد" : op.type === "out" ? "صرف" : op.type === "transfer" ? "تحويل" : "تسوية"}
                    </span></td>
                    <td className="p-2.5 text-white/60">{op.notes || "—"}</td>
                    <td className="p-2.5 text-white/40">{(op.items || []).length} صنف</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ))}
        {Object.keys(opsByDate).length === 0 && <div className="text-center py-8 text-emerald-400">لا توجد عمليات مخزنية في هذه الفترة</div>}
      </div>
    );
  };

  // ── Daily Journal ──
  const renderDailyJournal = () => {
    const byDate: Record<string, any[]> = {};
    fJournal.forEach((e: any) => {
      const d = (e.date || "").substring(0, 10);
      if (!byDate[d]) byDate[d] = [];
      byDate[d].push(e);
    });
    const totalDr = fJournal.reduce((s: number, e: any) => s + Number(e.totalDebit || 0), 0);
    const totalCr = fJournal.reduce((s: number, e: any) => s + Number(e.totalCredit || 0), 0);
    return (
      <div className="space-y-3">
        <div className="grid grid-cols-3 gap-2">
          {kpi("عدد القيود", String(fJournal.length), "text-indigo-400", FileText)}
          {kpi("إجمالي المدين", `${fmt(totalDr)} ${cur}`, "text-orange-400", TrendingDown)}
          {kpi("إجمالي الدائن", `${fmt(totalCr)} ${cur}`, "text-green-400", TrendingUp)}
        </div>
        {Object.keys(byDate).sort().reverse().map(date => (
          <div key={date} className="rounded-xl border border-white/10 overflow-hidden">
            <div className="p-2.5 bg-indigo-900/20 border-b border-white/10 flex items-center gap-2">
              <Calendar className="w-4 h-4 text-indigo-400" />
              <span className="text-indigo-300 font-bold text-sm">{date}</span>
              <Badge className="bg-indigo-900/60 text-indigo-200 text-xs border-0">{byDate[date].length} قيد</Badge>
            </div>
            {byDate[date].map((e: any) => (
              <div key={e.id} className="border-t border-white/5 p-3">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-white/60 text-xs font-mono">{e.entryNumber || e.id}</span>
                  <span className="text-emerald-300 text-xs">{e.description}</span>
                  <div className="flex gap-3 text-xs">
                    <span className="text-orange-300">مدين: {fmt(Number(e.totalDebit || 0))}</span>
                    <span className="text-green-300">دائن: {fmt(Number(e.totalCredit || 0))}</span>
                  </div>
                </div>
                {(e.lines || []).map((l: any, i: number) => {
                  const acc = (accounts as any[]).find((a: any) => a.id === l.accountId);
                  return (
                    <div key={i} className={`flex justify-between text-xs py-1 border-b border-white/5 ${l.debit > 0 ? "pr-4" : "pl-4"}`}>
                      <span className="text-white/60">{acc?.nameAr || `حساب #${l.accountId}`}</span>
                      <div className="flex gap-4">
                        <span className={`font-bold ${Number(l.debit||0) > 0 ? "text-orange-300" : "text-white/20"}`}>{Number(l.debit||0) > 0 ? fmt(Number(l.debit)) : "—"}</span>
                        <span className={`font-bold ${Number(l.credit||0) > 0 ? "text-green-300" : "text-white/20"}`}>{Number(l.credit||0) > 0 ? fmt(Number(l.credit)) : "—"}</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            ))}
          </div>
        ))}
        {Object.keys(byDate).length === 0 && <div className="text-center py-8 text-indigo-400">لا توجد قيود يومية في هذه الفترة</div>}
      </div>
    );
  };

  // ── Fund Movement ──
  const renderFundMovement = () => {
    const fundAccounts = (accounts as any[]).filter(a => !a.isMain && (a.subSubType === "cash" || a.subSubType === "bank"));
    return (
      <div className="space-y-3">
        {fundAccounts.length === 0 ? <div className="text-center py-8 text-green-400">لا توجد حسابات صناديق أو بنوك مضافة</div>
        : fundAccounts.map(acc => {
          const lines = fLines.filter((l: any) => l.accountId === acc.id);
          const inAmt  = lines.reduce((s: number, l: any) => s + Number(l.debit  || 0), 0);
          const outAmt = lines.reduce((s: number, l: any) => s + Number(l.credit || 0), 0);
          const balance = Number(acc.openingBalance || 0) + inAmt - outAmt;
          return (
            <div key={acc.id} className="rounded-xl border border-green-500/30 overflow-hidden">
              <div className="p-3 bg-green-900/20 border-b border-green-600/20 flex justify-between items-center">
                <div className="flex items-center gap-2">
                  {acc.subSubType === "bank" ? <Building2 className="w-4 h-4 text-teal-400" /> : <Wallet className="w-4 h-4 text-green-400" />}
                  <span className="text-green-300 font-bold">{acc.nameAr}</span>
                  <Badge className="bg-green-900/60 text-green-200 text-xs border-0">{acc.subSubType === "bank" ? "بنك" : "صندوق"}</Badge>
                </div>
                <span className={`font-black text-sm ${balance >= 0 ? "text-green-400" : "text-red-400"}`}>{fmt(balance)} {cur}</span>
              </div>
              <div className="p-3 grid grid-cols-3 gap-2 text-center text-xs">
                <div>
                  <p className="text-white/40">الرصيد الافتتاحي</p>
                  <p className="text-white font-bold">{fmt(Number(acc.openingBalance || 0))}</p>
                </div>
                <div>
                  <p className="text-blue-300">إجمالي الوارد</p>
                  <p className="text-blue-400 font-bold">{fmt(inAmt)}</p>
                </div>
                <div>
                  <p className="text-red-300">إجمالي الصادر</p>
                  <p className="text-red-400 font-bold">{fmt(outAmt)}</p>
                </div>
              </div>
              {lines.length > 0 && (
                <div className="border-t border-white/5">
                  <table className="w-full text-xs">
                    <tbody>
                      {lines.slice(0, 10).map((l: any, i: number) => (
                        <tr key={i} className="border-t border-white/5 hover:bg-white/5">
                          <td className="p-2 text-white/50">{l.description || "—"}</td>
                          <td className="p-2 text-center text-blue-300 font-bold">{Number(l.debit||0) > 0 ? fmt(Number(l.debit)) : "—"}</td>
                          <td className="p-2 text-center text-red-300 font-bold">{Number(l.credit||0) > 0 ? fmt(Number(l.credit)) : "—"}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          );
        })}
      </div>
    );
  };

  // ── Account Movement ──
  const renderAccountMovement = () => {
    const subAccs = (accounts as any[]).filter(a => !a.isMain);
    return (
      <div className="space-y-3">
        <div className="relative mb-2">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-purple-400" />
          <Input value={accSearch} onChange={e => setAccSearch(e.target.value)} placeholder="بحث في الحسابات..." className="bg-purple-900/20 border-purple-700/50 text-white pr-10" />
        </div>
        {subAccs.filter(a => !accSearch || a.nameAr?.includes(accSearch) || a.code?.includes(accSearch)).map(acc => {
          const lines = fLines.filter((l: any) => l.accountId === acc.id);
          if (lines.length === 0 && !accSearch) return null;
          const dr = lines.reduce((s: number, l: any) => s + Number(l.debit  || 0), 0);
          const cr = lines.reduce((s: number, l: any) => s + Number(l.credit || 0), 0);
          const bal = getBalance(acc);
          return (
            <div key={acc.id} className="rounded-xl border border-purple-500/20 overflow-hidden">
              <div className="p-2.5 bg-purple-900/20 border-b border-purple-600/20 flex justify-between items-center">
                <span className="text-purple-200 font-bold text-sm">{acc.code} — {acc.nameAr}</span>
                <span className={`font-black text-sm ${bal >= 0 ? "text-emerald-400" : "text-red-400"}`}>{fmt(bal)}</span>
              </div>
              <div className="p-2.5 flex gap-4 text-xs text-center">
                <div><p className="text-white/40">الرصيد الافتتاحي</p><p className="text-white font-bold">{fmt(Number(acc.openingBalance||0))}</p></div>
                <div><p className="text-orange-300">المدين</p><p className="text-orange-400 font-bold">{fmt(dr)}</p></div>
                <div><p className="text-green-300">الدائن</p><p className="text-green-400 font-bold">{fmt(cr)}</p></div>
                <div><p className="text-amber-300">الرصيد</p><p className={`font-black ${bal >= 0 ? "text-amber-400" : "text-red-400"}`}>{fmt(bal)}</p></div>
              </div>
              {lines.length > 0 && (
                <div className="border-t border-white/5">
                  <table className="w-full text-xs">
                    <tbody>
                      {lines.map((l: any, i: number) => (
                        <tr key={i} className="border-t border-white/5 hover:bg-white/5">
                          <td className="p-2 text-white/50 text-xs">{l.description || "—"}</td>
                          <td className="p-2 text-center text-orange-300">{Number(l.debit||0)>0 ? fmt(Number(l.debit)) : "—"}</td>
                          <td className="p-2 text-center text-green-300">{Number(l.credit||0)>0 ? fmt(Number(l.credit)) : "—"}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          );
        })}
        {subAccs.filter(a => !accSearch || a.nameAr?.includes(accSearch) || a.code?.includes(accSearch)).every(acc => {
          const lines = fLines.filter((l: any) => l.accountId === acc.id);
          return lines.length === 0 && !accSearch;
        }) && <div className="text-center py-8 text-purple-400">لا توجد حركة للحسابات في هذه الفترة</div>}
      </div>
    );
  };

  // ── Category Totals ──
  const renderCategoryTotals = () => {
    const cats = ["assets", "liabilities", "revenue", "expenses"];
    const catLabel: Record<string, string> = { assets: "الأصول", liabilities: "الخصوم", revenue: "الإيرادات", expenses: "المصروفات" };
    const catColor: Record<string, string> = { assets: "text-blue-400", liabilities: "text-red-400", revenue: "text-green-400", expenses: "text-orange-400" };
    return (
      <div className="space-y-3">
        <div className="grid grid-cols-2 gap-3">
          {cats.map(cat => {
            const catAccs = (accounts as any[]).filter(a => !a.isMain && a.type === cat);
            const total = catAccs.reduce((s, a) => s + getBalance(a), 0);
            return (
              <div key={cat} className="rounded-2xl border border-white/10 bg-white/5 p-4">
                <p className={`font-bold text-lg mb-2 ${catColor[cat]}`}>{catLabel[cat]}</p>
                <p className={`text-3xl font-black ${catColor[cat]}`}>{fmt(total)}</p>
                <p className="text-white/40 text-xs mt-1">{catAccs.length} حساب</p>
              </div>
            );
          })}
        </div>
        <div className="rounded-2xl border border-white/10 overflow-hidden">
          <table className="w-full text-xs">
            <thead className="bg-emerald-800/50"><tr>
              <th className="p-2.5 text-right text-amber-300">التصنيف</th>
              <th className="p-2.5 text-right text-amber-300">عدد الحسابات</th>
              <th className="p-2.5 text-center text-amber-300">إجمالي الأرصدة</th>
            </tr></thead>
            <tbody>
              {cats.map(cat => {
                const catAccs = (accounts as any[]).filter(a => !a.isMain && a.type === cat);
                const total = catAccs.reduce((s, a) => s + getBalance(a), 0);
                return (
                  <tr key={cat} className="border-t border-white/10 hover:bg-white/5">
                    <td className={`p-2.5 font-bold ${catColor[cat]}`}>{catLabel[cat]}</td>
                    <td className="p-2.5 text-white/60">{catAccs.length} حساب</td>
                    <td className={`p-2.5 text-center font-black ${catColor[cat]}`}>{fmt(total)}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    );
  };

  // ── Currency Diff ──
  const renderCurrencyDiff = () => {
    const baseCur = (currencies as any[]).find((c: any) => c.isBase || c.code === "YER");
    const otherCurs = (currencies as any[]).filter((c: any) => !c.isBase && c.code !== "YER");
    return (
      <div className="space-y-3">
        <div className="rounded-xl border border-amber-600/30 bg-amber-900/20 p-3 flex items-center gap-3">
          <span className="text-2xl">🇾🇪</span>
          <div>
            <p className="text-amber-400 font-bold">العملة الرسمية: الريال اليمني (YER)</p>
            <p className="text-white/50 text-xs">جميع الفوارق تُحسب نسبة إلى الريال اليمني</p>
          </div>
        </div>
        <div className="rounded-2xl border border-white/10 overflow-hidden">
          <table className="w-full text-sm">
            <thead className="bg-emerald-800/50"><tr>
              <th className="p-3 text-right text-amber-300">العملة</th>
              <th className="p-3 text-center text-amber-300">الرمز</th>
              <th className="p-3 text-center text-amber-300">سعر الصرف الحالي</th>
              <th className="p-3 text-center text-amber-300">سعر صرف للشراء (تقديري)</th>
              <th className="p-3 text-center text-amber-300">الفارق</th>
            </tr></thead>
            <tbody>
              {otherCurs.map((c: any) => {
                const rate = Number(c.exchangeRate || 1);
                const buyRate = rate * 0.995;
                const diff = rate - buyRate;
                return (
                  <tr key={c.id} className="border-t border-white/10 hover:bg-white/5">
                    <td className="p-3 text-white font-semibold">{c.nameAr}</td>
                    <td className="p-3 text-center text-amber-400 font-black text-lg">{c.symbol}</td>
                    <td className="p-3 text-center text-white font-bold">{fmt(rate)} ر.ي</td>
                    <td className="p-3 text-center text-blue-300">{fmt(buyRate)} ر.ي</td>
                    <td className="p-3 text-center"><span className="text-yellow-400 font-bold">{fmt(diff)} ر.ي</span></td>
                  </tr>
                );
              })}
              {otherCurs.length === 0 && <tr><td colSpan={5} className="p-6 text-center text-amber-400">لا توجد عملات مضافة غير الريال اليمني</td></tr>}
            </tbody>
          </table>
        </div>
        {/* Currency exchange gains accounts */}
        {(() => {
          const diffAccs = (accounts as any[]).filter(a => a.subSubType === "currency_diff");
          if (diffAccs.length === 0) return null;
          return (
            <div className="rounded-xl border border-yellow-600/30 bg-yellow-900/10 p-3">
              <p className="text-yellow-400 font-bold text-sm mb-2">💱 حسابات فوارق العملات</p>
              {diffAccs.map(a => (
                <div key={a.id} className="flex justify-between text-xs py-1 border-b border-white/5">
                  <span className="text-white/70">{a.nameAr}</span>
                  <span className="text-yellow-400 font-bold">{fmt(getBalance(a))} {cur}</span>
                </div>
              ))}
            </div>
          );
        })()}
      </div>
    );
  };

  // ── Working Capital ──
  const renderWorkingCapital = () => {
    // Aggregate sub-account balances under each main account
    const getMainTotal = (main: any) =>
      (accounts as any[])
        .filter(a => !a.isMain && a.type === main.type && a.subType === main.subType)
        .reduce((s, a) => s + getBalance(a), 0);

    const assetMains = mainAssets.map((m: any) => ({ ...m, total: getMainTotal(m) }));
    const liabMains  = mainLiabs.map((m: any)  => ({ ...m, total: getMainTotal(m) }));

    const ca = assetMains.reduce((s: number, m: any) => s + m.total, 0);
    const cl = liabMains.reduce((s: number, m: any)  => s + m.total, 0);
    const wc = ca - cl;

    return (
      <div className="space-y-3">
        {/* KPI Summary */}
        <div className="grid grid-cols-3 gap-3">
          {kpi("إجمالي الأصول",  `${fmt(ca)} ${cur}`, "text-blue-400",  TrendingUp)}
          {kpi("إجمالي الخصوم",  `${fmt(cl)} ${cur}`, "text-red-400",   TrendingDown)}
          {kpi(wc >= 0 ? "✅ صافي رأس المال" : "❌ عجز رأس المال", `${fmt(Math.abs(wc))} ${cur}`, wc >= 0 ? "text-green-400" : "text-red-400", Coins, wc >= 0 ? "الأصول - الخصوم" : "الخصوم تتجاوز الأصول")}
        </div>

        {/* Unified single list */}
        <div className="rounded-2xl border border-white/10 overflow-hidden">
          <table className="w-full text-sm">
            <thead className="bg-emerald-800/60">
              <tr>
                <th className="p-3 text-right text-amber-300">الحساب الرئيسي</th>
                <th className="p-3 text-center text-amber-300 w-24">النوع</th>
                <th className="p-3 text-center text-amber-300 w-32">الإجمالي</th>
              </tr>
            </thead>
            <tbody>
              {/* Assets section */}
              <tr className="bg-blue-900/40">
                <td colSpan={3} className="px-4 py-2 text-blue-300 font-black text-xs tracking-widest">
                  📊 الأصول
                </td>
              </tr>
              {assetMains.length === 0 ? (
                <tr><td colSpan={3} className="p-4 text-center text-white/30 text-xs">لا توجد حسابات أصول رئيسية</td></tr>
              ) : assetMains.map((m: any) => (
                <tr key={m.id} className="border-t border-white/5 hover:bg-white/5 transition-colors">
                  <td className="p-3 text-white font-semibold">{m.nameAr}</td>
                  <td className="p-3 text-center text-blue-300 text-xs">أصول</td>
                  <td className="p-3 text-center text-blue-400 font-black">{fmt(m.total)} {cur}</td>
                </tr>
              ))}
              <tr className="bg-blue-900/20 border-t-2 border-blue-500/40">
                <td colSpan={2} className="p-3 text-blue-300 font-black">إجمالي الأصول</td>
                <td className="p-3 text-center text-blue-400 font-black text-base">{fmt(ca)} {cur}</td>
              </tr>

              {/* Liabilities section */}
              <tr className="bg-red-900/40 border-t-4 border-white/10">
                <td colSpan={3} className="px-4 py-2 text-red-300 font-black text-xs tracking-widest">
                  📋 الخصوم
                </td>
              </tr>
              {liabMains.length === 0 ? (
                <tr><td colSpan={3} className="p-4 text-center text-white/30 text-xs">لا توجد حسابات خصوم رئيسية</td></tr>
              ) : liabMains.map((m: any) => (
                <tr key={m.id} className="border-t border-white/5 hover:bg-white/5 transition-colors">
                  <td className="p-3 text-white font-semibold">{m.nameAr}</td>
                  <td className="p-3 text-center text-red-300 text-xs">خصوم</td>
                  <td className="p-3 text-center text-red-400 font-black">{fmt(m.total)} {cur}</td>
                </tr>
              ))}
              <tr className="bg-red-900/20 border-t-2 border-red-500/40">
                <td colSpan={2} className="p-3 text-red-300 font-black">إجمالي الخصوم</td>
                <td className="p-3 text-center text-red-400 font-black text-base">{fmt(cl)} {cur}</td>
              </tr>

              {/* Net working capital */}
              <tr className={`border-t-4 ${wc >= 0 ? "border-green-500/60 bg-green-900/25" : "border-red-500/60 bg-red-900/25"}`}>
                <td colSpan={2} className={`p-4 font-black text-base ${wc >= 0 ? "text-green-300" : "text-red-300"}`}>
                  {wc >= 0 ? "✅ صافي رأس المال العامل" : "❌ عجز رأس المال العامل"}
                  <span className="block text-xs font-normal opacity-60 mt-0.5">الأصول — الخصوم</span>
                </td>
                <td className={`p-4 text-center font-black text-2xl ${wc >= 0 ? "text-green-400" : "text-red-400"}`}>
                  {wc < 0 ? "-" : ""}{fmt(Math.abs(wc))} {cur}
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    );
  };

  // ── Client Profit ──
  const renderClientProfit = () => {
    const clientMap: Record<string, { name: string; revenue: number; count: number }> = {};
    fSales.forEach((inv: any) => {
      const name = inv.customerName || inv.clientName || `عميل #${inv.customerId || inv.clientId || "غير محدد"}`;
      if (!clientMap[name]) clientMap[name] = { name, revenue: 0, count: 0 };
      clientMap[name].revenue += Number(inv.total || 0);
      clientMap[name].count += 1;
    });
    const rows = Object.values(clientMap).sort((a, b) => b.revenue - a.revenue);
    const total = rows.reduce((s, r) => s + r.revenue, 0);
    return (
      <div className="space-y-3">
        <div className="grid grid-cols-2 gap-2">
          {kpi("عدد العملاء", String(rows.length), "text-pink-400", Users)}
          {kpi("إجمالي المبيعات", `${fmt(total)} ${cur}`, "text-emerald-400", TrendingUp)}
        </div>
        <div className="rounded-2xl border border-white/10 overflow-hidden">
          <table className="w-full text-sm">
            <thead className="bg-emerald-800/50"><tr>
              <th className="p-3 text-right text-amber-300">#</th>
              <th className="p-3 text-right text-amber-300">اسم العميل</th>
              <th className="p-3 text-center text-amber-300">عدد الفواتير</th>
              <th className="p-3 text-center text-amber-300">إجمالي الإيراد</th>
              <th className="p-3 text-center text-amber-300">النسبة</th>
            </tr></thead>
            <tbody>
              {rows.length === 0 ? <tr><td colSpan={5} className="p-6 text-center text-pink-400">لا توجد فواتير مبيعات في هذه الفترة</td></tr>
              : rows.map((r, i) => (
                <tr key={i} className="border-t border-white/10 hover:bg-white/5">
                  <td className="p-3 text-white/30 text-xs">{i + 1}</td>
                  <td className="p-3 text-white font-semibold">{r.name}</td>
                  <td className="p-3 text-center text-white/60">{r.count}</td>
                  <td className="p-3 text-center text-emerald-400 font-bold">{fmt(r.revenue)}</td>
                  <td className="p-3 text-center">
                    <div className="flex items-center gap-2">
                      <div className="flex-1 bg-white/10 rounded-full h-1.5"><div className="bg-emerald-500 h-1.5 rounded-full" style={{ width: `${(r.revenue / total) * 100}%` }}></div></div>
                      <span className="text-white/50 text-xs w-10 text-right">{((r.revenue / total) * 100).toFixed(1)}%</span>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    );
  };

  // ── Sales By Item ──
  const renderSalesByItem = () => {
    const lines: any[] = [];
    fSales.forEach((inv: any) => (inv.items || []).forEach((l: any) => lines.push({
      invoiceNum: inv.invoiceNumber || inv.id, date: inv.date,
      itemName: l.itemName || l.name || `صنف #${l.itemId}`,
      qty: Number(l.quantity || 0), price: Number(l.price || l.salePrice || 0),
      total: Number(l.total || (l.quantity * (l.price || l.salePrice)) || 0),
      currency: inv.currency || cur,
    })));
    const itemTotals: Record<string, { qty: number; total: number; count: number }> = {};
    lines.forEach(l => { if (!itemTotals[l.itemName]) itemTotals[l.itemName] = { qty: 0, total: 0, count: 0 }; itemTotals[l.itemName].qty += l.qty; itemTotals[l.itemName].total += l.total; itemTotals[l.itemName].count++; });
    const rows = Object.entries(itemTotals).map(([name, v]) => ({ name, ...v })).sort((a, b) => b.total - a.total);
    return (
      <div className="space-y-3">
        <div className="grid grid-cols-2 gap-2">
          {kpi("عدد الأصناف", String(rows.length), "text-rose-400", ShoppingCart)}
          {kpi("إجمالي المبيعات", `${fmt(rows.reduce((s, r) => s + r.total, 0))} ${cur}`, "text-emerald-400", TrendingUp)}
        </div>
        <div className="rounded-2xl border border-white/10 overflow-hidden">
          <table className="w-full text-sm">
            <thead className="bg-emerald-800/50"><tr>
              <th className="p-3 text-right text-amber-300">الصنف</th>
              <th className="p-3 text-center text-amber-300">عدد المرات</th>
              <th className="p-3 text-center text-amber-300">الكمية الإجمالية</th>
              <th className="p-3 text-center text-amber-300">إجمالي المبيعات</th>
            </tr></thead>
            <tbody>
              {rows.length === 0 ? <tr><td colSpan={4} className="p-6 text-center text-rose-400">لا توجد مبيعات بأصناف</td></tr>
              : rows.map((r, i) => (
                <tr key={i} className="border-t border-white/10 hover:bg-white/5">
                  <td className="p-3 text-white font-semibold">{r.name}</td>
                  <td className="p-3 text-center text-white/50">{r.count}</td>
                  <td className="p-3 text-center text-amber-300 font-bold">{fmt(r.qty)}</td>
                  <td className="p-3 text-center text-emerald-400 font-bold">{fmt(r.total)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    );
  };

  // ── Purchases By Item ──
  const renderPurchasesByItem = () => {
    const lines: any[] = [];
    fPurchases.forEach((inv: any) => (inv.items || []).forEach((l: any) => lines.push({
      itemName: l.itemName || l.name || `صنف #${l.itemId}`,
      qty: Number(l.quantity || 0), price: Number(l.price || l.costPrice || 0),
      total: Number(l.total || (l.quantity * (l.price || l.costPrice)) || 0),
    })));
    const itemTotals: Record<string, { qty: number; total: number }> = {};
    lines.forEach(l => { if (!itemTotals[l.itemName]) itemTotals[l.itemName] = { qty: 0, total: 0 }; itemTotals[l.itemName].qty += l.qty; itemTotals[l.itemName].total += l.total; });
    const rows = Object.entries(itemTotals).map(([name, v]) => ({ name, ...v })).sort((a, b) => b.total - a.total);
    return (
      <div className="space-y-3">
        <div className="grid grid-cols-2 gap-2">
          {kpi("عدد الأصناف", String(rows.length), "text-violet-400", Layers)}
          {kpi("إجمالي المشتريات", `${fmt(rows.reduce((s, r) => s + r.total, 0))} ${cur}`, "text-orange-400", TrendingDown)}
        </div>
        <div className="rounded-2xl border border-white/10 overflow-hidden">
          <table className="w-full text-sm">
            <thead className="bg-emerald-800/50"><tr>
              <th className="p-3 text-right text-amber-300">الصنف</th>
              <th className="p-3 text-center text-amber-300">الكمية الإجمالية</th>
              <th className="p-3 text-center text-amber-300">إجمالي المشتريات</th>
            </tr></thead>
            <tbody>
              {rows.length === 0 ? <tr><td colSpan={3} className="p-6 text-center text-violet-400">لا توجد مشتريات بأصناف</td></tr>
              : rows.map((r, i) => (
                <tr key={i} className="border-t border-white/10 hover:bg-white/5">
                  <td className="p-3 text-white font-semibold">{r.name}</td>
                  <td className="p-3 text-center text-amber-300 font-bold">{fmt(r.qty)}</td>
                  <td className="p-3 text-center text-orange-400 font-bold">{fmt(r.total)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    );
  };

  // ── Item Details ──
  const renderItemDetails = () => {
    const rows = (items as any[]).map((it: any) => {
      const salesLines    = fSales.flatMap((s: any) => (s.items || []).filter((l: any) => l.itemId === it.id));
      const purchLines    = fPurchases.flatMap((p: any) => (p.items || []).filter((l: any) => l.itemId === it.id));
      const invInLines    = fInvOps.filter((op: any) => op.type === "in").flatMap((op: any) => (op.items || []).filter((l: any) => l.itemId === it.id));
      const invOutLines   = fInvOps.filter((op: any) => op.type === "out").flatMap((op: any) => (op.items || []).filter((l: any) => l.itemId === it.id));
      const soldQty  = salesLines.reduce((s: number, l: any) => s + Number(l.quantity || 0), 0);
      const soldAmt  = salesLines.reduce((s: number, l: any) => s + Number(l.total || 0), 0);
      const purchQty = purchLines.reduce((s: number, l: any) => s + Number(l.quantity || 0), 0);
      const invIn    = invInLines.reduce((s: number, l: any) => s + Number(l.quantity || 0), 0);
      const invOut   = invOutLines.reduce((s: number, l: any) => s + Number(l.quantity || 0), 0);
      const totalIn  = purchQty + invIn;
      const totalOut = soldQty + invOut;
      const avail    = totalIn - totalOut;
      const profit   = soldAmt - (soldQty * Number(it.costPrice || 0));
      return { ...it, soldQty, soldAmt, purchQty, invIn, invOut, totalIn, totalOut, avail, profit };
    }).filter(r => r.totalIn > 0 || r.totalOut > 0 || !itemSearch);

    return (
      <div className="space-y-3">
        <div className="relative">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-lime-400" />
          <Input value={itemSearch} onChange={e => setItemSearch(e.target.value)} placeholder="بحث في الأصناف..." className="bg-lime-900/20 border-lime-700/50 text-white pr-10" />
        </div>
        <div className="rounded-2xl border border-white/10 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-xs min-w-max">
              <thead className="bg-emerald-800/50">
                <tr>
                  <th className="p-2.5 text-right text-amber-300">الصنف</th>
                  <th className="p-2.5 text-center text-amber-300">الوحدة</th>
                  <th className="p-2.5 text-center text-amber-300">مشتريات</th>
                  <th className="p-2.5 text-center text-amber-300">توريد مخزني</th>
                  <th className="p-2.5 text-center text-amber-300">إجمالي الوارد</th>
                  <th className="p-2.5 text-center text-amber-300">مبيعات</th>
                  <th className="p-2.5 text-center text-amber-300">صرف مخزني</th>
                  <th className="p-2.5 text-center text-amber-300">إجمالي الصادر</th>
                  <th className="p-2.5 text-center text-amber-300">المتاح</th>
                  <th className="p-2.5 text-center text-amber-300">الربح</th>
                </tr>
              </thead>
              <tbody>
                {rows.filter(r => !itemSearch || r.nameAr?.includes(itemSearch) || r.code?.includes(itemSearch)).map(r => (
                  <tr key={r.id} className="border-t border-white/10 hover:bg-white/5">
                    <td className="p-2.5 text-white font-semibold">{r.nameAr}</td>
                    <td className="p-2.5 text-center text-white/40">{r.unit}</td>
                    <td className="p-2.5 text-center text-teal-300">{r.purchQty > 0 ? fmt(r.purchQty) : "—"}</td>
                    <td className="p-2.5 text-center text-blue-300">{r.invIn > 0 ? fmt(r.invIn) : "—"}</td>
                    <td className="p-2.5 text-center text-blue-400 font-bold">{fmt(r.totalIn)}</td>
                    <td className="p-2.5 text-center text-rose-300">{r.soldQty > 0 ? fmt(r.soldQty) : "—"}</td>
                    <td className="p-2.5 text-center text-orange-300">{r.invOut > 0 ? fmt(r.invOut) : "—"}</td>
                    <td className="p-2.5 text-center text-red-400 font-bold">{fmt(r.totalOut)}</td>
                    <td className="p-2.5 text-center"><span className={`font-black px-1.5 py-0.5 rounded ${r.avail >= 0 ? "text-amber-400 bg-amber-900/20" : "text-red-400 bg-red-900/20"}`}>{fmt(r.avail)}</span></td>
                    <td className="p-2.5 text-center"><span className={`font-bold ${r.profit >= 0 ? "text-green-400" : "text-red-400"}`}>{fmt(r.profit)}</span></td>
                  </tr>
                ))}
                {rows.length === 0 && <tr><td colSpan={10} className="p-6 text-center text-lime-400">لا توجد بيانات للأصناف في هذه الفترة</td></tr>}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    );
  };

  // ── Router for other reports ──
  const renderOtherContent = () => {
    const rpt = OTHER_RPTS.find(r => r.id === otherRpt);
    return (
      <div className="space-y-4">
        <div className="flex items-center gap-3 flex-wrap">
          <Button variant="ghost" size="sm" onClick={() => setOtherRpt(null)} className="text-white/50 hover:text-white h-9 gap-1.5 px-3">
            <ArrowLeft className="w-4 h-4" /> رجوع
          </Button>
          <h2 className={`font-bold text-lg ${rpt?.color || "text-white"}`}>{rpt?.label}</h2>
          <div className="flex gap-2 mr-auto">
            <div className="flex items-center gap-1.5 bg-emerald-900/40 border border-emerald-700/40 rounded-xl px-3 py-1.5">
              <span className="text-emerald-400 text-xs">من</span>
              <Input type="date" value={fromDate} onChange={e => setFromDate(e.target.value)} className="bg-transparent border-0 text-white h-7 text-xs p-0 w-28" />
            </div>
            <div className="flex items-center gap-1.5 bg-emerald-900/40 border border-emerald-700/40 rounded-xl px-3 py-1.5">
              <span className="text-emerald-400 text-xs">إلى</span>
              <Input type="date" value={toDate} onChange={e => setToDate(e.target.value)} className="bg-transparent border-0 text-white h-7 text-xs p-0 w-28" />
            </div>
            <Button size="sm" onClick={() => print(rpt?.label || "", "")} className="bg-blue-700 hover:bg-blue-600 text-white gap-1.5 h-9 text-xs px-3">
              <Printer className="w-3.5 h-3.5" /> طباعة
            </Button>
          </div>
        </div>
        {otherRpt === "remaining-stock"   && renderRemainingStock()}
        {otherRpt === "account-balances"  && renderAccountBalances()}
        {otherRpt === "item-profits"      && renderItemProfits()}
        {otherRpt === "daily-ops"         && renderDailyOps()}
        {otherRpt === "daily-journal"     && renderDailyJournal()}
        {otherRpt === "fund-movement"     && renderFundMovement()}
        {otherRpt === "account-movement"  && renderAccountMovement()}
        {otherRpt === "category-totals"   && renderCategoryTotals()}
        {otherRpt === "currency-diff"     && renderCurrencyDiff()}
        {otherRpt === "working-capital"   && renderWorkingCapital()}
        {otherRpt === "client-profit"     && renderClientProfit()}
        {otherRpt === "sales-by-item"     && renderSalesByItem()}
        {otherRpt === "purchases-by-item" && renderPurchasesByItem()}
        {otherRpt === "item-details"      && renderItemDetails()}
      </div>
    );
  };

  // ══════════════════════════════════════════════════════════════════════════
  // MAIN RENDER
  // ══════════════════════════════════════════════════════════════════════════
  return (
    <div className="space-y-5 animate-in fade-in duration-300" dir="rtl">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-amber-400">التقارير</h1>
        <p className="text-emerald-200 mt-1 text-sm">التقارير المالية والمحاسبية الشاملة</p>
      </div>

      {/* Tab navigation */}
      {!tab ? (
        /* Landing — 5 big cards */
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {MAIN_TABS.map(t => (
            <button key={t.id} onClick={() => { setTab(t.id); setOtherRpt(null); }}
              className={`bg-gradient-to-br ${t.grad} border border-white/10 rounded-2xl p-6 text-right hover:border-white/30 hover:scale-[1.02] transition-all active:scale-[0.98] group`}>
              <div className="p-3 rounded-xl bg-black/20 border border-white/10 w-fit mb-4 group-hover:bg-amber-500/20 transition-colors">
                <t.icon className="w-8 h-8 text-amber-300" />
              </div>
              <h3 className="text-xl font-black text-amber-300 mb-1">{t.label}</h3>
              <p className="text-white/50 text-sm">{t.desc}</p>
              <div className="mt-4 flex items-center gap-1 text-white/30 text-xs">
                <span>اضغط للعرض</span><ChevronLeft className="w-3 h-3" />
              </div>
            </button>
          ))}
        </div>
      ) : (
        /* Report content */
        <div className="space-y-4">
          {/* Back + Tab switcher */}
          <div className="flex items-center gap-2 flex-wrap">
            <Button variant="ghost" size="sm" onClick={() => { setTab(null); setOtherRpt(null); }} className="text-white/50 hover:text-white h-9 gap-1.5 px-3">
              <ArrowLeft className="w-4 h-4" /> رجوع
            </Button>
            <div className="flex gap-1 flex-wrap">
              {MAIN_TABS.map(t => (
                <button key={t.id} onClick={() => { setTab(t.id); setOtherRpt(null); }}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${tab === t.id ? "bg-amber-500 text-white" : "border border-white/10 text-emerald-300 hover:bg-white/10"}`}>
                  <t.icon className="w-3.5 h-3.5" />{t.label}
                </button>
              ))}
            </div>
          </div>

          {/* Report content */}
          <div className="bg-white/5 rounded-2xl border border-white/10 p-4">
            {tab === "item-movement" && renderItemMovement()}
            {tab === "trial-balance" && renderTrialBalance()}
            {tab === "income"        && renderIncome()}
            {tab === "balance-sheet" && renderBalanceSheet()}
            {tab === "other"         && (otherRpt ? renderOtherContent() : renderOtherMenu())}
          </div>
        </div>
      )}
    </div>
  );
}
