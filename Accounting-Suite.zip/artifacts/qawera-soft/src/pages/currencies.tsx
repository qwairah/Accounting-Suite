import { useState } from "react";
import { useListCurrencies, useCreateCurrency, useUpdateCurrency, useListAccounts, useUpdateAccount } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { getListCurrenciesQueryKey, getListAccountsQueryKey } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Plus, Edit2, Search, Save, TrendingUp, Globe, ShieldCheck, X, Trash2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

type TabId = "add" | "list" | "ceiling";

const TABS: { id: TabId; label: string; icon: any; color: string }[] = [
  { id: "add",     label: "إضافة عملة",    icon: Plus,        color: "text-amber-400"  },
  { id: "list",    label: "العملات",         icon: Globe,       color: "text-emerald-400"},
  { id: "ceiling", label: "سقف الحسابات",   icon: ShieldCheck, color: "text-blue-400"   },
];

const CURRENCIES_PRESET = [
  { code: "YR",  nameAr: "ريال يمني",      symbol: "ر.ي", rate: 1,    isBase: true  },
  { code: "SAR", nameAr: "ريال سعودي",     symbol: "ر.س", rate: 535,  isBase: false },
  { code: "USD", nameAr: "دولار أمريكي",   symbol: "$",   rate: 1370, isBase: false },
  { code: "EUR", nameAr: "يورو",            symbol: "€",   rate: 1490, isBase: false },
  { code: "GBP", nameAr: "جنيه إسترليني",  symbol: "£",   rate: 1720, isBase: false },
  { code: "AED", nameAr: "درهم إماراتي",   symbol: "د.إ", rate: 373,  isBase: false },
  { code: "KWD", nameAr: "دينار كويتي",    symbol: "د.ك", rate: 4450, isBase: false },
  { code: "EGP", nameAr: "جنيه مصري",      symbol: "ج.م", rate: 28,   isBase: false },
  { code: "TRY", nameAr: "ليرة تركية",     symbol: "₺",   rate: 42,   isBase: false },
  { code: "CNY", nameAr: "يوان صيني",      symbol: "¥",   rate: 190,  isBase: false },
  { code: "JOD", nameAr: "دينار أردني",    symbol: "د.أ", rate: 1930, isBase: false },
  { code: "BHD", nameAr: "دينار بحريني",   symbol: "د.ب", rate: 3640, isBase: false },
  { code: "QAR", nameAr: "ريال قطري",      symbol: "ر.ق", rate: 376,  isBase: false },
  { code: "OMR", nameAr: "ريال عماني",     symbol: "ر.ع", rate: 3560, isBase: false },
  { code: "LYD", nameAr: "دينار ليبي",     symbol: "ل.د", rate: 285,  isBase: false },
  { code: "MAD", nameAr: "درهم مغربي",     symbol: "د.م", rate: 135,  isBase: false },
];

export default function CurrenciesPage() {
  const qc = useQueryClient();
  const { toast } = useToast();
  const { data: currencies = [], isLoading } = useListCurrencies();
  const { data: accounts = [] }              = useListAccounts();
  const createCurrency = useCreateCurrency();
  const updateCurrency = useUpdateCurrency();
  const updateAccount  = useUpdateAccount();

  const [activeTab, setActiveTab] = useState<TabId>("list");
  const [search, setSearch] = useState("");
  const [accSearch, setAccSearch] = useState("");

  // ── Add form ──
  const [form, setForm] = useState({ code: "", nameAr: "", symbol: "", exchangeRate: 1 });
  const setF = (k: string, v: any) => setForm(f => ({ ...f, [k]: v }));

  // ── Full currency edit dialog ──
  const [editCurrency, setEditCurrency] = useState<any>(null);
  const [editCurrencyForm, setEditCurrencyForm] = useState({ code: "", nameAr: "", symbol: "", exchangeRate: 1 });
  const setECF = (k: string, v: any) => setEditCurrencyForm(f => ({ ...f, [k]: v }));

  const openEditCurrency = (c: any) => {
    setEditCurrency(c);
    setEditCurrencyForm({ code: c.code, nameAr: c.nameAr, symbol: c.symbol, exchangeRate: Number(c.exchangeRate) || 1 });
  };

  const handleEditCurrencySave = async () => {
    if (!editCurrencyForm.nameAr.trim()) { toast({ title: "خطأ", description: "اسم العملة مطلوب", variant: "destructive" }); return; }
    if (!editCurrencyForm.code.trim()) { toast({ title: "خطأ", description: "كود العملة مطلوب", variant: "destructive" }); return; }
    const data: any = {
      code: editCurrencyForm.code.toUpperCase().trim(),
      nameAr: editCurrencyForm.nameAr,
      symbol: editCurrencyForm.symbol,
      exchangeRate: editCurrencyForm.exchangeRate,
    };
    await updateCurrency.mutateAsync({ id: editCurrency.id, data });
    qc.invalidateQueries({ queryKey: getListCurrenciesQueryKey() });
    setEditCurrency(null);
    toast({ title: `✅ تم تحديث بيانات ${editCurrencyForm.nameAr}` });
  };

  // ── Inline rate editing ──
  const [editRates, setEditRates] = useState<Record<number, string>>({});

  // ── Ceiling editing per account ──
  const [editCeilings, setEditCeilings] = useState<Record<number, { ceiling: string; enableCeiling: boolean }>>({});

  // ─── Add Currency ───────────────────────────────────────────────────────────
  const handleCreate = async () => {
    if (!form.code || !form.nameAr) { toast({ title: "خطأ", description: "الكود والاسم مطلوبان", variant: "destructive" }); return; }
    const dup = (currencies as any[]).find(c => c.code === form.code);
    if (dup) { toast({ title: "خطأ", description: "هذا الكود مستخدم مسبقاً", variant: "destructive" }); return; }
    const isYER = form.code === "YER";
    await createCurrency.mutateAsync({ data: { code: form.code, nameAr: form.nameAr, symbol: form.symbol, exchangeRate: isYER ? 1 : form.exchangeRate, isBase: isYER } });
    qc.invalidateQueries({ queryKey: getListCurrenciesQueryKey() });
    setForm({ code: "", nameAr: "", symbol: "", exchangeRate: 1 });
    toast({ title: `✅ تمت إضافة عملة ${form.nameAr}` });
    setActiveTab("list");
  };

  const addPreset = async (p: typeof CURRENCIES_PRESET[0]) => {
    const exists = (currencies as any[]).find(c => c.code === p.code);
    if (exists) { toast({ title: "موجودة مسبقاً" }); return; }
    await createCurrency.mutateAsync({ data: { code: p.code, nameAr: p.nameAr, symbol: p.symbol, exchangeRate: p.rate, isBase: p.isBase } });
    qc.invalidateQueries({ queryKey: getListCurrenciesQueryKey() });
    toast({ title: `✅ تمت إضافة ${p.nameAr}` });
  };

  // ─── Delete Currency ─────────────────────────────────────────────────────────
  const [deletingId, setDeletingId] = useState<number | null>(null);
  const handleDeleteCurrency = async (c: any) => {
    if (c.isBase) { toast({ title: "لا يمكن حذف العملة الأساسية", variant: "destructive" }); return; }
    if (!window.confirm(`هل تريد حذف عملة "${c.nameAr}"؟ لا يمكن التراجع عن هذا الإجراء.`)) return;
    setDeletingId(c.id);
    try {
      const res = await fetch(`/api/currencies/${c.id}`, { method: "DELETE" });
      if (!res.ok) { const err = await res.json(); throw new Error(err.error || "فشل الحذف"); }
      qc.invalidateQueries({ queryKey: getListCurrenciesQueryKey() });
      toast({ title: `✅ تم حذف عملة ${c.nameAr}` });
    } catch (e: any) {
      toast({ title: "خطأ", description: e.message, variant: "destructive" });
    } finally { setDeletingId(null); }
  };

  // ─── Save Rate ──────────────────────────────────────────────────────────────
  const saveRate = async (id: number, val: string) => {
    const rate = parseFloat(val);
    if (isNaN(rate) || rate <= 0) { toast({ title: "خطأ", description: "سعر الصرف غير صالح", variant: "destructive" }); return; }
    await updateCurrency.mutateAsync({ id, data: { exchangeRate: rate } });
    qc.invalidateQueries({ queryKey: getListCurrenciesQueryKey() });
    setEditRates(r => { const n = { ...r }; delete n[id]; return n; });
    toast({ title: "✅ تم تحديث السعر" });
  };

  // ─── Save Ceiling ───────────────────────────────────────────────────────────
  const saveCeiling = async (acc: any) => {
    const ec = editCeilings[acc.id];
    if (!ec) return;
    await updateAccount.mutateAsync({ id: acc.id, data: { ...acc, ceiling: parseFloat(ec.ceiling) || 0, enableCeiling: ec.enableCeiling } });
    qc.invalidateQueries({ queryKey: getListAccountsQueryKey() });
    setEditCeilings(p => { const n = { ...p }; delete n[acc.id]; return n; });
    toast({ title: "✅ تم تحديث سقف الحساب" });
  };

  const sorted = (currencies as any[]).slice().sort((a, b) => (a.isBase ? -1 : b.isBase ? 1 : 0));
  const filteredCurrencies = sorted.filter(c => c.nameAr?.includes(search) || c.code?.includes(search) || c.symbol?.includes(search));
  const nonMainAccounts = (accounts as any[]).filter(a => !a.isMain).filter(a => a.nameAr?.includes(accSearch));

  // ═══════════════════════════════════════════════════════════════════════════
  //  TAB 1 — إضافة عملة
  // ═══════════════════════════════════════════════════════════════════════════
  const renderAdd = () => (
    <div className="space-y-5">
      {/* Add custom currency form */}
      <div className="bg-white/5 rounded-2xl border border-white/10 p-5 space-y-4">
        <h3 className="text-amber-400 font-bold text-base flex items-center gap-2">
          <Plus className="w-5 h-5 text-amber-300" /> إضافة عملة جديدة
        </h3>
        <div className="bg-emerald-900/40 rounded-xl p-3 text-xs text-emerald-300 border border-emerald-700/40">
          💡 الريال اليمني (YER) هو العملة الرسمية للنظام وسعر الصرف = 1 ثابت
        </div>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <Label className="text-emerald-200 text-xs font-semibold">كود العملة *</Label>
            <Input value={form.code} onChange={e => setF("code", e.target.value.toUpperCase())} className="bg-emerald-900/60 border-emerald-700 text-white mt-1 h-12 text-base font-bold tracking-widest" placeholder="USD" maxLength={5} dir="ltr" />
          </div>
          <div>
            <Label className="text-emerald-200 text-xs font-semibold">الرمز</Label>
            <Input value={form.symbol} onChange={e => setF("symbol", e.target.value)} className="bg-emerald-900/60 border-emerald-700 text-white mt-1 h-12 text-xl text-center" placeholder="$" maxLength={5} />
          </div>
          <div className="col-span-2">
            <Label className="text-emerald-200 text-xs font-semibold">اسم العملة بالعربي *</Label>
            <Input value={form.nameAr} onChange={e => setF("nameAr", e.target.value)} className="bg-emerald-900/60 border-emerald-700 text-white mt-1 h-12 text-base" placeholder="دولار أمريكي" />
          </div>
          {form.code !== "YER" && (
            <div className="col-span-2">
              <Label className="text-emerald-200 text-xs font-semibold">سعر الصرف (بالريال اليمني)</Label>
              <Input type="number" step="0.01" min="0" value={form.exchangeRate || ""} onChange={e => setF("exchangeRate", parseFloat(e.target.value) || 1)} className="bg-emerald-900/60 border-emerald-700 text-white mt-1 h-12" placeholder="مثال: 535 للريال السعودي" />
              {form.exchangeRate > 0 && (
                <p className="text-emerald-400 text-xs mt-1">1 {form.code || "عملة"} = {form.exchangeRate.toFixed(2)} ريال يمني</p>
              )}
            </div>
          )}
        </div>
        <Button onClick={handleCreate} disabled={createCurrency.isPending || !form.code || !form.nameAr} className="bg-amber-500 hover:bg-amber-400 text-white w-full h-12 font-bold text-base gap-2">
          <Plus className="w-5 h-5" /> {createCurrency.isPending ? "جاري الحفظ..." : "إضافة العملة"}
        </Button>
      </div>

      {/* Quick Preset Currencies */}
      <div className="bg-white/5 rounded-2xl border border-white/10 p-5 space-y-3">
        <h3 className="text-emerald-300 font-bold text-sm flex items-center gap-2">
          <TrendingUp className="w-4 h-4 text-emerald-400" /> إضافة سريعة من العملات الشائعة
        </h3>
        <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 gap-2">
          {CURRENCIES_PRESET.filter(p => !(currencies as any[]).find((c: any) => c.code === p.code)).map(p => (
            <button key={p.code} onClick={() => addPreset(p)}
              className="border border-emerald-700/50 hover:border-amber-500/50 bg-emerald-900/30 hover:bg-emerald-800/50 rounded-xl p-3 flex flex-col items-center gap-1 transition-all group">
              <span className="font-black text-amber-400 text-xl group-hover:text-amber-300">{p.symbol}</span>
              <span className="text-emerald-200 text-xs font-bold">{p.code}</span>
              <span className="text-emerald-400 text-[10px]">{p.nameAr}</span>
            </button>
          ))}
        </div>
        {CURRENCIES_PRESET.every(p => (currencies as any[]).find((c: any) => c.code === p.code)) && (
          <p className="text-center text-emerald-400 text-sm">✅ تم إضافة جميع العملات الشائعة</p>
        )}
      </div>
    </div>
  );

  // ═══════════════════════════════════════════════════════════════════════════
  //  TAB 2 — العملات
  // ═══════════════════════════════════════════════════════════════════════════
  const renderList = () => (
    <div className="space-y-4">
      {/* Search */}
      <div className="relative">
        <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-emerald-400" />
        <Input value={search} onChange={e => setSearch(e.target.value)} placeholder="بحث باسم العملة أو الكود..." className="bg-emerald-900/50 border-emerald-700 text-white pr-10 placeholder:text-emerald-500 h-11" />
      </div>

      <div className="bg-white/5 rounded-2xl border border-white/10 overflow-hidden">
        <div className="p-3 bg-emerald-800/20 border-b border-white/10 flex justify-between items-center">
          <span className="text-amber-400 font-bold text-sm">العملات المضافة ({filteredCurrencies.length})</span>
          <span className="text-white/40 text-xs">اضغط ✏️ لتعديل بيانات العملة</span>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-emerald-800/50">
              <tr>
                <th className="p-3 text-right text-amber-300">كود</th>
                <th className="p-3 text-right text-amber-300">الاسم</th>
                <th className="p-3 text-center text-amber-300">الرمز</th>
                <th className="p-3 text-center text-amber-300">سعر الصرف</th>
                <th className="p-3 text-center text-amber-300">إجراءات</th>
              </tr>
            </thead>
            <tbody>
              {isLoading ? <tr><td colSpan={5} className="p-6 text-center text-emerald-200">جاري التحميل...</td></tr>
              : filteredCurrencies.length === 0 ? <tr><td colSpan={5} className="p-8 text-center text-emerald-300">لا توجد عملات. أضف عملة من تبويب "إضافة عملة"</td></tr>
              : filteredCurrencies.map((c: any) => {
                const isBase = c.isBase;
                const editVal = editRates[c.id];
                return (
                  <tr key={c.id} className="border-t border-white/10 hover:bg-white/5 transition-colors">
                    <td className="p-3">
                      <span className="font-black px-3 py-1 rounded-lg text-sm bg-emerald-800/50 text-white">{c.code}</span>
                    </td>
                    <td className="p-3">
                      <span className="font-semibold text-emerald-100">{c.nameAr}</span>
                    </td>
                    <td className="p-3 text-center">
                      <span className="text-amber-400 font-black text-xl">{c.symbol}</span>
                    </td>
                    <td className="p-3 text-center">
                      {editVal !== undefined ? (
                        <div className="flex items-center justify-center gap-2">
                          <Input type="number" step="0.01" min="0" value={editVal} onChange={e => setEditRates(r => ({ ...r, [c.id]: e.target.value }))}
                            className="bg-emerald-900 border-emerald-600 text-white h-8 w-32 text-sm text-center" autoFocus
                            onKeyDown={e => { if (e.key === "Enter") saveRate(c.id, editVal); if (e.key === "Escape") setEditRates(r => { const n = {...r}; delete n[c.id]; return n; }); }} />
                          <Button size="sm" onClick={() => saveRate(c.id, editVal)} className="bg-amber-500 hover:bg-amber-400 text-white h-8 px-2"><Save className="w-3 h-3" /></Button>
                          <Button size="sm" variant="ghost" onClick={() => setEditRates(r => { const n={...r}; delete n[c.id]; return n; })} className="text-white/40 h-8 px-2"><X className="w-3 h-3" /></Button>
                        </div>
                      ) : (
                        <div className="flex items-center justify-center gap-2">
                          <span className="text-white font-bold">{Number(c.exchangeRate || 1).toLocaleString("ar-YE")}</span>
                          <Button size="sm" variant="ghost" onClick={() => setEditRates(r => ({ ...r, [c.id]: String(c.exchangeRate) }))} className="text-amber-400 h-7 w-7 p-0 hover:bg-amber-500/20">
                            <Edit2 className="w-3 h-3" />
                          </Button>
                        </div>
                      )}
                    </td>
                    <td className="p-3 text-center">
                      <div className="flex items-center justify-center gap-1">
                        <Button size="sm" variant="ghost" onClick={() => openEditCurrency(c)} className="text-amber-400 h-7 w-7 p-0 hover:bg-amber-500/20" title="تعديل بيانات العملة">
                          <Edit2 className="w-3.5 h-3.5" />
                        </Button>
                        {!isBase && (
                          <Button size="sm" variant="ghost" onClick={() => handleDeleteCurrency(c)} disabled={deletingId === c.id} className="text-red-400 h-7 w-7 p-0 hover:bg-red-500/20" title="حذف العملة">
                            <Trash2 className="w-3.5 h-3.5" />
                          </Button>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );

  // ═══════════════════════════════════════════════════════════════════════════
  //  TAB 3 — سقف الحسابات
  // ═══════════════════════════════════════════════════════════════════════════
  const renderCeiling = () => (
    <div className="space-y-4">
      <div className="bg-blue-900/20 border border-blue-700/30 rounded-2xl p-4 flex items-start gap-3">
        <ShieldCheck className="w-5 h-5 text-blue-400 mt-0.5 shrink-0" />
        <div>
          <p className="text-blue-300 font-bold text-sm">سقف الحسابات</p>
          <p className="text-blue-200/70 text-xs leading-relaxed mt-1">
            يمكنك تحديد حد أقصى للرصيد لكل حساب. عند تجاوز الرصيد للسقف المحدد، سيصدر النظام تحذيراً تلقائياً. ضع 0 لعدم وجود حد.
          </p>
        </div>
      </div>

      {/* Search accounts */}
      <div className="relative">
        <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-emerald-400" />
        <Input value={accSearch} onChange={e => setAccSearch(e.target.value)} placeholder="بحث في الحسابات..." className="bg-emerald-900/50 border-emerald-700 text-white pr-10 placeholder:text-emerald-500 h-11" />
      </div>

      <div className="bg-white/5 rounded-2xl border border-white/10 overflow-hidden">
        <div className="p-3 bg-blue-900/20 border-b border-white/10 flex justify-between items-center">
          <span className="text-blue-300 font-bold text-sm flex items-center gap-2"><ShieldCheck className="w-4 h-4" /> سقف الحسابات</span>
          <span className="text-white/40 text-xs">
            {(accounts as any[]).filter(a => !a.isMain && a.enableCeiling).length} حساب لديه سقف
          </span>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-emerald-800/50">
              <tr>
                <th className="p-3 text-right text-amber-300">الحساب</th>
                <th className="p-3 text-right text-amber-300">النوع</th>
                <th className="p-3 text-center text-amber-300 w-24">تفعيل السقف</th>
                <th className="p-3 text-center text-amber-300 w-40">قيمة السقف</th>
                <th className="p-3 text-center text-amber-300 w-24">حفظ</th>
              </tr>
            </thead>
            <tbody>
              {nonMainAccounts.length === 0 ? (
                <tr><td colSpan={5} className="p-8 text-center text-emerald-400">لا توجد حسابات. أضف حسابات من قيود وحسابات.</td></tr>
              ) : nonMainAccounts.map((acc: any) => {
                const isEditing = acc.id in editCeilings;
                const ec = editCeilings[acc.id] || { ceiling: String(acc.ceiling || 0), enableCeiling: acc.enableCeiling };
                const hasLimit = isEditing ? ec.enableCeiling : acc.enableCeiling;
                const ceilVal  = isEditing ? ec.ceiling : String(acc.ceiling || 0);
                const typeLabel = acc.type === "assets" ? "أصول" : acc.type === "liabilities" ? "خصوم" : acc.type === "expenses" ? "مصروفات" : "إيرادات";
                return (
                  <tr key={acc.id} className={`border-t border-white/10 hover:bg-white/5 transition-colors ${hasLimit ? "bg-blue-900/10" : ""}`}>
                    <td className="p-3">
                      <p className="text-white font-semibold">{acc.nameAr}</p>
                      {acc.code && <p className="text-emerald-400 text-xs mt-0.5">{acc.code}</p>}
                    </td>
                    <td className="p-3">
                      <span className={`text-xs px-2 py-0.5 rounded-full ${acc.type === "assets" ? "bg-emerald-900/60 text-emerald-300" : acc.type === "liabilities" ? "bg-red-900/60 text-red-300" : acc.type === "expenses" ? "bg-orange-900/60 text-orange-300" : "bg-blue-900/60 text-blue-300"}`}>
                        {typeLabel}
                      </span>
                    </td>
                    <td className="p-3 text-center">
                      <Switch
                        checked={isEditing ? ec.enableCeiling : acc.enableCeiling}
                        onCheckedChange={v => {
                          setEditCeilings(p => ({ ...p, [acc.id]: { ceiling: isEditing ? ec.ceiling : String(acc.ceiling || 0), enableCeiling: v } }));
                        }}
                      />
                    </td>
                    <td className="p-3">
                      {hasLimit ? (
                        <Input type="number" min="0" step="0.01" value={isEditing ? ec.ceiling : String(acc.ceiling || 0)}
                          onChange={e => setEditCeilings(p => ({ ...p, [acc.id]: { ceiling: e.target.value, enableCeiling: isEditing ? ec.enableCeiling : acc.enableCeiling } }))}
                          className="bg-blue-900/40 border-blue-700/60 text-white h-8 text-sm text-center"
                          placeholder="الحد الأقصى..." />
                      ) : (
                        <span className="text-white/30 text-xs block text-center">بلا حد</span>
                      )}
                    </td>
                    <td className="p-3 text-center">
                      {isEditing ? (
                        <div className="flex gap-1 justify-center">
                          <Button size="sm" onClick={() => saveCeiling(acc)} disabled={updateAccount.isPending} className="bg-blue-600 hover:bg-blue-500 text-white h-8 px-3 text-xs gap-1">
                            <Save className="w-3 h-3" /> حفظ
                          </Button>
                          <Button size="sm" variant="ghost" onClick={() => setEditCeilings(p => { const n={...p}; delete n[acc.id]; return n; })} className="text-white/40 h-8 w-8 p-0"><X className="w-3 h-3" /></Button>
                        </div>
                      ) : (
                        <span className="text-white/30 text-xs">—</span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );

  return (
    <div className="space-y-5 animate-in fade-in duration-300" dir="rtl">
      {/* ── Header ── */}
      <div>
        <h1 className="text-3xl font-bold text-amber-400">العملات</h1>
        <p className="text-emerald-200 mt-1 text-sm">إدارة العملات وأسعار الصرف وسقف الحسابات</p>
      </div>

      {/* ── Tabs ── */}
      <div className="flex gap-2 border-b border-white/10 pb-1">
        {TABS.map(tab => (
          <button key={tab.id} onClick={() => setActiveTab(tab.id)}
            className={`flex items-center gap-2 px-5 py-2.5 rounded-t-xl text-sm font-bold transition-all border-b-2 ${activeTab === tab.id ? `border-amber-500 text-amber-400 bg-white/5` : "border-transparent text-emerald-400 hover:text-white hover:bg-white/5"}`}>
            <tab.icon className={`w-4 h-4 ${activeTab === tab.id ? tab.color : "text-emerald-500"}`} />
            {tab.label}
          </button>
        ))}
      </div>

      {/* ── Content ── */}
      {activeTab === "add"     && renderAdd()}
      {activeTab === "list"    && renderList()}
      {activeTab === "ceiling" && renderCeiling()}

      {/* ── Edit Currency Dialog ── */}
      <Dialog open={!!editCurrency} onOpenChange={v => !v && setEditCurrency(null)}>
        <DialogContent className="max-w-sm text-white border-amber-600" dir="rtl" style={{background: "linear-gradient(135deg, #022c22, #064E3B)"}}>
          <DialogHeader>
            <DialogTitle className="text-amber-400">✏️ تعديل بيانات العملة — {editCurrency?.code}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label className="text-emerald-200 text-xs font-semibold">كود العملة *</Label>
                <Input
                  value={editCurrencyForm.code}
                  onChange={e => setECF("code", e.target.value.toUpperCase().slice(0, 6))}
                  className="bg-emerald-900/60 border-emerald-700 text-white mt-1 h-11 font-mono text-center text-lg font-bold tracking-widest"
                  placeholder="USD"
                  maxLength={6}
                  dir="ltr"
                />
              </div>
              <div>
                <Label className="text-emerald-200 text-xs font-semibold">الرمز</Label>
                <Input value={editCurrencyForm.symbol} onChange={e => setECF("symbol", e.target.value)} className="bg-emerald-900/60 border-emerald-700 text-white mt-1 h-11 text-center text-xl" placeholder="$" maxLength={5} />
              </div>
            </div>
            <div>
              <Label className="text-emerald-200 text-xs font-semibold">اسم العملة بالعربي *</Label>
              <Input value={editCurrencyForm.nameAr} onChange={e => setECF("nameAr", e.target.value)} className="bg-emerald-900/60 border-emerald-700 text-white mt-1 h-11" placeholder="مثال: ريال سعودي" />
            </div>
            <div>
              <Label className="text-emerald-200 text-xs font-semibold">سعر الصرف</Label>
              <Input
                type="number" step="0.01" min="0.01"
                value={editCurrencyForm.exchangeRate || ""}
                onChange={e => setECF("exchangeRate", parseFloat(e.target.value) || 1)}
                className="mt-1 h-11 text-center bg-emerald-900/60 border-amber-600 text-amber-300 font-bold"
              />
              {editCurrencyForm.exchangeRate > 0 && (
                <p className="text-emerald-400 text-xs mt-1">1 {editCurrencyForm.code} = {editCurrencyForm.exchangeRate.toFixed(2)}</p>
              )}
            </div>
            <div className="flex gap-2 pt-2">
              <Button onClick={handleEditCurrencySave} disabled={updateCurrency.isPending} className="flex-1 bg-amber-500 hover:bg-amber-400 text-white h-11 font-bold gap-2">
                <Save className="w-4 h-4" /> {updateCurrency.isPending ? "جاري الحفظ..." : "حفظ التعديلات"}
              </Button>
              <Button variant="ghost" onClick={() => setEditCurrency(null)} className="text-emerald-300 border border-emerald-700 h-11 px-4">إلغاء</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
