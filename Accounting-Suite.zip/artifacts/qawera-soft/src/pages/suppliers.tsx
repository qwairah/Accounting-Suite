import { useState } from "react";
import { useListSuppliers, useCreateSupplier, useDeleteSupplier } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { getListSuppliersQueryKey } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Plus, Trash2 } from "lucide-react";

type SupplierForm = { nameAr: string; code: string; phone: string; address: string; openingBalance: number; };
const defaultForm: SupplierForm = { nameAr: "", code: "", phone: "", address: "", openingBalance: 0 };

export default function SuppliersPage() {
  const qc = useQueryClient();
  const { data: suppliers = [], isLoading } = useListSuppliers();
  const createSupplier = useCreateSupplier();
  const deleteSupplier = useDeleteSupplier();
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState<SupplierForm>(defaultForm);

  const handleSubmit = async () => {
    if (!form.nameAr) return;
    await createSupplier.mutateAsync({ data: { ...form } });
    qc.invalidateQueries({ queryKey: getListSuppliersQueryKey() });
    setOpen(false);
    setForm(defaultForm);
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-amber-400">الموردون</h1>
          <p className="text-emerald-200 mt-1">إدارة بيانات الموردين</p>
        </div>
        <Button onClick={() => setOpen(true)} className="bg-amber-500 hover:bg-amber-600 text-white gap-2">
          <Plus className="w-4 h-4" /> مورد جديد
        </Button>
      </div>

      <div className="bg-white/5 rounded-xl border border-white/10 overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-emerald-800/50">
            <tr>
              <th className="p-3 text-right text-amber-300">الكود</th>
              <th className="p-3 text-right text-amber-300">الاسم</th>
              <th className="p-3 text-right text-amber-300">الجوال</th>
              <th className="p-3 text-right text-amber-300">الرصيد</th>
              <th className="p-3 text-right text-amber-300">حذف</th>
            </tr>
          </thead>
          <tbody>
            {isLoading ? <tr><td colSpan={5} className="p-6 text-center text-emerald-200">جاري التحميل...</td></tr>
            : suppliers.length === 0 ? <tr><td colSpan={5} className="p-6 text-center text-emerald-200">لا يوجد موردون</td></tr>
            : suppliers.map(s => (
              <tr key={s.id} className="border-t border-white/10 hover:bg-white/5">
                <td className="p-3 text-emerald-300 font-mono text-xs">{s.code}</td>
                <td className="p-3 text-white font-bold">{s.nameAr}</td>
                <td className="p-3 text-emerald-200">{s.phone || "-"}</td>
                <td className="p-3 text-amber-300 font-bold">{Number(s.balance).toFixed(2)} ر.س</td>
                <td className="p-3">
                  <Button size="sm" variant="ghost" className="text-red-400 h-8 w-8 p-0"
                    onClick={async () => { await deleteSupplier.mutateAsync({ id: s.id }); qc.invalidateQueries({ queryKey: getListSuppliersQueryKey() }); }}>
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-xl bg-emerald-950 border-emerald-700 text-white" dir="rtl">
          <DialogHeader><DialogTitle className="text-amber-400 text-xl">إضافة مورد جديد</DialogTitle></DialogHeader>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div><Label className="text-emerald-200">اسم المورد *</Label><Input value={form.nameAr} onChange={e => setForm(f => ({ ...f, nameAr: e.target.value }))} className="bg-emerald-900 border-emerald-700 text-white" /></div>
              <div><Label className="text-emerald-200">رقم الجوال</Label><Input value={form.phone} onChange={e => setForm(f => ({ ...f, phone: e.target.value }))} className="bg-emerald-900 border-emerald-700 text-white" /></div>
            </div>
            <div><Label className="text-emerald-200">العنوان</Label><Input value={form.address} onChange={e => setForm(f => ({ ...f, address: e.target.value }))} className="bg-emerald-900 border-emerald-700 text-white" /></div>
            <div><Label className="text-emerald-200">الرصيد الافتتاحي</Label><Input type="number" value={form.openingBalance} onChange={e => setForm(f => ({ ...f, openingBalance: parseFloat(e.target.value) || 0 }))} className="bg-emerald-900 border-emerald-700 text-white" /></div>
            <div className="flex gap-2 pt-2">
              <Button onClick={handleSubmit} disabled={createSupplier.isPending} className="bg-amber-500 hover:bg-amber-600 text-white flex-1">{createSupplier.isPending ? "جاري الحفظ..." : "حفظ"}</Button>
              <Button variant="outline" onClick={() => setOpen(false)} className="border-emerald-600 text-emerald-200">إلغاء</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
