import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Plus, Users, Shield, Edit2, Trash2, Eye, EyeOff, X, ChevronDown, Check } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

type Permission = {
  id: string; label: string; category: string;
};

const allPermissions: Permission[] = [
  { id: "sales_view", label: "عرض المبيعات", category: "المبيعات" },
  { id: "sales_create", label: "إنشاء فواتير مبيعات", category: "المبيعات" },
  { id: "sales_delete", label: "حذف فواتير المبيعات", category: "المبيعات" },
  { id: "purchases_view", label: "عرض المشتريات", category: "المشتريات" },
  { id: "purchases_create", label: "إنشاء فواتير مشتريات", category: "المشتريات" },
  { id: "purchases_delete", label: "حذف فواتير المشتريات", category: "المشتريات" },
  { id: "treasury_view", label: "عرض الصرف والقبض", category: "الصرف والقبض" },
  { id: "treasury_create", label: "إنشاء سندات", category: "الصرف والقبض" },
  { id: "journal_view", label: "عرض القيود", category: "القيود" },
  { id: "journal_create", label: "إنشاء قيود", category: "القيود" },
  { id: "accounts_view", label: "عرض الحسابات", category: "الحسابات" },
  { id: "accounts_create", label: "إنشاء حسابات", category: "الحسابات" },
  { id: "accounts_delete", label: "حذف الحسابات", category: "الحسابات" },
  { id: "items_view", label: "عرض الأصناف", category: "الأصناف" },
  { id: "items_create", label: "إنشاء وتعديل الأصناف", category: "الأصناف" },
  { id: "inventory_view", label: "عرض المخزون", category: "المخزون" },
  { id: "inventory_create", label: "عمليات مخزنية", category: "المخزون" },
  { id: "reports_view", label: "عرض التقارير", category: "التقارير" },
  { id: "reports_print", label: "طباعة وتصدير التقارير", category: "التقارير" },
  { id: "exchange_view", label: "عرض مصارفة العملات", category: "مصارفة العملات" },
  { id: "exchange_create", label: "إجراء عمليات مصارفة", category: "مصارفة العملات" },
  { id: "settings_view", label: "عرض الإعدادات", category: "الإعدادات" },
  { id: "settings_edit", label: "تعديل الإعدادات", category: "الإعدادات" },
  { id: "backup_create", label: "إنشاء نسخ احتياطية", category: "النسخ الاحتياطية" },
  { id: "backup_restore", label: "استرجاع النسخ الاحتياطية", category: "النسخ الاحتياطية" },
];

type AppUser = {
  id: number; name: string; password: string; isActive: boolean;
  isAdmin: boolean; permissions: string[];
  allowedAccounts: string; allowedWarehouses: string;
};

const defaultUser: AppUser = {
  id: 0, name: "", password: "", isActive: true, isAdmin: false,
  permissions: [], allowedAccounts: "الكل", allowedWarehouses: "الكل",
};

const permissionCategories = [...new Set(allPermissions.map(p => p.category))];

export default function UsersPage() {
  const { toast } = useToast();
  const [users, setUsers] = useState<AppUser[]>([
    { id: 1, name: "مدير النظام", password: "735162242", isActive: true, isAdmin: true, permissions: allPermissions.map(p => p.id), allowedAccounts: "الكل", allowedWarehouses: "الكل" },
  ]);
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState<AppUser>({ ...defaultUser });
  const [showPass, setShowPass] = useState(false);
  const [editId, setEditId] = useState<number | null>(null);
  const [expandedCategory, setExpandedCategory] = useState<string | null>(null);
  const set = (k: keyof AppUser, v: any) => setForm(f => ({ ...f, [k]: v }));

  const togglePerm = (permId: string) => {
    setForm(f => ({
      ...f, permissions: f.permissions.includes(permId)
        ? f.permissions.filter(p => p !== permId)
        : [...f.permissions, permId]
    }));
  };

  const toggleCategory = (cat: string) => {
    const catPerms = allPermissions.filter(p => p.category === cat).map(p => p.id);
    const allSelected = catPerms.every(p => form.permissions.includes(p));
    setForm(f => ({
      ...f, permissions: allSelected
        ? f.permissions.filter(p => !catPerms.includes(p))
        : [...new Set([...f.permissions, ...catPerms])]
    }));
  };

  const selectAll = () => setForm(f => ({ ...f, permissions: allPermissions.map(p => p.id) }));
  const clearAll = () => setForm(f => ({ ...f, permissions: [] }));

  const handleSave = () => {
    if (!form.name.trim()) { toast({ title: "أدخل اسم المستخدم", variant: "destructive" }); return; }
    if (!form.password.trim()) { toast({ title: "أدخل كلمة المرور", variant: "destructive" }); return; }
    if (users.length >= 50 && !editId) { toast({ title: "الحد الأقصى 50 مستخدم", variant: "destructive" }); return; }
    if (editId) {
      setUsers(prev => prev.map(u => u.id === editId ? { ...form, id: editId } : u));
      toast({ title: "✅ تم تحديث المستخدم" });
    } else {
      const newUser = { ...form, id: Date.now() };
      setUsers(prev => [...prev, newUser]);
      toast({ title: "✅ تم إنشاء المستخدم" });
    }
    setOpen(false);
    setForm({ ...defaultUser });
    setEditId(null);
  };

  const handleEdit = (user: AppUser) => {
    setForm({ ...user });
    setEditId(user.id);
    setOpen(true);
  };

  const handleDelete = (id: number) => {
    if (id === 1) { toast({ title: "لا يمكن حذف مدير النظام", variant: "destructive" }); return; }
    setUsers(prev => prev.filter(u => u.id !== id));
    toast({ title: "✅ تم حذف المستخدم" });
  };

  return (
    <div className="space-y-4 animate-in fade-in duration-300" dir="rtl">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-amber-400 flex items-center gap-3"><Users className="w-8 h-8" />المستخدمون والصلاحيات</h1>
          <p className="text-emerald-200 mt-1">إدارة المستخدمين وتحديد صلاحياتهم — الحد الأقصى 50 مستخدم</p>
        </div>
        <Button onClick={() => { setForm({ ...defaultUser }); setEditId(null); setOpen(true); }}
          className="bg-amber-500 hover:bg-amber-400 text-white gap-2 h-11 px-5 font-bold">
          <Plus className="w-5 h-5" />مستخدم جديد
        </Button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-3">
        <div className="rounded-xl p-3 border border-white/10 text-center" style={{ background: "rgba(6,78,59,0.3)" }}>
          <p className="text-2xl font-black text-amber-400">{users.length}</p>
          <p className="text-white/40 text-xs">إجمالي المستخدمين</p>
        </div>
        <div className="rounded-xl p-3 border border-white/10 text-center" style={{ background: "rgba(6,78,59,0.3)" }}>
          <p className="text-2xl font-black text-green-400">{users.filter(u => u.isActive).length}</p>
          <p className="text-white/40 text-xs">مستخدم نشط</p>
        </div>
        <div className="rounded-xl p-3 border border-white/10 text-center" style={{ background: "rgba(6,78,59,0.3)" }}>
          <p className="text-2xl font-black text-blue-400">{50 - users.length}</p>
          <p className="text-white/40 text-xs">متبقي من الحصة</p>
        </div>
      </div>

      {/* Users List */}
      <div className="space-y-3">
        {users.map(user => (
          <div key={user.id} className="rounded-2xl border border-white/10 overflow-hidden hover:border-white/20 transition-all"
            style={{ background: "rgba(6,78,59,0.25)" }}>
            <div className="p-4 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className={`w-12 h-12 rounded-2xl flex items-center justify-center border-2 font-black text-lg ${user.isAdmin ? "bg-amber-500/20 border-amber-400/40 text-amber-400" : "bg-emerald-800/40 border-emerald-600/40 text-emerald-300"}`}>
                  {user.name.charAt(0)}
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <p className="text-white font-bold">{user.name}</p>
                    {user.isAdmin && <span className="text-xs px-1.5 py-0.5 bg-amber-500/20 border border-amber-500/30 text-amber-400 rounded-full">مدير</span>}
                    {!user.isActive && <span className="text-xs px-1.5 py-0.5 bg-red-500/20 border border-red-500/30 text-red-400 rounded-full">موقوف</span>}
                  </div>
                  <p className="text-white/40 text-xs mt-0.5">{user.permissions.length} صلاحية | الحسابات: {user.allowedAccounts} | المخازن: {user.allowedWarehouses}</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Switch checked={user.isActive} onCheckedChange={v => setUsers(prev => prev.map(u => u.id === user.id ? { ...u, isActive: v } : u))} />
                <button onClick={() => handleEdit(user)} className="p-2 rounded-xl bg-blue-500/20 border border-blue-500/30 hover:bg-blue-500/40 transition-colors">
                  <Edit2 className="w-4 h-4 text-blue-400" />
                </button>
                {user.id !== 1 && (
                  <button onClick={() => handleDelete(user.id)} className="p-2 rounded-xl bg-red-500/20 border border-red-500/30 hover:bg-red-500/40 transition-colors">
                    <Trash2 className="w-4 h-4 text-red-400" />
                  </button>
                )}
              </div>
            </div>
            {/* Permission badges */}
            <div className="px-4 pb-3 flex flex-wrap gap-1">
              {permissionCategories.map(cat => {
                const catPerms = allPermissions.filter(p => p.category === cat).map(p => p.id);
                const granted = catPerms.filter(p => user.permissions.includes(p)).length;
                if (granted === 0) return null;
                return (
                  <span key={cat} className={`text-xs px-2 py-0.5 rounded-full border ${granted === catPerms.length ? "bg-emerald-500/20 border-emerald-500/30 text-emerald-300" : "bg-amber-500/10 border-amber-500/20 text-amber-400"}`}>
                    {cat} ({granted}/{catPerms.length})
                  </span>
                );
              })}
            </div>
          </div>
        ))}
      </div>

      {/* Add/Edit Dialog */}
      <Dialog open={open} onOpenChange={v => { setOpen(v); if (!v) { setForm({ ...defaultUser }); setEditId(null); } }}>
        <DialogContent className="max-w-2xl text-white border-emerald-700 max-h-[90vh] overflow-y-auto" dir="rtl"
          style={{ background: "linear-gradient(135deg, #022c22, #064E3B)" }}>
          <DialogHeader>
            <DialogTitle className="text-amber-400 text-xl flex items-center gap-2">
              <Users className="w-6 h-6" />{editId ? "تعديل مستخدم" : "إضافة مستخدم جديد"}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-5">
            {/* Basic Info */}
            <div className="grid grid-cols-2 gap-3">
              <div><Label className="text-emerald-200 text-xs">اسم المستخدم *</Label><Input value={form.name} onChange={e => set("name", e.target.value)} className="bg-emerald-900/50 border-emerald-700 text-white mt-1" placeholder="الاسم الكامل..." /></div>
              <div>
                <Label className="text-emerald-200 text-xs">كلمة المرور *</Label>
                <div className="relative mt-1">
                  <Input type={showPass ? "text" : "password"} value={form.password} onChange={e => set("password", e.target.value)} className="bg-emerald-900/50 border-emerald-700 text-white pr-3 pl-10" dir="ltr" />
                  <button onClick={() => setShowPass(v => !v)} className="absolute left-2 top-1/2 -translate-y-1/2 text-white/40 hover:text-white">
                    {showPass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>
              <div><Label className="text-emerald-200 text-xs">الحسابات المسموح بها</Label><Input value={form.allowedAccounts} onChange={e => set("allowedAccounts", e.target.value)} className="bg-emerald-900/50 border-emerald-700 text-white mt-1" placeholder="الكل" /></div>
              <div><Label className="text-emerald-200 text-xs">المخازن المسموح بها</Label><Input value={form.allowedWarehouses} onChange={e => set("allowedWarehouses", e.target.value)} className="bg-emerald-900/50 border-emerald-700 text-white mt-1" placeholder="الكل" /></div>
            </div>
            <div className="flex gap-4">
              <div className="flex items-center gap-2"><Switch checked={form.isActive} onCheckedChange={v => set("isActive", v)} /><span className="text-white text-sm">حساب مفعل</span></div>
              <div className="flex items-center gap-2"><Switch checked={form.isAdmin} onCheckedChange={v => { set("isAdmin", v); if (v) selectAll(); }} /><span className="text-white text-sm">مدير النظام (كل الصلاحيات)</span></div>
            </div>

            {/* Permissions */}
            {!form.isAdmin && (
              <div>
                <div className="flex items-center justify-between mb-3">
                  <Label className="text-amber-300 font-bold flex items-center gap-2"><Shield className="w-4 h-4" />الصلاحيات</Label>
                  <div className="flex gap-2">
                    <button onClick={selectAll} className="text-xs text-emerald-400 hover:text-emerald-300">تحديد الكل</button>
                    <button onClick={clearAll} className="text-xs text-red-400 hover:text-red-300">إلغاء الكل</button>
                  </div>
                </div>
                <div className="space-y-2 max-h-72 overflow-y-auto">
                  {permissionCategories.map(cat => {
                    const catPerms = allPermissions.filter(p => p.category === cat);
                    const allSel = catPerms.every(p => form.permissions.includes(p.id));
                    const someSel = catPerms.some(p => form.permissions.includes(p.id));
                    return (
                      <div key={cat} className="rounded-xl border border-white/10 overflow-hidden">
                        <button onClick={() => setExpandedCategory(expandedCategory === cat ? null : cat)}
                          className="w-full flex items-center justify-between p-3 hover:bg-white/5 transition-colors">
                          <div className="flex items-center gap-2">
                            <div onClick={e => { e.stopPropagation(); toggleCategory(cat); }}
                              className={`w-5 h-5 rounded border-2 flex items-center justify-center transition-colors ${allSel ? "bg-emerald-500 border-emerald-400" : someSel ? "bg-amber-500/50 border-amber-400" : "border-white/30"}`}>
                              {allSel && <Check className="w-3 h-3 text-white" />}
                              {!allSel && someSel && <div className="w-2 h-2 bg-amber-400 rounded-sm" />}
                            </div>
                            <span className="text-white font-semibold text-sm">{cat}</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <span className="text-white/40 text-xs">{catPerms.filter(p => form.permissions.includes(p.id)).length}/{catPerms.length}</span>
                            <ChevronDown className={`w-4 h-4 text-white/40 transition-transform ${expandedCategory === cat ? "rotate-180" : ""}`} />
                          </div>
                        </button>
                        {expandedCategory === cat && (
                          <div className="bg-black/20 p-3 space-y-2">
                            {catPerms.map(perm => (
                              <label key={perm.id} className="flex items-center gap-2 cursor-pointer">
                                <div onClick={() => togglePerm(perm.id)}
                                  className={`w-4 h-4 rounded border-2 flex items-center justify-center transition-colors ${form.permissions.includes(perm.id) ? "bg-emerald-500 border-emerald-400" : "border-white/30 hover:border-white/60"}`}>
                                  {form.permissions.includes(perm.id) && <Check className="w-2.5 h-2.5 text-white" />}
                                </div>
                                <span className={`text-sm ${form.permissions.includes(perm.id) ? "text-white" : "text-white/50"}`}>{perm.label}</span>
                              </label>
                            ))}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            <div className="flex gap-2">
              <Button onClick={handleSave} className="bg-amber-500 hover:bg-amber-400 text-white flex-1 h-11 font-bold">
                ✅ {editId ? "تحديث المستخدم" : "حفظ المستخدم"}
              </Button>
              <Button variant="outline" onClick={() => setOpen(false)} className="border-emerald-600 text-emerald-200 h-11">إلغاء</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
