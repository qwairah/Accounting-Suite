import React, { useState, useMemo } from "react";
import { useListItems, useListSuppliers, useListCurrencies } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Plus, Trash2, Printer, Save, ShoppingCart, X, MessageCircle, MoreVertical, Camera, ArrowLeft } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useSettings } from "@/contexts/SettingsContext";
import { sendWhatsApp, printDocument } from "@/lib/printUtils";
import { Link } from "wouter";

type LineItem = { id: number; itemId: string; itemName: string; qty: number; price: number; total: number };

export default function PurchaseOrderPage() {
  const { data: items = [] } = useListItems();
  const { data: suppliers = [] } = useListSuppliers();
  const { data: currencies = [] } = useListCurrencies();
  const { toast } = useToast();
  const { settings } = useSettings();

  const [orderNo, setOrderNo] = useState(1);
  const [date, setDate] = useState(new Date().toISOString().split("T")[0]);
  const [expectedDate, setExpectedDate] = useState("");
  const [supplierId, setSupplierId] = useState("");
  const [supplierSearch, setSupplierSearch] = useState("");
  const [currencyId, setCurrencyId] = useState("");
  const [notes, setNotes] = useState("");
  const [discount, setDiscount] = useState(0);
  const [lines, setLines] = useState<LineItem[]>([]);
  const [nextLine, setNextLine] = useState(1);

  const selectedSupplier = (suppliers as any[]).find(s => String(s.id) === supplierId);
  const selectedCurrency = (currencies as any[]).find(c => String(c.id) === currencyId);
  const subtotal = useMemo(() => lines.reduce((s, l) => s + l.total, 0), [lines]);
  const total = subtotal - discount;

  const addLine = () => {
    setLines(prev => [...prev, { id: nextLine, itemId: "", itemName: "", qty: 1, price: 0, total: 0 }]);
    setNextLine(n => n + 1);
  };

  const updateLine = (id: number, field: string, value: any) => {
    setLines(prev => prev.map(l => {
      if (l.id !== id) return l;
      const updated = { ...l, [field]: value };
      if (field === "itemId") {
        const item = (items as any[]).find(i => String(i.id) === value);
        if (item) { updated.itemName = item.nameAr; updated.price = Number(item.costPrice || 0); }
      }
      if (field === "qty" || field === "price" || field === "itemId") {
        updated.total = parseFloat(((field === "qty" ? value : updated.qty) * (field === "price" ? value : updated.price)).toFixed(2));
      }
      return updated;
    }));
  };

  const handlePrint = () => {
    printDocument(
      `طلب شراء رقم: ${orderNo}`,
      [
        { label: "التاريخ", value: date },
        { label: "تاريخ التسليم المتوقع", value: expectedDate || "-" },
        { label: "المورد", value: selectedSupplier?.nameAr || "-" },
        { label: "العملة", value: selectedCurrency?.nameAr || "ريال سعودي" },
      ],
      ["#", "اسم الصنف", "الكمية", "سعر التكلفة", "الإجمالي"],
      lines.map((l, i) => [String(i + 1), l.itemName, String(l.qty), l.price.toFixed(2), l.total.toFixed(2)]),
      [
        { label: "المجموع", value: subtotal.toFixed(2) },
        { label: "الخصم", value: discount.toFixed(2) },
        { label: "الإجمالي النهائي", value: total.toFixed(2) },
      ],
      settings,
      notes ? `ملاحظات: ${notes}` : ""
    );
  };

  const handleWhatsApp = () => {
    if (!selectedSupplier?.phone) { toast({ title: "لا يوجد رقم جوال للمورد", variant: "destructive" }); return; }
    const itemsList = lines.map((l, i) => `${i + 1}. ${l.itemName} — الكمية: ${l.qty}`).join("\n");
    const msg = `${settings.msgPrefix}\n*طلب شراء رقم: ${orderNo}*\n🚚 المورد: ${selectedSupplier.nameAr}\n📦 الأصناف:\n${itemsList}\n💰 الإجمالي: ${total.toFixed(2)} ${selectedCurrency?.code || "ر.س"}\n📅 التسليم المتوقع: ${expectedDate || "-"}\n${notes ? "ملاحظة: " + notes : ""}\n${settings.msgSuffix}`;
    sendWhatsApp(selectedSupplier.phone, msg);
  };

  return (
    <div className="space-y-4 animate-in fade-in duration-300" dir="rtl">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Link href="/items"><button className="p-2 rounded-xl bg-white/10 hover:bg-white/20"><ArrowLeft className="w-5 h-5 text-white" /></button></Link>
          <div>
            <h1 className="text-2xl font-bold text-amber-400 flex items-center gap-2"><ShoppingCart className="w-6 h-6" />طلب شراء</h1>
            <p className="text-emerald-200 text-sm">إنشاء طلب شراء وإرساله للمورد</p>
          </div>
        </div>
        <div className="flex gap-2">
          <button onClick={() => {}} className="p-2 rounded-xl bg-white/10 hover:bg-white/20"><MoreVertical className="w-5 h-5 text-white/60" /></button>
          <button onClick={handleWhatsApp} className="p-2 rounded-xl bg-green-700/60 hover:bg-green-600/80 border border-green-600/30"><MessageCircle className="w-5 h-5 text-green-400" /></button>
          <button onClick={handlePrint} className="p-2 rounded-xl bg-blue-700/60 hover:bg-blue-600/80 border border-blue-600/30"><Printer className="w-5 h-5 text-blue-400" /></button>
          <Button onClick={() => toast({ title: "✅ تم حفظ طلب الشراء" })} className="bg-amber-500 hover:bg-amber-400 text-white gap-2 h-9"><Save className="w-4 h-4" />حفظ</Button>
        </div>
      </div>

      <div className="rounded-2xl border border-teal-500/20 p-5 space-y-4" style={{ background: "rgba(6,78,59,0.25)" }}>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
          <div><Label className="text-emerald-200 text-xs">رقم طلب الشراء</Label><Input type="number" value={orderNo} onChange={e => setOrderNo(parseInt(e.target.value))} className="bg-emerald-900/50 border-emerald-700 text-white mt-1 font-bold" /></div>
          <div><Label className="text-emerald-200 text-xs">تاريخ الطلب</Label><Input type="date" value={date} onChange={e => setDate(e.target.value)} className="bg-emerald-900/50 border-emerald-700 text-white mt-1" /></div>
          <div><Label className="text-emerald-200 text-xs">تاريخ التسليم المتوقع</Label><Input type="date" value={expectedDate} onChange={e => setExpectedDate(e.target.value)} className="bg-emerald-900/50 border-emerald-700 text-white mt-1" /></div>
          <div>
            <Label className="text-emerald-200 text-xs">العملة</Label>
            <Select value={currencyId} onValueChange={setCurrencyId}>
              <SelectTrigger className="bg-emerald-900/50 border-emerald-700 text-white mt-1"><SelectValue placeholder="ريال سعودي" /></SelectTrigger>
              <SelectContent className="bg-emerald-900 border-emerald-700">
                {(currencies as any[]).map(c => <SelectItem key={c.id} value={String(c.id)} className="text-white">{c.code} — {c.nameAr}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div className="col-span-2">
            <Label className="text-emerald-200 text-xs">المورد</Label>
            <Select value={supplierId} onValueChange={setSupplierId}>
              <SelectTrigger className="bg-emerald-900/50 border-emerald-700 text-white mt-1"><SelectValue placeholder="اختر المورد..." /></SelectTrigger>
              <SelectContent className="bg-emerald-900 border-emerald-700">
                <div className="p-2"><Input value={supplierSearch} onChange={e => setSupplierSearch(e.target.value)} placeholder="بحث..." className="bg-emerald-800 border-emerald-600 text-white h-8 text-sm" /></div>
                {(suppliers as any[]).filter(s => !supplierSearch || s.nameAr?.includes(supplierSearch)).map(s => <SelectItem key={s.id} value={String(s.id)} className="text-white">{s.nameAr}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div className="col-span-2">
            <Label className="text-emerald-200 text-xs">ملاحظات / شروط الطلب</Label>
            <div className="flex gap-2 mt-1">
              <Textarea value={notes} onChange={e => setNotes(e.target.value)} className="bg-emerald-900/50 border-emerald-700 text-white resize-none h-9 py-1.5" placeholder="شروط الدفع، التسليم..." />
              <button className="p-2 rounded-xl bg-white/10 hover:bg-white/20 shrink-0"><Camera className="w-5 h-5 text-amber-400" /></button>
            </div>
          </div>
        </div>

        <div>
          <div className="flex items-center justify-between mb-2">
            <Label className="text-amber-300 font-bold">الأصناف المطلوبة</Label>
            <Button type="button" size="sm" onClick={addLine} className="bg-teal-700 hover:bg-teal-600 text-white gap-1 h-8"><Plus className="w-3 h-3" />إضافة صنف</Button>
          </div>
          <div className="rounded-xl border border-white/10 overflow-hidden">
            <table className="w-full text-sm">
              <thead><tr style={{ background: "#064E3B" }}>
                <th className="p-2 text-right text-amber-300 text-xs">#</th>
                <th className="p-2 text-right text-amber-300 text-xs">اسم الصنف</th>
                <th className="p-2 text-right text-amber-300 text-xs">الكمية</th>
                <th className="p-2 text-right text-amber-300 text-xs">سعر التكلفة</th>
                <th className="p-2 text-right text-amber-300 text-xs">الإجمالي</th>
                <th className="p-2"></th>
              </tr></thead>
              <tbody>
                {lines.length === 0 && <tr><td colSpan={6} className="p-6 text-center text-emerald-400 text-sm">اضغط "إضافة صنف" للبدء</td></tr>}
                {lines.map((line, i) => (
                  <tr key={line.id} className="border-b border-white/5">
                    <td className="p-2 text-white/40 text-xs text-center">{i + 1}</td>
                    <td className="p-2">
                      <Select value={line.itemId} onValueChange={v => updateLine(line.id, "itemId", v)}>
                        <SelectTrigger className="bg-transparent border-emerald-700/50 text-white h-8 text-xs"><SelectValue placeholder="اختر الصنف..." /></SelectTrigger>
                        <SelectContent className="bg-emerald-900 border-emerald-700">
                          {(items as any[]).map(it => <SelectItem key={it.id} value={String(it.id)} className="text-white text-xs">{it.nameAr}</SelectItem>)}
                        </SelectContent>
                      </Select>
                    </td>
                    <td className="p-2"><Input type="number" step="0.01" value={line.qty} onChange={e => updateLine(line.id, "qty", parseFloat(e.target.value) || 0)} className="bg-transparent border-emerald-700/50 text-white h-8 text-xs text-center w-16" /></td>
                    <td className="p-2"><Input type="number" step="0.01" value={line.price} onChange={e => updateLine(line.id, "price", parseFloat(e.target.value) || 0)} className="bg-transparent border-emerald-700/50 text-white h-8 text-xs text-center w-24" /></td>
                    <td className="p-2 text-teal-400 font-bold text-xs">{line.total.toFixed(2)}</td>
                    <td className="p-2"><button onClick={() => setLines(p => p.filter(l => l.id !== line.id))} className="text-red-400 hover:text-red-300"><X className="w-4 h-4" /></button></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <div className="flex justify-end">
          <div className="space-y-2 min-w-64">
            <div className="flex justify-between text-sm"><span className="text-white/60">المجموع الفرعي:</span><span className="text-white font-bold">{subtotal.toFixed(2)}</span></div>
            <div className="flex justify-between items-center text-sm">
              <span className="text-white/60">الخصم:</span>
              <Input type="number" step="0.01" value={discount} onChange={e => setDiscount(parseFloat(e.target.value) || 0)} className="bg-emerald-900/50 border-emerald-700 text-white h-7 text-xs w-28 text-center" />
            </div>
            <div className="flex justify-between text-base font-black border-t border-teal-500/30 pt-2">
              <span className="text-teal-300">الإجمالي النهائي:</span>
              <span className="text-teal-400 text-lg">{total.toFixed(2)} {selectedCurrency?.code || "ر.س"}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
