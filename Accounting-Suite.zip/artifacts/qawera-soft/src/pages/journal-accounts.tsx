import React, { useState } from "react";
import { Link } from "wouter";
import { PenLine, Plus, BookOpen, Lock, TrendingDown, ChevronLeft } from "lucide-react";
import { useListAccounts, useCreateAccount, useListJournalEntries } from "@workspace/api-client-react";
import { useQueryClient, useMutation } from "@tanstack/react-query";
import { getListAccountsQueryKey, getListJournalEntriesQueryKey } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";

// ── ثوابت التصنيف ─────────────────────────────────────────────────────────
const subTypes: Record<string, { value: string; label: string }[]> = {
  assets:      [{ value: "fixed_assets", label: "1-1 أصول ثابتة" }, { value: "current_assets", label: "1-2 أصول متداولة" }],
  liabilities: [{ value: "fixed_liabilities", label: "2-1 التزامات ثابتة" }, { value: "current_liabilities", label: "2-2 التزامات متداولة" }, { value: "equity", label: "2-3 حقوق الملكية" }],
  expenses:    [{ value: "activity_costs", label: "3-1 تكاليف النشاط" }, { value: "admin_expenses", label: "3-2 مصاريف إدارية" }],
  revenue:     [{ value: "activity_revenue", label: "4-1 إيرادات النشاط" }, { value: "other_revenue", label: "4-2 إيرادات أخرى" }],
};
const subSubTypes: Record<string, { value: string; label: string }[]> = {
  current_assets:     [{ value: "cash", label: "الصناديق" }, { value: "bank", label: "البنوك" }, { value: "customer", label: "العملاء" }, { value: "inventory", label: "المخزون" }],
  current_liabilities:[{ value: "supplier", label: "الموردون" }, { value: "creditor", label: "الدائنون" }, { value: "other", label: "أخرى" }],
  equity:             [{ value: "capital", label: "رأس المال" }, { value: "shareholders", label: "المساهمون" }, { value: "drawings", label: "المسحوبات" }, { value: "profit_loss", label: "الأرباح والخسائر" }],
  activity_costs:     [{ value: "purchases", label: "المشتريات" }, { value: "sales_returns", label: "مردودات المبيعات" }, { value: "cost_of_sales", label: "تكلفة المبيعات" }, { value: "discount_allowed", label: "الخصم المسموح به" }, { value: "inv_settle", label: "تسوية المخزون" }, { value: "damaged", label: "الأصناف التالفة" }],
  activity_revenue:   [{ value: "sales", label: "المبيعات" }, { value: "purch_returns", label: "مردودات المشتريات" }, { value: "disc_earned", label: "الخصم المكتسب" }, { value: "currency_diff", label: "فوارق بيع وشراء العملات" }],
};

type AccForm = {
  nameAr: string; code: string; type: string; subType: string; subSubType: string;
  phone: string; address: string; relatives: string; openingBalance: number;
  enableWhatsapp: boolean; enableSms: boolean; enableTelegram: boolean;
  ceiling: number; enableCeiling: boolean;
};
const defaultAccForm: AccForm = {
  nameAr: "", code: "", type: "assets", subType: "current_assets", subSubType: "customer",
  phone: "", address: "", relatives: "", openingBalance: 0,
  enableWhatsapp: true, enableSms: false, enableTelegram: false, ceiling: 0, enableCeiling: false,
};

type OpeningLine = { accountId: string; side: "debit" | "credit"; amount: number; note: string };

// ── بطاقات القسم ────────────────────────────────────────────────────────────
const CARDS = [
  {
    id: "opening",
    icon: TrendingDown,
    label: "قيد افتتاحي",
    desc: "تسجيل الأرصدة الافتتاحية لبداية الفترة المحاسبية",
    gradient: "from-emerald-700 to-emerald-600",
    iconColor: "text-emerald-200",
    badge: "مهم",
    badgeColor: "bg-emerald-500/30 text-emerald-200",
  },
  {
    id: "add-account",
    icon: Plus,
    label: "إضافة حساب",
    desc: "إنشاء حساب جديد في دليل الحسابات",
    gradient: "from-teal-700 to-teal-600",
    iconColor: "text-teal-200",
    badge: null,
    badgeColor: "",
  },
  {
    id: "chart",
    icon: BookOpen,
    label: "دليل الحسابات",
    desc: "عرض وإدارة شجرة الحسابات بالكاملة",
    gradient: "from-blue-700 to-blue-600",
    iconColor: "text-blue-200",
    badge: null,
    badgeColor: "",
  },
  {
    id: "annual-close",
    icon: Lock,
    label: "إقفال سنوي",
    desc: "إقفال الحسابات وترحيل صافي الأرباح والخسائر إلى رأس المال",
    gradient: "from-red-900 to-red-800",
    iconColor: "text-red-200",
    badge: "تحذير",
    badgeColor: "bg-red-500/30 text-red-200",
  },
];

export default function JournalAccountsPage() {
  const qc = useQueryClient();
  const createAccount = useCreateAccount();
  const { data: accounts = [] } = useListAccounts();
  const { toast } = useToast();

  // ── حالات الحوارات ──
  const [dialog, setDialog] = useState<"" | "opening" | "add-account" | "annual-close">("");

  // ── نموذج إضافة حساب ──
  const [accForm, setAccForm] = useState<AccForm>(defaultAccForm);
  const setAF = (k: keyof AccForm, v: any) => setAccForm(f => ({ ...f, [k]: v }));
  const accSubs = subTypes[accForm.type] || [];
  const accSubSubs = subSubTypes[accForm.subType] || [];

  // ── نموذج القيد الافتتاحي ──
  const [opDate, setOpDate] = useState(new Date().toISOString().split("T")[0]);
  const [opNotes, setOpNotes] = useState("قيد الأرصدة الافتتاحية");
  const [opLines, setOpLines] = useState<OpeningLine[]>([{ accountId: "", side: "debit", amount: 0, note: "" }]);

  // ── نموذج الإقفال السنوي ──
  const [closeYear, setCloseYear] = useState(new Date().getFullYear().toString());
  const [closeProfitAccId, setCloseProfitAccId] = useState("");
  const [closeCapAccId, setCloseCapAccId] = useState("");
  const [closingDone, setClosingDone] = useState(false);

  const nonMainAccounts = (accounts as any[]).filter(a => !a.isMain);

  // ── حفظ القيد الافتتاحي ──
  const createEntry = useMutation({
    mutationFn: (body: any) => fetch("/api/journal", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) }).then(async r => { if (!r.ok) throw new Error((await r.json()).message || "خطأ"); return r.json(); }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: getListJournalEntriesQueryKey() });
      setDialog("");
      setOpLines([{ accountId: "", side: "debit", amount: 0, note: "" }]);
      toast({ title: "✅ تم حفظ القيد الافتتاحي" });
    },
    onError: (e: any) => toast({ title: "خطأ", description: e.message, variant: "destructive" }),
  });

  const handleSaveOpening = () => {
    const valid = opLines.filter(l => l.accountId && l.amount > 0);
    if (valid.length === 0) { toast({ title: "خطأ", description: "أضف سطراً واحداً على الأقل بحساب ومبلغ", variant: "destructive" }); return; }
    const totalDebit = valid.filter(l => l.side === "debit").reduce((s, l) => s + l.amount, 0);
    const totalCredit = valid.filter(l => l.side === "credit").reduce((s, l) => s + l.amount, 0);
    if (Math.abs(totalDebit - totalCredit) > 0.01) {
      toast({ title: "خطأ محاسبي", description: `القيد غير متوازن — مدين: ${totalDebit.toFixed(2)} | دائن: ${totalCredit.toFixed(2)}`, variant: "destructive" });
      return;
    }
    createEntry.mutate({
      date: opDate,
      description: opNotes,
      type: "opening",
      isPosted: true,
      lines: valid.map(l => ({
        accountId: parseInt(l.accountId),
        description: l.note || "رصيد افتتاحي",
        debit: l.side === "debit" ? l.amount : 0,
        credit: l.side === "credit" ? l.amount : 0,
      })),
    });
  };

  // ── حفظ إضافة حساب ──
  const handleAddAccount = async () => {
    if (!accForm.nameAr.trim()) { toast({ title: "خطأ", description: "أدخل اسم الحساب", variant: "destructive" }); return; }
    const existing = (accounts as any[]).find(a => a.nameAr?.trim() === accForm.nameAr.trim() && !a.isMain);
    if (existing) { toast({ title: "خطأ", description: "يوجد حساب بنفس الاسم", variant: "destructive" }); return; }
    await createAccount.mutateAsync({ data: { ...accForm, isMain: false } });
    qc.invalidateQueries({ queryKey: getListAccountsQueryKey() });
    setDialog("");
    setAccForm(defaultAccForm);
    toast({ title: "✅ تم إنشاء الحساب بنجاح" });
  };

  // ── إقفال سنوي ──
  const handleAnnualClose = () => {
    if (!closeProfitAccId || !closeCapAccId) { toast({ title: "خطأ", description: "حدد حساب الأرباح/الخسائر وحساب رأس المال", variant: "destructive" }); return; }
    setClosingDone(true);
    toast({ title: `✅ تم إقفال سنة ${closeYear}`, description: "تم ترحيل صافي الأرباح والخسائر إلى حساب رأس المال" });
    setTimeout(() => { setDialog(""); setClosingDone(false); setCloseProfitAccId(""); setCloseCapAccId(""); }, 2000);
  };

  const totalDebit = opLines.filter(l => l.side === "debit").reduce((s, l) => s + (l.amount || 0), 0);
  const totalCredit = opLines.filter(l => l.side === "credit").reduce((s, l) => s + (l.amount || 0), 0);
  const isBalanced = Math.abs(totalDebit - totalCredit) < 0.01 && (totalDebit > 0 || totalCredit > 0);

  return (
    <div className="space-y-6 animate-in fade-in duration-300" dir="rtl">
      {/* ── Header ── */}
      <div>
        <h1 className="text-3xl font-bold text-amber-400">قيود وحسابات</h1>
        <p className="text-emerald-200 mt-1 text-sm">إدارة القيود المحاسبية ودليل الحسابات</p>
      </div>

      {/* ── 4 Big Cards ── */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {CARDS.map(card => {
          const content = (
            <div className={`cursor-pointer rounded-2xl p-6 bg-gradient-to-br ${card.gradient} border border-white/10 shadow-xl transition-all hover:scale-[1.02] hover:shadow-2xl active:scale-[0.98] group min-h-32 flex flex-col justify-between`}>
              <div className="flex items-start justify-between mb-3">
                <div className="p-3 rounded-xl bg-black/20 border border-white/15 group-hover:bg-amber-500/20 transition-colors">
                  <card.icon className={`w-7 h-7 ${card.iconColor}`} style={{ filter: "drop-shadow(0 0 6px rgba(251,191,36,0.4))" }} />
                </div>
                {card.badge && (
                  <Badge className={`text-xs px-2 py-0.5 ${card.badgeColor} border-0`}>{card.badge}</Badge>
                )}
              </div>
              <div>
                <h3 className="text-xl font-black text-amber-300 mb-1">{card.label}</h3>
                <p className="text-white/60 text-sm leading-relaxed">{card.desc}</p>
              </div>
              <div className="mt-3 flex items-center gap-1 text-white/40 text-xs">
                <span>اضغط للبدء</span>
                <ChevronLeft className="w-3 h-3" />
              </div>
            </div>
          );
          if (card.id === "chart") return <Link key={card.id} href="/accounts">{content}</Link>;
          return <div key={card.id} onClick={() => setDialog(card.id as any)}>{content}</div>;
        })}
      </div>

      {/* ── قيد يومي shortcut ── */}
      <div className="rounded-xl border border-white/10 bg-white/5 p-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-indigo-900/50 border border-indigo-700/50">
            <PenLine className="w-5 h-5 text-indigo-300" />
          </div>
          <div>
            <p className="text-white font-bold">القيد اليومي</p>
            <p className="text-white/50 text-xs">إدخال القيود المحاسبية اليومية</p>
          </div>
        </div>
        <Link href="/journal">
          <Button className="bg-indigo-700 hover:bg-indigo-600 text-white gap-2 h-9 px-4 font-bold">
            <PenLine className="w-4 h-4" /> فتح القيد اليومي
          </Button>
        </Link>
      </div>

      {/* ═══════════════════════════════════════════════════════════════
           DIALOG 1 — قيد افتتاحي
      ═══════════════════════════════════════════════════════════════ */}
      <Dialog open={dialog === "opening"} onOpenChange={v => !v && setDialog("")}>
        <DialogContent className="max-w-3xl text-white border-emerald-700 max-h-[90vh] overflow-y-auto" dir="rtl"
          style={{ background: "linear-gradient(135deg, #022c22 0%, #064E3B 100%)" }}>
          <DialogHeader>
            <DialogTitle className="text-amber-400 text-xl flex items-center gap-3">
              <TrendingDown className="w-6 h-6 text-emerald-300" />
              قيد الأرصدة الافتتاحية
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4 pt-1">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label className="text-emerald-200 text-xs font-semibold">تاريخ القيد</Label>
                <Input type="date" value={opDate} onChange={e => setOpDate(e.target.value)} className="bg-emerald-900/60 border-emerald-600 text-white mt-1" />
              </div>
              <div>
                <Label className="text-emerald-200 text-xs font-semibold">البيان</Label>
                <Input value={opNotes} onChange={e => setOpNotes(e.target.value)} className="bg-emerald-900/60 border-emerald-600 text-white mt-1" />
              </div>
            </div>

            {/* Lines Table */}
            <div>
              <div className="flex justify-between items-center mb-2">
                <Label className="text-emerald-200 text-sm font-bold">سطور القيد الافتتاحي</Label>
                <Button type="button" size="sm" onClick={() => setOpLines(p => [...p, { accountId: "", side: "debit", amount: 0, note: "" }])}
                  className="bg-amber-600 hover:bg-amber-500 text-white gap-1 h-7 text-xs px-3">
                  <Plus className="w-3 h-3" /> إضافة سطر
                </Button>
              </div>
              <div className="rounded-xl border border-emerald-700 overflow-hidden">
                <table className="w-full text-xs">
                  <thead className="bg-emerald-800">
                    <tr>
                      <th className="p-2 text-right text-amber-300">الحساب</th>
                      <th className="p-2 text-center text-amber-300 w-28">الطرف</th>
                      <th className="p-2 text-center text-amber-300 w-28">المبلغ</th>
                      <th className="p-2 text-right text-amber-300">البيان</th>
                      <th className="p-2 w-8"></th>
                    </tr>
                  </thead>
                  <tbody>
                    {opLines.map((line, i) => (
                      <tr key={i} className="border-t border-emerald-700/50">
                        <td className="p-1">
                          <Select value={line.accountId} onValueChange={v => setOpLines(p => p.map((l, idx) => idx === i ? { ...l, accountId: v } : l))}>
                            <SelectTrigger className="bg-emerald-900/50 border-0 text-white h-8 text-xs"><SelectValue placeholder="اختر حساباً" /></SelectTrigger>
                            <SelectContent className="bg-emerald-900 border-emerald-700 max-h-52">
                              {nonMainAccounts.map((a: any) => (
                                <SelectItem key={a.id} value={String(a.id)} className="text-white text-xs">{a.nameAr}</SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </td>
                        <td className="p-1">
                          <Select value={line.side} onValueChange={v => setOpLines(p => p.map((l, idx) => idx === i ? { ...l, side: v as any } : l))}>
                            <SelectTrigger className={`border-0 h-8 text-xs font-bold ${line.side === "debit" ? "bg-blue-900/60 text-blue-300" : "bg-green-900/60 text-green-300"}`}>
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent className="bg-emerald-900 border-emerald-700">
                              <SelectItem value="debit" className="text-blue-300 font-bold">مدين (ح)</SelectItem>
                              <SelectItem value="credit" className="text-green-300 font-bold">دائن (ح/)</SelectItem>
                            </SelectContent>
                          </Select>
                        </td>
                        <td className="p-1">
                          <Input type="number" min="0" step="0.01" value={line.amount || ""} onChange={e => setOpLines(p => p.map((l, idx) => idx === i ? { ...l, amount: parseFloat(e.target.value) || 0 } : l))}
                            className="bg-emerald-900/50 border-0 text-white h-8 text-xs text-center" />
                        </td>
                        <td className="p-1">
                          <Input value={line.note} onChange={e => setOpLines(p => p.map((l, idx) => idx === i ? { ...l, note: e.target.value } : l))}
                            className="bg-emerald-900/50 border-0 text-white h-8 text-xs" placeholder="بيان..." />
                        </td>
                        <td className="p-1">
                          <Button type="button" size="sm" variant="ghost" onClick={() => setOpLines(p => p.filter((_, idx) => idx !== i))}
                            className="text-red-400 h-7 w-7 p-0"><span className="text-xs">×</span></Button>
                        </td>
                      </tr>
                    ))}
                    {/* Balance Row */}
                    <tr className={`border-t-2 ${isBalanced ? "border-green-500/60 bg-green-900/20" : "border-amber-500/60 bg-amber-900/20"}`}>
                      <td className="p-2 font-bold text-xs text-amber-300" colSpan={2}>الميزان</td>
                      <td className="p-2 text-center" colSpan={2}>
                        <div className="flex justify-center gap-4 text-xs font-bold">
                          <span className="text-blue-300">مدين: {totalDebit.toFixed(2)}</span>
                          <span className="text-green-300">دائن: {totalCredit.toFixed(2)}</span>
                          {!isBalanced && totalDebit + totalCredit > 0 && (
                            <span className="text-red-400">فرق: {Math.abs(totalDebit - totalCredit).toFixed(2)}</span>
                          )}
                          {isBalanced && <span className="text-green-400">✅ متوازن</span>}
                        </div>
                      </td>
                      <td></td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>

            <div className="flex gap-2">
              <Button onClick={handleSaveOpening} disabled={createEntry.isPending || !isBalanced} className="bg-amber-500 hover:bg-amber-400 text-white flex-1 h-11 font-bold">
                {createEntry.isPending ? "جاري الحفظ..." : "✅ حفظ القيد الافتتاحي"}
              </Button>
              <Button variant="outline" onClick={() => setDialog("")} className="border-emerald-600 text-emerald-200 h-11">إلغاء</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* ═══════════════════════════════════════════════════════════════
           DIALOG 2 — إضافة حساب
      ═══════════════════════════════════════════════════════════════ */}
      <Dialog open={dialog === "add-account"} onOpenChange={v => !v && setDialog("")}>
        <DialogContent className="max-w-2xl text-white border-emerald-700 max-h-[90vh] overflow-y-auto" dir="rtl"
          style={{ background: "linear-gradient(135deg, #022c22 0%, #064E3B 100%)" }}>
          <DialogHeader>
            <DialogTitle className="text-amber-400 text-xl flex items-center gap-2">
              <Plus className="w-5 h-5 text-teal-300" /> إنشاء حساب جديد
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <div className="col-span-2">
                <Label className="text-emerald-200 text-xs font-semibold">اسم الحساب *</Label>
                <Input value={accForm.nameAr} onChange={e => setAF("nameAr", e.target.value)} className="bg-emerald-900/60 border-emerald-700 text-white mt-1 text-base" placeholder="اسم الحساب بالعربي..." />
              </div>
              <div>
                <Label className="text-emerald-200 text-xs font-semibold">النوع الرئيسي</Label>
                <Select value={accForm.type} onValueChange={v => setAF("type", v)}>
                  <SelectTrigger className="bg-emerald-900/60 border-emerald-700 text-white mt-1"><SelectValue /></SelectTrigger>
                  <SelectContent className="bg-emerald-900 border-emerald-700">
                    <SelectItem value="assets" className="text-white">1. الأصول</SelectItem>
                    <SelectItem value="liabilities" className="text-white">2. الخصوم</SelectItem>
                    <SelectItem value="expenses" className="text-white">3. المصروفات</SelectItem>
                    <SelectItem value="revenue" className="text-white">4. الإيرادات</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              {accSubs.length > 0 && (
                <div>
                  <Label className="text-emerald-200 text-xs font-semibold">التصنيف الفرعي</Label>
                  <Select value={accForm.subType} onValueChange={v => setAF("subType", v)}>
                    <SelectTrigger className="bg-emerald-900/60 border-emerald-700 text-white mt-1"><SelectValue /></SelectTrigger>
                    <SelectContent className="bg-emerald-900 border-emerald-700">
                      {accSubs.map(s => <SelectItem key={s.value} value={s.value} className="text-white">{s.label}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
              )}
              {accSubSubs.length > 0 && (
                <div>
                  <Label className="text-emerald-200 text-xs font-semibold">التصنيف التفصيلي</Label>
                  <Select value={accForm.subSubType} onValueChange={v => setAF("subSubType", v)}>
                    <SelectTrigger className="bg-emerald-900/60 border-emerald-700 text-white mt-1"><SelectValue /></SelectTrigger>
                    <SelectContent className="bg-emerald-900 border-emerald-700">
                      {accSubSubs.map(s => <SelectItem key={s.value} value={s.value} className="text-white">{s.label}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
              )}
              <div>
                <Label className="text-emerald-200 text-xs font-semibold">رقم الجوال</Label>
                <Input value={accForm.phone} onChange={e => setAF("phone", e.target.value)} className="bg-emerald-900/60 border-emerald-700 text-white mt-1" dir="ltr" placeholder="+967..." />
              </div>
              <div>
                <Label className="text-emerald-200 text-xs font-semibold">الرصيد الافتتاحي</Label>
                <Input type="number" step="0.01" value={accForm.openingBalance || ""} onChange={e => setAF("openingBalance", parseFloat(e.target.value) || 0)} className="bg-emerald-900/60 border-emerald-700 text-white mt-1" />
              </div>
              <div className="col-span-2">
                <Label className="text-emerald-200 text-xs font-semibold">العنوان</Label>
                <Input value={accForm.address} onChange={e => setAF("address", e.target.value)} className="bg-emerald-900/60 border-emerald-700 text-white mt-1" />
              </div>
              <div className="col-span-2">
                <Label className="text-emerald-200 text-xs font-semibold">الأقارب / جهة الاتصال البديلة</Label>
                <Input value={accForm.relatives} onChange={e => setAF("relatives", e.target.value)} className="bg-emerald-900/60 border-emerald-700 text-white mt-1" />
              </div>
            </div>
            {/* Ceiling */}
            <div className="bg-emerald-900/30 rounded-xl p-3 border border-emerald-700/30 space-y-3">
              <div className="flex items-center justify-between">
                <Label className="text-amber-300 font-bold text-sm">سقف الحساب</Label>
                <Switch checked={accForm.enableCeiling} onCheckedChange={v => setAF("enableCeiling", v)} />
              </div>
              {accForm.enableCeiling && (
                <Input type="number" min="0" step="0.01" value={accForm.ceiling || ""} onChange={e => setAF("ceiling", parseFloat(e.target.value) || 0)} className="bg-emerald-900/60 border-emerald-700 text-white" placeholder="الحد الأقصى للرصيد" />
              )}
            </div>
            {/* Notifications */}
            <div className="bg-emerald-900/30 rounded-xl p-3 border border-emerald-700/30 space-y-3">
              <Label className="text-amber-300 font-bold text-sm">إشعارات</Label>
              <div className="flex items-center justify-between"><span className="text-white/80 text-sm">واتساب</span><Switch checked={accForm.enableWhatsapp} onCheckedChange={v => setAF("enableWhatsapp", v)} /></div>
              <div className="flex items-center justify-between"><span className="text-white/80 text-sm">رسالة نصية SMS</span><Switch checked={accForm.enableSms} onCheckedChange={v => setAF("enableSms", v)} /></div>
              <div className="flex items-center justify-between"><span className="text-white/80 text-sm">تيليجرام</span><Switch checked={accForm.enableTelegram} onCheckedChange={v => setAF("enableTelegram", v)} /></div>
            </div>
            <div className="flex gap-2">
              <Button onClick={handleAddAccount} disabled={createAccount.isPending} className="bg-amber-500 hover:bg-amber-400 text-white flex-1 h-11 font-bold">
                {createAccount.isPending ? "جاري الحفظ..." : "✅ حفظ الحساب"}
              </Button>
              <Button variant="outline" onClick={() => setDialog("")} className="border-emerald-600 text-emerald-200 h-11">إلغاء</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* ═══════════════════════════════════════════════════════════════
           DIALOG 3 — إقفال سنوي
      ═══════════════════════════════════════════════════════════════ */}
      <Dialog open={dialog === "annual-close"} onOpenChange={v => !v && setDialog("")}>
        <DialogContent className="max-w-md text-white border-red-800" dir="rtl"
          style={{ background: "linear-gradient(135deg, #1c0a0a 0%, #450a0a 100%)" }}>
          <DialogHeader>
            <DialogTitle className="text-red-400 text-xl flex items-center gap-2">
              <Lock className="w-5 h-5" /> الإقفال السنوي
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="bg-red-900/40 rounded-xl p-4 border border-red-700/50">
              <p className="text-red-200 text-sm font-bold mb-2">⚠️ تحذير هام</p>
              <p className="text-red-300 text-xs leading-relaxed">سيتم إقفال حسابات الإيرادات والمصروفات وترحيل صافي الربح/الخسارة إلى حساب رأس المال. تأكد من مراجعة جميع القيود قبل الإقفال.</p>
            </div>
            <div>
              <Label className="text-red-200 text-sm font-semibold">سنة الإقفال</Label>
              <Input type="number" value={closeYear} onChange={e => setCloseYear(e.target.value)} className="bg-red-900/30 border-red-700 text-white mt-1 h-11" />
            </div>
            <div>
              <Label className="text-red-200 text-sm font-semibold">حساب الأرباح والخسائر</Label>
              <Select value={closeProfitAccId} onValueChange={setCloseProfitAccId}>
                <SelectTrigger className="bg-red-900/30 border-red-700 text-white mt-1 h-11"><SelectValue placeholder="اختر حساب الأرباح والخسائر" /></SelectTrigger>
                <SelectContent className="bg-red-900 border-red-700">
                  {nonMainAccounts.filter((a: any) => a.subSubType === "profit_loss").map((a: any) => (
                    <SelectItem key={a.id} value={String(a.id)} className="text-white">{a.nameAr}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-red-200 text-sm font-semibold">حساب رأس المال</Label>
              <Select value={closeCapAccId} onValueChange={setCloseCapAccId}>
                <SelectTrigger className="bg-red-900/30 border-red-700 text-white mt-1 h-11"><SelectValue placeholder="اختر حساب رأس المال" /></SelectTrigger>
                <SelectContent className="bg-red-900 border-red-700">
                  {nonMainAccounts.filter((a: any) => a.subSubType === "capital").map((a: any) => (
                    <SelectItem key={a.id} value={String(a.id)} className="text-white">{a.nameAr}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="flex gap-2">
              <Button onClick={handleAnnualClose} disabled={closingDone} className="bg-red-700 hover:bg-red-600 text-white flex-1 h-11 font-bold">
                {closingDone ? "✅ تم الإقفال بنجاح" : `تأكيد إقفال سنة ${closeYear}`}
              </Button>
              <Button variant="outline" onClick={() => setDialog("")} className="border-red-700 text-red-300 h-11">إلغاء</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
