import React, { useState, useMemo, useRef } from "react";
import { useListCurrencies, useListAccounts } from "@workspace/api-client-react";
import { postToLedger, removeFromLedger, makeId } from "@/lib/ledger";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import {
  ArrowLeftRight, Plus, Trash2, Save, Camera, MoreVertical, FileText,
  ImageIcon, Share2, MessageCircle, Send, Search, X, Edit2, ArrowRight,
  TrendingUp, TrendingDown, RefreshCw
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useSettings } from "@/contexts/SettingsContext";
import { sendWhatsApp, printDocument } from "@/lib/printUtils";
import { ShareDocumentDialog } from "@/components/ShareDocumentDialog";

// ─── Types ──────────────────────────────────────────────────────────────────
type ExchangeRecord = {
  id: number;
  serialNum: number;
  date: string;
  fromCurrencyId: string;
  fromCurrencyCode: string;
  fromCurrencySymbol: string;
  toCurrencyId: string;
  toCurrencyCode: string;
  toCurrencySymbol: string;
  fromAmount: number;
  toAmount: number;
  rate: number;
  fromAccountId: string;
  fromAccountName: string;
  toAccountId: string;
  toAccountName: string;
  description: string;
  imagePreview: string | null;
  profitLoss: number;
};

// ─── localStorage helpers ────────────────────────────────────────────────────
const LS_KEY = "qawera_exchange_v2";
const LS_SEQ = "qawera_exchange_seq_v2";
const loadRecords = (): ExchangeRecord[] => {
  try { return JSON.parse(localStorage.getItem(LS_KEY) || "[]"); } catch { return []; }
};
const saveRecords = (recs: ExchangeRecord[]) => {
  localStorage.setItem(LS_KEY, JSON.stringify(recs));
};
const loadSeq = (): number => parseInt(localStorage.getItem(LS_SEQ) || "1");
const saveSeq = (n: number) => localStorage.setItem(LS_SEQ, String(n));

// ─── Print helper ────────────────────────────────────────────────────────────
const printExchange = (rec: ExchangeRecord, companyName: string) => {
  printDocument(
    "مصارفة عملات",
    [
      { label: "رقم المصارفة", value: String(rec.serialNum) },
      { label: "التاريخ", value: rec.date },
      { label: "من حساب", value: rec.fromAccountName || "—" },
      { label: "إلى حساب", value: rec.toAccountName || "—" },
      { label: "البيان", value: rec.description || "—" },
    ],
    ["البيان", "المبلغ", "العملة"],
    [
      ["تم صرف", rec.fromAmount.toFixed(2), rec.fromCurrencyCode],
      ["تم استلام", rec.toAmount.toFixed(2), rec.toCurrencyCode],
      ["سعر الصرف", `1 ${rec.fromCurrencyCode} = ${rec.rate.toFixed(4)}`, rec.toCurrencyCode],
    ],
    [],
    { companyName: companyName || "قـويـره سوفت", companyNameEn: "Qwairah Soft", printHeader: true, printSignature: true },
    rec.profitLoss !== 0 ? `صافي الربح/الخسارة: ${rec.profitLoss > 0 ? "+" : ""}${rec.profitLoss.toFixed(2)}` : ""
  );
};

const buildMsg = (rec: ExchangeRecord, prefix: string, suffix: string) =>
  [
    prefix,
    `💱 *مصارفة عملات رقم: ${rec.serialNum}*`,
    `التاريخ: ${rec.date}`,
    "─────────────────────",
    `💰 ${rec.fromAmount.toFixed(2)} *${rec.fromCurrencyCode}* ← ${rec.fromAccountName || "—"}`,
    `⇆`,
    `💰 ${rec.toAmount.toFixed(2)} *${rec.toCurrencyCode}* → ${rec.toAccountName || "—"}`,
    `📊 سعر الصرف: 1 ${rec.fromCurrencyCode} = ${rec.rate.toFixed(4)} ${rec.toCurrencyCode}`,
    rec.description ? `📝 البيان: ${rec.description}` : "",
    rec.profitLoss !== 0 ? `${rec.profitLoss > 0 ? "📈 ربح" : "📉 خسارة"}: ${Math.abs(rec.profitLoss).toFixed(2)} ر.ي` : "",
    "─────────────────────",
    suffix,
  ].filter(Boolean).join("\n");

// ─── Calculator component ────────────────────────────────────────────────────
function InlineCalc({ onResult }: { onResult: (v: number) => void }) {
  const [expr, setExpr] = useState("");
  const apply = () => {
    try {
      // eslint-disable-next-line no-new-func
      const v = Function('"use strict"; return (' + expr.replace(/×/g, "*").replace(/÷/g, "/") + ")")();
      if (!isNaN(v)) { onResult(Number(v)); setExpr(""); }
    } catch { /**/ }
  };
  const keys = ["7","8","9","÷","4","5","6","×","1","2","3","-","0",".","C","+"];
  return (
    <div className="bg-emerald-950 rounded-xl border border-emerald-700 p-2 space-y-1.5 w-44">
      <Input value={expr} onChange={e => setExpr(e.target.value)} placeholder="حساب..."
        className="bg-emerald-900 border-emerald-600 text-white h-8 text-sm text-left font-mono" dir="ltr" />
      <div className="grid grid-cols-4 gap-1">
        {keys.map(k => (
          <button key={k} onClick={() => k === "C" ? setExpr("") : setExpr(p => p + k)}
            className="bg-emerald-800 hover:bg-emerald-700 text-white rounded-lg h-8 text-sm font-bold transition-colors">
            {k}
          </button>
        ))}
      </div>
      <button onClick={apply} className="w-full bg-amber-500 hover:bg-amber-400 text-white rounded-lg h-8 text-sm font-bold">
        = تطبيق
      </button>
    </div>
  );
}

// ════════════════════════════════════════════════════════════════════════════
export default function ExchangePage() {
  const { data: currencies = [] } = useListCurrencies();
  const { data: allAccounts = [] } = useListAccounts();
  const { toast } = useToast();
  const { settings } = useSettings();

  // ── List state ──
  const [records, setRecords] = useState<ExchangeRecord[]>(loadRecords);
  const [nextSerial, setNextSerial] = useState(loadSeq);
  const [listSearch, setListSearch] = useState("");
  const [pageSize, setPageSize] = useState(25);

  // ── Dialog state ──
  const [open, setOpen] = useState(false);
  const [shareOpen, setShareOpen] = useState(false);
  const [shareMsg, setShareMsg] = useState("");
  const [shareRec, setShareRec] = useState<ExchangeRecord | null>(null);

  // ── Form state ──
  const [serialNum, setSerialNum] = useState(loadSeq);
  const [date, setDate] = useState(new Date().toISOString().split("T")[0]);
  const [fromCurrencyId, setFromCurrencyId] = useState("");
  const [toCurrencyId, setToCurrencyId] = useState("");
  const [fromAmount, setFromAmount] = useState<number>(0);
  const [toAmount, setToAmount] = useState<number>(0);
  const [rate, setRate] = useState<number>(1);
  const [customRate, setCustomRate] = useState(false);
  const [fromAccountId, setFromAccountId] = useState("");
  const [fromAccountSearch, setFromAccountSearch] = useState("");
  const [toAccountId, setToAccountId] = useState("");
  const [toAccountSearch, setToAccountSearch] = useState("");
  const [description, setDescription] = useState("");
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [showCalc, setShowCalc] = useState(false);

  const imgRef = useRef<HTMLInputElement>(null);

  // ── Derived ──
  const subAccounts = useMemo(() => (allAccounts as any[]).filter(a => !a.isMain), [allAccounts]);
  const filtFromAcc = useMemo(() => fromAccountSearch ? subAccounts.filter(a => a.nameAr?.includes(fromAccountSearch)) : subAccounts, [subAccounts, fromAccountSearch]);
  const filtToAcc   = useMemo(() => toAccountSearch   ? subAccounts.filter(a => a.nameAr?.includes(toAccountSearch))   : subAccounts, [subAccounts, toAccountSearch]);

  const fromCurrency = (currencies as any[]).find(c => String(c.id) === fromCurrencyId);
  const toCurrency   = (currencies as any[]).find(c => String(c.id) === toCurrencyId);
  const fromAccount  = subAccounts.find(a => String(a.id) === fromAccountId);
  const toAccount    = subAccounts.find(a => String(a.id) === toAccountId);

  // صافي الربح/الخسارة: الفرق بالريال اليمني بين ما دفعناه وما استلمناه
  const computeProfitLoss = (fAmt: number, tAmt: number, fCur: any, tCur: any) => {
    if (!fCur || !tCur) return 0;
    const fromYER = fAmt * Number(fCur.exchangeRate || 1);
    const toYER   = tAmt * Number(tCur.exchangeRate || 1);
    return toYER - fromYER;
  };
  const currentPL = computeProfitLoss(fromAmount, toAmount, fromCurrency, toCurrency);

  // مجموع الربح والخسارة من كل العمليات
  const totalProfit = records.reduce((s, r) => s + (r.profitLoss > 0 ? r.profitLoss : 0), 0);
  const totalLoss   = records.reduce((s, r) => s + (r.profitLoss < 0 ? r.profitLoss : 0), 0);
  const netIncome   = totalProfit + totalLoss;

  // ── Rate recalculation ──
  const recalcRate = (fId: string, tId: string) => {
    const f = (currencies as any[]).find(c => String(c.id) === fId);
    const t = (currencies as any[]).find(c => String(c.id) === tId);
    if (f && t) {
      const r = Number(t.exchangeRate) / Number(f.exchangeRate);
      setRate(parseFloat(r.toFixed(6)));
      setToAmount(parseFloat((fromAmount * r).toFixed(4)));
    }
  };

  const handleFromCur = (v: string) => { setFromCurrencyId(v); if (!customRate) recalcRate(v, toCurrencyId); };
  const handleToCur   = (v: string) => { setToCurrencyId(v);   if (!customRate) recalcRate(fromCurrencyId, v); };
  const handleFromAmt = (v: number) => { setFromAmount(v); setToAmount(parseFloat((v * rate).toFixed(4))); };
  const handleToAmt   = (v: number) => { setToAmount(v); if (v > 0 && fromAmount > 0) setRate(parseFloat((v / fromAmount).toFixed(6))); };
  const handleRate    = (v: number) => { setRate(v); setToAmount(parseFloat((fromAmount * v).toFixed(4))); };

  const swap = () => {
    const tmpCId = fromCurrencyId; setFromCurrencyId(toCurrencyId); setToCurrencyId(tmpCId);
    const tmpAccId = fromAccountId; setFromAccountId(toAccountId); setToAccountId(tmpAccId);
    const tmpAmt = fromAmount; setFromAmount(toAmount); setToAmount(tmpAmt);
    recalcRate(toCurrencyId, fromCurrencyId);
  };

  const openNew = () => {
    const seq = loadSeq();
    setSerialNum(seq);
    setDate(new Date().toISOString().split("T")[0]);
    setFromCurrencyId(""); setToCurrencyId("");
    setFromAmount(0); setToAmount(0); setRate(1); setCustomRate(false);
    setFromAccountId(""); setToAccountId("");
    setFromAccountSearch(""); setToAccountSearch("");
    setDescription(""); setImagePreview(null); setShowCalc(false);
    setOpen(true);
  };

  const handleSave = () => {
    if (!fromCurrencyId || !toCurrencyId || fromAmount <= 0) {
      toast({ title: "خطأ", description: "أدخل العملتين والمبلغ", variant: "destructive" }); return;
    }
    const pl = computeProfitLoss(fromAmount, toAmount, fromCurrency, toCurrency);
    const rec: ExchangeRecord = {
      id: Date.now(),
      serialNum,
      date,
      fromCurrencyId, fromCurrencyCode: fromCurrency?.code || "", fromCurrencySymbol: fromCurrency?.symbol || fromCurrency?.code || "",
      toCurrencyId,   toCurrencyCode: toCurrency?.code || "",   toCurrencySymbol: toCurrency?.symbol || toCurrency?.code || "",
      fromAmount, toAmount, rate,
      fromAccountId,   fromAccountName: fromAccount?.nameAr || "",
      toAccountId,     toAccountName:   toAccount?.nameAr   || "",
      description, imagePreview,
      profitLoss: pl,
    };

    const newRecs = [rec, ...records];
    setRecords(newRecs); saveRecords(newRecs);
    const nextSeq = serialNum + 1; saveSeq(nextSeq); setNextSerial(nextSeq);

    // ── ترحيل للأستاذ ──
    const ledgerEntries: any[] = [];
    const docNum = String(serialNum);
    const docId  = `exchange-${rec.id}`;
    const desc   = description || "مصارفة عملات";
    if (fromAccountId) {
      ledgerEntries.push({
        id: makeId(), date, docType: "exchange" as const, docNumber: docNum, docId,
        accountId: parseInt(fromAccountId), debit: 0, credit: fromAmount,
        description: `${desc} — دائن ${fromCurrency?.code || ""}`,
        currencySymbol: fromCurrency?.symbol || fromCurrency?.code || "؟",
        ref: toAccount?.nameAr || "",
      });
    }
    if (toAccountId) {
      ledgerEntries.push({
        id: makeId(), date, docType: "exchange" as const, docNumber: docNum, docId,
        accountId: parseInt(toAccountId), debit: toAmount, credit: 0,
        description: `${desc} — مدين ${toCurrency?.code || ""}`,
        currencySymbol: toCurrency?.symbol || toCurrency?.code || "؟",
        ref: fromAccount?.nameAr || "",
      });
    }
    if (ledgerEntries.length > 0) postToLedger(ledgerEntries);

    toast({ title: "✅ تم حفظ المصارفة وترحيلها" });
    setOpen(false);
  };

  const handleDelete = (rec: ExchangeRecord) => {
    if (!confirm(`حذف مصارفة رقم ${rec.serialNum}؟`)) return;
    const newRecs = records.filter(r => r.id !== rec.id);
    setRecords(newRecs); saveRecords(newRecs);
    removeFromLedger(`exchange-${rec.id}`);
    toast({ title: "🗑️ تم الحذف" });
  };

  const openShare = (rec: ExchangeRecord) => {
    setShareRec(rec);
    setShareMsg(buildMsg(rec, settings.msgPrefix || "", settings.msgSuffix || ""));
    setShareOpen(true);
  };

  // ── Filtered list ──
  const filtered = useMemo(() => {
    const s = listSearch.toLowerCase();
    return records.filter(r =>
      !s ||
      String(r.serialNum).includes(s) ||
      r.fromCurrencyCode.toLowerCase().includes(s) ||
      r.toCurrencyCode.toLowerCase().includes(s) ||
      r.fromAccountName.toLowerCase().includes(s) ||
      r.toAccountName.toLowerCase().includes(s) ||
      r.description.toLowerCase().includes(s) ||
      r.date.includes(s)
    );
  }, [records, listSearch]);
  const displayed = pageSize === -1 ? filtered : filtered.slice(0, pageSize);

  // ────────────────────────────────────────────────────────────────────────────
  return (
    <div className="space-y-4 animate-in fade-in duration-300" dir="rtl">
      <ShareDocumentDialog
        open={shareOpen}
        onClose={() => setShareOpen(false)}
        docTitle="مصارفة عملات"
        message={shareMsg}
        onPrintPDF={() => shareRec && printExchange(shareRec, settings.companyName || "قـويـره سوفت")}
      />

      {/* ── رأس الصفحة ── */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-amber-400">مصارفة العملات</h1>
          <p className="text-emerald-300 text-sm mt-0.5">تبادل وتحويل العملات بين الحسابات</p>
        </div>
        <Button onClick={openNew} className="bg-amber-500 hover:bg-amber-400 text-white gap-2 h-11 px-5 font-bold">
          <Plus className="w-5 h-5" /> مصارفة جديدة
        </Button>
      </div>

      {/* ── بطاقات الملخص المالي ── */}
      <div className="grid grid-cols-3 gap-3">
        <div className="bg-emerald-900/40 border border-emerald-700/50 rounded-2xl p-4 text-center">
          <p className="text-emerald-400 text-xs mb-1">إجمالي العمليات</p>
          <p className="text-white font-black text-2xl">{records.length}</p>
        </div>
        <div className={`rounded-2xl p-4 text-center border ${netIncome >= 0 ? "bg-green-900/30 border-green-700/50" : "bg-red-900/30 border-red-700/50"}`}>
          <div className="flex items-center justify-center gap-1 mb-1">
            {netIncome >= 0 ? <TrendingUp className="w-3.5 h-3.5 text-green-400" /> : <TrendingDown className="w-3.5 h-3.5 text-red-400" />}
            <p className={`text-xs ${netIncome >= 0 ? "text-green-400" : "text-red-400"}`}>صافي الدخل (ر.ي)</p>
          </div>
          <p className={`font-black text-xl ${netIncome >= 0 ? "text-green-300" : "text-red-300"}`}>
            {netIncome >= 0 ? "+" : ""}{netIncome.toFixed(0)}
          </p>
        </div>
        <div className="bg-emerald-900/40 border border-emerald-700/50 rounded-2xl p-4 text-center">
          <p className="text-emerald-400 text-xs mb-1">الرقم التسلسلي التالي</p>
          <p className="text-amber-400 font-black text-2xl">#{nextSerial}</p>
        </div>
      </div>

      {/* ── شريط البحث ── */}
      <div className="flex items-center gap-2">
        <div className="relative flex-1">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-emerald-400" />
          <Input value={listSearch} onChange={e => setListSearch(e.target.value)}
            className="bg-emerald-900/50 border-emerald-700 text-white pr-9 h-10 text-sm"
            placeholder="بحث برقم العملية، العملة، الحساب، التاريخ..." />
        </div>
        <Select value={String(pageSize)} onValueChange={v => setPageSize(Number(v))}>
          <SelectTrigger className="w-24 bg-emerald-900/50 border-emerald-700 text-white h-10 text-sm">
            <SelectValue />
          </SelectTrigger>
          <SelectContent className="bg-emerald-900 border-emerald-700">
            {[10,25,50,100,-1].map(n => (
              <SelectItem key={n} value={String(n)} className="text-white text-sm">{n === -1 ? "الكل" : n}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* ── قائمة السجلات ── */}
      <div className="space-y-2">
        {displayed.length === 0 ? (
          <div className="text-center py-16 text-emerald-500">
            <ArrowLeftRight className="w-16 h-16 mx-auto mb-3 opacity-30" />
            <p className="text-lg">لا توجد عمليات مصارفة</p>
            <p className="text-sm mt-1 opacity-70">اضغط "مصارفة جديدة" لبدء تسجيل عمليات تبادل العملات</p>
          </div>
        ) : displayed.map(rec => (
          <div key={rec.id} className="rounded-2xl border border-emerald-700/50 overflow-hidden"
            style={{background:"rgba(6,78,59,0.25)"}}>
            {/* رأس البطاقة */}
            <div className="flex items-center gap-3 px-4 py-3 border-b border-emerald-700/30">
              <span className="text-amber-400 font-black text-base">#{rec.serialNum}</span>
              <span className="text-emerald-400 text-xs">{rec.date}</span>
              <span className="flex-1" />
              {/* ربح/خسارة */}
              {rec.profitLoss !== 0 && (
                <span className={`text-xs font-bold px-2 py-0.5 rounded-full ${rec.profitLoss > 0 ? "bg-green-900/50 text-green-300" : "bg-red-900/50 text-red-300"}`}>
                  {rec.profitLoss > 0 ? "▲ ربح" : "▼ خسارة"} {Math.abs(rec.profitLoss).toFixed(0)} ر.ي
                </span>
              )}
              {/* أزرار الإجراءات */}
              <Button size="sm" variant="ghost" onClick={() => printExchange(rec, settings.companyName || "قـويـره سوفت")}
                className="text-red-400 hover:text-red-300 h-7 w-7 p-0">
                <FileText className="w-4 h-4" />
              </Button>
              <Button size="sm" variant="ghost" onClick={() => openShare(rec)}
                className="text-blue-400 hover:text-blue-300 h-7 w-7 p-0">
                <Share2 className="w-4 h-4" />
              </Button>
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button size="sm" variant="ghost" className="text-emerald-300 hover:text-white h-7 w-7 p-0">
                    <MoreVertical className="w-4 h-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent className="bg-emerald-900 border-emerald-700 text-white" align="end">
                  <DropdownMenuItem className="text-white gap-2 cursor-pointer" onClick={() => openShare(rec)}>
                    <Share2 className="w-4 h-4 text-blue-400" /> مشاركة
                  </DropdownMenuItem>
                  <DropdownMenuItem className="text-green-400 gap-2 cursor-pointer" onClick={() => {
                    window.open(`https://wa.me/?text=${encodeURIComponent(buildMsg(rec, settings.msgPrefix || "", settings.msgSuffix || ""))}`, "_blank");
                  }}>
                    <MessageCircle className="w-4 h-4" /> واتساب
                  </DropdownMenuItem>
                  <DropdownMenuItem className="text-blue-400 gap-2 cursor-pointer" onClick={() => {
                    window.open(`https://t.me/share/url?text=${encodeURIComponent(buildMsg(rec, settings.msgPrefix || "", settings.msgSuffix || ""))}`, "_blank");
                  }}>
                    <Send className="w-4 h-4" /> تيليجرام
                  </DropdownMenuItem>
                  <DropdownMenuItem className="text-purple-400 gap-2 cursor-pointer" onClick={() => {
                    window.location.href = `sms:?body=${encodeURIComponent(buildMsg(rec, settings.msgPrefix || "", settings.msgSuffix || ""))}`;
                  }}>
                    <Send className="w-4 h-4" /> رسالة نصية
                  </DropdownMenuItem>
                  <DropdownMenuItem className="text-red-400 gap-2 cursor-pointer" onClick={() => handleDelete(rec)}>
                    <Trash2 className="w-4 h-4" /> حذف
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>

            {/* محتوى البطاقة: المبالغ والعملات */}
            <div className="px-4 py-3 flex items-center gap-4">
              {/* من */}
              <div className="text-center">
                {rec.fromAccountName && <p className="text-emerald-400 text-xs mb-1 truncate max-w-20">{rec.fromAccountName}</p>}
                <div className="bg-emerald-800/60 rounded-xl px-3 py-2">
                  <span className="text-white font-black text-lg">{rec.fromAmount.toLocaleString()}</span>
                  <span className="text-amber-300 text-sm font-bold mr-1">{rec.fromCurrencyCode}</span>
                </div>
              </div>

              {/* سهم */}
              <div className="flex flex-col items-center gap-0.5">
                <ArrowLeftRight className="w-5 h-5 text-amber-400" />
                <span className="text-emerald-500 text-xs">×{rec.rate.toFixed(4)}</span>
              </div>

              {/* إلى */}
              <div className="text-center">
                {rec.toAccountName && <p className="text-blue-400 text-xs mb-1 truncate max-w-20">{rec.toAccountName}</p>}
                <div className="bg-blue-900/40 rounded-xl px-3 py-2">
                  <span className="text-white font-black text-lg">{rec.toAmount.toLocaleString()}</span>
                  <span className="text-blue-300 text-sm font-bold mr-1">{rec.toCurrencyCode}</span>
                </div>
              </div>

              {rec.description && (
                <>
                  <div className="w-px h-8 bg-white/10" />
                  <p className="text-emerald-300 text-sm flex-1 truncate">{rec.description}</p>
                </>
              )}
              {rec.imagePreview && (
                <img src={rec.imagePreview} alt="" className="h-10 w-12 object-cover rounded-lg border border-emerald-700/50" />
              )}
            </div>
          </div>
        ))}
      </div>

      {filtered.length > displayed.length && (
        <button onClick={() => setPageSize(p => p === -1 ? 25 : -1)}
          className="w-full text-center py-2 text-emerald-400 hover:text-emerald-300 text-sm transition-colors">
          عرض {filtered.length - displayed.length} سجل إضافي...
        </button>
      )}

      {/* ══════════════════════════════════════════════════
           نموذج إضافة مصارفة جديدة
         ══════════════════════════════════════════════════ */}
      <Dialog open={open} onOpenChange={v => { if (!v) setOpen(false); }}>
        <DialogContent className="max-w-md bg-emerald-950 border-emerald-700 text-white p-0 overflow-hidden" dir="rtl">

          {/* ── شريط الأدوات العلوي ── */}
          <div className="flex items-center gap-1.5 px-3 py-2.5 bg-emerald-900 border-b border-emerald-700">
            {/* زر الرجوع */}
            <Button size="sm" variant="ghost" onClick={() => setOpen(false)}
              className="text-emerald-200 hover:text-white h-8 w-8 p-0">
              <ArrowRight className="w-4 h-4" />
            </Button>

            {/* ثلاث نقاط */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button size="sm" variant="ghost" className="text-emerald-300 hover:text-white h-8 w-8 p-0">
                  <MoreVertical className="w-4 h-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent className="bg-emerald-900 border-emerald-700 text-white" align="start">
                <DropdownMenuItem className="text-white gap-2 cursor-pointer" onClick={() => setListSearch("")}>
                  <Search className="w-4 h-4 text-emerald-400" /> بحث
                </DropdownMenuItem>
                <DropdownMenuItem className="text-green-400 gap-2 cursor-pointer" onClick={() => {
                  const m = description || "مصارفة عملات";
                  window.open(`https://wa.me/?text=${encodeURIComponent(m)}`, "_blank");
                }}>
                  <MessageCircle className="w-4 h-4" /> واتساب
                </DropdownMenuItem>
                <DropdownMenuItem className="text-blue-400 gap-2 cursor-pointer" onClick={() => {
                  window.open(`https://t.me/share/url?text=${encodeURIComponent(description || "")}`, "_blank");
                }}>
                  <Send className="w-4 h-4" /> تيليجرام
                </DropdownMenuItem>
                <DropdownMenuItem className="text-purple-400 gap-2 cursor-pointer" onClick={() => {
                  window.location.href = `sms:?body=${encodeURIComponent(description || "")}`;
                }}>
                  <Send className="w-4 h-4" /> رسالة نصية
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>

            {/* حفظ */}
            <Button size="sm" onClick={handleSave}
              className="bg-amber-500 hover:bg-amber-400 text-white h-8 px-3 text-xs font-bold gap-1">
              <Save className="w-3 h-3" /> حفظ
            </Button>

            {/* PDF */}
            <Button size="sm" variant="ghost" onClick={() => {
              const dummy: ExchangeRecord = {
                id: 0, serialNum, date,
                fromCurrencyId, fromCurrencyCode: fromCurrency?.code || "", fromCurrencySymbol: fromCurrency?.symbol || "",
                toCurrencyId, toCurrencyCode: toCurrency?.code || "", toCurrencySymbol: toCurrency?.symbol || "",
                fromAmount, toAmount, rate,
                fromAccountId, fromAccountName: fromAccount?.nameAr || "",
                toAccountId, toAccountName: toAccount?.nameAr || "",
                description, imagePreview, profitLoss: currentPL,
              };
              printExchange(dummy, settings.companyName || "قـويـره سوفت");
            }} className="text-red-400 hover:text-red-300 h-8 w-8 p-0">
              <FileText className="w-4 h-4" />
            </Button>

            {/* صورة */}
            <Button size="sm" variant="ghost" onClick={() => {
              const msg = buildMsg({
                id: 0, serialNum, date,
                fromCurrencyId, fromCurrencyCode: fromCurrency?.code || "", fromCurrencySymbol: fromCurrency?.symbol || "",
                toCurrencyId, toCurrencyCode: toCurrency?.code || "", toCurrencySymbol: toCurrency?.symbol || "",
                fromAmount, toAmount, rate,
                fromAccountId, fromAccountName: fromAccount?.nameAr || "",
                toAccountId, toAccountName: toAccount?.nameAr || "",
                description, imagePreview, profitLoss: currentPL,
              }, settings.msgPrefix || "", settings.msgSuffix || "");
              setShareMsg(msg); setShareRec(null); setShareOpen(true);
            }} className="text-blue-400 hover:text-blue-300 h-8 w-8 p-0">
              <ImageIcon className="w-4 h-4" />
            </Button>

            {/* عنوان */}
            <span className="flex-1 text-center text-amber-400 font-bold text-sm">💱 مصارفة العملات</span>
          </div>

          {/* ── محتوى النموذج ── */}
          <div className="overflow-y-auto max-h-[75vh]">
            <div className="p-4 space-y-3">

              {/* 1 — رقم المصارفة + التاريخ */}
              <div className="flex items-center gap-3 bg-emerald-900/50 rounded-xl px-3 py-2.5 border border-emerald-700/40">
                <div className="flex items-center gap-2">
                  <span className="text-emerald-400 text-xs">رقم</span>
                  <Input
                    type="number" value={serialNum}
                    onChange={e => setSerialNum(parseInt(e.target.value) || 1)}
                    className="bg-amber-500/20 border-amber-500/40 text-amber-300 font-black text-center h-8 w-20 text-sm"
                  />
                </div>
                <div className="w-px h-6 bg-white/10" />
                <div className="flex items-center gap-2 flex-1">
                  <span className="text-emerald-400 text-xs whitespace-nowrap">التاريخ</span>
                  <Input type="date" value={date} onChange={e => setDate(e.target.value)}
                    className="bg-transparent border-none text-white text-sm p-0 h-auto focus-visible:ring-0 flex-1" />
                </div>
              </div>

              {/* 2 — من حساب + من عملة | سعر الصرف | إلى حساب + إلى عملة */}
              <div className="rounded-xl border border-emerald-700/40 overflow-hidden" style={{background:"rgba(6,78,59,0.3)"}}>

                {/* من حساب + عملة */}
                <div className="grid grid-cols-2 gap-0 border-b border-emerald-700/30">
                  <div className="p-3 border-l border-emerald-700/30">
                    <p className="text-emerald-400 text-xs mb-1.5">من حساب</p>
                    <Select value={fromAccountId} onValueChange={setFromAccountId}>
                      <SelectTrigger className="bg-emerald-900/60 border-emerald-600/60 text-white h-9 text-xs">
                        {fromAccountId ? <span className="truncate">{fromAccount?.nameAr}</span> : <SelectValue placeholder="اختر الحساب..." />}
                      </SelectTrigger>
                      <SelectContent className="bg-emerald-900 border-emerald-700">
                        <div className="p-2"><Input value={fromAccountSearch} onChange={e => setFromAccountSearch(e.target.value)} placeholder="بحث..." className="bg-emerald-800 border-emerald-600 text-white h-7 text-xs" /></div>
                        {filtFromAcc.map(a => <SelectItem key={a.id} value={String(a.id)} className="text-white text-xs">{a.nameAr}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="p-3">
                    <p className="text-emerald-400 text-xs mb-1.5">من عملة</p>
                    <Select value={fromCurrencyId} onValueChange={handleFromCur}>
                      <SelectTrigger className="bg-emerald-900/60 border-emerald-600/60 text-white h-9 text-xs">
                        {fromCurrencyId
                          ? <span><span className="text-amber-300 font-bold">{fromCurrency?.code}</span> {fromCurrency?.nameAr}</span>
                          : <SelectValue placeholder="العملة..." />}
                      </SelectTrigger>
                      <SelectContent className="bg-emerald-900 border-emerald-700">
                        {(currencies as any[]).map((c: any) => (
                          <SelectItem key={c.id} value={String(c.id)} className="text-white text-xs">
                            <span className="text-amber-300 font-bold">{c.code}</span> — {c.nameAr}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {/* سعر الصرف في الوسط */}
                <div className="flex items-center gap-2 px-3 py-2 bg-amber-900/20 border-b border-emerald-700/30">
                  <ArrowLeftRight className="w-4 h-4 text-amber-400 shrink-0" />
                  <span className="text-amber-300 text-xs">سعر الصرف:</span>
                  <Input
                    type="number" step="0.0001" value={rate}
                    onChange={e => { setCustomRate(true); handleRate(parseFloat(e.target.value) || 0); }}
                    className="bg-amber-900/50 border-amber-600/60 text-amber-300 font-bold text-center h-8 flex-1 text-sm"
                  />
                  <span className="text-amber-300 text-xs whitespace-nowrap">
                    {fromCurrency?.code || "?"} ⇆ {toCurrency?.code || "?"}
                  </span>
                  {customRate && (
                    <button onClick={() => { setCustomRate(false); recalcRate(fromCurrencyId, toCurrencyId); }}
                      className="text-red-400 hover:text-red-300">
                      <RefreshCw className="w-3.5 h-3.5" />
                    </button>
                  )}
                  <button onClick={swap} className="text-amber-400 hover:text-amber-300">
                    <ArrowLeftRight className="w-4 h-4" />
                  </button>
                </div>

                {/* إلى حساب + عملة */}
                <div className="grid grid-cols-2 gap-0">
                  <div className="p-3 border-l border-emerald-700/30">
                    <p className="text-blue-400 text-xs mb-1.5">إلى حساب</p>
                    <Select value={toAccountId} onValueChange={setToAccountId}>
                      <SelectTrigger className="bg-blue-900/30 border-blue-600/40 text-white h-9 text-xs">
                        {toAccountId ? <span className="truncate">{toAccount?.nameAr}</span> : <SelectValue placeholder="اختر الحساب..." />}
                      </SelectTrigger>
                      <SelectContent className="bg-emerald-900 border-emerald-700">
                        <div className="p-2"><Input value={toAccountSearch} onChange={e => setToAccountSearch(e.target.value)} placeholder="بحث..." className="bg-emerald-800 border-emerald-600 text-white h-7 text-xs" /></div>
                        {filtToAcc.map(a => <SelectItem key={a.id} value={String(a.id)} className="text-white text-xs">{a.nameAr}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="p-3">
                    <p className="text-blue-400 text-xs mb-1.5">إلى عملة</p>
                    <Select value={toCurrencyId} onValueChange={handleToCur}>
                      <SelectTrigger className="bg-blue-900/30 border-blue-600/40 text-white h-9 text-xs">
                        {toCurrencyId
                          ? <span><span className="text-blue-300 font-bold">{toCurrency?.code}</span> {toCurrency?.nameAr}</span>
                          : <SelectValue placeholder="العملة..." />}
                      </SelectTrigger>
                      <SelectContent className="bg-emerald-900 border-emerald-700">
                        {(currencies as any[]).map((c: any) => (
                          <SelectItem key={c.id} value={String(c.id)} className="text-white text-xs">
                            <span className="text-blue-300 font-bold">{c.code}</span> — {c.nameAr}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </div>

              {/* 3 — المبلغ + الإجمالي بعد المصارفة */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label className="text-emerald-300 text-xs mb-1 block">
                    المبلغ {fromCurrency ? <span className="text-amber-400">({fromCurrency.code})</span> : ""}
                  </Label>
                  <Input
                    type="number" step="0.01" min="0"
                    value={fromAmount || ""}
                    onChange={e => handleFromAmt(parseFloat(e.target.value) || 0)}
                    className="bg-emerald-900 border-emerald-700 text-white h-12 text-xl font-black text-center"
                    placeholder="0.00"
                  />
                </div>
                <div>
                  <Label className="text-blue-300 text-xs mb-1 block">
                    الإجمالي {toCurrency ? <span className="text-blue-400">({toCurrency.code})</span> : ""}
                  </Label>
                  <Input
                    type="number" step="0.01" min="0"
                    value={toAmount || ""}
                    onChange={e => handleToAmt(parseFloat(e.target.value) || 0)}
                    className="bg-blue-900/30 border-blue-700/60 text-white h-12 text-xl font-black text-center"
                    placeholder="0.00"
                  />
                </div>
              </div>

              {/* صافي الربح/الخسارة للعملية الحالية */}
              {fromAmount > 0 && toAmount > 0 && fromCurrency && toCurrency && (
                <div className={`rounded-xl px-4 py-2.5 flex items-center justify-between border ${currentPL > 0 ? "bg-green-900/30 border-green-700/40" : currentPL < 0 ? "bg-red-900/30 border-red-700/40" : "bg-emerald-900/30 border-emerald-700/40"}`}>
                  <div className="flex items-center gap-1.5">
                    {currentPL > 0 ? <TrendingUp className="w-4 h-4 text-green-400" /> : currentPL < 0 ? <TrendingDown className="w-4 h-4 text-red-400" /> : null}
                    <span className={`text-sm font-bold ${currentPL > 0 ? "text-green-300" : currentPL < 0 ? "text-red-300" : "text-emerald-300"}`}>
                      {currentPL > 0 ? "ربح" : currentPL < 0 ? "خسارة" : "تعادل"}
                    </span>
                  </div>
                  <span className={`font-black text-lg ${currentPL > 0 ? "text-green-400" : currentPL < 0 ? "text-red-400" : "text-emerald-400"}`}>
                    {currentPL > 0 ? "+" : ""}{currentPL.toFixed(2)} ر.ي
                  </span>
                </div>
              )}

              {/* 4 — البيان + كاميرا + آلة حاسبة */}
              <div className="space-y-2">
                <div className="flex gap-2 items-start">
                  <div className="flex-1">
                    <Label className="text-emerald-300 text-xs mb-1 block">البيان / الملاحظات</Label>
                    <Input value={description} onChange={e => setDescription(e.target.value)}
                      className="bg-emerald-900 border-emerald-700 text-white h-10 text-sm"
                      placeholder="تفاصيل عملية المصارفة..." />
                  </div>
                  {/* كاميرا */}
                  <label className="cursor-pointer mt-5">
                    <div className={`h-10 w-11 rounded-xl border-2 border-dashed flex items-center justify-center transition-colors ${imagePreview ? "border-emerald-500 bg-emerald-800" : "border-emerald-700 hover:border-amber-400"}`}>
                      {imagePreview ? <img src={imagePreview} alt="" className="h-9 w-10 object-cover rounded-lg" /> : <Camera className="w-5 h-5 text-emerald-400" />}
                    </div>
                    <input ref={imgRef} type="file" accept="image/*" capture="environment" className="hidden"
                      onChange={e => { const f = e.target.files?.[0]; if (f) setImagePreview(URL.createObjectURL(f)); }} />
                  </label>
                </div>

                {/* آلة حاسبة */}
                <div className="flex items-center gap-2">
                  <button onClick={() => setShowCalc(v => !v)}
                    className={`flex items-center gap-1.5 text-xs px-3 py-1.5 rounded-xl border transition-colors ${showCalc ? "bg-amber-500 border-amber-400 text-white" : "bg-white/5 border-white/10 text-emerald-300 hover:border-amber-500/50"}`}>
                    🧮 آلة حاسبة
                  </button>
                  {imagePreview && (
                    <button onClick={() => setImagePreview(null)} className="text-red-400 text-xs hover:text-red-300">
                      × حذف الصورة
                    </button>
                  )}
                </div>
                {showCalc && (
                  <InlineCalc onResult={v => { handleFromAmt(v); setShowCalc(false); }} />
                )}
              </div>

              {/* 5 — أزرار الحفظ والإغلاق */}
              <div className="flex gap-2 pt-1">
                <Button onClick={handleSave}
                  className="flex-1 bg-amber-500 hover:bg-amber-400 text-white h-12 text-base font-bold gap-2">
                  <Save className="w-5 h-5" /> حفظ
                </Button>
                <Button variant="outline" onClick={() => setOpen(false)}
                  className="border-emerald-600 text-emerald-200 hover:bg-emerald-900 h-12 px-6">
                  <X className="w-4 h-4" />
                </Button>
              </div>

              {/* ملخص إجمالي المبالغ */}
              {(fromAmount > 0 || toAmount > 0) && (
                <div className="border-t border-emerald-700/30 pt-3 text-center space-y-1">
                  <p className="text-emerald-400 text-xs">مجموع المصارفة</p>
                  <div className="flex items-center justify-center gap-3">
                    <span className="text-white font-black text-xl">{fromAmount.toFixed(2)} <span className="text-amber-300 text-sm">{fromCurrency?.code || "—"}</span></span>
                    <ArrowLeftRight className="w-4 h-4 text-amber-400" />
                    <span className="text-white font-black text-xl">{toAmount.toFixed(2)} <span className="text-blue-300 text-sm">{toCurrency?.code || "—"}</span></span>
                  </div>
                </div>
              )}
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
