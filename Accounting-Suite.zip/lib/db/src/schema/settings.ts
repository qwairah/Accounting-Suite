import { pgTable, text, serial, integer, boolean, numeric } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const settingsTable = pgTable("settings", {
  id: serial("id").primaryKey(),
  companyName: text("company_name").notNull().default("قويرة سوفت"),
  companyNameEn: text("company_name_en").notNull().default("Qawera Soft"),
  address: text("address").notNull().default(""),
  phone: text("phone").notNull().default(""),
  taxNumber: text("tax_number").notNull().default(""),
  logoUrl: text("logo_url"),
  signatureUrl: text("signature_url"),
  printCopies: integer("print_copies").notNull().default(1),
  showLogo: boolean("show_logo").notNull().default(true),
  taxRate: numeric("tax_rate", { precision: 5, scale: 2 }).notNull().default("15"),
  baseCurrency: text("base_currency").notNull().default("SAR"),
  renewalDate: text("renewal_date"),
});

export const insertSettingsSchema = createInsertSchema(settingsTable).omit({ id: true });
export type InsertSettings = z.infer<typeof insertSettingsSchema>;
export type Settings = typeof settingsTable.$inferSelect;
