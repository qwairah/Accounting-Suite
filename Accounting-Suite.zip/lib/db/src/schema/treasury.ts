import { pgTable, text, serial, integer, boolean, numeric, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const treasuriesTable = pgTable("treasuries", {
  id: serial("id").primaryKey(),
  code: text("code").notNull().unique(),
  nameAr: text("name_ar").notNull(),
  isMain: boolean("is_main").notNull().default(false),
  balance: numeric("balance", { precision: 18, scale: 4 }).notNull().default("0"),
});

export const treasuryTransactionsTable = pgTable("treasury_transactions", {
  id: serial("id").primaryKey(),
  transactionNumber: text("transaction_number").notNull().unique(),
  type: text("type").notNull(),
  date: text("date").notNull(),
  accountId: integer("account_id"),
  accountNameAr: text("account_name_ar"),
  amount: numeric("amount", { precision: 18, scale: 4 }).notNull(),
  currencyId: integer("currency_id"),
  description: text("description"),
  treasuryId: integer("treasury_id").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertTreasurySchema = createInsertSchema(treasuriesTable).omit({ id: true });
export const insertTreasuryTransactionSchema = createInsertSchema(treasuryTransactionsTable).omit({ id: true, createdAt: true });
export type InsertTreasury = z.infer<typeof insertTreasurySchema>;
export type InsertTreasuryTransaction = z.infer<typeof insertTreasuryTransactionSchema>;
export type Treasury = typeof treasuriesTable.$inferSelect;
export type TreasuryTransaction = typeof treasuryTransactionsTable.$inferSelect;
