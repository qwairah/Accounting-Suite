import { pgTable, text, serial, numeric, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const itemsTable = pgTable("items", {
  id: serial("id").primaryKey(),
  code: text("code").notNull().unique(),
  nameAr: text("name_ar").notNull(),
  nameEn: text("name_en"),
  category: text("category"),
  unit: text("unit").notNull().default("قطعة"),
  costPrice: numeric("cost_price", { precision: 18, scale: 4 }).notNull().default("0"),
  salePrice: numeric("sale_price", { precision: 18, scale: 4 }).notNull().default("0"),
  stockQuantity: numeric("stock_quantity", { precision: 18, scale: 4 }).notNull().default("0"),
  minStock: numeric("min_stock", { precision: 18, scale: 4 }).notNull().default("0"),
  barcode: text("barcode"),
  taxRate: numeric("tax_rate", { precision: 5, scale: 2 }).notNull().default("0"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertItemSchema = createInsertSchema(itemsTable).omit({ id: true, createdAt: true });
export type InsertItem = z.infer<typeof insertItemSchema>;
export type Item = typeof itemsTable.$inferSelect;
