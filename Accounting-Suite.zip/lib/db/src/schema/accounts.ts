import { pgTable, text, serial, integer, boolean, numeric, timestamp, pgEnum } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const accountTypeEnum = pgEnum("account_type", [
  "assets",
  "liabilities",
  "equity",
  "revenue",
  "expenses",
]);

export const accountsTable = pgTable("accounts", {
  id: serial("id").primaryKey(),
  code: text("code").notNull().unique(),
  nameAr: text("name_ar").notNull(),
  nameEn: text("name_en"),
  type: text("type").notNull(),
  subType: text("sub_type"),
  subSubType: text("sub_sub_type"),
  parentId: integer("parent_id"),
  isMain: boolean("is_main").notNull().default(false),
  phone: text("phone"),
  address: text("address"),
  relatives: text("relatives"),
  whatsappNotify: boolean("whatsapp_notify").notNull().default(false),
  telegramNotify: boolean("telegram_notify").notNull().default(false),
  smsNotify: boolean("sms_notify").notNull().default(false),
  openingBalance: numeric("opening_balance", { precision: 18, scale: 4 }).notNull().default("0"),
  enableCeiling: boolean("enable_ceiling").notNull().default(false),
  ceiling: numeric("ceiling", { precision: 18, scale: 4 }).notNull().default("0"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertAccountSchema = createInsertSchema(accountsTable).omit({ id: true, createdAt: true });
export type InsertAccount = z.infer<typeof insertAccountSchema>;
export type Account = typeof accountsTable.$inferSelect;
