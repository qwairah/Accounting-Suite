import { pgTable, text, serial, boolean, numeric, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const customersTable = pgTable("customers", {
  id: serial("id").primaryKey(),
  code: text("code").notNull().unique(),
  nameAr: text("name_ar").notNull(),
  phone: text("phone"),
  address: text("address"),
  relatives: text("relatives"),
  whatsappNotify: boolean("whatsapp_notify").notNull().default(false),
  smsNotify: boolean("sms_notify").notNull().default(false),
  creditLimit: numeric("credit_limit", { precision: 18, scale: 4 }).notNull().default("0"),
  openingBalance: numeric("opening_balance", { precision: 18, scale: 4 }).notNull().default("0"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertCustomerSchema = createInsertSchema(customersTable).omit({ id: true, createdAt: true });
export type InsertCustomer = z.infer<typeof insertCustomerSchema>;
export type Customer = typeof customersTable.$inferSelect;
