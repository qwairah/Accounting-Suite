import { pgTable, text, serial, integer, boolean, numeric, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const warehousesTable = pgTable("warehouses", {
  id: serial("id").primaryKey(),
  code: text("code").notNull().unique(),
  nameAr: text("name_ar").notNull(),
  address: text("address"),
  isMain: boolean("is_main").notNull().default(false),
});

export const inventoryOperationsTable = pgTable("inventory_operations", {
  id: serial("id").primaryKey(),
  operationNumber: text("operation_number").notNull().unique(),
  type: text("type").notNull(),
  adjustType: text("adjust_type"),
  date: text("date").notNull(),
  warehouseId: integer("warehouse_id").notNull(),
  toWarehouseId: integer("to_warehouse_id"),
  items: jsonb("items").notNull().default("[]"),
  notes: text("notes"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertWarehouseSchema = createInsertSchema(warehousesTable).omit({ id: true });
export const insertInventoryOperationSchema = createInsertSchema(inventoryOperationsTable).omit({ id: true, createdAt: true });
export type InsertWarehouse = z.infer<typeof insertWarehouseSchema>;
export type InsertInventoryOperation = z.infer<typeof insertInventoryOperationSchema>;
export type Warehouse = typeof warehousesTable.$inferSelect;
export type InventoryOperation = typeof inventoryOperationsTable.$inferSelect;
