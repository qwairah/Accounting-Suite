import { pgTable, text, serial, integer, numeric, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const salesInvoicesTable = pgTable("sales_invoices", {
  id: serial("id").primaryKey(),
  invoiceNumber: text("invoice_number").notNull().unique(),
  customerId: integer("customer_id"),
  customerName: text("customer_name"),
  date: text("date").notNull(),
  dueDate: text("due_date"),
  status: text("status").notNull().default("posted"),
  items: jsonb("items").notNull().default("[]"),
  subtotal: numeric("subtotal", { precision: 18, scale: 4 }).notNull().default("0"),
  discount: numeric("discount", { precision: 18, scale: 4 }).notNull().default("0"),
  taxAmount: numeric("tax_amount", { precision: 18, scale: 4 }).notNull().default("0"),
  total: numeric("total", { precision: 18, scale: 4 }).notNull().default("0"),
  paidAmount: numeric("paid_amount", { precision: 18, scale: 4 }).notNull().default("0"),
  notes: text("notes"),
  currencyId: integer("currency_id"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const purchaseInvoicesTable = pgTable("purchase_invoices", {
  id: serial("id").primaryKey(),
  invoiceNumber: text("invoice_number").notNull().unique(),
  supplierId: integer("supplier_id"),
  supplierName: text("supplier_name"),
  date: text("date").notNull(),
  status: text("status").notNull().default("posted"),
  items: jsonb("items").notNull().default("[]"),
  subtotal: numeric("subtotal", { precision: 18, scale: 4 }).notNull().default("0"),
  discount: numeric("discount", { precision: 18, scale: 4 }).notNull().default("0"),
  taxAmount: numeric("tax_amount", { precision: 18, scale: 4 }).notNull().default("0"),
  total: numeric("total", { precision: 18, scale: 4 }).notNull().default("0"),
  paidAmount: numeric("paid_amount", { precision: 18, scale: 4 }).notNull().default("0"),
  notes: text("notes"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertSalesInvoiceSchema = createInsertSchema(salesInvoicesTable).omit({ id: true, createdAt: true });
export const insertPurchaseInvoiceSchema = createInsertSchema(purchaseInvoicesTable).omit({ id: true, createdAt: true });
export type InsertSalesInvoice = z.infer<typeof insertSalesInvoiceSchema>;
export type InsertPurchaseInvoice = z.infer<typeof insertPurchaseInvoiceSchema>;
export type SalesInvoice = typeof salesInvoicesTable.$inferSelect;
export type PurchaseInvoice = typeof purchaseInvoicesTable.$inferSelect;
