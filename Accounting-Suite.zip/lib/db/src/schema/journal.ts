import { pgTable, text, serial, numeric, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const journalEntriesTable = pgTable("journal_entries", {
  id: serial("id").primaryKey(),
  entryNumber: text("entry_number").notNull().unique(),
  date: text("date").notNull(),
  description: text("description").notNull(),
  lines: jsonb("lines").notNull().default("[]"),
  totalDebit: numeric("total_debit", { precision: 18, scale: 4 }).notNull().default("0"),
  totalCredit: numeric("total_credit", { precision: 18, scale: 4 }).notNull().default("0"),
  status: text("status").notNull().default("posted"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertJournalEntrySchema = createInsertSchema(journalEntriesTable).omit({ id: true, createdAt: true });
export type InsertJournalEntry = z.infer<typeof insertJournalEntrySchema>;
export type JournalEntry = typeof journalEntriesTable.$inferSelect;
